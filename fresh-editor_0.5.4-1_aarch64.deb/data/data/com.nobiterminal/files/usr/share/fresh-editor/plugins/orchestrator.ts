/// <reference path="./lib/fresh.d.ts" />
//
// Orchestrator — multi-agent / multi-worktree session orchestration.
//
// MVP scope (`docs/internal/orchestrator-sessions-design.md`):
//
//   - "Orchestrator: Open" opens a floating overlay prompt listing
//     every session with its state column. Up/Down navigates,
//     Enter dives into the selected session.
//   - "Orchestrator: New Session" opens a single floating widget
//     form with three optional fields (session name, agent
//     command, branch), allocates a worktree-rooted session and
//     spawns the agent in a terminal attached to it.
//   - "Orchestrator: Kill Selected" closes the session whose row is
//     currently highlighted in the open prompt.
//   - Agent state column updates from terminal_output regex and
//     terminal_exit code: RUNNING / AWAITING / READY / ERRORED.

import {
  activate,
  button,
  col,
  dropdown,
  flexSpacer,
  FloatingWidgetPanel,
  hintBar,
  divider,
  label,
  labeledSection,
  list,
  raw,
  row,
  endRow,
  overlay,
  radio,
  spacer,
  styledRow,
  text,
  textInputChar,
  toggle,
  tree,
  treeNode,
  windowEmbed,
  WidgetPanel,
  type WidgetSpec,
  type WidgetEvt,
} from "./lib/widgets.ts";
import { BIG_FILE_ARGS } from "./lib/git_repo.ts";
import {
  AGENT_REGISTRY,
  agentEntryForBase,
  namedSession,
  type AgentEntry,
  type AgentPromptArg,
} from "./lib/agent_registry.ts";
import { PathPicker, machinePicker, type BrowseEntry, type BrowseSource } from "./lib/pickers.ts";
import {
  DISCOVER_ALL_KEY,
  type DiscoverTarget,
  type DiscoveryHost,
  type FormSeed,
} from "./lib/discovery.ts";
import {
  liveBaseName,
  liveBranchName,
  liveSource,
  liveWhere,
  liveDetail,
  liveNormPath,
  livePlan,
  unrepresented,
  type LivePlan,
  type LiveSession,
} from "./lib/live_sessions.ts";

const editor = getEditor();

// =============================================================================
// Types
// =============================================================================

// A session's coarse activity, inferred from its agent terminal and never
// from the process — so "working" means "printing", and an agent that goes
// quiet to think reads as idle or blocked until it prints again. `blocked`
// (a question on screen) and `done` (unseen finished work) are heuristics
// over the output stream — see `sessionState` — good enough to drive the
// dock's attention line, never a guarantee. `idle` is a workspace with no
// agent terminal; `unknown` is one whose terminal has printed nothing yet,
// which is the difference `agent wait --until` turns on.
type AgentState = "working" | "blocked" | "done" | "idle" | "unknown";

// One row in the completion popup. `kind: "history"` items
// render with a leading `↶` marker + italic styling so the user
// can tell at-a-glance that the row came from their submission
// history rather than from the live completion source. Sent to
// the host via `formPanel.setCompletions`; the host renders the
// marker + style.
type CompletionItem = { value: string; kind?: "history" };

interface AgentSession {
  // Editor's stable session id.
  id: number;
  // Durable workspace identity (`ws-…`) reported by the host window.
  // Unlike `root` it distinguishes co-tenant workspaces sharing one
  // project root (e.g. a tab extracted to a new workspace), so manual
  // renames are keyed by it. Undefined for rows without a live window
  // (discovered worktrees, pending placeholders) and for legacy
  // workspace files that predate stable ids.
  stableId?: string;
  // Resolved display name shown in the dock / picker. Computed by
  // `workspaceDisplayName` from three sources, most-specific first: a
  // manual rename (`renameWorkspace`, persisted per workspace), else an
  // auto-name tracking the terminal's tab title (constant workspace
  // prefix + the terminal/process title), else `hostLabel`.
  label: string;
  // The raw label the host reports for this window (root basename for a
  // fresh session). The stable fallback when there's no manual rename and
  // no terminal to track — kept separate from `label` so the resolver can
  // recompute the display name without losing the host's own name.
  hostLabel: string;
  // Last-seen terminal tab title (combined foreground process + OSC title,
  // the same string shown on the terminal's tab). Drives the auto-name
  // when the workspace hasn't been manually renamed. `undefined` until the
  // session's terminal reports a non-default title.
  terminalTitle?: string;
  // Latest explicit OSC activity signal from the session's terminal (OSC
  // 133 command markers / OSC 9;4 progress): `true` = a command/task is
  // running, `false` = it has finished. When set, this is authoritative for
  // the working/idle indicator (see `sessionState`), so an agent that goes
  // quiet mid-command still reads "working" and a finished one flips to
  // idle at once. `undefined`/`null` ⇒ no signal, fall back to output
  // timing.
  oscRunning?: boolean | null;
  // Absolute filesystem root.
  root: string;
  // Canonical project root this session belongs to (set at
  // create time from the Project Path field). Equals `root`
  // for sessions without an explicit project — the host
  // normalises at the API boundary so plugins never have to
  // distinguish `null`/`undefined`/`""`.
  projectPath: string;
  // `true` if the session was created with the worktree
  // checkbox unchecked (shared worktree / non-git path).
  sharedWorktree: boolean;
  // The terminal id Orchestrator spawned in this session, if any.
  terminalId: number | null;
  // Coarse activity, recomputed from `lastOutputAt` at render time
  // (see `sessionState`). Not authoritative on its own — the timestamp
  // is. ("active" — the focused window — is computed separately from
  // `editor.activeWindow()`.)
  state: AgentState;
  // Wall-clock ms of the most recent terminal_output for this session,
  // or null if it has never produced output (or has no terminal). This
  // is the real signal; `state` is just `Date.now() - lastOutputAt`
  // bucketed against IDLE_AFTER_MS.
  lastOutputAt: number | null;
  // The last few non-blank lines the agent terminal printed, oldest
  // first (capped at RECENT_LINES). `sessionState` matches these against
  // BLOCKED_PATTERNS to tell a "waiting on you" prompt from plain idle.
  recentLines?: string[];
  // `true` once the agent has produced a sustained burst of output
  // (≥ WORK_MIN_MS) while its window was NOT the active one — i.e.
  // there is something the user hasn't seen yet. Cleared on activation.
  workedSinceSeen?: boolean;
  // Start of the current output burst (ms), for the WORK_MIN_MS check.
  burstStartAt?: number;
  // The state `sweepAttention` last saw for this session, so a change
  // into blocked/done is announced exactly once per transition.
  notifiedState?: AgentState;
  // The question line behind the last "needs you" notice for this session.
  // A blocked state that wobbles (an activation redraw reads as a short
  // "working") comes back with the same question and is not announced
  // again; a new question is a new line, and is.
  announcedPrompt?: string;
  // Wall-clock ms when orchestrator.new fired createWindow.
  createdAt: number;
  // `true` when this row is a worktree discovered on disk (via
  // `git worktree list`) that has no live editor window yet.
  // Discovered rows carry a synthetic negative `id`, no
  // `terminalId`, and dive by *attaching* a new session to
  // `root` rather than switching to an existing window. They are
  // dropped from `orchestratorSessions` the moment a real window
  // is opened at the same `root`.
  discovered?: boolean;
  // Branch checked out in this worktree (best-effort, for
  // display). Set for discovered rows; left undefined for live
  // sessions where the tab/label already carries the identity.
  branch?: string;
  // Opportunistically-gathered GitHub PR summary for this session's
  // branch (via `gh`), shown on the pill's third line. `undefined`
  // until first probed; see `PrProbe` for the lifecycle.
  pr?: PrProbe;
  // Opportunistically-gathered local git summary (ahead/behind +
  // working-tree diffstat) for the pill's second line — useful even
  // before there's a PR. Same lifecycle as `pr`.
  git?: GitProbe;
  // Wall-clock ms when this session last became the active window. Used
  // to suppress the terminal's activation redraw from registering as
  // agent activity (so selecting a session doesn't flash it `working`).
  activatedAt?: number;
  // Optional remote/cloud facet — present only for sessions whose backend is
  // not local (ssh / kubernetes / devcontainer). Drives the extra state glyph
  // + label in the picker/dock; absent for local sessions, which render
  // exactly as before (the design's "backend-opaque" facet — see
  // K8S_WORKSPACE_UX_DESIGN.md §"Orchestrator integration").
  remote?: {
    kind: SessionBackend;
    // Short human identity for the row (e.g. `deploy@build-01`, `ns/pod`).
    detail: string;
    state: "starting" | "running" | "stopped" | "error";
  };
  // Present while this workspace is still being built (the non-blocking
  // New-Workspace flow — see `startPendingWorkspace`). A LOCAL create owns
  // a real window from the moment it is asked for, so the row is a full
  // workspace throughout — switchable, renameable, filable, closable — and
  // `pending` only says that its *contents* are still on their way (the
  // window renders the host's "being created" page instead of a buffer).
  // A remote create has no window until its connect resolves, so its row is
  // still a synthetic placeholder (negative `id`, `terminalId` null). Either
  // way, success clears `pending` and failure flips `phase` to `"error"`,
  // leaving retry / dismiss on the row.
  pending?: PendingCreate;
  // Overrides the root as this row's dock-order key (see `stableOrderKey`).
  // Set on a workspace born as a placeholder: its root changes underneath
  // it when the worktree it was standing in for is finally created, and
  // without a fixed key the row would jump to the bottom of the dock at
  // exactly the moment it came alive.
  orderKey?: string;
}

// A workspace-create request captured off the (now-closing) New-Workspace
// form so the background worker — and any later retry — never has to read
// form state that no longer exists. One variant per submit path.
type RemoteFacet = NonNullable<AgentSession["remote"]>;
type CreateSpec =
  | {
      backend: "local";
      // Directory the session roots at (typed value or resolved default).
      projectPath: string;
      // Explicit workspace name; "" ⇒ auto-generate at create time.
      name: string;
      // Agent command; "" ⇒ a bare terminal.
      cmd: string;
      // Enable the agent's auto/reduced-approval mode (adds the agent's
      // documented flag, e.g. `claude --permission-mode auto`). Only honoured
      // for a command that resolves to a known agent with an `auto` flag;
      // ignored for a bare terminal / unknown command.
      auto: boolean;
      // Initial prompt to hand the agent at launch (positional or via the
      // agent's prompt flag). "" ⇒ no prompt. Only applied to a resolved agent
      // that documents a prompt argument; never replayed on resume.
      startPrompt: string;
      // Inject the Fresh CLI system prompt + mint a capability token so the
      // agent can drive the editor from the shell. Only honoured for a command
      // that resolves to an agent with a `systemPrompt` strategy.
      teachFreshCli: boolean;
      // "Checkout branch": an existing branch/ref to check out (worktree) or
      // switch to (in-place). "" ⇒ the detected default branch (worktree only).
      branch: string;
      // "New branch name": when set, create the worktree on a freshly-cut
      // branch off the checkout branch (or default). "" ⇒ no new branch.
      // Ignored in the non-worktree (in-place checkout) path.
      newBranch: string;
      // Create a fresh worktree (only honoured when the path is a git tree).
      createWorktree: boolean;
      // Row label + project shown on the pending dock row.
      displayLabel: string;
      displayProject: string;
    }
  | {
      backend: "ssh" | "kubernetes";
      // The host payload handed to `attachRemoteAgent`.
      spec: RemoteAgentSpec;
      // Facet stamped on both the born window and the pending placeholder.
      facet: RemoteFacet;
      displayLabel: string;
      displayProject: string;
      // The command to persist as `orchestrator.last_cmd` on success (ssh
      // remembers it), or "" to persist nothing.
      persistCmd: string;
      // When set, `git worktree add` runs on the remote host before the
      // attach and the session roots at what it creates, instead of at the
      // transport's `remote_path`. Carried on the spec rather than resolved
      // at submit so a retry — or a row restored after a restart — re-runs
      // the same create rather than a different one.
      remoteWorktree?: RemoteWorktreePlan;
    };

interface RemoteWorktreePlan {
  // ssh argv up to and including the destination; a remote command is
  // appended to it.
  ssh: string[];
  // A path inside the repository, as the user typed it. The repository root
  // and the remote's `$HOME` are both resolved on the far side: this side
  // knows neither the remote's `$HOME` nor its repo layout, and a guess at
  // either is a path that works for one user and silently not for another.
  path: string;
  // Worktree directory name under `~/.fresh/worktrees/<repo>/`.
  name: string;
  // Existing ref to fork from; "" = whatever the remote has checked out.
  base: string;
  // New branch to cut; "" = check `base` out instead.
  newBranch: string;
}

interface PendingCreate {
  // `"creating"` while the background create/connect runs; `"error"` once it
  // has failed; `"paused"` for a row restored from a previous session that
  // hasn't been resumed yet. Both `error` and `paused` offer retry / dismiss.
  phase: "creating" | "error" | "paused";
  // Human status shown on the row while creating, or the failure reason
  // when `phase === "error"`.
  message: string;
  // Everything the worker needs to (re-)run the create.
  spec: CreateSpec;
  // `true` when the user chose "Create & Visit": once the workspace is real,
  // focus follows into it (dive) instead of staying put. `false` for "Create
  // in Background" (and for restored/resumed rows — a relaunch never yanks
  // focus). Either way the create itself is non-blocking.
  visit: boolean;
  // The placeholder window's seed buffer, which this workspace's page is
  // drawn into (see `renderPlaceholderPage`). Absent only for a row whose
  // window is gone.
  bufferId?: number;
}

// Local git summary + freshness bookkeeping (mirrors `PrProbe`).
interface GitProbe {
  status: "loading" | "ok";
  fetchedAt: number;
  info?: GitStat;
}

// Compact working-tree + branch-position summary, from
// `git status --porcelain=v2 --branch` and `git diff --shortstat HEAD`.
interface GitStat {
  branch?: string;
  // Commits ahead / behind the upstream (or base), when an upstream
  // is configured.
  ahead?: number;
  behind?: number;
  // Count of dirty paths (staged + unstaged + untracked).
  dirty?: number;
  // Uncommitted line churn vs HEAD.
  added?: number;
  deleted?: number;
}

// PR info gathered for a session, plus the freshness bookkeeping that
// keeps the probe opportunistic (never blocks a render, refreshes on a
// slow cadence). `status` distinguishes "haven't looked", "looking",
// "looked, no PR / gh unavailable", and "have a PR".
interface PrProbe {
  status: "loading" | "none" | "ok";
  // Wall-clock ms of the last completed probe (success or "none"),
  // used to throttle re-probes.
  fetchedAt: number;
  info?: PrInfo;
}

// The subset of `gh pr view --json …` we surface. All optional so a
// partial/older `gh` still renders what it can.
interface PrInfo {
  number: number;
  // "OPEN" | "MERGED" | "CLOSED".
  state?: string;
  isDraft?: boolean;
  // "APPROVED" | "CHANGES_REQUESTED" | "REVIEW_REQUIRED" | "".
  reviewDecision?: string;
  // gh's MERGEABLE / CONFLICTING / UNKNOWN.
  mergeable?: string;
  // Rolled-up CI: counts derived from statusCheckRollup.
  checksPass?: number;
  checksFail?: number;
  checksPending?: number;
  // Count of (review) comments.
  comments?: number;
}

// =============================================================================
// Module state — editor-global, survives every dive.
// =============================================================================

const orchestratorSessions = new Map<number, AgentSession>();

// Permanent display slot for each session, keyed by its canonical root
// (NOT its id — a discovered worktree keeps its slot when it opens and its
// negative id is swapped for a live window id). The dock orders rows by
// this slot ALONE, so the list never reshuffles: a row's position is fixed
// the first time its root is seen and never depends on the session's label,
// project, activity state, or which window is currently active. New roots
// append at the bottom. See `stableOrderKey` / the dock branch of
// `filterSessions`.
const rootDisplayOrder = new Map<string, number>();
let nextRootDisplayOrder = 0;
function stableOrderKey(s: AgentSession): number {
  const key = s.orderKey ?? normRoot(s.root);
  let order = rootDisplayOrder.get(key);
  if (order === undefined) {
    order = nextRootDisplayOrder++;
    rootDisplayOrder.set(key, order);
  }
  return order;
}

// Facet to stamp onto the next born-attached remote window when it surfaces in
// `reconcileSessions` (via the core `window_created` hook). Set just before
// `attachRemoteAgent({ window: true })`, consumed by the first new live window.
let pendingRemoteFacet: AgentSession["remote"] | null = null;

// Stable synthetic ids for discovered (on-disk, not-yet-opened)
// worktrees, keyed by canonical path. Live windows own the
// positive id space (editor `WindowId`s); discovered rows take
// negative ids so the two never collide and the existing
// `orchestratorSessions.get(id)` call sites keep working. Ids
// stay stable across rescans so the dialog selection doesn't
// jump when the worktree set is refreshed. `-1` is reserved as a
// "no selection" sentinel elsewhere, so allocation starts at `-2`.
const discoveredIdByPath = new Map<string, number>();
let nextDiscoveredId = -2;
function discoveredIdFor(path: string): number {
  let id = discoveredIdByPath.get(path);
  if (id === undefined) {
    id = nextDiscoveredId--;
    discoveredIdByPath.set(path, id);
  }
  return id;
}

// Only one remote attach may be in flight at a time. The host's
// `cancelRemoteAgent()` cancels *every* in-flight connect, so
// backgrounding two concurrent remote creates would let cancelling one
// tear down the other. Remote pending rows therefore run one at a time:
// `remoteAttachBusy` gates the in-flight connect and `remoteCreateQueue`
// holds the pending ids waiting their turn. Local creates have no such
// constraint and run immediately, in parallel.
let remoteAttachBusy = false;
const remoteCreateQueue: number[] = [];
// The pending id whose remote connect is currently in flight (null when
// none). Dismissing exactly this row must tear the connect down via
// `cancelRemoteAgent`; a queued row hasn't started one.
let remoteInFlightId: number | null = null;

// New-session form state. `null` ⇒ the floating form isn't
// open. Each field's `value` + `cursor` mirrors what the host
// renders inside the panel's TextInput widgets; the `submitting`
// flag debounces double-Enter on the Create button; `lastError`
// is rendered as a styled error row inside the form when the
// most recent submit failed (status bar would get clobbered —
// see MEMORY.md).
// Where a new session runs. `local` is today's worktree/folder flow; the
// other three sit behind the `Authority` seam (SSH remote host, a Kubernetes
// pod via `kubectl exec`, or a devcontainer). The New Session dialog shows a
// "Run in:" tab row so the user picks one and the body swaps to its fields.
type SessionBackend = "local" | "ssh" | "kubernetes" | "devcontainer";
// Where the New Workspace form can put a session. A devcontainer is a
// property of a project rather than of where a machine is, so it is its own
// group in the Machine control rather than one of the hosts (design §5.1).
type FormBackend = "local" | "ssh" | "kubernetes" | "devcontainer";

interface NewSessionForm {
  // Where the agent lands: a terminal in the CURRENT workspace, or a brand-new
  // one. This is the dialog's top-level mode switch — "current" hides every
  // workspace-creation control (backend tabs, Project Path, Workspace Name,
  // the Advanced fold), leaving just "which agent, with what options", which
  // is the whole of the old separate Run-Agent dialog. "new" reveals them all.
  //
  // Both entry points open *this* form; they differ only in what they default
  // this field to (Run Agent → "current", New Workspace → "new"). Keeping one
  // form is what stops the two launch paths drifting apart — they used to be
  // separate dialogs with separate submit functions, and the current-workspace
  // one silently dropped the agent-resume argv.
  target: RunAgentTarget;
  // The `▸ Details` fold: shows the workspace name and the GIT section.
  // Remembered across opens (`orchestrator.launch_details_open`).
  detailsOpen: boolean;
  // The Project control: a repository's id, or null for `Folder…`.
  repoId: string | null;
  // A local git folder's `origin`, read by the folder probe, so the form can
  // say when the folder is a clone of a known repository.
  folderOrigin: string;
  // Launch found the project isn't on this machine yet and asks where it is
  // (§4.17); `visit` is the launch to resume once answered.
  place: (PlaceAsk & { visit: boolean }) | null;
  // Which backend the session runs in, as the Machine control set it: drives
  // the connection fields and the submit path. Only meaningful when
  // `target === "new"`.
  backend: FormBackend;
  // The saved machine chosen in the Machine control (design §5.1), or null
  // for Local and the devcontainer. A remote workspace only ever runs on a
  // saved machine: the Machines dialog is where one is added.
  // `machinePick` indexes `machineOptions()`.
  machineId: string | null;
  machinePick: number;
  // Where on the saved machine the workspace is rooted (blank = the
  // machine's default path), for an ssh and a Kubernetes machine.
  sshPath: { value: string; cursor: number };
  k8sWorkspace: { value: string; cursor: number };
  // Project Path: the directory the session is rooted at. When
  // `createWorktree` is true (default for git paths) this is
  // the *base* repo for `git worktree add`. When false, this
  // is the session root itself (no git interaction).
  projectPath: { value: string; cursor: number };
  name: { value: string; cursor: number };
  cmd: { value: string; cursor: number };
  // Initial prompt handed to a supporting agent at launch (a single-line box,
  // shown only for the local backend where agent launch is wired). Ignored for
  // a bare terminal / an agent with no prompt argument.
  startPrompt: { value: string; cursor: number };
  // "Auto mode" toggle — adds the resolved agent's auto/reduced-approval flag
  // to the launch (and resume) argv. Only meaningful for an agent that
  // documents such a flag; the checkbox is hidden otherwise.
  autoMode: boolean;
  // "Teach Fresh CLI" toggle — injects a system prompt teaching the agent the
  // `fresh` CLI and mints a capability token so it can drive the editor. Only
  // meaningful for an agent with a `systemPrompt` injection strategy; the
  // checkbox is hidden otherwise.
  teachFreshCli: boolean;
  branch: { value: string; cursor: number };
  // "New branch name" field (Advanced): when set, the new worktree is
  // created on a freshly-cut branch (`git worktree add -b <newBranch>`).
  // Empty ⇒ use the "Checkout branch" value (or the default) instead.
  newBranch: { value: string; cursor: number };
  // The agent selector is on `custom…`: picked from the dropdown, or
  // implied by a command no preset spells. Reveals the command field —
  // and keeps it revealed while the user types a command that happens to
  // spell a preset, so the field they are typing in does not vanish.
  agentCustom: boolean;
  // No agent chosen yet: a first launch, with no last-used agent to fall
  // back on. The selector shows `Choose an agent…` and nothing launches
  // until one is picked — the terminal is a choice, not a silent default.
  agentUnset: boolean;
  // The name the created workspace takes on the dock when it is not the
  // name field's (a session imported with a worktree: the field names the
  // worktree and branch, so it holds a slug of this). Undefined: the field's.
  // Only while the field still reads `prefillName`: a name typed over the
  // proposed one is the user's, for the workspace as for its worktree.
  displayName?: string;
  // The name field's value as a prefill proposed it (an imported session's
  // name), so a submit can tell it from one the user typed.
  prefillName?: string;
  // The Claude cloud session the created workspace is a teleported copy of,
  // remembered so the session's external session row can say where the copy went.
  teleportOf?: string;
  // Whether to create a new git worktree under
  // `<XDG>/orchestrator/<slug>/<session>/` (true) or run the
  // session directly inside `projectPath` (false). Enabled
  // only when the resolved `projectPath` is inside a git
  // working tree (`projectPathIsGit === true`). Forced to
  // false on non-git paths and the checkbox is disabled.
  createWorktree: boolean;
  // The remote counterpart of `projectPathIsGit` and friends, kept separate
  // because the local probes run against `projectPath` on this filesystem
  // and these run against `sshPath` on another one. `null` = not yet known,
  // which is the state the toggle must not read as "no".
  remoteIsGit: boolean | null;
  remoteRepoRoot: string;
  remoteDefaultBranch: string;
  // Set when the host could not be reached at all, so the form can say "cannot
  // tell from here" rather than "not a git repository" — a difference the
  // user can act on.
  remoteProbeError: string;
  // `true` while a remote probe is in flight, so the row can say so instead
  // of looking like a settled answer.
  remoteProbing: boolean;
  remoteProbeToken: number;
  submitting: boolean;
  lastError: string | null;
  // Resolved canonical project root from the editor's cwd —
  // surfaced as the Project Path placeholder. Empty while the
  // async probe runs at `openForm` time.
  defaultProjectPath: string;
  // `true`: resolved Project Path is inside a git working
  // tree (worktree checkbox enabled). `false`: non-git path
  // (checkbox disabled, branch field inert). `null`: probe
  // in flight (keep checkbox in its last-known state).
  projectPathIsGit: boolean | null;
  // `true` when the resolved Project Path is itself an existing
  // *linked* worktree (created by `git worktree add`). In that
  // case leaving "Create a new git worktree" unchecked attaches
  // the session to it as a managed worktree rather than treating
  // it as a shared root. The probe defaults the checkbox to
  // unchecked when it first detects this, and `buildFormSpec`
  // surfaces an explanatory hint. `null` while the probe runs.
  projectPathIsLinkedWorktree: boolean | null;
  // Concrete session name the auto-generator would produce
  // for the current Project Path (e.g. "session-3"). Surfaced
  // as the Session Name placeholder so the user sees the
  // exact name an empty submit would create. Empty while the
  // refs probe runs.
  defaultSessionName: string;
  // Resolved default branch (e.g. "origin/main"). Empty while
  // the async `git fetch + symbolic-ref` probe is in flight;
  // the branch input's placeholder reads this so the user sees
  // the exact base ref the worktree will fork off if they
  // leave the field blank.
  defaultBranch: string;
  // True when the default branch fell through to bare `HEAD`
  // because no `origin` is configured. Surfaced in the
  // placeholder as `HEAD  (no origin configured)` so the user
  // knows why.
  defaultBranchIsHeadFallback: boolean;
  // True when this form was opened from the picker (Alt+N or
  // the "+ New Session" button). On cancel (Esc / Cancel
  // button) we re-open the picker so the user lands back where
  // they were instead of being dropped into the bare editor.
  fromPicker: boolean;
  // Token incremented every time the user changes the Project
  // Path field. Async probes (is-git, session-name, default-
  // branch) capture the token at launch and bail on result if
  // a newer token has been issued — prevents stale probes from
  // overwriting fresh state on rapid typing.
  probeToken: number;
  // Per-field input-history cursor. -1 = "not in history"
  // (showing the user's current draft). 0 = most recent, 1 =
  // older, etc. (Now only consulted by the host-side `↶`
  // history rows mixed into the completion popup — Up/Down on a
  // history-bearing field reopens the popup, where historical
  // entries appear after live completion candidates.)
  historyCursor: { project_path: number; name: number; cmd: number; branch: number };
  // Saved draft text per field: when the user first presses Up
  // we squirrel away whatever was in `value` so Down can
  // restore it.
  historyDraft: { project_path: string; name: string; cmd: string; branch: string };
  // Inline-dropdown completion state. `field` names which input
  // the suggestion list belongs to; the list is only rendered
  // while that input is focused. `items` is the post-filter set
  // (already in display order); `selectedIndex` is the
  // highlighted row. `anchor` is the value the user had typed
  // when the candidates were last fetched — used to ignore
  // stale async results that land after the user keeps typing.
  // `token` mirrors the project-path probe pattern: every fresh
  // fetch bumps it; results bail if they're not the latest.
  completion: {
    field: "project_path" | "branch" | null;
    items: CompletionItem[];
    selectedIndex: number;
    anchor: string;
    token: number;
  };
}
let form: NewSessionForm | null = null;
let formPanel: FloatingWidgetPanel | null = null;

// Where a launch lands: a terminal in the CURRENT workspace, or a fresh
// worktree + window. The New-Workspace form's top-level switch (see
// `NewSessionForm.target`); "Run Agent…" is that same form opened on
// "current".
type RunAgentTarget = "current" | "new";

const NEW_SESSION_MODE = "orchestrator-new-form";
// The dock's own keymap: the mode its panel is mounted with, whose bindings
// the host resolves on the dock's node ahead of the focused widget. Bound
// here rather than through the window's editor mode, which is the buffer's.
const DOCK_MODE = "orchestrator-dock";
// The dock's project scope dropdown, by widget key. It is a `list`, so ↑/↓
// and Enter are the list's own and the plugin hears `select` and `activate`;
// Esc is the dock mode's, and closes it.
const PROJECT_MENU_KEY = "project-pick";

// Every orchestrator keymap rides on the panel it belongs to (the `mount`
// option `mode`), never on the window's editor mode: that is one slot per
// window, shared with every plugin, and a dialog that borrowed it had nothing
// to hand back on close, so clearing it wiped whatever lived there — vi's
// mode, before vi moved to the editor-wide input mode (issues #3305, #3395). The dock's menus bind nothing, so they mount
// without a mode: the keys their focused control leaves go to the panel's own
// defaults, never to the window's mode.

// The "New Folder" dialog — a small centered floating panel with a name
// field, an "organize the current session under it" checkbox, and
// Cancel / Create Folder buttons. Replaces the old bottom-of-screen
// minibuffer prompt (and works identically in the web UI, which renders
// the same WidgetSpec). Enter submits (via a one-binding editor mode);
// Esc / Cancel dismiss.
const CREATE_FOLDER_MODE = "orchestrator-folder-dialog";
interface CreateFolderDialogState {
  // The name field: mirror of the host TextInput's value + cursor byte.
  name: { value: string; cursor: number };
  // Checkbox: file `sessionId` under the new folder on create. Default
  // true. Only shown when `sessionId` resolves to a live session.
  organizeCurrent: boolean;
  // Parent folder for the new folder (null = top level; a folder id for
  // the "New Subfolder…" path).
  parent: string | null;
  // The session the checkbox organizes — the active window for the
  // toolbar / subfolder paths, or the explicitly-moved session for the
  // "Move to → New folder…" path. null ⇒ no session to organize.
  sessionId: number | null;
  // Rename mode: the id of an existing folder this dialog renames
  // instead of creating a new one (title/button change, the organize
  // checkbox is dropped, and submit renames). Sharing the dialog keeps
  // create and rename the same UX rather than bouncing rename through
  // the bottom minibuffer prompt. null ⇒ create mode.
  renameId: string | null;
  // Workspace-rename mode: the session id this dialog renames. Mutually
  // exclusive with `renameId` (a folder rename). When set, the dialog
  // prompts for a workspace name and submit pins a manual name on the
  // session's root. null ⇒ not a workspace rename.
  renameSessionId: number | null;
  // An external session row (by `LiveSession.key`) the checkbox organizes instead
  // of a workspace: it is opened as a workspace, filed under the new
  // folder, only once the folder is created — asked first, so the dialog
  // is never raced by whatever opening the workspace brings up (the trust
  // prompt for a folder seen for the first time). null ⇒ none.
  liveKey: string | null;
}
let createFolderDialog: CreateFolderDialogState | null = null;
let createFolderPanel: FloatingWidgetPanel | null = null;

// ---------------------------------------------------------------------
// "Run Agent…" dialog — a lightweight picker to launch one of the
// starting processes the New-Workspace dialogue offers (a bare terminal
// or a registered agent) from an existing session, WITHOUT the full
// workspace-creation form. The user picks the process, whether it runs
// in the current window or a fresh worktree+window, auto mode, and an
// optional first prompt; the choice is remembered for next time. Both
// targets reuse the dialogue's launch logic (session-id pin, auto flags,
// Fresh-CLI system-prompt injection, capability token) so a
// palette-launched agent is indistinguishable from a dialogue-launched
// one.
// ---------------------------------------------------------------------

// Open dialog state. `null` ⇒ the picker isn't mounted. Lives
// alongside the new-session form state but is independent of
// it — the two dialogs share the orchestrator mode plumbing but
// not their data.
interface OpenDialogState {
  // Filter input value + cursor byte. Mirrors what the host
  // renders inside the panel's filter TextInput.
  filter: { value: string; cursor: number };
  // Subset of `orchestratorSessions` keys that pass the filter,
  // in display order. Recomputed on every filter change.
  filteredIds: number[];
  // The selection inside the list widget. The host owns the
  // authoritative copy as instance state; this mirror lets
  // `buildOpenSpec` render the matching preview pane without a
  // round-trip.
  selectedIndex: number;
  // Active session at the moment the dialog opened. Recorded
  // so a future "Esc restores active" affordance has the
  // anchor it needs.
  originalActiveSession: number;
  // When non-null, the preview pane swaps to a confirmation
  // panel for the named action against the listed session ids.
  // A single-element `ids` is the per-row Stop/Archive/Delete
  // path; a multi-element `ids` is a bulk action over the
  // checkbox selection. Cleared on Cancel or after the action
  // completes.
  pendingConfirm:
    | { action: "stop" | "archive" | "delete"; ids: number[] }
    | null;
  // Rows the user has checkbox-selected (Space, or click) for a
  // bulk Stop/Archive/Delete. Holds session ids — positive for
  // live windows, negative for discovered on-disk worktrees
  // (which bulk-delete via `git worktree remove`). Survives filter
  // and scope changes; pruned against the live set on every
  // refresh. Bulk mode (the dedicated selection bar) engages once
  // two or more rows are checked.
  selectedIds: Set<number>;
  // `true` shows the discovered on-disk worktree rows in the list.
  // The "Show all worktrees" checkbox below the scope control toggles
  // it (Alt+T / `orchestrator_toggle_worktrees`). Defaults to false
  // (worktrees hidden) — discovery is opt-in. Remembered across opens
  // via `lastShowWorktrees`.
  showWorktrees: boolean;
  // `true` hides "trivial" sessions — those with no terminal and at
  // most one open file/buffer (empty-unnamed-buffer and single-file
  // shells left behind by one-off editor launches). The "Show
  // empty/1-file sessions" checkbox (Alt+I / `orchestrator_toggle_trivial`)
  // flips it. Defaults to true; remembered across opens via
  // `lastHideTrivial`. The active session and discovered worktree rows
  // are never hidden by this filter regardless of the flag.
  hideTrivial: boolean;
  // Progress marker for an in-flight *bulk* action. While set, the
  // selection bar shows "Archiving 2/3…" and its buttons are
  // hidden so a second Enter can't re-fire mid-batch. Cleared when
  // the batch finishes.
  bulkInFlight:
    | { action: "stop" | "archive" | "delete"; total: number; done: number }
    | null;
  // Rows the embed reserves and rows the sessions list shows.
  // Captured once at dialog-open from the editor's viewport so
  // the layout stays constant across re-renders — recomputing
  // mid-dialog would let the size jitter when the active
  // window's viewport changes (e.g. terminal buffer's shorter
  // height vs. a file buffer's).
  listVisibleRows: number;
  embedRows: number;
  // Dock-only: the screen row where the session tree starts (the rows
  // of chrome above it — title, toolbar, filters, divider). Captured in
  // `buildDockSpec` so keyboard-opened context menus can anchor near
  // the highlighted node without re-deriving the chrome layout.
  dockTreeTop: number;
  // Toggle between "compact preview" (default — buttons + live
  // embed only, no info row) and "details" (state + path metadata
  // row visible above the embed). Compact is the default because
  // the embed is the part the user actually wants to see; the
  // metadata row is rarely read and just eats embed height.
  showDetails: boolean;
  // The session id whose lifecycle action (archive / delete) is
  // currently running. While set:
  //   - that session's preview pane swaps to an "Archiving…" /
  //     "Deleting…" panel with no action buttons, so the user
  //     sees the operation is in flight rather than wondering
  //     why their click took no effect.
  //   - the user can still navigate to other sessions and act on
  //     them; only the in-flight session is disabled.
  // Cleared by the async handler on success or failure. The row
  // disappears from the list naturally once the editor's
  // `window_closed` hook fires `refreshOpenDialog`.
  inFlight: { action: "archive" | "delete"; sessionId: number } | null;
  // Last user-visible error from a refused lifecycle action
  // (e.g. "cannot archive the base session", "dive elsewhere
  // first…"). Rendered as a banner row above the filter so it's
  // hard to miss — the status bar at the bottom of the screen is
  // too easy to skip over when the user's eyes are on the dialog.
  // Cleared on the next nav / filter change.
  lastError: string | null;
  // Which sessions the list foregrounds:
  //   - "current": only sessions belonging to the active window's
  //     project (the default — launching in project B shouldn't
  //     bury you under project A's sessions). A trailing affordance
  //     row advertises how many sessions live in other projects.
  //   - "all": every session, across every project, each row
  //     labeled with its project so cross-project rows are obvious.
  // Toggled with the scope key (⌥P by default). The filter input
  // always searches globally regardless of scope, so typing a name
  // from another project still surfaces it.
  scope: "current" | "all";
  // Dock-only project filter. `null` shows every project's sessions
  // (the default); a project key restricts the dock list to that one
  // project. Driven by the dock toolbar's project dropdown (which
  // lists every project that has a session in the worktree/trivial-
  // filtered set). Independent of `scope`, which governs the modal
  // picker; the dock uses this instead.
  projectFilter: string | null;
  // `true` while the dock project dropdown overlay is open.
  projectMenuOpen: boolean;
  // Keyboard cursor (highlighted row) within the open project
  // dropdown, indexing `projectMenuKeys()` (0 = "All projects").
  // Distinct from `projectFilter`, which is the *applied* scope shown
  // with a `●`; this is just where ↑/↓ currently sit before Enter
  // commits. Only meaningful while `projectMenuOpen`.
  projectMenuIndex: number;
  // Dock-only: the search row is open. `/` (or the header's `/ search`)
  // opens it; Esc on an empty field, or leaving the dock, closes it. A
  // non-empty filter keeps the row on screen regardless — the row says
  // what the list is filtered by, so it cannot go while a filter applies.
  searchOpen: boolean;
  // Dock-only: the header's Menu while it is open (a panel of its own,
  // `mainMenuPanel`), or null. The dock mode's Esc closes it.
  dockMenu: DockDropdown | null;
  // Dock-only: the item key (`folder:<id>` / `session:<id>`) of the
  // currently-highlighted tree node. The tree is host-owned; this mirror
  // — updated from every `select` event — is how the dock resolves what
  // Enter / a click / a right-click acts on, since a tree node index no
  // longer maps 1:1 to a session in `filteredIds`.
  dockSelKey: string | null;
  // Dock-only: the flat node model (folders + session leaves) mirroring
  // the last-emitted tree, and the parallel item keys. Rebuilt on every
  // `buildDockSpec`; lets `dockSelKey` be resolved to a node/index.
  dockNodes: DockNode[];
  dockKeys: string[];
}

// A transient dock toolbar dropdown: the Menu, a panel of its own
// (`mainMenuPanel`). Moving a row to a folder is a pick in the tree itself
// (`movePick`), not a dropdown.
type DockDropdown = { kind: "main" };
let openDialog: OpenDialogState | null = null;
let openPanel: FloatingWidgetPanel | null = null;
// The dock panel kept alive in its own host slot (PanelSlot::Dock) while
// the modal Open picker is floated over it (PanelSlot::Floating). When
// non-null, `openPanel` is the picker and this is the dock underneath;
// closing the picker hands control back to it (`restoreDockBehindPicker`)
// rather than tearing everything down. The host renders both slots, so
// the dock stays visible (dimmed + passive) in its left column beside
// the picker.
let dockPanel: FloatingWidgetPanel | null = null;
// When the open panel is mounted as the persistent left dock rather
// than the centered modal picker. The dock reuses the same panel +
// `openDialog` state; these flags drive the dock-only behaviours
// (live-switch on nav, Enter/Esc blur instead of close).
let dockMode = false;
// True while the dock is visible but blurred — keyboard focus is in
// the editor and the dock just reflects the active session. The
// toggle command re-focuses; Enter/Esc blur.
let dockBlurred = false;
// Monotonic token so a rapid run of ↑/↓ only commits the *last*
// selection after the debounce window (30ms) — see `scheduleDockSwitch`.
let dockSwitchToken = 0;
// Right-click context menu for a dock session row. At `stage: "menu"`
// it's an unobtrusive content-sized popup anchored at the click (no
// background dim) offering Visit / Archive / Delete against one session.
// Choosing Archive/Delete swaps the SAME panel to a centered, dimmed
// `stage: "confirm"` modal (the destructive actions require a
// confirmation), reusing `buildConfirmPane`. Visit acts immediately.
// `anchorCol`/`anchorRow` are the right-click cell, kept so a return
// from confirm→menu (Cancel) re-anchors the popup where it opened.
// The right-clicked target: a session (Visit / Move to folder… /
// Archive / Delete) or a user folder (Rename / New Subfolder / Delete
// Folder). The confirm stage only ever applies to a session's
// destructive Archive/Delete.
type DockMenuTarget =
  | { kind: "session"; id: number }
  | { kind: "folder"; id: string }
  // An external session row, by `LiveSession.key`.
  | { kind: "live"; key: string };
type DockMenuState =
  | { target: DockMenuTarget; anchorCol: number; anchorRow: number; stage: "menu" }
  | {
      target: { kind: "session"; id: number };
      anchorCol: number;
      anchorRow: number;
      stage: "confirm";
      action: "archive" | "delete";
    };
let dockMenuPanel: FloatingWidgetPanel | null = null;
let dockMenuState: DockMenuState | null = null;
// The floor of the manifest's width rule (`orchestrator.manifest.json`).
// The dock's actual width is the host's; `dockWidth()` reads it back.
const DOCK_MIN_WIDTH_COLS = 24;
// `×` (U+00D7), the multiplication sign the file explorer's close button and
// the host's native modal `[×]` use — not the ASCII letter — so all three
// close affordances read identically.
const DOCK_CLOSE_GLYPH = "×";

// The dock column's width as the host carves it (mounted, held open at
// startup, or what it would get). `0` means the terminal is too narrow for
// a dock; content math floors at the declared minimum so it can still wrap.
function dockWidth(): number {
  return editor.dockCols() || DOCK_MIN_WIDTH_COLS;
}

// Inner content width for a given dock width: the host reserves one
// column for the right border plus an editor-side gutter, so list rows
// get `dockWidth - 2` cells. Floored so a clamped/narrow dock still
// renders something. Drives session name/tag truncation. (The header
// divider is host-rendered via `divider()`, so it no longer needs this.)
function dockContentCols(dockWidth: number): number {
  return Math.max(8, dockWidth - 2);
}
// Set just before the dock blurs *because the user picked a workspace*
// (a row click, Enter on the list, or attaching a discovered worktree
// with `dive`). The `blur` handler clears the search filter so a stale
// needle can't silently hide sessions on the next focus (F5) — but a
// dive isn't "leaving the dock", it's acting on the very list the
// filter produced. Wiping the needle there forces a retype for every
// workspace picked out of a search. Consumed (and reset) by the next
// `blur`; also reset on `focus` so an unconsumed flag can't leak into a
// later, unrelated blur.
let dockDiveBlur = false;
// Which control holds the open dialog's focus (dock or centred picker) —
// the host's fact, read when a binding needs it.
function pickerFocusKey(): string {
  return openPanel?.focusKey() ?? "";
}
// Scope is remembered across opens of the picker (module state
// survives dialog close). Defaults to "all" so the picker opens
// showing every session; flipping it with the Project control / Alt+P
// updates this and the next open honours it.
let lastOpenScope: "current" | "all" = "all";
// Remembered across opens, like `lastOpenScope`: whether the
// discovered on-disk worktree rows are shown. `null` means "not touched
// this session" — the dock then seeds it from the `showAllWorktrees`
// plugin setting (default false: worktrees hidden, surfacing them is
// opt-in via "Show all worktrees" / Alt+T). Flipping the checkbox pins a
// concrete value that wins for the rest of the session.
let lastShowWorktrees: boolean | null = null;
// Remembered across opens: whether "trivial" sessions are hidden.
// `null` ⇒ seeded from the `showEmptyWorkspaces` setting, which defaults
// to true (nothing hidden). A freshly created workspace starts empty, so
// hiding trivial sessions made it vanish the instant it lost the
// "active" exemption (issue: "new workspace immediately disappears").
// Showing all by default keeps new workspaces visible; the "show empty"
// checkbox (Alt+I) opts back into hiding the throwaway single-file /
// restored-shell rows.
let lastHideTrivial: boolean | null = null;
// Dock card density. "compact" (default) shows one line per session;
// "card" shows the three-line rounded pill. Read all over the render
// path, so it stays a plain value rather than a config lookup; the dock
// re-seeds it from the `defaultView` setting on open unless the user has
// hit the toolbar's "view" button this session (`dockViewOverride`).
// Compact is the default because the dock is a *switcher* first: one
// line per workspace fits several times as many rows in the same column,
// and the card's extra lines (branch, git, PR) are detail you go looking
// for, not detail you navigate by.
let dockView: "card" | "compact" = "compact";
let dockViewOverride: "card" | "compact" | null = null;
// Remembered dock project filter (see `OpenDialogState.projectFilter`).
let lastDockProjectFilter: string | null = null;

// =============================================================================
// Dock settings (Settings → Plugin: orchestrator)
//
// The dock's start-up defaults are *plugin* config, not core editor
// config: they only mean anything while this plugin is loaded, and the
// plugin-config API already gives us schema validation, the layered
// User/Project/Session merge, and a rendered Settings sub-category for
// free. Declaring them here is what makes them discoverable — before
// this, the dock's defaults were module constants only a source-reader
// could find, and the checkbox/density state was session-only.
//
// Each field is the *default* the dock opens with. The in-dock controls
// (the "view" button, the two Filters checkboxes) still win for the rest
// of the session — they set the `*Override` / `last*` values above —
// they just no longer decide where the dock starts.
// Closed on a first run; once the user opens it, it comes back at every start
// (unfocused, so the keyboard stays with the editor) until they close it.
editor.defineConfigEnum("autoOpenDock", {
  values: ["auto", "always", "never"] as const,
  default: "auto",
  description:
    "Whether the workspace dock opens when Fresh starts. Opening or closing the dock yourself (View ▸ Orchestrator Dock, Orchestrator: Toggle Dock, the dock's ×) sets this to 'always' or 'never', so Fresh starts the way you last asked; choosing 'always' or 'never' here also opens or closes the dock now. 'auto' (the default, until you first open or close the dock) starts with it closed. Replaces the old true/false, which are still read as 'auto' and 'never'.",
});
editor.defineConfigEnum("defaultView", {
  values: ["compact", "card"] as const,
  default: "compact",
  description:
    "Dock layout the panel opens with: 'compact' (one line per workspace) or 'card' (multi-line pill per workspace). The dock's 'view' button flips it for the current session.",
});
editor.defineConfigBoolean("showAllWorktrees", {
  default: false,
  description:
    "Start the dock (and the Open picker) with 'all worktrees' checked, listing on-disk worktrees that have no open workspace.",
});
editor.defineConfigBoolean("showEmptyWorkspaces", {
  default: true,
  description:
    "Start the dock (and the Open picker) with 'show empty' checked, listing workspaces with no edited files (freshly created ones included).",
});
editor.defineConfigEnum("notifications", {
  values: ["all", "needs-you", "off"] as const,
  default: "all",
  description:
    "Announce a background workspace in the status bar when it needs you ('needs-you'), or also when it finishes a run ('all'). 'off' leaves only the dock's attention line.",
});
editor.defineConfigBoolean("notifySound", {
  default: false,
  description:
    "Ring the terminal bell with each notification (needs-you and finished). Off by default.",
});
editor.defineConfigString("detectionRulesUrl", {
  default: "",
  description:
    "URL of a published detection-rules JSON ({version, blocked: [regex…]}). Fetched at startup and by Orchestrator: Reload Detection Rules; adopted when its version is newer than <data dir>/orchestrator/detection-rules.json. Empty = built-in rules (or the local file).",
});

interface DockSettings {
  autoOpenDock?: "auto" | "always" | "never";
  notifications?: "all" | "needs-you" | "off";
  notifySound?: boolean;
  detectionRulesUrl?: string;
  defaultView?: "card" | "compact";
  showAllWorktrees?: boolean;
  showEmptyWorkspaces?: boolean;
}

// Re-read on demand rather than caching the values `defineConfigX`
// returned at load time: a Settings-UI edit lands in the config snapshot
// straight away, so the next dock open honours it without a plugin
// reload or an editor restart.
function dockSettings(): DockSettings {
  return (editor.getPluginConfig() ?? {}) as DockSettings;
}

// Density the dock should open at: the session's own "view" toggle if
// the user has hit it, otherwise the configured default.
function configuredDockView(): "card" | "compact" {
  if (dockViewOverride !== null) return dockViewOverride;
  return dockSettings().defaultView === "card" ? "card" : "compact";
}

// The two Filters checkboxes, same precedence. `hideTrivial` is the
// inverse of the user-facing "show empty" checkbox.
function configuredShowWorktrees(): boolean {
  if (lastShowWorktrees !== null) return lastShowWorktrees;
  return dockSettings().showAllWorktrees === true;
}

function configuredHideTrivial(): boolean {
  if (lastHideTrivial !== null) return lastHideTrivial;
  return dockSettings().showEmptyWorkspaces === false;
}

// =============================================================================
// Dock folder tree
//
// The dock presents sessions in a user-organised hierarchy: arbitrary
// folders the user creates to group, nest, and arrange their agent
// sessions and remote connections however they like. Folders and the
// session→folder assignment are editor-global plugin state (the dock
// lists every project's sessions, so the organisation is global, not
// per-project) and persist across restarts.
//
// A session is assigned by a durable key, not its numeric window id:
// the id churns (a discovered on-disk worktree carries a synthetic
// negative id that becomes a positive window id the moment it is
// opened) and isn't stable run-to-run. The durable key is the window's
// stable id when the host reports one (`stableIdKey` — co-tenant
// workspaces share a root, so a per-root key would file them all
// together), falling back to the canonical root path for windowless
// rows and entries written before stable-id keying (§3 of
// orchestrator-sessions.md).
// =============================================================================

interface DockFolder {
  id: string; // stable unique id, e.g. "df3"
  name: string;
  parent: string | null; // parent folder id; null = top level
}

const FOLDERS_KEY = "orchestrator.dock.folders";
const ASSIGN_KEY = "orchestrator.dock.assignments";
const EXPANDED_KEY = "orchestrator.dock.expanded";
const FOLDER_COUNTER_KEY = "orchestrator.dock.folder_counter";

const FOLDER_NODE_PREFIX = "folder:";
const SESSION_NODE_PREFIX = "session:";

// Lazily-hydrated in-memory caches, written through to global state on
// every mutation so a later read (or the next launch) sees the change.
let dockFolders: DockFolder[] | null = null;
let dockAssign: Record<string, string> | null = null;
let dockExpanded: Set<string> | null = null;

function loadFolders(): DockFolder[] {
  if (dockFolders) return dockFolders;
  const raw = editor.getGlobalState(FOLDERS_KEY);
  const out: DockFolder[] = [];
  if (Array.isArray(raw)) {
    for (const e of raw) {
      if (e && typeof e === "object") {
        const rec = e as Record<string, unknown>;
        const id = rec.id;
        const name = rec.name;
        const parent = rec.parent;
        if (typeof id === "string" && typeof name === "string") {
          out.push({ id, name, parent: typeof parent === "string" ? parent : null });
        }
      }
    }
  }
  dockFolders = out;
  return out;
}

function saveFolders(): void {
  editor.setGlobalState(FOLDERS_KEY, (dockFolders ?? []) as unknown as object);
}

function loadAssign(): Record<string, string> {
  if (dockAssign) return dockAssign;
  const raw = editor.getGlobalState(ASSIGN_KEY);
  const out: Record<string, string> = {};
  if (raw && typeof raw === "object" && !Array.isArray(raw)) {
    for (const [k, v] of Object.entries(raw as Record<string, unknown>)) {
      if (typeof v === "string") out[k] = v;
    }
  }
  dockAssign = out;
  return out;
}

function saveAssign(): void {
  editor.setGlobalState(ASSIGN_KEY, (dockAssign ?? {}) as unknown as object);
}

function loadExpanded(): Set<string> {
  if (dockExpanded) return dockExpanded;
  const raw = editor.getGlobalState(EXPANDED_KEY);
  const out = new Set<string>();
  if (Array.isArray(raw)) {
    for (const v of raw) if (typeof v === "string") out.add(v);
  }
  dockExpanded = out;
  return out;
}

function saveExpanded(): void {
  editor.setGlobalState(
    EXPANDED_KEY,
    Array.from(dockExpanded ?? new Set<string>()) as unknown as object,
  );
}

function allocFolderId(): string {
  const raw = editor.getGlobalState(FOLDER_COUNTER_KEY);
  const n = (typeof raw === "number" && raw >= 0 ? Math.floor(raw) : 0) + 1;
  editor.setGlobalState(FOLDER_COUNTER_KEY, n as unknown as object);
  return `df${n}`;
}

function folderNodeKey(id: string): string {
  return FOLDER_NODE_PREFIX + id;
}
function sessionNodeKey(id: number): string {
  return SESSION_NODE_PREFIX + id;
}

// Durable store key for a workspace-scoped entry (manual name, folder
// assignment). Keyed by the host's stable id: co-tenant workspaces (a
// tab extracted to a new workspace) share one root, so a per-root key
// would apply the entry to all of them at once. The bare root remains
// both the legacy key (entries written before stable-id keying) and the
// only key available for rows without a live window (discovered
// worktrees).
function stableIdKey(stableId: string): string {
  return "id:" + stableId;
}

// Whether another live workspace co-tenants `s`'s root. When one does, a
// legacy per-root store entry may still describe *that* workspace, so
// writers must leave it alone — touching it is the "renaming the
// extracted workspace renamed the original too" bug, and its
// move-to-folder twin.
function hasLiveCoTenant(s: AgentSession): boolean {
  const rootKey = normRoot(s.root);
  return [...orchestratorSessions.values()].some(
    (o) => o.id !== s.id && !o.discovered && o.id > 0 && normRoot(o.root) === rootKey,
  );
}

function folderById(id: string): DockFolder | undefined {
  return loadFolders().find((f) => f.id === id);
}

// Direct child folders of `parent` (null = top level), sorted by name so
// the tree order is stable and predictable.
function childFoldersOf(parent: string | null): DockFolder[] {
  return loadFolders()
    .filter((f) => (f.parent ?? null) === parent)
    .sort((a, b) => {
      const la = a.name.toLowerCase();
      const lb = b.name.toLowerCase();
      if (la !== lb) return la < lb ? -1 : 1;
      return a.id < b.id ? -1 : 1;
    });
}

// The folder a live session is filed under, or null when it is unfiled
// or its folder was deleted out from under it (treated as top level).
// The session's own stable-id entry wins; an empty string there is an
// explicit "top level" (recorded when unfiling next to a co-tenant, so
// the legacy per-root entry can't pull the row back into a folder).
// Only a session with no entry of its own falls back to the legacy /
// windowless per-root entry.
function folderOfSession(id: number): string | null {
  const s = orchestratorSessions.get(id);
  if (!s) return null;
  const assign = loadAssign();
  const own = s.stableId ? assign[stableIdKey(s.stableId)] : undefined;
  // A workspace still being created borrows its project's directory as a
  // root (its own doesn't exist yet), so the root-keyed fallback would file
  // it wherever the *project's* workspace lives. Its stable id is its own
  // from birth — that alone speaks for it.
  const a = own !== undefined
    ? own
    : (s.pending && s.stableId ? undefined : assign[normRoot(s.root)]);
  return a && folderById(a) ? a : null;
}

function createFolder(name: string, parent: string | null): string {
  const id = allocFolderId();
  loadFolders().push({ id, name, parent });
  saveFolders();
  // New folders open expanded so their contents are immediately visible.
  loadExpanded().add(folderNodeKey(id));
  saveExpanded();
  return id;
}

function renameFolder(id: string, name: string): void {
  const f = folderById(id);
  if (f) {
    f.name = name;
    saveFolders();
  }
}

// ── Per-workspace "last active" day — the dock's within-folder sort key ──
//
// Within a folder the dock lists the most-recently-active workspaces first,
// but at DAY granularity so the order is stable through the day and only
// reshuffles when a workspace crosses a day boundary (a finer key would
// re-sort — and, since a changed serialized row forces a full panel
// teardown/rebuild, flicker — on every render; same rationale as
// `ageString`). We persist the last-active *day number* keyed by canonical
// root so the recency order survives restarts: the in-memory `lastOutputAt`
// / `activatedAt` reset each launch and `createdAt` is stamped at reconcile
// time, so without persistence every workspace would read "active today"
// after a relaunch and the order would collapse to first-seen.
const LAST_ACTIVE_KEY = "orchestrator.dock.last_active";
const MS_PER_DAY = 86_400_000;
let dockLastActive: Record<string, number> | null = null;

function loadLastActive(): Record<string, number> {
  if (dockLastActive) return dockLastActive;
  const raw = editor.getGlobalState(LAST_ACTIVE_KEY);
  const out: Record<string, number> = {};
  if (raw && typeof raw === "object" && !Array.isArray(raw)) {
    for (const [k, v] of Object.entries(raw as Record<string, unknown>)) {
      if (typeof v === "number" && Number.isFinite(v)) out[k] = v;
    }
  }
  dockLastActive = out;
  return out;
}

function saveLastActive(): void {
  editor.setGlobalState(LAST_ACTIVE_KEY, (dockLastActive ?? {}) as unknown as object);
}

function todayDayNumber(): number {
  return Math.floor(Date.now() / MS_PER_DAY);
}

// Record that a session was active "today". Writes through to global state
// only when the stored day actually advances, so a chatty terminal (this
// fires on every output batch) persists at most once per session per day
// rather than thrashing the store on every keystroke.
function markSessionActiveToday(s: AgentSession): void {
  // On-disk (discovered) rows have no activity of their own — their recency
  // is meaningless, so don't record (and they sort oldest, see below).
  if (s.discovered) return;
  const key = normRoot(s.root);
  const day = todayDayNumber();
  const store = loadLastActive();
  if (store[key] === day) return;
  store[key] = day;
  saveLastActive();
}

// The most recent day this session was active, at day granularity. Prefer
// the persisted value — it's the real last-active day, updated on every
// output / activation — so a workspace last used days ago sorts below one
// used today even though both are live *now* (`createdAt` is stamped at
// reconcile time and would otherwise pin every restored session to "today").
// A session with no persisted day yet (never active this run, no history)
// falls back to today, so a brand-new workspace still sorts as current. A
// discovered on-disk row is keyed by the same root as the live session it
// becomes, so opening it never changes its day — hence never its position.
function sessionLastActiveDay(s: AgentSession): number {
  const stored = loadLastActive()[normRoot(s.root)];
  if (stored !== undefined) return stored;
  const liveMs = Math.max(s.lastOutputAt ?? 0, s.activatedAt ?? 0, s.createdAt ?? 0);
  return liveMs > 0 ? Math.floor(liveMs / MS_PER_DAY) : todayDayNumber();
}

// ── Workspace names: manual rename + terminal-tracking auto-name ─────────
//
// A workspace's display name comes from three sources, most-specific first:
//   1. a manual rename (persisted per workspace, survives restarts),
//   2. else, when it has a terminal that reports a title, an auto-name that
//      tracks that terminal: a constant prefix (the workspace's own name, so
//      you can still tell which workspace it is) + the changing terminal/
//      process title (the same string the terminal tab shows),
//   3. else the host's own label (root basename).
// Manual rename always wins, so naming a workspace pins it against the
// auto-name (which would otherwise keep overwriting it as the tab title
// shifts).
const WORKSPACE_NAMES_KEY = "orchestrator.dock.names";
// Separator between the constant workspace prefix and the changing terminal
// title in an auto-name (e.g. `proj · bash — root@host: ~/proj`).
const WORKSPACE_AUTONAME_SEP = " \u{b7} ";
let dockNames: Record<string, string> | null = null;

function loadNames(): Record<string, string> {
  if (dockNames) return dockNames;
  const raw = editor.getGlobalState(WORKSPACE_NAMES_KEY);
  const out: Record<string, string> = {};
  if (raw && typeof raw === "object" && !Array.isArray(raw)) {
    for (const [k, v] of Object.entries(raw as Record<string, unknown>)) {
      if (typeof v === "string" && v.length > 0) out[k] = v;
    }
  }
  dockNames = out;
  return out;
}

function saveNames(): void {
  editor.setGlobalState(WORKSPACE_NAMES_KEY, (dockNames ?? {}) as unknown as object);
}

// The manual name pinned to a workspace, if any: its own stable-id entry
// first, else the legacy / windowless per-root entry.
function customNameFor(stableId: string | undefined, root: string): string | undefined {
  const store = loadNames();
  if (stableId) {
    const own = store[stableIdKey(stableId)];
    if (own) return own;
  }
  return store[normRoot(root)];
}

// The manual name pinned to this session, if any.
//
// A workspace that is still being created is rooted at its *project*
// directory until its worktree exists, which another workspace may already
// occupy — so the root-keyed fallback would hand it that workspace's name.
// It has a stable id of its own from birth, so key it by that alone.
function workspaceCustomName(s: AgentSession): string | undefined {
  if (s.pending && s.stableId) return loadNames()[stableIdKey(s.stableId)];
  return customNameFor(s.stableId, s.root);
}

// The workspace's own name, without the terminal-title suffix a dock row
// carries.
//
// `label` is built for a wide row: with no manual rename and a live terminal it
// is `<workspace> · <terminal title>`, and a shell's title is routinely its
// whole `user@host: /long/path`. Beside a row that is useful context; as the
// only line of a dialog heading it is actively harmful, because the heading
// truncates and what gets cut is the end — leaving
// `Delete workspace demo-3 · bash — root@vm: ~/.local/share/…/dem`, which
// answers everything except the one question the heading exists for: *which
// workspace*. A manual rename is the user's own name for it and is kept as is.
function sessionShortName(s: AgentSession): string {
  return workspaceCustomName(s) || s.hostLabel || editor.pathBasename(s.root) || "";
}

// Compute the display name for a session from the three sources above.
function workspaceDisplayName(s: AgentSession): string {
  const manual = workspaceCustomName(s);
  if (manual) return manual;
  const title = (s.terminalTitle ?? "").trim();
  if (title && !s.discovered) {
    const prefix = (s.hostLabel || editor.pathBasename(s.root) || "workspace").trim();
    return prefix + WORKSPACE_AUTONAME_SEP + title;
  }
  return s.hostLabel;
}

// Recompute and store `s.label` from the current sources. Called whenever an
// input changes: reconcile (host label), terminal output (title), or a
// manual rename.
function applyResolvedLabel(s: AgentSession): void {
  s.label = workspaceDisplayName(s);
  // A workspace still being built shows this name on its own page too, so
  // renaming it while it runs renames what the user is looking at — not
  // just the dock row.
  syncPreparingPage(s);
}

// Push a still-building workspace's name + status onto the placeholder page
// inside its window. A no-op for a finished workspace, and for a windowless
// (remote) placeholder, which has no page to write to.
function syncPreparingPage(s: AgentSession): void {
  if (!s.pending || s.id <= 0) return;
  // Keep the host's record of "this window is a placeholder" current: it is
  // what makes the window adoptable when the create lands, and it carries the
  // fallback page for anyone who is not us.
  editor.setWindowPreparing(
    s.id,
    s.pending.message,
    s.label,
    // Both "failed" and "paused" (interrupted by a restart) are stalled
    // states waiting on the same retry, and the page says so.
    pendingActionable(s.pending),
    false,
  );
  renderPlaceholderPage(s);
}

// ── The placeholder page ─────────────────────────────────────────────
//
// A workspace being built is a window the user is standing in, and its page
// is ours to write: we are the only thing that knows what it is waiting on,
// what failed, and that "retry" means re-running *this* recipe against
// *this* host. The host draws a generic page for a window nobody has
// claimed; mounting a panel on the placeholder's seed buffer replaces it.
//
// This is why the failure is not also a panel at the bottom of the dock any
// more. It was in both places because the page could not carry buttons and
// the dock could; now that it can, the dock row is back to being a summary —
// *which* workspace is unhappy — and everything else is here.

/** The mark the page carries, matching the host's own placeholder page so
 *  the two read as one surface. */
const PREPARING_GLYPH = "⛭";

/** The panel each placeholder page is drawn by, keyed by window id. */
const placeholderPanels = new Map<number, WidgetPanel>();
/** Reverse lookup for `widget_event`: which window a panel id belongs to. */
const placeholderWindows = new Map<number, number>();
/** Panel ids for placeholder pages. Per-plugin, so any range we do not
 *  otherwise use will do; offsetting by the window id keeps one page per
 *  workspace. */
const PLACEHOLDER_PANEL_BASE = 900_000;

/** The page's measure and its left margin, in columns.
 *
 *  Set here rather than left to `wrap: true`, which breaks at whatever width
 *  layout settles on — the whole pane, so on a wide terminal the error ran
 *  the width of the screen. A paragraph that wide is a worse read than a
 *  clipped one; this holds it to something a reader's eye can track and
 *  centres what is left over. */
function placeholderMeasure(): { measure: number; margin: number } {
  const screen = editor.getScreenSize();
  const dock = openPanel && dockMode ? dockWidth() : 0;
  const pane = Math.max(20, (screen.width > 0 ? screen.width : 100) - dock);
  const measure = Math.max(24, Math.min(72, pane - 8));
  return { measure, margin: Math.max(1, Math.floor((pane - measure) / 2)) };
}

/** Greedy word wrap at `cols`, measured the way the terminal measures — the
 *  message carries host names and ssh's own punctuation, so character counts
 *  are not column counts. */
function wrapToMeasure(textValue: string, cols: number): string[] {
  const out: string[] = [];
  let line = "";
  for (const word of textValue.split(/\s+/).filter(Boolean)) {
    if (!line) line = word;
    else if (editor.stringWidth(line) + 1 + editor.stringWidth(word) <= cols) line += " " + word;
    else {
      out.push(line);
      line = word;
    }
  }
  if (line) out.push(line);
  return out.length > 0 ? out : [""];
}

function placeholderSpec(s: AgentSession): WidgetSpec {
  const p = s.pending!;
  const { measure, margin } = placeholderMeasure();
  const wrapped = (t: string, style: Record<string, unknown>): WidgetSpec[] =>
    wrapToMeasure(t, measure).map((l) => label(l, { style }));
  const body: WidgetSpec[] = [
    label(`${PREPARING_GLYPH} ${s.label}`, { style: { bold: true } }),
    spacer(1),
    ...wrapped(p.message, { fg: pendingMsgFg(p) }),
    spacer(1),
  ];
  // No hint line under the message: the two buttons below say what can be
  // done, and the dock's "Enter to retry · menu to dismiss" copy describes
  // the *row's* affordances, which are not the ones on this page.
  if (pendingActionable(p)) {
    body.push(
      endRow(
        button(editor.t("dock.ctx_retry"), {
          intent: "primary",
          key: "placeholder-retry",
        }),
        spacer(1),
        // "Delete", not "Dismiss": this does not put a notice away, it gets
        // rid of the workspace — the row goes, the window closes, and a
        // worktree the create had already added is removed with it. A label
        // that reads as "do nothing" on a button that destroys something is
        // the wrong way round.
        button(editor.t("dock.ctx_delete"), {
          intent: "danger",
          key: "placeholder-dismiss",
        }),
      ),
    );
  }
  // Nothing else while it is still working: the message is the whole content
  // of the wait, and a line of reassurance under it is one more thing to
  // read on the way to the only fact that matters.
  return col(spacer(1), row(spacer(margin), col(...body), spacer(margin)));
}

function renderPlaceholderPage(s: AgentSession): void {
  const bufferId = s.pending?.bufferId;
  if (!bufferId) return;
  let panel = placeholderPanels.get(s.id);
  if (!panel) {
    const panelId = PLACEHOLDER_PANEL_BASE + s.id;
    // `autoFocusFirst: false`: the page opens as something to read. The
    // buttons are there when there is something to decide, and Tab reaches
    // them; seeding focus onto Retry the moment a create starts would arm
    // Enter on an action nobody has asked for yet.
    panel = new WidgetPanel(bufferId, panelId, { autoFocusFirst: false });
    placeholderPanels.set(s.id, panel);
    placeholderWindows.set(panelId, s.id);
  }
  panel.set(placeholderSpec(s));
}

/** Drop a placeholder page — the workspace became real, or went away. */
function dropPlaceholderPage(id: number): void {
  const panel = placeholderPanels.get(id);
  if (!panel) return;
  panel.unmount();
  placeholderPanels.delete(id);
  placeholderWindows.delete(PLACEHOLDER_PANEL_BASE + id);
}

// Set (or, with an empty name, clear) the manual name for a session and
// refresh its resolved label. Clearing lets the auto-name / host label take
// over again.
function renameWorkspace(s: AgentSession, name: string): void {
  const rootKey = normRoot(s.root);
  const store = loadNames();
  const trimmed = name.trim();
  if (s.stableId) {
    const idKey = stableIdKey(s.stableId);
    if (trimmed) store[idKey] = trimmed;
    else delete store[idKey];
    // Keep the per-root entry in step when it can only mean this
    // workspace, so root-keyed lookups (a later discovered row at this
    // root, a legacy workspace file) agree with the rename / clear.
    // With a co-tenant present the entry may still name *that*
    // workspace, so it is left alone — touching it is exactly the
    // "renaming the extracted workspace renamed the original too" bug.
    // A still-being-created workspace is borrowing its project's root the
    // same way, so it never writes the root entry either.
    if (!hasLiveCoTenant(s) && !s.pending) {
      if (trimmed) store[rootKey] = trimmed;
      else delete store[rootKey];
    }
  } else {
    if (trimmed) store[rootKey] = trimmed;
    else delete store[rootKey];
  }
  saveNames();
  applyResolvedLabel(s);
}

// Delete a folder. Its child folders and member sessions reparent to the
// deleted folder's own parent so nothing is orphaned — the subtree
// bubbles up one level rather than disappearing.
function deleteFolder(id: string): void {
  const f = folderById(id);
  if (!f) return;
  const parent = f.parent ?? null;
  const folders = loadFolders();
  for (const c of folders) {
    if ((c.parent ?? null) === id) c.parent = parent;
  }
  dockFolders = folders.filter((x) => x.id !== id);
  saveFolders();
  const assign = loadAssign();
  for (const [k, v] of Object.entries(assign)) {
    if (v === id) {
      if (parent) assign[k] = parent;
      else delete assign[k];
    }
  }
  saveAssign();
  loadExpanded().delete(folderNodeKey(id));
  saveExpanded();
}

function assignSessionToFolder(id: number, folderId: string | null): void {
  const s = orchestratorSessions.get(id);
  if (!s) return;
  const assign = loadAssign();
  const rootKey = normRoot(s.root);
  if (s.stableId) {
    const idKey = stableIdKey(s.stableId);
    const coTenant = hasLiveCoTenant(s);
    if (folderId) assign[idKey] = folderId;
    // Unfiling next to a co-tenant records an explicit "top level" ("")
    // rather than deleting the entry — a bare delete would fall back to
    // the co-tenant's legacy per-root entry and the move wouldn't stick.
    else if (coTenant) assign[idKey] = "";
    else delete assign[idKey];
    // Keep the per-root entry in step when it can only mean this
    // workspace, so root-keyed lookups (a later discovered row at this
    // root, a legacy workspace file) agree with the move. A still-being-
    // created workspace is only borrowing this root, so it never writes it.
    if (!coTenant && !s.pending) {
      if (folderId) assign[rootKey] = folderId;
      else delete assign[rootKey];
    }
  } else {
    if (folderId) assign[rootKey] = folderId;
    else delete assign[rootKey];
  }
  saveAssign();
}

// =============================================================================
// External sessions: Claude and Codex sessions open outside this editor
//
// The `live_sessions` plugin polls each tool's own listing (another terminal,
// a `claude --bg` job, Claude or Codex cloud) and hands the answer to
// `setExternalSessions`. They are drawn as a group of their own at the foot
// of the dock, not as workspaces: nothing here owns them, so none of the
// workspace verbs (Stop, Archive, Delete, rename) apply. Opening one — Enter,
// a click, a menu's Take Over or Fork — *materializes* it: a workspace is
// created that attaches to it, and from then on it is an ordinary workspace
// (and drops out of the group, see `unrepresented`). Filing one into a folder
// does not: the row moves there as it is (`setExternalFolder`).
//
// Kept apart from `orchestratorSessions` on purpose: every loop over that map
// would otherwise have to learn that some of its rows are not workspaces.
// =============================================================================

// Sessions outside the editor are grouped by product — "Claude", "Codex" —
// each row saying where it runs. Each header is a `folder` node with a
// reserved id (`__external:<agent>`), so it folds, counts and rolls up like
// a folder. `allocFolderId` only mints `df<n>`.
type ExternalGroup = LiveSession["agent"];
const EXTERNAL_FOLDER_PREFIX = "__external:";
const EXTERNAL_GROUPS: ExternalGroup[] = ["claude", "codex"];
const EXTERNAL_GROUP_NAME: Record<ExternalGroup, string> = { claude: "Claude", codex: "Codex" };
const LIVE_NODE_PREFIX = "live:";
// A group starts open, unlike a folder, so what is remembered is the fold:
// the ids of the folded groups.
const EXTERNAL_COLLAPSED_KEY = "orchestrator.dock.external_collapsed_groups";

let externalSessions: LiveSession[] = [];
let externalProblems: string[] = [];
// What went wrong with each source, so its group can say so.
let externalProblemsBySource: Partial<Record<LiveSession["source"], string>> = {};
// The CLIs the feed was configured to run, so a materialized session attaches
// with the same program the listing came from.
let externalCommands = { claude: "claude", codex: "codex" };
// First-seen order, so a poll never reshuffles the group (the dock's rule for
// workspaces too, see `rootDisplayOrder`).
const externalOrder = new Map<string, number>();
let nextExternalOrder = 0;

interface ExternalUpdate {
  sessions: LiveSession[];
  problems: string[];
  problemsBySource?: Partial<Record<LiveSession["source"], string>>;
  commands?: { claude?: string; codex?: string };
}

function externalFolderId(group: ExternalGroup): string {
  return EXTERNAL_FOLDER_PREFIX + group;
}

function isExternalFolder(id: string | null | undefined): boolean {
  return typeof id === "string" && id.startsWith(EXTERNAL_FOLDER_PREFIX);
}

function externalGroupOf(folderId: string): ExternalGroup {
  return folderId.slice(EXTERNAL_FOLDER_PREFIX.length) as ExternalGroup;
}

function externalGroupKey(group: ExternalGroup): string {
  return folderNodeKey(externalFolderId(group));
}

/** The group a folder-node key names, if it is one of the external sessions groups. */
function externalGroupOfKey(key: string): ExternalGroup | null {
  return EXTERNAL_GROUPS.find((g) => externalGroupKey(g) === key) ?? null;
}

// A product name, not translated.
function externalGroupName(group: ExternalGroup): string {
  return EXTERNAL_GROUP_NAME[group];
}

// What went wrong with a group's sources (a sign-in that expired, a CLI
// that failed), for its menu.
function externalGroupProblems(group: ExternalGroup): string[] {
  return Object.entries(externalProblemsBySource)
    .filter(([src, msg]) => src.startsWith(`${group}-`) && typeof msg === "string")
    .map(([, msg]) => msg as string);
}

function liveNodeKey(key: string): string {
  return LIVE_NODE_PREFIX + key;
}

function externalCollapsedSet(): Set<string> {
  const v = editor.getGlobalState(EXTERNAL_COLLAPSED_KEY);
  return new Set(Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : []);
}

function externalCollapsed(group: ExternalGroup): boolean {
  return externalCollapsedSet().has(group);
}

function setExternalCollapsed(group: ExternalGroup, collapsed: boolean): void {
  const set = externalCollapsedSet();
  if (collapsed) set.add(group);
  else set.delete(group);
  editor.setGlobalState(EXTERNAL_COLLAPSED_KEY, [...set]);
}

// Every expansion the dock's tree is drawn with: the user's open folders,
// plus the external sessions group unless they folded it.
function dockExpandedKeys(): string[] {
  const keys = Array.from(loadExpanded());
  for (const g of EXTERNAL_GROUPS) if (!externalCollapsed(g)) keys.push(externalGroupKey(g));
  return keys;
}

// The last answer drawn, so a poll that changed nothing costs no repaint.
let externalSignature = "";

// The feed's push (published as `setExternalSessions`).
function setExternalSessions(update: ExternalUpdate): void {
  externalSessions = Array.isArray(update?.sessions) ? update.sessions : [];
  externalProblems = Array.isArray(update?.problems) ? update.problems : [];
  externalProblemsBySource = update?.problemsBySource && typeof update.problemsBySource === "object"
    ? update.problemsBySource
    : {};
  externalCommands = {
    claude: update?.commands?.claude || "claude",
    codex: update?.commands?.codex || "codex",
  };
  for (const s of externalSessions) {
    if (!externalOrder.has(s.key)) externalOrder.set(s.key, nextExternalOrder++);
  }
  const signature = JSON.stringify([externalSessions, externalProblems, externalProblemsBySource]);
  if (signature === externalSignature) return;
  externalSignature = signature;
  if (openPanel && dockMode) refreshOpenDialog();
}

// The feed plugin's side (`live_sessions.ts`), or null when it isn't loaded.
interface ExternalFeed {
  refresh(): Promise<void>;
  snapshot(): ExternalUpdate;
  claudeCloudEnabled(): boolean;
  setClaudeCloud(on: boolean): Promise<void>;
}

function externalFeed(): ExternalFeed | null {
  return editor.getPluginApi("live-sessions") as ExternalFeed | null;
}

// Ask the feed for a fresh answer (the dock just opened, or the user asked),
// and take whatever it already has in the meantime.
function refreshExternal(): void {
  const feed = externalFeed();
  if (!feed) return;
  setExternalSessions(feed.snapshot());
  void feed.refresh();
}

// The group's rows: sessions not already a workspace here, matching the
// dock's search, in first-seen order. Only workspaces on this machine can
// stand for a local session, and one on its host for a session over SSH; a
// cloud one is matched by the directory it materializes into.
function externalVisible(): LiveSession[] {
  const roots: string[] = [];
  const remoteRoots: { host: string; root: string }[] = [];
  for (const s of orchestratorSessions.values()) {
    if (s.id > 0 && !s.remote) roots.push(s.root);
    // A session taken over on its SSH host is that host's workspace now.
    if (s.id > 0 && s.remote?.kind === "ssh") remoteRoots.push({ host: s.remote.detail, root: s.root });
  }
  const needle = (openDialog?.filter.value ?? "").trim().toLowerCase();
  return unrepresented(externalSessions, roots, editor.getDataDir(), remoteRoots)
    .filter((s) =>
      needle === "" ||
      `${s.title} ${liveTail(s)} ${s.agent}`.toLowerCase().includes(needle)
    )
    .sort((a, b) => (externalOrder.get(a.key) ?? 0) - (externalOrder.get(b.key) ?? 0));
}

function liveByKey(key: string): LiveSession | undefined {
  return externalSessions.find((s) => s.key === key);
}

// Teleporting copies a cloud session: the cloud one goes on as it was, so
// its row stays. Which workspace each copy became is remembered (cloud id →
// the workspace's durable id), so the row can say where it went and offer
// to go there rather than make another copy.
const TELEPORTED_KEY = "orchestrator.teleported";

function teleportedMap(): Record<string, string> {
  const v = editor.getGlobalState(TELEPORTED_KEY);
  return v && typeof v === "object" ? { ...(v as Record<string, string>) } : {};
}

function rememberTeleport(cloudId: string, stableId: string): void {
  const map = teleportedMap();
  map[cloudId] = stableId;
  // Forget copies whose workspace is gone, so the record stays small.
  const live = new Set([...orchestratorSessions.values()].map((w) => w.stableId).filter(Boolean));
  for (const [k, v] of Object.entries(map)) if (!live.has(v) && k !== cloudId) delete map[k];
  editor.setGlobalState(TELEPORTED_KEY, map);
}

// External sessions filed into a user folder: session key → folder id. Filing
// only moves the row; the session is not forked or attached.
const EXTERNAL_FOLDERS_KEY = "orchestrator.external_folders";

function externalFoldersMap(): Record<string, string> {
  const v = editor.getGlobalState(EXTERNAL_FOLDERS_KEY);
  return v && typeof v === "object" ? { ...(v as Record<string, string>) } : {};
}

/** The folder an external session was filed into, while that folder exists. */
function externalFolderOf(key: string): string | null {
  const fid = externalFoldersMap()[key];
  return fid && folderById(fid) ? fid : null;
}

/** File an external session under a folder, or back into its product's
 *  group with `null`. */
function setExternalFolder(key: string, folderId: string | null): void {
  const map = externalFoldersMap();
  if (folderId) map[key] = folderId;
  else delete map[key];
  editor.setGlobalState(EXTERNAL_FOLDERS_KEY, map);
  refreshDockTree();
}

/** The workspace a cloud session was teleported into, while it exists. */
function teleportedWorkspace(s: LiveSession): AgentSession | undefined {
  if (s.source !== "claude-cloud") return undefined;
  const stableId = teleportedMap()[s.id];
  if (!stableId) return undefined;
  return [...orchestratorSessions.values()].find((w) => w.id > 0 && w.stableId === stableId);
}

// Where the session is — a card's second line, and search text — or, for a
// cloud session copied here, which workspace the copy is.
function liveTail(s: LiveSession): string {
  const w = teleportedWorkspace(s);
  return w ? editor.t("dock.live_teleported", { name: w.label }) : liveDetail(s);
}

// What an external session row is, for the top of its menu: read-only lines.
function liveInfoLines(s: LiveSession): string[] {
  const lines = [`${editor.t("dock.live_source")}: ${liveSource(s)}`];
  const where = liveWhere(s);
  if (where) lines.push(`${editor.t("dock.live_where")}: ${where}`);
  if (s.state !== "unknown") {
    const state = editor.t(`preview.state_${s.state}`);
    lines.push(`${editor.t("dock.live_state")}: ${s.waitingFor ? `${state} — ${s.waitingFor}` : state}`);
  }
  if (s.updatedAt) lines.push(`${editor.t("dock.live_active")}: ${agoText(s.updatedAt)}`);
  const copy = teleportedWorkspace(s);
  if (copy) lines.push(editor.t("dock.live_teleported", { name: copy.label }));
  return lines;
}

function liveStateEntry(s: LiveSession): Entry {
  const sym = STATE_SYMBOL[s.state];
  return { text: sym.glyph + " ", style: { fg: sym.fg, bold: true } };
}

// Compact: the state and the title. Where it runs is in its menu (a tail
// here would only be cut off at the dock's edge).
function liveNodeEntry(s: LiveSession): TextPropertyEntry {
  const segs: Entry[] = [
    liveStateEntry(s),
    { text: s.title, style: { bold: true } },
  ];
  return styledRow(segs as Parameters<typeof styledRow>[0]);
}

// Card: the same two rows a workspace card has — name and agent, then where.
function liveCardPrimary(s: LiveSession): TextPropertyEntry {
  return cardSplitRow(
    [liveStateEntry(s), { text: s.title, style: { bold: true } }],
    [{ text: s.agent, style: { fg: "ui.menu_disabled_fg" } }],
  );
}

function liveCardExtraLines(s: LiveSession): TextPropertyEntry[] {
  return [
    cardSplitRow([{ text: "  " + liveTail(s), style: { fg: "ui.menu_disabled_fg", italic: true } }], []),
  ];
}

// The group header: a folder row, with the same `●n ✓n` roll-up, so a
// folded group still says when a session out there needs you.
function externalGroupEntry(group: ExternalGroup, live: LiveSession[]): TextPropertyEntry {
  const rollup = { blocked: 0, done: 0 };
  for (const s of live) {
    if (s.state === "blocked") rollup.blocked++;
    else if (s.state === "done") rollup.done++;
  }
  return folderNodeEntry(
    { id: externalFolderId(group), name: externalGroupName(group), parent: null },
    live.length,
    rollup,
  );
}

// Take a Claude cloud session over: `claude --teleport <id>` moves it into a
// local checkout and resumes it there. Which checkout is the user's call —
// the New Workspace form opens with the command filled in, on a fresh
// worktree (the teleport checks the session's branch out), pointed at a
// workspace of the same repository when one is open.
function teleportLiveSession(key: string): void {
  const s = liveByKey(key);
  if (!s) return;
  const repoName = s.repo ? liveBaseName(s.repo) : undefined;
  const match = repoName
    ? [...orchestratorSessions.values()].find((w) =>
      w.id > 0 && !w.remote && liveBaseName(w.projectPath) === repoName
    )
    : undefined;
  openWorkspaceForm({ kind: "option", key: "local" }, {
    projectPath: match?.projectPath ?? "",
    cmd: `${externalCommands.claude} --teleport ${s.id}`,
    label: s.title,
    teleportOf: s.id,
    createWorktree: true,
  });
}

// Open a URL with the platform's opener. Fire-and-forget: only one of the
// Unix openers exists on a given machine, and the other fails harmlessly.
function openInBrowser(url: string): void {
  if (editor.getEnv("OS") === "Windows_NT") {
    editor.spawnHostProcess("cmd", ["/c", "start", "", url]);
    return;
  }
  editor.spawnHostProcess("xdg-open", [url]);
  editor.spawnHostProcess("open", [url]);
}

// What opening `s` does, with this editor's settings.
// Opening is the only way a row becomes a workspace — filing one into a
// folder moves the row, and forks nothing — so a row with a page of its own
// (a Codex Cloud task) opens that page rather than a workspace.
function externalPlan(s: LiveSession): LivePlan {
  return livePlan(s, {
    dataDir: editor.getDataDir(),
    claude: externalCommands.claude,
    codex: externalCommands.codex,
    windows: editor.getEnv("OS") === "Windows_NT",
  }, false);
}

// Enter or a click on an external session row. What takes the session over or
// connects to it here runs at once; anything that would leave the editor —
// a page in the browser, Claude Desktop — or teleport a cloud session is
// offered instead (the row's menu, at the row), never done on a click.
// `at` is where a click landed, so the menu opens at the pointer; Enter has
// none and opens it at the row.
function activateLiveRow(key: string, at?: { index: number; col: number; row: number }): void {
  const s = liveByKey(key);
  if (!s) return;
  const plan = externalPlan(s);
  if (plan.kind === "browser" || plan.kind === "teleport") {
    // One row below the click, so the row stays in sight above its menu.
    if (at) openDockContextMenu(at.index, at.col, at.row + 1);
    else openDockContextMenuFromKeyboard();
    return;
  }
  void openLiveSession(key, { dive: true });
}

// The link Claude Desktop opens a session of its own with.
function desktopLink(s: LiveSession): string | null {
  return s.desktopId ? `claude://code/continue?session=${encodeURIComponent(s.desktopId)}` : null;
}

// A page or app outside the editor, opened from a menu item.
function openLiveOutside(s: LiveSession, url: string): void {
  openInBrowser(url);
  editor.setStatus(editor.t(
    url.startsWith("claude://") ? "status.external_desktop" : "status.external_browser",
    { name: s.title },
  ));
}

// Take a session over on the SSH host it runs on (a Claude Desktop session
// over SSH): a remote workspace there, in its folder, whose terminal stops
// the copy running now and resumes the conversation. The same create the New
// Workspace dialog's SSH backend runs — its placeholder row, its host-key
// prompt, its errors — with the takeover as the terminal's command.
async function takeOverOnHost(
  s: LiveSession,
  plan: Extract<LivePlan, { kind: "ssh" }>,
  opts: { dive: boolean },
): Promise<void> {
  const built = buildSshSpec({
    auto: false,
    prompt: "",
    teach: false,
    host: plan.target,
    name: plan.label,
    cmd: "",
    remotePath: plan.path,
    identity: plan.identity ?? "",
    extraArgs: [],
  });
  if (!built.ok) {
    editor.setStatus(editor.t("status.external_cannot_open", { name: s.title, why: built.error }));
    return;
  }
  if (built.spec.backend === "ssh") built.spec.spec.command = plan.command;
  editor.setStatus(editor.t("status.external_taking_over", { name: s.title, host: plan.target }));
  await startPendingWorkspace(built.spec, { visit: opts.dive });
}

// Open an external session row as a workspace here, or its page where it has
// no other way in (a Codex Cloud task). `dive` hands the keyboard to it.
async function openLiveSession(key: string, opts: { dive: boolean }): Promise<void> {
  const s = liveByKey(key);
  if (!s) return;
  const plan: LivePlan = externalPlan(s);
  if (plan.kind === "none") {
    editor.setStatus(editor.t("status.external_cannot_open", { name: s.title, why: plan.why }));
    return;
  }
  if (plan.kind === "browser") {
    openLiveOutside(s, plan.url);
    return;
  }
  if (plan.kind === "teleport") {
    // The checkout is the user's to choose.
    teleportLiveSession(key);
    return;
  }
  if (plan.kind === "ssh") {
    await takeOverOnHost(s, plan, opts);
    return;
  }
  let id: number;
  // One workspace per directory: a session whose directory is already open
  // (a second session in the same checkout) joins that workspace.
  const existing = [...orchestratorSessions.values()].find(
    (w) => w.id > 0 && !w.remote && liveNormPath(w.root) === liveNormPath(plan.root),
  );
  if (existing) {
    id = existing.id;
    if (id !== editor.activeWindow()) editor.setActiveWindow(id);
  } else {
    try {
      // A cloud session's directory is ours to make (under the data dir).
      editor.createDir(editor.localPath(plan.root));
      const result = await editor.createWindowWithTerminal({
        root: plan.root,
        label: plan.label,
        cwd: plan.root,
        command: plan.command,
        // The tab says which agent, not `sh` (a Codex task runs through one).
        title: plan.command ? s.agent : undefined,
        allowScript: FRESH_CLI_ALLOW_SCRIPT,
      });
      id = result.windowId;
      // Not a worktree this editor made: nothing to remove on Delete.
      editor.setWindowState("project_path", plan.root);
      editor.setWindowState("shared_worktree", true);
      orchestratorSessions.set(id, {
        id,
        stableId: result.stableId || undefined,
        label: customNameFor(result.stableId || undefined, plan.root) ?? plan.label,
        hostLabel: plan.label,
        root: plan.root,
        projectPath: plan.root,
        sharedWorktree: true,
        terminalId: result.terminalId,
        state: "idle",
        lastOutputAt: null,
        createdAt: Date.now(),
      });
    } catch (e) {
      editor.setStatus(editor.t("status.attach_failed", {
        error: e instanceof Error ? e.message : String(e),
      }));
      return;
    }
  }
  if (plan.note) editor.setStatus(editor.t("status.external_in_place", { name: s.title }));
  if (opts.dive && dockMode && openPanel) {
    dockDiveBlur = true;
    dockBlurred = true;
    editor.floatingPanelControl(openPanel.id(), "blur", 0);
  } else if (dockMode && openPanel) {
    refreshOpenDialog();
    syncDockSelectionToActive();
  }
}

// A flat, depth-first traversal of the dock hierarchy: each entry is
// either a user folder or a session leaf, in render order. Built by
// `buildDockTree`, mirrored 1:1 with the emitted `TreeNode[]`.
type DockNode =
  | { kind: "folder"; folderId: string }
  | { kind: "session"; sessionId: number }
  // A row of the external sessions group (whose own header is a `folder` node with
  // a reserved `__external:<agent>` id, so it folds like one).
  | { kind: "live"; liveKey: string };

interface DockTree {
  nodes: TreeNode[];
  keys: string[];
  model: DockNode[];
}

// Turn the filtered session list into the tree the dock renders:
// user folders (nested) with their member sessions, then the ungrouped
// sessions at top level. When a search is active, folders with no
// matching descendant are dropped so results aren't buried under empty
// folders.
function buildDockTree(filtered: number[]): DockTree {
  const nodes: TreeNode[] = [];
  const keys: string[] = [];
  const model: DockNode[] = [];

  const membersByFolder = new Map<string | null, number[]>();
  for (const id of filtered) {
    const fid = folderOfSession(id);
    const arr = membersByFolder.get(fid) ?? [];
    arr.push(id);
    membersByFolder.set(fid, arr);
  }
  // External sessions the user filed into a folder show there (they are
  // still external: filing forks nothing); the rest stay in their
  // product's group, emitted last.
  const allLive = dockMode ? externalVisible() : [];
  const liveByFolder = new Map<string, LiveSession[]>();
  const liveUnfiled: LiveSession[] = [];
  for (const s of allLive) {
    const fid = externalFolderOf(s.key);
    if (fid) liveByFolder.set(fid, [...(liveByFolder.get(fid) ?? []), s]);
    else liveUnfiled.push(s);
  }
  const countRec = (fid: string): number => {
    let n = (membersByFolder.get(fid) ?? []).length + (liveByFolder.get(fid)?.length ?? 0);
    for (const c of childFoldersOf(fid)) n += countRec(c.id);
    return n;
  };
  // Every session under a folder, recursively — for the attention
  // roll-up (`●2 ✓1`) on the folder row.
  const membersRec = (fid: string): number[] => {
    const out = [...(membersByFolder.get(fid) ?? [])];
    for (const c of childFoldersOf(fid)) out.push(...membersRec(c.id));
    return out;
  };
  // …and the external sessions filed under it, counted by their own state,
  // so a collapsed folder can't hide one of those that needs you either.
  const liveRec = (fid: string): LiveSession[] => {
    const out = [...(liveByFolder.get(fid) ?? [])];
    for (const c of childFoldersOf(fid)) out.push(...liveRec(c.id));
    return out;
  };
  const rollupRec = (fid: string): { blocked: number; done: number } => {
    const r = attentionCounts(membersRec(fid));
    for (const s of liveRec(fid)) {
      if (s.state === "blocked") r.blocked++;
      else if (s.state === "done") r.done++;
    }
    return r;
  };
  const searching = (openDialog?.filter.value ?? "") !== "";
  // A drag in progress: the row lifted, and the row a drop now would land in.
  const lifted = dockDrag?.key ?? null;
  // A drop being previewed keeps its folder lit until the row lands.
  const dropKey = dockDropTargetKey() ?? pendingDockDrop?.landKey ?? null;
  const liftedGroup = lifted?.startsWith(LIVE_NODE_PREFIX)
    ? liveByKey(lifted.slice(LIVE_NODE_PREFIX.length))?.agent ?? null
    : null;

  const emitFolder = (f: DockFolder, depth: number): void => {
    const entry = folderNodeEntry(f, countRec(f.id), rollupRec(f.id));
    nodes.push(
      treeNode(folderNodeKey(f.id) === dropKey ? dropTargetEntry(entry) : entry, {
        depth,
        hasChildren: true,
      }),
    );
    keys.push(folderNodeKey(f.id));
    model.push({ kind: "folder", folderId: f.id });
  };
  // "card" density (dock only) renders session leaves as fixed-height
  // multi-row cards inside a rounded border (`cardBorders` on the
  // tree); "compact" keeps the single-line row. Folders stay one
  // single-row line either way.
  const card = dockMode && dockView === "card";
  const emitSession = (id: number, depth: number): void => {
    const plain = card ? sessionCardPrimary(id) : sessionNodeEntry(id);
    // Choosing a folder: a workspace is not a target. Dragged: lifted.
    const primary = movePick
      ? dimEntry(plain)
      : sessionNodeKey(id) === lifted ? liftedEntry(plain) : plain;
    nodes.push(
      treeNode(primary, {
        depth,
        hasChildren: false,
        // No gutter: a row starts where a sibling folder's ▼ does, so rows
        // and folders at one level line up (at the dock's edge for the top
        // level).
        flush: true,
        // Dragged onto another row, it is filed where that row is.
        draggable: true,
        extraLines: card ? sessionCardExtraLines(id) : undefined,
      }),
    );
    keys.push(sessionNodeKey(id));
    model.push({ kind: "session", sessionId: id });
  };
  const emitLive = (s: LiveSession, depth: number): void => {
    const plain = card ? liveCardPrimary(s) : liveNodeEntry(s);
    const primary = movePick
      ? dimEntry(plain)
      : liveNodeKey(s.key) === lifted ? liftedEntry(plain) : plain;
    nodes.push(
      treeNode(primary, {
        depth,
        hasChildren: false,
        flush: true,
        draggable: true,
        extraLines: card ? liveCardExtraLines(s) : undefined,
      }),
    );
    keys.push(liveNodeKey(s.key));
    model.push({ kind: "live", liveKey: s.key });
  };
  const walk = (parent: string | null, depth: number): void => {
    for (const f of childFoldersOf(parent)) {
      if (searching && countRec(f.id) === 0) continue;
      emitFolder(f, depth);
      walk(f.id, depth + 1);
      for (const sid of membersByFolder.get(f.id) ?? []) emitSession(sid, depth + 1);
      for (const s of liveByFolder.get(f.id) ?? []) emitLive(s, depth + 1);
    }
  };
  // Workspaces in no folder first, then the folders.
  for (const sid of membersByFolder.get(null) ?? []) emitSession(sid, 0);
  walk(null, 0);

  // The external sessions groups, last: the dock's own workspaces come first.
  // Absent while there is nothing in them (or the feed plugin is not loaded).
  for (const group of EXTERNAL_GROUPS) {
    const live = liveUnfiled.filter((s) => s.agent === group);
    // A group whose source failed (a sign-in that expired) stays, empty, so
    // its menu can say what went wrong; and while one of its sessions is
    // dragged from a folder, so the way home has a row to light.
    if (live.length === 0 && externalGroupProblems(group).length === 0 && liftedGroup !== group) {
      continue;
    }
    const plainHeader = externalGroupEntry(group, live);
    const header = movePick
      ? dimEntry(plainHeader)
      : externalGroupKey(group) === dropKey ? dropTargetEntry(plainHeader) : plainHeader;
    nodes.push(treeNode(header, { depth: 0, hasChildren: live.length > 0 }));
    keys.push(externalGroupKey(group));
    model.push({ kind: "folder", folderId: externalFolderId(group) });
    for (const s of live) emitLive(s, 1);
  }

  return { nodes, keys, model };
}

// One tree row for a folder: the (bold) name — the tree's own ▼/▶ already
// says it is a folder, so no glyph of its own spends two more columns on
// every level — the recursive session count in dim parentheses, and — so a collapsed
// folder can't hide a workspace that needs you — the roll-up of its
// members' blocked (`●n`) and done (`✓n`) counts in the state colours.
function folderNodeEntry(
  f: DockFolder,
  count: number,
  rollup: { blocked: number; done: number } = { blocked: 0, done: 0 },
): TextPropertyEntry {
  const segs: Entry[] = [
    { text: f.name, style: { bold: true } },
  ];
  if (count > 0) {
    segs.push({ text: `  (${count})`, style: { fg: "ui.menu_disabled_fg" } });
  }
  if (rollup.blocked > 0) {
    const sym = STATE_SYMBOL.blocked;
    segs.push({ text: `  ${sym.glyph}${rollup.blocked}`, style: { fg: sym.fg, bold: true } });
  }
  if (rollup.done > 0) {
    const sym = STATE_SYMBOL.done;
    segs.push({ text: `  ${sym.glyph}${rollup.done}`, style: { fg: sym.fg, bold: true } });
  }
  return styledRow(segs as Parameters<typeof styledRow>[0]);
}

// ── Pending placeholder row presentation (single source of truth) ─────────
//
// A being-created placeholder is drawn on four surfaces with different
// shapes: the compact tree line (`sessionNodeEntry`), the card continuation
// lines (`sessionCardExtraLines`), the modal pill (`renderPendingPillSpec`),
// and the preview pane (`buildPreviewEntries`). The *shape* differs per
// surface, but the phase → colour / affordance mapping must not: these
// helpers own it so the surfaces can't drift (they had — creating rows
// disagreed on the hint and on whether the message italicised).

// Message colour: red once the create has failed, amber while it is still
// creating or is paused (interrupted, awaiting resume).
function pendingMsgFg(p: PendingCreate): string {
  return p.phase === "error" ? "diagnostic.error_fg" : "diagnostic.warning_fg";
}

// `error` and `paused` are actionable — Enter retries / resumes them — while
// `creating` is passive (the create is running; the only action is Dismiss).
function pendingActionable(p: PendingCreate): boolean {
  return p.phase !== "creating";
}

// The one-line action hint for a pending row's phase: retry/resume when
// actionable, otherwise the "you can still dismiss this" affordance.
function pendingHintText(p: PendingCreate): string {
  return pendingActionable(p)
    ? editor.t("dock.pending_retry_hint")
    : editor.t("dock.pending_dismiss_hint");
}

// The workspace the dock's highlighted node stands for, when it is a session
// row at all (a folder header is not).
function dockSelectedSession(): AgentSession | null {
  const key = openDialog?.dockSelKey;
  if (!key || !key.startsWith(SESSION_NODE_PREFIX)) return null;
  return orchestratorSessions.get(Number(key.slice(SESSION_NODE_PREFIX.length))) ?? null;
}

// The backend target (host / ns·pod) as a trailing row segment — unless the
// label already carries it.
//
// A remote row's label is `<name> · ssh:<target>`, so appending the bare target
// after it prints the machine twice: exactly the duplication the cold study
// reported, and only half-fixed when the name was added to the label. On a
// narrow dock the repeat is not merely redundant, it is destructive: the row is
// one line, and the duplicate pushes the pending status — the one part that
// changes while a workspace is being created — off the end, leaving a row that
// says what the session is but never what it is doing.
function remoteDetailSegs(s: AgentSession): Entry[] {
  const detail = s.remote?.detail;
  if (!detail || s.label.includes(detail)) return [];
  return [{
    text: "  " + detail,
    style: { fg: remoteStateFg(s.remote!.state), italic: true },
  }];
}

// One tree row for a session leaf: state glyph, optional remote facet,
// and the name (highlighted when it's the active window). A single
// line — the tree owns indentation and the disclosure column, so the
// rich two-line PR pill of the modal picker is traded for a compact,
// nestable row here. The branch is deliberately dropped in this density
// (it's the "compact" trade — card view carries it on its second line).
function sessionNodeEntry(id: number): TextPropertyEntry {
  const s = orchestratorSessions.get(id);
  if (!s) return styledRow([{ text: editor.t("pill.unknown") }]);
  const segs: Entry[] = [stateGlyphEntry(s)];
  if (s.remote) {
    segs.push({
      text: REMOTE_GLYPH[s.remote.kind] + " ",
      style: { fg: remoteStateFg(s.remote.state), bold: true },
    });
  }
  // No "active" styling here, deliberately. The dock has exactly one
  // highlight — the tree's — and `buildDockSpec` keeps it on the active
  // session whenever the dock is blurred, so the highlight *is* the
  // answer to "which workspace am I in". A second marker on the name
  // could only ever agree with it or contradict it.
  segs.push({ text: s.label, style: { bold: true } });
  // A remote session surfaces its backend target (host / ns·pod), coloured
  // by the connection state — the same detail the pill shows on the right,
  // and skipped when the label already names it (see `remoteDetailSegs`).
  segs.push(...remoteDetailSegs(s));
  // A discovered on-disk worktree keeps its "· on-disk" tag — the "this
  // row isn't an open session yet" indicator the pill also shows.
  if (s.discovered) {
    segs.push({
      text: "  " + editor.t("pill.on_disk_worktree"),
      style: { fg: "ui.menu_disabled_fg", italic: true },
    });
  }
  // A being-created placeholder trails its status on the single compact line
  // (there's no second row to put it on).
  if (s.pending) {
    segs.push({
      text: "  " + s.pending.message,
      style: { fg: pendingMsgFg(s.pending), italic: true },
    });
  }
  return styledRow(segs as Parameters<typeof styledRow>[0]);
}

// The dock's "card" density renders each session leaf as a fixed
// 2-content-row card inside the tree; with `cardBorders` the host wraps
// those rows in a rounded `╭─…─╮` border (4 screen rows total). Two
// rows, each one "what it is" on the left and "how it's doing" flush
// right, so the status columns line up down the dock:
//
//   ╭──────────────────────────────╮
//   │ * fresh-27            ↑2 +14 │   name              git
//   │ ▸ fix/wrapped-nav   PR #2784 │   branch / project  PR
//   ╰──────────────────────────────╯
//
// It was three rows: the third held the PR badge and stood empty on
// every session without one, and the branch shared the middle row with
// the git summary as a single right-aligned group — which left it
// floating in the middle of the card instead of starting at the left
// edge. The name-repeating branch (a worktree branch usually *is* the
// workspace name) and the project tag beside the name were dropped for
// the same reason: they spent a card's scarce width on what the row
// already said.
const DOCK_CARD_HEIGHT = 2;

// A card row split into a left group and a right group flush against
// the card's right border. Tree card rows are plain text entries (no
// host flex spacer like the modal pill's `flexLine`), so the split
// point rides along as a byte offset and the host's `render_tree_card`
// — which knows the card's *actual* inner width, responsive or dragged
// — inserts the gap. Plugin-side padding could only estimate that width
// and drifted at every other one.
function cardSplitRow(left: Entry[], right: Entry[]): TextPropertyEntry {
  const row = styledRow([...left, ...right] as Parameters<typeof styledRow>[0]);
  if (right.length === 0) return row;
  row.properties = {
    align: "between",
    splitByte: left.reduce((n, e) => n + utf8Len(e.text), 0),
  };
  return row;
}

// Truncate to `cols` display columns, ellipsising when it doesn't fit.
// Code-point aware (`Array.from`), so a multi-byte name can't be cut
// mid-character.
function capText(s: string, cols: number): string {
  const chars = Array.from(s);
  if (chars.length <= cols) return s;
  return chars.slice(0, Math.max(1, cols - 1)).join("") + "…";
}

// Columns a group of entries occupies, for the left-group cap below.
function entriesWidth(entries: Entry[]): number {
  return entries.reduce((n, e) => n + Array.from(e.text).length, 0);
}

// Inner width of a card at the dock's default width — an estimate (the
// dock can be dragged), used only to cap the branch so it doesn't shove
// the right-hand group off the row. The host does the exact alignment.
function cardInnerColsEstimate(): number {
  return Math.max(12, dockContentCols(dockWidth()) - 2);
}

// Card line 1 (the tree node's primary text): state glyph, optional
// remote facet, the name (highlighted when active) and — for a remote
// session — its backend target, with the git summary flush right.
// Distinct from the compact `sessionNodeEntry`, which trails the git
// summary on the single line it has.
function sessionCardPrimary(id: number): TextPropertyEntry {
  const s = orchestratorSessions.get(id);
  if (!s) return styledRow([{ text: editor.t("pill.unknown") }]);
  const segs: Entry[] = [stateGlyphEntry(s)];
  if (s.remote) {
    segs.push({
      text: REMOTE_GLYPH[s.remote.kind] + " ",
      style: { fg: remoteStateFg(s.remote.state), bold: true },
    });
  }
  // See `sessionNodeEntry`: the tree's highlight is the only one.
  segs.push({ text: s.label, style: { bold: true } });
  // A remote session surfaces its backend target (host / ns·pod) coloured
  // by the connection state — pill parity (the pill shows it at the right
  // end of line 1), and skipped when the label already names it.
  segs.push(...remoteDetailSegs(s));
  // Right group. A being-created placeholder has no git summary; it gets
  // the one-key affordance instead ("↵ Retry"), so the row below is free
  // for the whole status message.
  if (s.pending) {
    return cardSplitRow(
      segs,
      pendingActionable(s.pending)
        ? [{
          text: "↵ " + editor.t("dock.ctx_retry"),
          style: { fg: "ui.menu_disabled_fg", italic: true },
        }]
        : [],
    );
  }
  return cardSplitRow(segs, gitLineParts(s).right);
}

// Card line 2 (the continuation row): what this workspace *is* on the
// left — its branch when that says something the name doesn't, else the
// project it belongs to — and its PR badge (or the on-disk tag) flush
// right.
function sessionCardExtraLines(id: number): TextPropertyEntry[] {
  const s = orchestratorSessions.get(id);
  if (!s) return [];
  // A being-created placeholder spends the row on its status message
  // (the retry affordance sits on line 1).
  if (s.pending) {
    const p = s.pending;
    return [
      styledRow([{
        text: p.message,
        style: { fg: pendingMsgFg(p), italic: pendingActionable(p) },
      }]),
    ];
  }
  const dim = "ui.menu_disabled_fg";
  const right = prLineEntries(s);
  // The branch earns the row only when it differs from the workspace
  // name — a worktree's branch is usually named after it, and printing
  // it twice was pure noise. Otherwise the project takes the slot: it's
  // the context the name doesn't carry. `(detached)` is reserved for a
  // real repo with no branch; a plain directory just shows its project.
  const branch = s.branch ||
    (s.discovered
      ? editor.t("pill.branch_worktree")
      : s.git?.info
      ? editor.t("pill.branch_detached")
      : "");
  const showBranch = branch !== "" && branch !== s.label;
  const proj = editor.pathBasename(projectKeyOf(s));
  const icon = showBranch ? BRANCH_ICON : PROJECT_ICON;
  const text = showBranch ? branch : proj;
  // Nothing to say that the name doesn't already say (a plain folder
  // opened as its own project, whose label *is* the folder). The row
  // stays empty rather than echoing the line above it.
  if (text === s.label) {
    return [cardSplitRow(right.length > 0 ? [] : [{ text: " " }], right)];
  }
  // Cap the branch/project so the badge keeps its columns: the host
  // truncates the row's *end*, which is the badge. Budget = the card's
  // inner width less this row's icon (2 cols), the badge, and the one
  // column that always separates the two groups.
  const cap = cardInnerColsEstimate() - 2 - entriesWidth(right) -
    (right.length > 0 ? 1 : 0);
  return [
    cardSplitRow(
      [
        { text: icon + " ", style: { fg: dim } },
        { text: capText(text, Math.max(8, cap)), style: { fg: dim, italic: !showBranch } },
      ],
      right,
    ),
  ];
}

// Per-session content summary keyed by canonical session root, built
// from the on-disk workspace files. The restored shell windows don't
// carry their open-tab layout (it's lazily re-warmed on first dive), so
// the workspace file is the only place to learn how much a session
// holds. Rebuilt each time the picker opens. A session is "trivial"
// when it has no terminal and at most one real file/unnamed buffer —
// the empty-unnamed-buffer and single-file cases the filter targets.
interface SessionContent {
  files: number;
  hasTerminal: boolean;
  trivial: boolean;
}
const sessionContentByRoot = new Map<string, SessionContent>();

// Roots from the editor (`WindowInfo.root`) and from workspace files
// (`working_dir`) are both canonical absolute paths, but normalise a
// trailing slash so the two always key the same map entry.
function normRoot(p: string): string {
  return p.length > 1 && p.endsWith("/") ? p.slice(0, -1) : p;
}

// Scan `<dataDir>/workspaces/*.json` and summarise each session's open
// content. Mirrors the host's own `discover_sessions` (which keys on the
// file's `working_dir`), so a root matches regardless of how the
// filename was percent-encoded. Best-effort: unreadable / unparseable
// files are skipped, and a missing summary is treated as "not trivial"
// (shown) by the filter, so we never hide a session we couldn't classify.
function scanSessionContent(): void {
  sessionContentByRoot.clear();
  const dir = editor.pathJoin(editor.getDataDir(), "workspaces");
  let entries: DirEntry[];
  try {
    entries = editor.readDir(editor.localPath(dir));
  } catch {
    return;
  }
  if (!entries) return;
  for (const e of entries) {
    if (!e.is_file || !e.name.endsWith(".json")) continue;
    const raw = editor.readFile(editor.localPath(editor.pathJoin(dir, e.name)));
    if (!raw) continue;
    let ws: Record<string, unknown>;
    try {
      ws = JSON.parse(raw);
    } catch {
      continue;
    }
    const wd = ws["working_dir"];
    if (typeof wd !== "string") continue;
    let files = 0;
    let hasTerminal = Array.isArray(ws["terminals"]) &&
      (ws["terminals"] as unknown[]).length > 0;
    const splits = ws["split_states"];
    if (splits && typeof splits === "object") {
      for (const sv of Object.values(splits as Record<string, unknown>)) {
        const tabs = (sv as Record<string, unknown> | null)?.["open_tabs"];
        if (!Array.isArray(tabs)) continue;
        for (const t of tabs) {
          if (t && typeof t === "object") {
            if ("File" in t || "Unnamed" in t) files++;
            else if ("Terminal" in t) hasTerminal = true;
          }
        }
      }
    }
    sessionContentByRoot.set(normRoot(wd), {
      files,
      hasTerminal,
      trivial: !hasTerminal && files <= 1,
    });
  }
}

const OPEN_MODE = "orchestrator-open";

// =============================================================================
// Session-list reconciliation
// =============================================================================

// Remote facet derived from the host's `WindowInfo.remote` backend identity.
// Present for SSH/Kubernetes sessions — including *dormant* ones restored
// from disk that have never connected this run — so their dock rows carry
// the backend glyph + detail and a disconnected ("stopped") state instead of
// masquerading as local sessions. Plugin-managed backends (devcontainer)
// carry no host facet; theirs still arrives via `pendingRemoteFacet`.
function backendFacet(info: WindowInfo): AgentSession["remote"] | undefined {
  if (!info.remote) return undefined;
  return {
    kind: info.remote.kind as SessionBackend,
    detail: info.remote.detail,
    state: info.remote.connected ? "running" : "stopped",
  };
}

// Window ids we've deliberately closed as part of a lifecycle action
// (Delete / Archive / Kill). `editor.closeWindow` is asynchronous — the
// host keeps reporting the window from `listWindows()` for a beat after we
// drop it from the model — so without this guard the very next
// `refreshOpenDialog` → `reconcileSessions` resurrects the workspace the
// user just deleted from that stale snapshot, leaving a deleted row
// lingering in the dock (and, whenever the healing reconcile lost the
// race, staying there for good). An id is removed from the set once the
// host confirms the close (the window leaves `listWindows()`), or by the
// `window_closed` hook.
const closingWindowIds = new Set<number>();

// The editor reads only the launch directory's workspaces at startup; the
// rest of the registry is read once something lists them to the user. The
// dock and the picker are that something: the first time either lists
// workspaces, ask for the rest and redraw when they are in.
let allWorkspacesRequested = false;
function requestAllWorkspaces(): void {
  if (allWorkspacesRequested) return;
  allWorkspacesRequested = true;
  void editor.loadWorkspaces().then(() => {
    reconcileSessions();
    refreshOpenDialog();
  });
}

function reconcileSessions(): void {
  const editorSessions = editor.listWindows();
  const seen = new Set<number>();
  for (const s of editorSessions) {
    seen.add(s.id);
    // A window we just closed for a lifecycle action still shows up in the
    // host snapshot until the deferred close lands. Keep it out of the
    // model rather than re-adding the row the user just deleted.
    if (closingWindowIds.has(s.id)) {
      orchestratorSessions.delete(s.id);
      continue;
    }
    const existing = orchestratorSessions.get(s.id);
    if (!existing) {
      // A born-attached remote window (created by core after
      // `attachRemoteAgent({ window: true })`) surfaces here for the first
      // time. Core makes it the *active* window, so claim the pending facet
      // only for the active id — otherwise a pre-existing untracked window
      // processed first would wrongly grab it. Cleared once claimed.
      const remote =
        pendingRemoteFacet && s.id === editor.activeWindow()
          ? pendingRemoteFacet
          : undefined;
      if (remote) pendingRemoteFacet = null;
      orchestratorSessions.set(s.id, {
        id: s.id,
        stableId: s.stable_id || undefined,
        label: customNameFor(s.stable_id || undefined, s.root) ?? s.label,
        hostLabel: s.label,
        root: s.root,
        projectPath: s.project_path,
        sharedWorktree: s.shared_worktree ?? false,
        terminalId: null,
        // Idle until the terminal actually prints something — we have
        // no evidence of work yet. `lastOutputAt` is the real signal;
        // `state` is recomputed from it at render time.
        state: "idle",
        lastOutputAt: null,
        createdAt: Date.now(),
        remote: remote ?? backendFacet(s),
      });
    } else {
      // Track the host's raw label, then re-resolve the display name (a
      // manual rename or terminal auto-name overrides it). The stable id
      // is adopted first — the manual-name lookup is keyed by it.
      existing.stableId = s.stable_id || undefined;
      existing.hostLabel = s.label;
      applyResolvedLabel(existing);
      existing.root = s.root;
      existing.projectPath = s.project_path;
      if (s.shared_worktree != null) existing.sharedWorktree = s.shared_worktree;
      // Keep the backend facet in step with the host's view: adopt it when
      // missing (a dormant session that predates the facet, or one whose
      // plugin-side record was created before the snapshot carried it), and
      // track the connected/disconnected flip so a promoted or dropped
      // backend re-badges the row. A plugin-owned lifecycle state
      // ("starting") is left alone — it resolves through its own path.
      const facet = backendFacet(s);
      if (facet) {
        if (!existing.remote) {
          existing.remote = facet;
        } else if (existing.remote.state !== "starting") {
          existing.remote.state = facet.state;
        }
      } else if (existing.remote && existing.remote.state !== "starting") {
        // The window detached: drop the badge, or the row keeps naming a
        // backend it has left. "starting" is left alone; the connect sets it
        // before the window has a backend to report.
        existing.remote = undefined;
      }
    }
  }
  // Live windows live in the positive id space; their absence from
  // `listWindows()` means they were closed, so drop them. Discovered
  // worktrees (negative ids) are NOT backed by a window and must
  // survive this sweep — they're pruned separately, against the
  // on-disk worktree set, by `refreshDiscoveredWorktrees`.
  for (const id of orchestratorSessions.keys()) {
    if (id > 0 && !seen.has(id)) orchestratorSessions.delete(id);
  }
  // Retire tombstones whose window the host has now actually closed: a
  // live window is added to `seen` above (before the tombstone skip), so
  // `!seen.has(id)` means the close landed and `listWindows()` no longer
  // reports it. Clearing it keeps a future window that reuses the id from
  // being wrongly suppressed.
  for (const id of [...closingWindowIds]) {
    if (!seen.has(id)) closingWindowIds.delete(id);
  }
  // A worktree that's now open as a live window must not also linger
  // as a discovered row. Drop any discovered entry whose root a live
  // session already occupies.
  const liveRoots = new Set<string>();
  for (const s of orchestratorSessions.values()) {
    if (!s.discovered) liveRoots.add(s.root);
  }
  for (const [id, s] of orchestratorSessions) {
    if (s.discovered && liveRoots.has(s.root)) orchestratorSessions.delete(id);
  }
}

// =============================================================================
// Discovered-worktree scan
//
// Surfaces worktrees that exist on disk but have no live editor
// window, so the user doesn't have to add them by hand. Because
// open sessions can span several repos, `git worktree list` must
// run once *per project*: the scan set is the distinct canonical
// repo roots of every live session, plus the editor's cwd repo.
// Each linked worktree not already open (and not an
// orchestrator-internal tree) becomes a discovered row that dives
// by attaching a fresh session to it.
// =============================================================================

let discoveryInFlight = false;

function isInternalWorktreePath(path: string): boolean {
  // The `.archived/` graveyard is orchestrator bookkeeping, not a user
  // session.
  //
  // `.sync-workspace` is kept here although nothing creates one any more: it
  // was the worktree the removed session-list-on-a-branch mechanism
  // maintained inside the user's own repository, and anyone who ran a build
  // that had it still has one registered in `git worktree list`. Dropping the
  // filter would turn that leftover into a discovered session row — a stray
  // row appearing out of nowhere on upgrade. It costs one string compare.
  return path.includes(".sync-workspace") || path.includes("/.archived/");
}

async function refreshDiscoveredWorktrees(): Promise<void> {
  if (discoveryInFlight) return;
  discoveryInFlight = true;
  try {
    reconcileSessions();

    // (1) Candidate dirs: every live session's root + the editor
    //     cwd. Resolve each to its canonical main repo root and
    //     dedupe so a repo with N open worktrees is scanned once.
    const candidates = new Set<string>([editor.getCwd()]);
    for (const s of orchestratorSessions.values()) {
      if (!s.discovered) candidates.add(s.root);
    }
    const mainRoots = new Set<string>();
    for (const dir of candidates) {
      const canonical = await resolveCanonicalRepoRoot(dir);
      if (canonical) mainRoots.add(canonical);
    }

    // (2) Roots already occupied by a live session — discovered rows
    //     for these would be duplicates.
    const liveRoots = new Set<string>();
    for (const s of orchestratorSessions.values()) {
      if (!s.discovered) liveRoots.add(s.root);
    }

    // (3) Scan each repo and collect the linked worktrees worth
    //     surfacing.
    const foundPaths = new Set<string>();
    for (const repoRoot of mainRoots) {
      const listed = await listLinkedWorktrees(repoRoot);
      if (!listed) continue;
      for (const wt of listed.worktrees) {
        if (liveRoots.has(wt.path)) continue;
        if (isInternalWorktreePath(wt.path)) continue;
        foundPaths.add(wt.path);
        const id = discoveredIdFor(wt.path);
        const label = wt.branch || editor.pathBasename(wt.path);
        const existing = orchestratorSessions.get(id);
        if (existing) {
          existing.hostLabel = label;
          applyResolvedLabel(existing);
          existing.root = wt.path;
          existing.projectPath = listed.mainRoot;
          existing.branch = wt.branch;
        } else {
          orchestratorSessions.set(id, {
            id,
            label: customNameFor(undefined, wt.path) ?? label,
            hostLabel: label,
            root: wt.path,
            projectPath: listed.mainRoot,
            sharedWorktree: false,
            terminalId: null,
            // Discovered on-disk rows have no live terminal; they render
            // a `· on-disk` tag, not a pill, so state is moot — idle.
            state: "idle",
            lastOutputAt: null,
            createdAt: Date.now(),
            discovered: true,
            branch: wt.branch,
          });
        }
      }
    }

    // (4) Prune discovered rows that vanished from disk (or got
    //     opened, picked up by the liveRoots check above).
    for (const [id, s] of orchestratorSessions) {
      if (s.discovered && !foundPaths.has(s.root)) {
        orchestratorSessions.delete(id);
        discoveredIdByPath.delete(s.root);
      }
    }
  } finally {
    discoveryInFlight = false;
  }
  if (openPanel) refreshOpenDialog();
}

// =============================================================================
// Session display helpers
// =============================================================================

// A session counts as "working" only if its terminal printed something
// within this window. Agents are bursty — they pause to think or wait on
// the model between chunks — so a few seconds of grace keeps the dot from
// flickering idle mid-task. Too long and a finished agent reads as busy;
// 5s is a reasonable middle.
let IDLE_AFTER_MS = 5000;

// An output burst has to last at least this long before a quiet session
// counts as "done" (something to review). Shorter bursts are prompt
// redraws, a single echoed keystroke, a status line — not work.
let WORK_MIN_MS = 1500;

// How many trailing terminal lines `sessionState` inspects for a
// waiting-on-you prompt. Agents draw their question plus a short menu
// (`❯ 1. Yes  2. No`) so a handful of lines is enough.
let RECENT_LINES = 6;

// Lines that mean "the agent is waiting on the user", generic across Claude
// Code, Codex, Aider, Gemini and a plain shell `read -p`. Matched against the
// last RECENT_LINES lines only, so a question that scrolled off cannot keep a
// row blocked forever. Agent CLIs redesign their chrome constantly, so this
// built-in set is replaceable by data — see `loadDetectionRules`.
const BUILTIN_BLOCKED_SOURCES: string[] = [
  "\\(y\\/n\\)|\\[y\\/n\\]|\\(yes\\/no\\)|\\[y\\/N\\]|\\[Y\\/n\\]",
  "\\bdo you want to\\b",
  "\\b(proceed|continue|allow|approve|confirm|accept)\\?",
  "\\bpress (enter|return)\\b",
  "[❯>]\\s*1[.)]\\s*yes",
  "\\bdon'?t ask again\\b",
  "\\bwaiting for (your )?(input|approval|confirmation)\\b",
  "\\besc(ape)? to cancel\\b",
];
const BUILTIN_RULES_VERSION = 1;

// The rule set in force: where it came from and its version, for
// `explainState` and the CLI's `agent explain`.
interface DetectionRules {
  version: number;
  source: "built-in" | "file" | "url";
  blocked: string[];
  workMinMs?: number;
  idleAfterMs?: number;
  recentLines?: number;
}
let detectionRules: DetectionRules = {
  version: BUILTIN_RULES_VERSION,
  source: "built-in",
  blocked: BUILTIN_BLOCKED_SOURCES,
};
// The compiled rules and the sources they came from, in lockstep: a rule
// that does not compile is dropped from both, so an index into one names
// the same rule in the other (`explain` reports the source).
let BLOCKED_COMPILED_SOURCES: string[] = [];
let BLOCKED_PATTERNS: RegExp[] = compileBlocked(BUILTIN_BLOCKED_SOURCES);

// Compile rule sources case-insensitively, dropping any that do not parse
// (one bad rule in a fetched file must not disable detection).
function compileBlocked(sources: string[]): RegExp[] {
  const out: RegExp[] = [];
  const kept: string[] = [];
  for (const src of sources) {
    if (hasNestedQuantifier(src)) {
      editor.warn(`orchestrator: detection rule can backtrack catastrophically, skipped: ${src}`);
      continue;
    }
    try {
      out.push(new RegExp(src, "i"));
      kept.push(src);
    } catch {
      editor.warn(`orchestrator: detection rule does not compile, skipped: ${src}`);
    }
  }
  BLOCKED_COMPILED_SOURCES = kept;
  return out;
}

function detectionRulesFile(): string {
  return editor.pathJoin(editor.getDataDir(), "orchestrator", "detection-rules.json");
}

function parseDetectionRules(raw: string): Omit<DetectionRules, "source"> | null {
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return null;
  }
  if (!parsed || typeof parsed !== "object") return null;
  const p = parsed as Record<string, unknown>;
  // `Number.isFinite`, not `typeof === "number"`: `1e999` parses as `Infinity`,
  // beats every on-disk version, and `JSON.stringify` writes it back as
  // `null` — after which the file never parses again and the plugin silently
  // re-downloads and re-corrupts it on every start. `NaN` loses every
  // comparison instead, which is quieter but just as wrong.
  if (!Number.isFinite(p.version as number) || !Array.isArray(p.blocked)) return null;
  const blocked = p.blocked.filter((x): x is string => typeof x === "string" && x !== "");
  if (blocked.length === 0) return null;
  const num = (v: unknown): number | undefined =>
    typeof v === "number" && Number.isFinite(v) && v > 0 ? v : undefined;
  return {
    version: p.version as number,
    blocked,
    workMinMs: num(p.workMinMs),
    idleAfterMs: num(p.idleAfterMs),
    recentLines: num(p.recentLines),
  };
}

// Bounds on what a rules file may ask for. The patterns run on the plugin
// thread against every terminal line of every session, and when
// `detectionRulesUrl` is set the file is remote, mutable data — so the host
// serving it decides what this plugin executes on every render.
//
// **Length and count bound volume, not cost.** They are here because a file
// with ten thousand rules would be slow whatever the rules are. They do
// nothing about backtracking: `(a+)+$` is six characters, and against thirty
// `x`s it does not finish. That is what `hasNestedQuantifier` is for, and it
// is a heuristic, not a proof — it rejects a quantified group that contains a
// quantifier, which is the shape every published catastrophic pattern takes,
// and it does not catch ambiguous alternation (`(a|a)+`). JavaScript gives a
// regex no deadline, so a rule that gets past this and does not terminate
// hangs the plugin thread.
const RULES_MAX_PATTERNS = 64;
const RULES_MAX_PATTERN_LEN = 200;

// Star height of two or more: a group carrying a quantifier, itself
// quantified. `(a+)+`, `(a*)*`, `(?:x+y+)+`, `(a?)*`. Scans rather than
// parses — escapes are skipped, character classes are opaque, and `?` counts
// as an inner quantifier but not as an outer one, since `(a+)?` is bounded.
function hasNestedQuantifier(src: string): boolean {
  const outer: boolean[] = [];
  let quantified = false;
  let inClass = false;
  for (let i = 0; i < src.length; i++) {
    const c = src[i];
    if (c === "\\") {
      i++;
      continue;
    }
    if (inClass) {
      if (c === "]") inClass = false;
      continue;
    }
    if (c === "[") {
      inClass = true;
      continue;
    }
    if (c === "(") {
      outer.push(quantified);
      quantified = false;
      continue;
    }
    if (c === ")") {
      const inner = quantified;
      quantified = outer.pop() ?? false;
      const next = src[i + 1];
      if (inner && (next === "*" || next === "+" || next === "{")) return true;
      if (next === "*" || next === "+" || next === "?" || next === "{") quantified = true;
      continue;
    }
    if (c === "*" || c === "+" || c === "?" || c === "{") quantified = true;
  }
  return false;
}

function clampNum(v: number | undefined, lo: number, hi: number, dflt: number): number {
  return Math.min(hi, Math.max(lo, v ?? dflt));
}

// Returns whether the file's own patterns survived the bounds and the
// compiler. A caller that is about to persist the file needs to know: a file
// whose every rule is unusable must not be written, or the fallback repeats
// on every start with nothing to show for it.
function applyDetectionRules(rules: DetectionRules): boolean {
  const dropped = rules.blocked.filter((p) => p.length > RULES_MAX_PATTERN_LEN).length;
  if (dropped > 0) editor.warn(`orchestrator: ${dropped} detection rule(s) over ${RULES_MAX_PATTERN_LEN} chars, skipped`);
  let blocked = rules.blocked
    .filter((p) => p.length <= RULES_MAX_PATTERN_LEN)
    .slice(0, RULES_MAX_PATTERNS);
  let patterns = compileBlocked(blocked);
  // The bounds and the compiler both drop rules; between them they must not
  // leave nothing detecting, which would read as "no agent ever blocked".
  const usable = patterns.length > 0;
  let meta = rules;
  if (!usable) {
    editor.warn("orchestrator: no usable detection rule in the file, using the built-ins");
    blocked = BUILTIN_BLOCKED_SOURCES;
    patterns = compileBlocked(blocked);
    // **Say which rules are actually in force.** Keeping the file's version
    // and source here made `Explain State` and `agent explain --json` report
    // `v999 (url)` while the built-ins were doing the detecting.
    meta = { ...rules, version: BUILTIN_RULES_VERSION, source: "built-in" };
  }
  detectionRules = { ...meta, blocked };
  BLOCKED_PATTERNS = patterns;
  WORK_MIN_MS = clampNum(rules.workMinMs, 200, 60_000, 1500);
  IDLE_AFTER_MS = clampNum(rules.idleAfterMs, 1000, 120_000, 5000);
  RECENT_LINES = Math.floor(clampNum(rules.recentLines, 1, 50, 6));
  return usable;
}

// Load the rules file if there is one (else the built-ins), then — when
// `detectionRulesUrl` is set — fetch the published set and adopt it if its
// version is newer than what is on disk. Best-effort throughout: a missing
// file, a bad download or an unreachable host leaves the current rules.
// Set when the last load found a rules file it could not use, so a reload
// from the palette can say so instead of reporting the rules still in
// force as if the file had been read.
let detectionRulesProblem: string | null = null;
// Whether a rules download is already running; see `loadDetectionRules`.
let fetchInFlight = false;

async function loadDetectionRules(): Promise<DetectionRules> {
  const path = detectionRulesFile();
  const raw = editor.readFile(editor.localPath(path));
  const local = raw ? parseDetectionRules(raw) : null;
  detectionRulesProblem = null;
  if (local) applyDetectionRules({ ...local, source: "file" });
  else if (raw) {
    detectionRulesProblem = editor.pathBasename(path);
    editor.warn(`orchestrator: ${path} is not a rules file, using built-in rules`);
  }
  const url = (dockSettings().detectionRulesUrl ?? "").trim();
  if (url && /^https?:\/\//i.test(url)) {
    // The editor's own HTTP client, into a scratch file beside the rules;
    // the file only replaces the rules once it parses and is newer.
    const scratch = editor.pathJoin(editor.getDataDir(), "orchestrator", "detection-rules.fetched.json");
    // One fetch at a time. Two in flight — the palette's Reload while the
    // startup load is still running — write and read the same scratch file
    // and each can parse the other's half-written download. A unique name per
    // fetch would fix that too, but there is no delete in the plugin file API,
    // so the scratch files would accumulate without bound.
    if (fetchInFlight) return detectionRules;
    fetchInFlight = true;
    try {
      const r = await editor.httpFetch(url, scratch);
      const fetched = r.exit_code === 0 ? editor.readFile(editor.localPath(scratch)) : null;
      const remote = fetched ? parseDetectionRules(fetched) : null;
      if (!remote) {
        editor.warn(`orchestrator: could not fetch detection rules from ${url}: ${r.stderr || "not a rules file"}`);
      } else if (remote.version > (local?.version ?? 0)) {
        // **Apply first, persist only if it worked.** Writing before knowing
        // whether a single rule survives puts an unusable file on disk, where
        // it is re-read and re-rejected on every start, with the network no
        // longer involved.
        if (applyDetectionRules({ ...remote, source: "url" })) {
          editor.replaceFile(editor.localPath(path), JSON.stringify(remote, null, 2));
          editor.info(`orchestrator: detection rules v${remote.version} fetched from ${url}`);
        } else {
          editor.warn(`orchestrator: detection rules from ${url} had no usable rule, not saved`);
        }
      }
    } catch (e) {
      editor.warn(`orchestrator: detection rules fetch failed: ${String(e)}`);
    } finally {
      fetchInFlight = false;
    }
  } else if (url) {
    editor.warn(`orchestrator: detectionRulesUrl must be http(s): ${url}`);
  }
  return detectionRules;
}

// The most recent line of the agent terminal that reads as a question for
// the user, with the rule that matched it — or null when none does.
function agentQuestionMatch(s: AgentSession): { line: string; rule: string; index: number } | null {
  const lines = s.recentLines ?? [];
  for (let i = lines.length - 1; i >= 0; i--) {
    const idx = BLOCKED_PATTERNS.findIndex((re) => re.test(lines[i]));
    if (idx >= 0) {
      const rule = BLOCKED_COMPILED_SOURCES[idx] ?? String(BLOCKED_PATTERNS[idx]);
      return { line: lines[i], rule, index: idx };
    }
  }
  return null;
}

// The question line alone (the notice's repeat guard keys on it).
function agentQuestionLine(s: AgentSession): string | null {
  return agentQuestionMatch(s)?.line ?? null;
}

function agentWaitsForInput(s: AgentSession): boolean {
  return agentQuestionMatch(s) !== null;
}

// The decision chain behind a session's state, in plain words, so a wrong
// badge is a bug report with evidence: what the terminal said, how long
// ago, which rule fired, which rule set was in force.
interface StateExplanation {
  state: AgentState;
  reasons: string[];
  question: string | null;
  rule: string | null;
  outputAgeMs: number | null;
  osc: boolean | null;
  unseenWork: boolean;
  recentLines: string[];
  rules: { version: number; source: string };
}

function explainState(s: AgentSession): StateExplanation {
  const state = sessionState(s);
  const age = s.lastOutputAt === null ? null : Date.now() - s.lastOutputAt;
  const secs = (ms: number): string => `${(ms / 1000).toFixed(1)}s`;
  const q = agentQuestionMatch(s);
  const reasons: string[] = [];
  if (s.discovered) reasons.push("on-disk worktree with no live window");
  else if (s.pending) reasons.push("workspace still being created");
  else if (s.oscRunning === true) reasons.push("shell integration marks a command as running (OSC 133/9;4)");
  else if (age === null && s.terminalId === null) reasons.push("no agent terminal in this window");
  else if (age === null) reasons.push("the terminal has produced no output yet, or it exited");
  else {
    if (s.oscRunning === false) reasons.push("shell integration marks the last command finished");
    if (age < IDLE_AFTER_MS && s.oscRunning !== false) {
      reasons.push(`output ${secs(age)} ago, inside the ${secs(IDLE_AFTER_MS)} idle window`);
    } else {
      reasons.push(`quiet for ${secs(age)} (idle window ${secs(IDLE_AFTER_MS)})`);
      if (q) reasons.push(`line ${JSON.stringify(q.line)} matched rule ${q.index + 1}: /${q.rule}/i`);
      else reasons.push(`none of the last ${RECENT_LINES} lines reads as a question`);
      if (!q) {
        if (s.workedSinceSeen && s.id !== editor.activeWindow()) {
          reasons.push(`a burst of output of at least ${secs(WORK_MIN_MS)} arrived while another window was active and has not been viewed`);
        } else if (s.workedSinceSeen) {
          reasons.push("unseen work, but this window is active so it counts as seen");
        } else {
          reasons.push("no unseen work since the window was last viewed");
        }
      }
    }
  }
  return {
    state,
    reasons,
    question: q?.line ?? null,
    rule: q ? q.rule : null,
    outputAgeMs: age,
    osc: s.oscRunning ?? null,
    unseenWork: s.workedSinceSeen === true,
    recentLines: [...(s.recentLines ?? [])],
    rules: { version: detectionRules.version, source: detectionRules.source },
  };
}

function explainSummaryLine(s: AgentSession, ex: StateExplanation): string {
  const name = workspaceCustomName(s) || s.hostLabel || s.label;
  return `${STATE_SYMBOL[ex.state].glyph} ${name}: ${ex.state} — ${ex.reasons.join("; ")} (rules v${ex.rules.version}, ${ex.rules.source})`;
}

// Coarse activity for a session, derived from how recently its terminal
// produced output plus two heuristics over what it printed. This is the
// single source of truth — the stored `state` field is just a cache of
// this for persistence/sorting.
function sessionState(s: AgentSession): AgentState {
  // An explicit OSC activity signal (shell integration / progress) is
  // authoritative over the output-timing heuristic: a command running keeps
  // the workspace "working" even while it prints nothing.
  if (s.oscRunning === true) return "working";
  // No output ever: a window with no agent terminal has nothing to wait
  // on (idle); one that has a terminal we haven't heard from — or whose
  // terminal exited — is a blank ("unknown").
  if (s.lastOutputAt === null) return s.terminalId === null ? "idle" : "unknown";
  // A finished OSC command flips out of "working" at once rather than
  // riding out IDLE_AFTER_MS; otherwise recent output means working.
  if (s.oscRunning !== false && Date.now() - s.lastOutputAt < IDLE_AFTER_MS) {
    return "working";
  }
  // Quiet. A question on screen needs the user regardless of anything
  // else; otherwise unseen work is "done" until they look at it.
  if (agentWaitsForInput(s)) return "blocked";
  if (s.workedSinceSeen && s.id !== editor.activeWindow()) return "done";
  return "idle";
}

// How many live sessions currently need the user / have unseen work —
// the numbers on the dock's attention line and in the folder roll-ups.
function attentionCounts(ids: Iterable<number>): { blocked: number; done: number } {
  let blocked = 0;
  let done = 0;
  for (const id of ids) {
    const s = orchestratorSessions.get(id);
    if (!s || s.discovered || s.pending) continue;
    const st = sessionState(s);
    if (st === "blocked") blocked++;
    else if (st === "done") done++;
  }
  return { blocked, done };
}

// Record one terminal line for the blocked-prompt heuristic. Blank lines
// and pure control noise are skipped so a redraw can't push the real
// question out of the window; the buffer is capped at RECENT_LINES.
//
// Four escape shapes, not one, and the order matters: OSC first (it runs to
// a BEL or ST and would otherwise be eaten piecemeal), then CSI, then the
// charset designators and the remaining two-character escapes, then the bare
// C0 bytes an agent emits for a spinner. Tab survives; it is content.
//
// These rows are shown verbatim in the Explain popup, so a line that is only
// cursor-parking and a bell has to read as empty rather than as the question
// that blocked the agent.
function noteRecentLine(s: AgentSession, line: string): void {
  const clean = line
    .replace(/\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)?/g, "")
    .replace(/\x1b\[[0-9;?]*[ -\/]*[@-~]/g, "")
    .replace(/\x1b[()#][\x20-\x7e]/g, "")
    .replace(/\x1b[\x20-\x7e]/g, "")
    // eslint-disable-next-line no-control-regex
    .replace(/[\x00-\x08\x0b-\x1f\x7f]/g, "")
    .trim();
  if (clean === "") return;
  const lines = s.recentLines ?? [];
  if (lines[lines.length - 1] === clean) return;
  lines.push(clean);
  if (lines.length > RECENT_LINES) lines.splice(0, lines.length - RECENT_LINES);
  s.recentLines = lines;
}

// =============================================================================
// Attention notifications + jump
//
// The attention line only helps while the dock is in view, so a workspace
// that turns `blocked` or `done` while the user is elsewhere is also
// announced in the status bar — `● ux-3 needs you · F8 to jump` — with an
// optional bell, and `orchestrator_jump` takes the user there and back.
// =============================================================================

// Per-terminal last-output / exit stamps, for `runAgent`'s readiness check:
// a launch has to be judged by *its* terminal, not by whatever else prints in
// the same window (the shell that ran `fresh --cmd agent start`, say).
const terminalOutputAt = new Map<number, number>();
const terminalExitAt = new Map<number, number>();

// `runAgent` reads a stamp for the ~15s after a launch, so anything older is
// dead weight in a long-lived editor.
const TERMINAL_STAMP_TTL_MS = 60_000;

function reapTerminalStamps(): void {
  const cutoff = Date.now() - TERMINAL_STAMP_TTL_MS;
  for (const m of [terminalOutputAt, terminalExitAt]) {
    for (const [id, at] of [...m]) if (at < cutoff) m.delete(id);
  }
}

// Where "Jump Back" returns to: the window the first jump of a chain left.
let jumpReturnId: number | null = null;
// The windows visited by the current chain of jumps (blocked → done → …),
// so the same command walks each pending workspace once and then goes
// back, instead of bouncing between two that stay pending.
const jumpVisited = new Set<number>();
// The notice currently in the status bar, so it can be retired when its
// workspace is looked at or moves on. `setStatus` writes to whichever window
// is active at the time and only that window can clear it, so the notice has
// to remember where it landed or a retired one lingers there.
let lastNotice: { id: number; state: AgentState; windowId: number } | null = null;
const noticeWindows = new Set<number>();

function showNotice(text: string): void {
  editor.setStatus(text);
  noticeWindows.add(editor.activeWindow());
}

function clearNoticeHere(): void {
  editor.setStatus("");
  noticeWindows.delete(editor.activeWindow());
}

// No host API rings the terminal bell, so write BEL to the controlling tty
// from a child process; the terminal (or tmux, which forwards it) sounds it.
function ringBell(): void {
  try {
    void Promise.resolve(editor.spawnHostProcess("sh", ["-c", "printf '\\a' > /dev/tty"])).catch(
      () => undefined,
    );
  } catch {
    // No shell / no tty: the notice still shows.
  }
}

// `● name needs you · <key> to jump` — the key from the user's binding for
// `orchestrator_jump` when there is one, else the command's palette name.
function noticeText(s: AgentSession, st: AgentState): string {
  // The status bar's message slot is short, so: the workspace's own name
  // (rename or host label, not the `name · title` dock row), and the jump
  // key only when one is bound — the palette command is always there.
  const name = workspaceCustomName(s) || s.hostLabel || s.label;
  const body =
    st === "blocked"
      ? editor.t("notify.needs_you", { name })
      : editor.t("notify.done", { name });
  const key =
    editor.getKeybindingLabel("orchestrator_jump", "normal") ??
    editor.getKeybindingLabel("orchestrator_jump", null);
  return `${STATE_SYMBOL[st].glyph} ${body}` + (key ? ` ${editor.t("notify.jump_key", { key })}` : "");
}

// Announce every session whose state just became blocked/done while the
// user was elsewhere, and retire a notice whose workspace was looked at
// or moved on. Called wherever a state can change: terminal output, the
// idle sweep, a terminal exit, a window switch.
function sweepAttention(): void {
  const active = editor.activeWindow();
  const settings = dockSettings();
  const mode = settings.notifications ?? "all";
  if (noticeWindows.has(active) && lastNotice?.windowId !== active) clearNoticeHere();
  // One sweep can flip several sessions at once (they went quiet in the
  // same window); the status bar holds one line, so a needs-you wins over
  // a finished, and the bell rings once.
  let announce: { s: AgentSession; st: AgentState } | null = null;
  for (const s of orchestratorSessions.values()) {
    if (s.discovered || s.pending) continue;
    const st = sessionState(s);
    if (st === s.notifiedState) continue;
    s.notifiedState = st;
    if (s.id === active) continue;
    if (st !== "blocked" && st !== "done") continue;
    if (mode === "off" || (mode === "needs-you" && st !== "blocked")) continue;
    if (st === "blocked") {
      // `done` can't repeat without a fresh burst (activation clears it);
      // `blocked` can, so it is keyed on the question itself.
      const prompt = agentQuestionLine(s) ?? "";
      if (prompt === s.announcedPrompt) continue;
      s.announcedPrompt = prompt;
    }
    if (!announce || (st === "blocked" && announce.st !== "blocked")) announce = { s, st };
  }
  if (announce) {
    lastNotice = { id: announce.s.id, state: announce.st, windowId: active };
    showNotice(noticeText(announce.s, announce.st));
    if (settings.notifySound) ringBell();
  }
  if (lastNotice) {
    const s = orchestratorSessions.get(lastNotice.id);
    if (!s || s.id === active || sessionState(s) !== lastNotice.state) {
      if (lastNotice.windowId === active) clearNoticeHere();
      lastNotice = null;
    }
  }
}

// The workspace the user should look at next: blocked before done, each in
// the order the dock lists them, never the one they are already in.
function attentionTarget(): number | null {
  const active = editor.activeWindow();
  const live = [...orchestratorSessions.values()].filter(
    (s) => !s.discovered && !s.pending && s.id > 0 && s.id !== active && !jumpVisited.has(s.id),
  );
  const pick = (st: AgentState): number | null =>
    live.find((s) => sessionState(s) === st)?.id ?? null;
  return pick("blocked") ?? pick("done");
}

// Jump to what needs you; with nothing pending, the same command returns
// to where the last jump came from (so one key toggles there and back).
function jumpToAttention(): void {
  const target = attentionTarget();
  if (target === null) {
    if (jumpReturnId === null) {
      jumpVisited.clear();
      editor.setStatus(editor.t("notify.nothing"));
      return;
    }
    jumpBack();
    return;
  }
  const from = editor.activeWindow();
  // A fresh chain starts from wherever the user is; a continued one keeps
  // its original return point.
  if (!jumpVisited.has(from)) {
    jumpReturnId = from;
    jumpVisited.clear();
    jumpVisited.add(from);
  }
  jumpVisited.add(target);
  editor.setActiveWindow(target);
}

function jumpBack(): void {
  jumpVisited.clear();
  if (jumpReturnId === null || !orchestratorSessions.has(jumpReturnId)) {
    jumpReturnId = null;
    editor.setStatus(editor.t("notify.no_return"));
    return;
  }
  const to = jumpReturnId;
  jumpReturnId = editor.activeWindow();
  editor.setActiveWindow(to);
}

// Age is shown at DAY granularity on purpose. A finer (s/m/h) counter ticks
// every second/minute, and because the dock re-renders on the probe-poll
// cadence, each tick changed the serialized card → a real frame → a full
// dock teardown/rebuild, i.e. a scrollbar flicker and a dropped scroll
// gesture for a purely cosmetic counter. At day granularity the string is
// stable across the whole session's normal lifetime, so idle re-renders
// diff to nothing and the panel stays still.
function ageString(createdAt: number): string {
  const days = Math.max(0, Math.floor((Date.now() - createdAt) / 86_400_000));
  if (days <= 0) return "today";
  if (days === 1) return "1d";
  return `${days}d`;
}

// =============================================================================
// Status symbol
//
// Each live session shows a single status symbol in the row's left margin —
// before the checkbox and name — so every name lines up in the same column
// regardless of state. Activity is derived from how recently the session's
// terminal printed (see `sessionState`):
//
//   working : `*` in the warning/progress colour — terminal actively printing
//   idle    : `✓` in the added/green colour       — quiet / waiting / done
//
// `*` is ASCII; `✓` (U+2713) is a single-cell glyph present in essentially
// every terminal font — both avoid the box-drawing / half-block / emoji
// glyphs that render unevenly. Colours are theme keys so they track the
// active theme. On-disk (discovered) rows have no agent process, so they get
// no symbol (a blank margin) and keep their `· on-disk` tag instead.
// =============================================================================

interface StatusSymbol {
  // The single glyph painted in the left margin.
  glyph: string;
  // Theme key for the glyph colour, resolved by the host.
  fg: string;
}

const STATE_SYMBOL: Record<AgentState, StatusSymbol> = {
  // In progress — amber/warning, an asterisk reads as "busy/spinner".
  working: { glyph: "*", fg: "diagnostic.warning_fg" },
  // Needs you — a solid red dot, the only glyph meant to pull the eye.
  blocked: { glyph: "●", fg: "diagnostic.error_fg" },
  // Unseen finished work — a green check: something to review.
  done: { glyph: "✓", fg: "ui.file_status_added_fg" },
  // Quiet / nothing pending — a small dim dot. Deliberately understated:
  // idle is the resting state, so it shouldn't draw the eye.
  idle: { glyph: "·", fg: "ui.menu_disabled_fg" },
  // No signal at all (never printed, or the terminal exited).
  unknown: { glyph: "?", fg: "ui.menu_disabled_fg" },
};

// Width of the left status margin: glyph + trailing space.
const STATUS_MARGIN_W = 2;

// Remote/cloud facet glyphs — a per-backend mark prepended to a session row
// when it has a `remote` facet (ssh / kubernetes / devcontainer). Local
// sessions have no facet, so their rows are untouched.
const REMOTE_GLYPH: Record<SessionBackend, string> = {
  local: "",
  ssh: "⇅",
  kubernetes: "⎈",
  devcontainer: "⬢",
};

// Theme colour for a remote facet's state.
function remoteStateFg(state: "starting" | "running" | "stopped" | "error"): string {
  switch (state) {
    case "running":
      return "diagnostic.info_fg";
    case "starting":
      return "diagnostic.warning_fg";
    case "error":
      return "diagnostic.error_fg";
    case "stopped":
      return "ui.menu_disabled_fg";
  }
}

// =============================================================================
// Open dialog — widget-based session picker (Phase 1 of the
// open-dialog redesign; see docs/internal/
// orchestrator-open-dialog-and-lifecycle.md).
//
// Dive is the only action the dialog wires up directly. Other
// lifecycle commands (Stop / Archive / Delete / New) ship in
// later phases. New session is still reachable through the
// "Orchestrator: New Session" palette command in the meantime.
// =============================================================================

// Case-insensitive substring match over a session's label and
// root path. Ordering: prefix-of-label hits beat substring hits,
// then ties broken by label length so shorter matches surface
// first. Empty needle returns the full list in numeric-id order.
//
// The picker is cross-project by design — every session is a
// candidate regardless of which project the active window
// points at — so there is no project-scope filter here.
// Project a session belongs to, as a comparison key. Prefer the
// canonical `projectPath` recorded at create time; fall back to
// the session root for sessions that predate the field (the base
// session, externally-created windows).
function projectKeyOf(s: AgentSession): string {
  // The host guarantees `projectPath` is always a non-empty string
  // (defaults to `root` when no explicit project is set), so no
  // `?? root` / `|| root` defence is needed here.
  return s.projectPath;
}

// The project the user is currently "in" — the active window's
// project. Falls back to the editor cwd when the active window
// isn't a tracked session (shouldn't normally happen, but keeps
// scoping well-defined).
function currentProjectKey(): string {
  const s = orchestratorSessions.get(editor.activeWindow());
  return s ? projectKeyOf(s) : editor.getCwd();
}

// Short, human-readable label for a project key — the trailing
// `parent/base` of the path, matching the new-session form's
// `deriveProjectLabel` style.
function projectLabel(key: string): string {
  const base = editor.pathBasename(key);
  const parent = editor.pathBasename(editor.pathDirname(key));
  if (parent && parent !== base) return `${parent}/${base}`;
  return base || key;
}

// Resolve the id list for the current filter + scope.
//
// Scope only constrains the *empty-filter* view: with no needle
// and `scope === "current"`, the list shows just the active
// project's sessions (current project first, by id). As soon as
// the user types, the search goes global regardless of scope —
// hiding a session the user is explicitly searching for would be
// the worse surprise. `scope === "all"` always shows everything,
// sorted by project (current project first) so rows are grouped
// rather than interleaved.
function filterSessions(needle: string): number[] {
  requestAllWorkspaces();
  reconcileSessions();
  const scope = openDialog?.scope ?? "current";
  const showWorktrees = openDialog?.showWorktrees ?? false;
  const hideTrivial = openDialog?.hideTrivial ?? false;
  const cur = currentProjectKey();
  let allIds = Array.from(orchestratorSessions.keys());
  // Lock in each session's permanent display slot up front, in Map
  // insertion (first-seen) order, before any filtering or sorting. This
  // fixes the dock's row order the first time a session appears so it never
  // reshuffles afterward (see `stableOrderKey`).
  for (const id of allIds) stableOrderKey(orchestratorSessions.get(id)!);
  // "Show all worktrees" is opt-in: by default the discovered on-disk
  // worktree rows are filtered out.
  if (!showWorktrees) {
    allIds = allIds.filter((id) => !orchestratorSessions.get(id)!.discovered);
  }
  // "Hide empty/1-file sessions": drop the restored shells that hold no
  // real work. The active session is always kept (you must be able to
  // see where you are), and discovered worktree rows are governed by
  // their own toggle, not this one. A session with no summary (e.g. a
  // freshly created agent session not yet written to disk) is kept too.
  if (hideTrivial) {
    const activeId = editor.activeWindow();
    allIds = allIds.filter((id) => {
      const s = orchestratorSessions.get(id)!;
      // Keep: the active session (you must see where you are), discovered
      // worktree rows (their own toggle governs them), and any remote
      // (SSH / k8s) session. A remote session is a live connection, never an
      // "empty restored shell" — and its persisted workspace records no local
      // terminal, so it looked trivial and got dropped the instant it stopped
      // being the active card. In the dock (a live switcher) that made the
      // first card vanish on the first ↓ and desynced the selection.
      if (s.discovered || id === activeId || s.remote) return true;
      const c = sessionContentByRoot.get(normRoot(s.root));
      return !c || !c.trivial;
    });
  }

  // Dock project dropdown: when a specific project is picked, hard-
  // restrict the list to that project (search included — the dock is a
  // per-project switcher once a project is chosen). `null` = all
  // projects, the default.
  if (dockMode && openDialog?.projectFilter) {
    const want = openDialog.projectFilter;
    // A being-created placeholder is always shown (its project isn't
    // meaningful until it resolves) so the user sees it appear.
    allIds = allIds.filter((id) => {
      const s = orchestratorSessions.get(id)!;
      return !!s.pending || projectKeyOf(s) === want;
    });
  }

  // Sort by (current-project-first, project, then a stable identity key)
  // so an "all" view groups the current project's sessions at the top and
  // other projects' below.
  //
  // Within a project the order is a *stable* identity key, deliberately
  // NOT the live/discovered state or the numeric id — a row must keep its
  // place when its session changes state. Opening a discovered on-disk
  // worktree turns it into a live session (and swaps its synthetic
  // negative id for a positive window id), but it should stay exactly
  // where it was instead of jumping into a "live" group and shuffling the
  // rows under you as you arrow-navigate. The key is:
  //   1. main checkout first — the project's own checkout (root ===
  //      projectPath) sits above its linked worktrees. This is stable:
  //      whether a worktree is discovered or open, its root never equals
  //      its projectPath, so it never crosses this boundary.
  //   2. then label, then root — alphabetical within each group.
  //   3. id only as a final tie-break for two otherwise-identical rows.
  //
  // The dock is persistent and switches the active session constantly, so
  // it must NOT reorder as the active project changes — it pins this
  // stable order. The modal picker, opened fresh each time, additionally
  // floats the current project to the top.
  const isWorktree = (s: AgentSession): number =>
    normRoot(s.root) === normRoot(projectKeyOf(s)) ? 0 : 1;
  const pinCurrentFirst = !dockMode;
  const byProjectThenStable = (a: number, b: number): number => {
    const sa = orchestratorSessions.get(a)!;
    const sb = orchestratorSessions.get(b)!;
    const aCur = projectKeyOf(sa) === cur ? 0 : 1;
    const bCur = projectKeyOf(sb) === cur ? 0 : 1;
    if (pinCurrentFirst && aCur !== bCur) return aCur - bCur;
    const ka = projectKeyOf(sa);
    const kb = projectKeyOf(sb);
    if (ka !== kb) return ka < kb ? -1 : 1;
    const wa = isWorktree(sa);
    const wb = isWorktree(sb);
    if (wa !== wb) return wa - wb;
    const la = sa.label.toLowerCase();
    const lb = sb.label.toLowerCase();
    if (la !== lb) return la < lb ? -1 : 1;
    if (sa.root !== sb.root) return sa.root < sb.root ? -1 : 1;
    return a - b;
  };

  if (!needle) {
    // The dock orders by recency at DAY granularity: most-recently-active
    // workspaces first, older ones below. Ties within a day (the common
    // case) fall back to newest-created-first, then to each session's
    // permanent first-seen slot — both keys are stable through the day, so
    // the list holds still as the active window switches or a session's
    // sub-day fields change, and only reorders when a workspace crosses a
    // day boundary. Folder grouping (which folder a session sits under, and
    // the folders' own name order) is applied later in `buildDockTree`; this
    // only orders sessions *within* a group. The modal picker (opened fresh
    // each time) keeps the grouped, current-project-first browse order.
    const comparator = dockMode
      ? (a: number, b: number) => {
          const sa = orchestratorSessions.get(a)!;
          const sb = orchestratorSessions.get(b)!;
          const da = sessionLastActiveDay(sa);
          const db = sessionLastActiveDay(sb);
          if (da !== db) return db - da; // more recent active-day first
          // Same day (the common case): fall back to the permanent first-seen
          // slot — the dock's long-standing stable order. Keeping this
          // *ascending* means within-day order is unchanged from before the
          // recency feature, so a discovered worktree keeps its position when
          // it opens and the persistent dock never reshuffles intra-day; only
          // a genuine cross-day change floats a workspace up.
          return stableOrderKey(sa) - stableOrderKey(sb);
        }
      : byProjectThenStable;
    const ids = allIds.slice().sort(comparator);
    if (scope === "current") {
      // Keep being-created placeholders visible regardless of scope — they
      // were just launched and must show up in the list right away.
      return ids.filter((id) => {
        const s = orchestratorSessions.get(id)!;
        return !!s.pending || projectKeyOf(s) === cur;
      });
    }
    return ids;
  }

  const n = needle.toLowerCase();
  type Scored = { id: number; score: number; len: number };
  const matches: Scored[] = [];
  for (const id of allIds) {
    const s = orchestratorSessions.get(id)!;
    const label = s.label.toLowerCase();
    const root = s.root.toLowerCase();
    if (label.startsWith(n)) {
      matches.push({ id, score: 0, len: label.length });
    } else if (label.includes(n)) {
      matches.push({ id, score: 1, len: label.length });
    } else if (root.includes(n)) {
      matches.push({ id, score: 2, len: label.length });
    }
  }
  // At equal relevance, a project's own checkout sorts before its
  // worktrees (same stable `isWorktree` grouping as the browse list), so
  // the on-disk / worktree rows still trail the project's own session in
  // search results — and a result doesn't jump when a discovered worktree
  // is opened (its root/projectPath, hence its group, don't change).
  matches.sort(
    (a, b) =>
      a.score - b.score ||
      isWorktree(orchestratorSessions.get(a.id)!) -
        isWorktree(orchestratorSessions.get(b.id)!) ||
      a.len - b.len ||
      a.id - b.id,
  );
  return matches.map((m) => m.id);
}

// Distinct project keys that have at least one session in the dock's
// worktree/trivial-filtered set — the menu contents for the dock's
// project dropdown. Deliberately ignores the active `projectFilter`
// (the menu must offer every project, not just the selected one) and
// any text filter. Sorted lexically for a stable menu order.
function dockProjectOptions(): string[] {
  const showWorktrees = openDialog?.showWorktrees ?? false;
  const hideTrivial = openDialog?.hideTrivial ?? false;
  const activeId = editor.activeWindow();
  const keys = new Set<string>();
  for (const [id, s] of orchestratorSessions) {
    if (!showWorktrees && s.discovered) continue;
    if (hideTrivial && !s.discovered && id !== activeId && !s.remote) {
      const c = sessionContentByRoot.get(normRoot(s.root));
      if (c && c.trivial) continue;
    }
    keys.add(projectKeyOf(s));
  }
  return Array.from(keys).sort();
}

// Header row above the session list: a single dim `NAME`, indented to
// sit over the per-row name (status margin + checkbox = STATUS_MARGIN_W
// + 4 cols). The status symbol lives in the left margin now, so there's
// no separate status column to label.
function sessionsColumnHeader(): WidgetSpec {
  const text = " ".repeat(STATUS_MARGIN_W + 4) + editor.t("list.col_name");
  return {
    kind: "raw",
    entries: [
      styledRow([{ text, style: { fg: "ui.menu_disabled_fg" } }]),
    ],
  };
}

// =============================================================================
// Pill (card) rendering — the richer multi-line list item
//
// Each session renders as a rounded `labeledSection` card with two
// content lines:
//
//   ╭────────────────────────────────────╮
//   │ * agent-auth              demo-proj │   line 1: status · name · project
//   │ #1287 ✓7/8 ●2 approved · merge ok   │   line 2: PR badge (or branch)
//   ╰────────────────────────────────────╯
//
// The host `list` widget lays these out one card per item (selection,
// scroll, and clicks all in item units) via the `itemSpecs` channel.
// =============================================================================

type Entry = { text: string; style?: Record<string, unknown> };

// Field icons (Alt-5 style) — a small glyph labels each field so its
// slot is unambiguous. `BRANCH_ICON` falls back gracefully: it's only
// decorative, and the branch name follows it.
const PROJECT_ICON = "▣";
// `▸` (not the git-fork `⎇`, which is absent from many monospace fonts
// and renders as tofu) — matches the branch marker the dock detail line
// already uses.
const BRANCH_ICON = "▸";

// The modal pill's branch line: branch (with icon, left) + a compact
// git summary (right-aligned) that's useful even before any PR exists —
// ahead/behind the upstream and the uncommitted diffstat
// (`+added −deleted`), or `clean`. The dock card takes only the `right`
// half — its name row carries the summary — so `left` (the branch) is
// the pill's alone.
function gitLineParts(s: AgentSession): { left: Entry[]; right: Entry[] } {
  const dim = "ui.menu_disabled_fg";
  let branch = s.branch || (s.discovered ? editor.t("pill.branch_worktree") : editor.t("pill.branch_detached"));
  // Cap the branch so it doesn't push the right-aligned git summary off
  // the tail (the host truncates the row's *end*, which is the summary)
  // on a normal-width card. Very narrow docks may still clip it.
  const BRANCH_CAP = 28;
  if (branch.length > BRANCH_CAP) branch = branch.slice(0, BRANCH_CAP - 1) + "…";
  const left: Entry[] = [
    { text: BRANCH_ICON + " ", style: { fg: dim } },
    { text: branch, style: { fg: dim } },
  ];
  // The git summary is right-aligned on the line (see `renderPillSpec`),
  // so it's returned separately from the branch.
  const right: Entry[] = [];
  const sep = (): string => (right.length ? " " : "");
  const probe = s.git;
  // Keep the last good summary on screen while a re-poll is in flight
  // (only the very first probe, with no prior info, shows the spinner).
  const g = probe?.info;
  if (!g) {
    // Show the spinner only on the genuinely FIRST probe (never completed yet,
    // so `fetchedAt` is still 0). A directory that simply isn't a git repo
    // never gains `info`, so re-probing it every TTL would otherwise re-enter
    // "loading" and blink "…" back on each poll — a serialized change that
    // pushed a redundant widgets frame (dock flicker) every ~15s per session.
    if (probe?.status === "loading" && !probe.fetchedAt) {
      right.push({ text: "…", style: { fg: dim, italic: true } });
    }
    return { left, right };
  }
  if (g.ahead && g.ahead > 0) {
    right.push({ text: `${sep()}↑${g.ahead}`, style: { fg: "ui.file_status_added_fg" } });
  }
  if (g.behind && g.behind > 0) {
    right.push({ text: `${sep()}↓${g.behind}`, style: { fg: "diagnostic.warning_fg" } });
  }
  if (g.added) {
    right.push({ text: `${sep()}+${g.added}`, style: { fg: "ui.file_status_added_fg" } });
  }
  if (g.deleted) {
    right.push({ text: `${sep()}−${g.deleted}`, style: { fg: "ui.file_status_deleted_fg" } });
  }
  if (right.length === 0) {
    right.push({ text: editor.t("pill.clean"), style: { fg: dim, italic: true } });
  }
  return { left, right };
}

// Card line 3: the GitHub PR badge (number, checks, comments, review,
// conflicts). Degrades to a dim placeholder when there's no PR yet,
// the probe is still running, or `gh` is unavailable.
function prLineEntries(s: AgentSession): Entry[] {
  const dim = "ui.menu_disabled_fg";
  const probe = s.pr;
  // Keep the last good badge on screen while a re-poll is in flight —
  // don't flash a placeholder over real data (only the very first probe,
  // with no prior info, shows the spinner).
  if (probe?.info && (probe.status === "ok" || probe.status === "loading")) {
    const p = probe.info;
    const out: Entry[] = [
      { text: editor.t("pill.pr_prefix"), style: { fg: dim } },
      { text: `#${p.number}`, style: { fg: "ui.help_key_fg", bold: true } },
    ];
    if (p.isDraft) out.push({ text: editor.t("pill.pr_draft"), style: { fg: dim } });
    if (p.checksFail && p.checksFail > 0) {
      out.push({ text: ` ✗${p.checksFail}`, style: { fg: "diagnostic.error_fg" } });
    } else if (p.checksPending && p.checksPending > 0) {
      out.push({ text: ` •${p.checksPending}`, style: { fg: "diagnostic.warning_fg" } });
    } else if (p.checksPass && p.checksPass > 0) {
      out.push({ text: ` ✓${p.checksPass}`, style: { fg: "ui.file_status_added_fg" } });
    }
    if (p.comments && p.comments > 0) {
      out.push({ text: ` ●${p.comments}`, style: { fg: dim } });
    }
    if (p.reviewDecision === "APPROVED") {
      out.push({ text: editor.t("pill.pr_approved"), style: { fg: "ui.file_status_added_fg" } });
    } else if (p.reviewDecision === "CHANGES_REQUESTED") {
      out.push({ text: editor.t("pill.pr_chg_req"), style: { fg: "diagnostic.warning_fg" } });
    }
    if (p.mergeable === "CONFLICTING") {
      out.push({ text: editor.t("pill.pr_conflicts"), style: { fg: "diagnostic.error_fg" } });
    }
    return out;
  }
  // A discovered on-disk worktree keeps its "· on-disk worktree" tag —
  // it's a useful "this row isn't an open session yet" indicator, not a
  // PR placeholder. A live session with no PR returns nothing here; the
  // caller renders a blank spacer line in its place (keeping the card a
  // uniform three lines) rather than a "no PR yet" placeholder.
  if (s.discovered) {
    return [{ text: editor.t("pill.on_disk_worktree"), style: { fg: dim, italic: true } }];
  }
  return [];
}

// On-disk (discovered, unopened) worktrees get a dim hollow ring in the
// status column — distinct from the live `*` working / `✓` idle glyphs.
const ON_DISK_GLYPH = "○";

// A flex row: left group, host-filled spacer, right group. The host
// right-aligns the right group to the row's *actual* width (flush to
// the edge with one column of padding), re-flowing on a dock resize —
// no plugin-side width estimate needed.
function flexLine(l: Entry[], r: Entry[]): WidgetSpec {
  return row(
    raw([styledRow(l as Parameters<typeof styledRow>[0])]),
    flexSpacer(),
    raw([styledRow(r as Parameters<typeof styledRow>[0])]),
  );
}

// The leading status glyph for a session row: the on-disk ring for a
// discovered worktree, otherwise the live working/idle state symbol.
function stateGlyphEntry(s: AgentSession): Entry {
  if (s.pending) {
    // A being-created row: amber `*` while creating (reads as busy/spinner,
    // same glyph as a working session), red `!` once it has failed. Colour
    // comes from the shared helper so glyph and message always agree.
    const glyph = s.pending.phase === "error" ? "! " : "* ";
    return { text: glyph, style: { fg: pendingMsgFg(s.pending), bold: true } };
  }
  if (s.discovered) {
    return { text: ON_DISK_GLYPH + " ", style: { fg: "ui.menu_disabled_fg" } };
  }
  const sym = STATE_SYMBOL[sessionState(s)];
  return { text: sym.glyph + " ", style: { fg: sym.fg, bold: true } };
}

// Build one session row for the modal picker's list. (The dock's own
// tree rows are built by `sessionCardPrimary` / `sessionNodeEntry`; its
// cards are two rows, not the three below.) Two densities, picked by
// `dockView`:
//
//   card (default): a rounded `labeledSection` pill —
//     line 1: <state> NAME (bold)              ▣ project
//     line 2: ▸ branch        <git: ↑ahead ↓behind +add −del / clean>
//     line 3: PR #1287 ✓7/8 ●2 approved        (blank spacer when no PR)
//
//   compact: a single un-boxed line —
//     <state> NAME                    <git summary>
//
// The bulk-select checkbox only appears in the modal picker (the dock
// delegates bulk actions to it via the "manage" button), so dock rows
// drop it. The right-hand groups are right-aligned by the host (a flex
// spacer), so they adapt to the row's real width including a drag.
function renderPillSpec(
  id: number,
  activeId: number,
): WidgetSpec {
  const s = orchestratorSessions.get(id);
  if (!s) return labeledSection({ label: "", child: label(editor.t("pill.unknown")) });
  // A being-created placeholder renders its status in place of the live
  // pill body: name on line 1, the creating/connecting/error message on
  // line 2 (amber while creating, red on failure), and a retry hint on the
  // error card's line 3.
  if (s.pending) return renderPendingPillSpec(s);
  const isActive = id === activeId;
  const nameEntry: Entry = {
    text: s.label,
    style: { fg: isActive ? "ui.help_key_fg" : undefined, bold: true },
  };
  // Remote/cloud facet glyph (ssh ⇅ / kubernetes ⎈ / devcontainer ⬢), coloured
  // by the remote state, sits just before the name. Local sessions have none,
  // so their rows render exactly as before (the facet is backend-opaque).
  const remoteGlyph: Entry[] = s.remote
    ? [{
        text: REMOTE_GLYPH[s.remote.kind] + " ",
        style: { fg: remoteStateFg(s.remote.state), bold: true },
      }]
    : [];
  const proj = editor.pathBasename(projectKeyOf(s));
  const projEntries: Entry[] = [
    { text: PROJECT_ICON + " ", style: { fg: "ui.menu_disabled_fg" } },
    { text: proj, style: { fg: "ui.menu_disabled_fg", italic: true } },
  ];
  // For a remote session, surface the backend target (host / ns·pod) on the
  // right — unless the label already names it.
  projEntries.push(...remoteDetailSegs(s));
  const git = gitLineParts(s);

  // Compact: one un-boxed line — glyph + (facet) + name on the left, the
  // compact git summary right-aligned. Branch, project tag, and PR badge are
  // dropped (that's the "compact" trade).
  if (dockMode && dockView === "compact") {
    return flexLine([stateGlyphEntry(s), ...remoteGlyph, nameEntry], git.right);
  }

  // Card line 1, left: state glyph · [facet] · NAME. In the modal picker keep
  // the multi-select checkbox between them (Space/click bulk-select); the
  // dock drops it.
  const left: Entry[] = [stateGlyphEntry(s)];
  if (!dockMode) {
    const isChecked = openDialog?.selectedIds.has(id) ?? false;
    left.push({
      text: isChecked ? "[x] " : "[ ] ",
      style: isChecked
        ? { fg: "ui.help_key_fg", bold: true }
        : { fg: "ui.menu_disabled_fg" },
    });
  }
  left.push(...remoteGlyph);
  left.push(nameEntry);

  const children: WidgetSpec[] = [
    flexLine(left, projEntries),
    flexLine(git.left, git.right),
  ];
  // Line 3 is the PR badge when there's an actual PR; when `prLineEntries`
  // returns `[]` we still emit a blank spacer line so every card is a
  // uniform three lines tall — a 2-line card next to 3-line ones looks
  // ragged in the dock.
  const prEntries = prLineEntries(s);
  const prLine: Entry[] = prEntries.length > 0 ? prEntries : [{ text: " " }];
  children.push(raw([styledRow(prLine as Parameters<typeof styledRow>[0])]));
  return labeledSection({ label: "", child: col(...children) });
}

// Row for a being-created placeholder. The dialog scope the user asked
// for lives *here*: instead of blocking the whole editor behind a modal,
// the progress/failure of this one workspace is confined to its own dock
// row. Line 1 is the state glyph + (facet) + name; line 2 is the pending
// message; line 3 is a retry/dismiss hint on failure (blank otherwise, so
// the card keeps the uniform three-line height).
function renderPendingPillSpec(s: AgentSession): WidgetSpec {
  const p = s.pending!;
  const actionable = pendingActionable(p);
  const msgFg = pendingMsgFg(p);
  const remoteGlyph: Entry[] = s.remote
    ? [{ text: REMOTE_GLYPH[s.remote.kind] + " ", style: { fg: msgFg, bold: true } }]
    : [];
  const nameEntry: Entry = { text: s.label, style: { bold: true } };
  const proj = editor.pathBasename(projectKeyOf(s));
  const projEntries: Entry[] = [
    { text: PROJECT_ICON + " ", style: { fg: "ui.menu_disabled_fg" } },
    { text: proj, style: { fg: "ui.menu_disabled_fg", italic: true } },
  ];

  // Compact: glyph + name on the left, the status on the right. A stuck
  // workspace shows the short affordance ("↵ Retry") rather than its
  // sentence-long message — the dock column is ~39 cells, so
  // "Interrupted — press Enter to resume" clips to "Interrupted — press "
  // and loses the very instruction it exists to give. The glyph and the
  // colour already say something is wrong; the full message is a line of
  // the card and an entry of the row menu away.
  if (dockMode && dockView === "compact") {
    return flexLine(
      [stateGlyphEntry(s), ...remoteGlyph, nameEntry],
      [
        actionable
          ? { text: "↵ " + editor.t("dock.ctx_retry"), style: { fg: msgFg, italic: true } }
          : { text: p.message, style: { fg: msgFg, italic: true } },
      ],
    );
  }

  const children: WidgetSpec[] = [
    flexLine([stateGlyphEntry(s), ...remoteGlyph, nameEntry], projEntries),
    raw([styledRow([{ text: p.message, style: { fg: msgFg, italic: actionable } }])]),
  ];
  const hint: Entry[] = actionable
    ? [{ text: pendingHintText(p), style: { fg: "ui.menu_disabled_fg", italic: true } }]
    : [{ text: " " }];
  children.push(raw([styledRow(hint as Parameters<typeof styledRow>[0])]));
  return labeledSection({ label: "", child: col(...children) });
}

// Preview-pane content for the currently selected session.
// Plain info for Phase 1; later phases append pgid/pids + the
// last terminal lines.
function buildPreviewEntries(
  s: AgentSession | undefined,
): TextPropertyEntry[] {
  if (!s) {
    return [
      styledRow([
        {
          text: editor.t("preview.no_workspace_selected"),
          style: { fg: "ui.menu_disabled_fg", italic: true },
        },
      ]),
    ];
  }
  // A being-created placeholder: show its status (creating/connecting or
  // the failure reason) rather than live-session detail it doesn't have.
  if (s.pending) {
    const p = s.pending;
    return [
      styledRow([{ text: s.label, style: { bold: true } }]),
      styledRow([{ text: p.message, style: { fg: pendingMsgFg(p), italic: true } }]),
      styledRow([
        { text: pendingHintText(p), style: { fg: "ui.menu_disabled_fg", italic: true } },
      ]),
    ];
  }
  const activeId = editor.activeWindow();
  const isActive = s.id === activeId;
  // The focused window is labelled "active"; everything else shows its
  // live working/idle activity (recomputed from the output timestamp).
  const st = sessionState(s);
  const stateText = isActive
    ? editor.t("preview.state_active")
    : st === "working"
    ? editor.t("preview.state_working")
    : st === "blocked"
    ? editor.t("preview.state_blocked")
    : st === "done"
    ? editor.t("preview.state_done")
    : st === "unknown"
    ? editor.t("preview.state_unknown")
    : editor.t("preview.state_idle");
  const headerEntries: { text: string; style?: Record<string, unknown> }[] = [
    {
      text: stateText,
      style: isActive
        ? { fg: "ui.help_key_fg", bold: true }
        : { fg: "ui.menu_disabled_fg" },
    },
    { text: "  " },
    { text: ageString(s.createdAt), style: { fg: "ui.menu_disabled_fg" } },
  ];
  if (!s.discovered && !ownsWorktree(s)) {
    // In-place / launch session: runs inside a real checkout, owns no
    // dedicated worktree. Surfaced so the user knows Archive doesn't
    // apply (Delete just forgets it, leaving the directory untouched).
    headerEntries.push(
      { text: "  " },
      { text: editor.t("preview.in_place"), style: { fg: "ui.menu_disabled_fg", italic: true } },
    );
  }
  return [
    styledRow(headerEntries as Parameters<typeof styledRow>[0]),
    styledRow([
      { text: s.root, style: { fg: "ui.menu_disabled_fg" } },
    ]),
  ];
}

// Is there a worktree for Delete to remove at all?
//
// `ownsWorktree` answers it for a local session (and for a discovered on-disk
// one); a remote session needs the separate test, because the host records no
// separate project for it. The confirm dialog asks this to decide whether the
// "also remove the worktree" choice is even meaningful — an in-place or
// shared-tree session has nothing to remove, and offering the choice there
// would imply it does.
function hasRemovableWorktree(s: AgentSession): boolean {
  return ownsWorktree(s) || looksLikeOurRemoteWorktree(s);
}

// A session "owns" a removable git worktree when it was created as a
// dedicated `git worktree add` (project path set, not a shared/in-place
// root) or was discovered on disk via `git worktree list`. Only these
// have a worktree to `git worktree remove`/`move`. The launch session
// (the dir the editor was started in) and in-place sessions run inside
// a real checkout, so Archive (which moves the worktree) doesn't apply
// and Delete simply forgets the session without touching the directory.
function ownsWorktree(s: AgentSession): boolean {
  // "Has an explicit project that's separate from this session's
  // root" means the session is a worktree of that project — Archive
  // / Delete apply. `projectPath === root` is the "no separate
  // project" case (host normalises absence → root); skip those too.
  return (
    !!s.discovered || (s.projectPath !== s.root && !s.sharedWorktree)
  );
}

// =============================================================================
// Multi-select / bulk actions
//
// The user checkbox-selects rows (Space — the rebindable
// `orchestrator_toggle_select` — or a click). Once two or more rows
// are checked the preview pane swaps to the bulk selection bar
// (`buildBulkPane`) offering Stop / Archive / Delete over the whole
// set, with a single confirmation for the batch. Rows ineligible for
// a given action (the base session; live sessions sharing a worktree)
// are skipped, and each button's count reflects only the eligible
// members.
// =============================================================================

type BulkAction = "stop" | "archive" | "delete";

// Checked ids that still resolve to a known session, in the dialog's
// current display order (so the bulk bar lists them the way the list
// shows them). Selection persists across filter/scope changes, so an
// id can be checked while filtered out of view — those still count.
function selectedSessions(): number[] {
  if (!openDialog) return [];
  const order = openDialog.filteredIds;
  const seen = new Set<number>();
  const out: number[] = [];
  for (const id of order) {
    if (openDialog.selectedIds.has(id) && orchestratorSessions.has(id)) {
      out.push(id);
      seen.add(id);
    }
  }
  // Checked-but-filtered-out rows, appended in id order so the count
  // stays honest even when a search hides part of the selection.
  for (const id of openDialog.selectedIds) {
    if (!seen.has(id) && orchestratorSessions.has(id)) out.push(id);
  }
  return out;
}

// Is `id` a legal target for `action`? Base session is never
// touched. Stop only applies to live windows. Archive/Delete apply
// to discovered worktrees (removable on disk) and to live sessions
// that own their worktree outright (not shared with siblings or the
// project root).
function bulkEligible(action: BulkAction, id: number): boolean {
  const s = orchestratorSessions.get(id);
  if (!s) return false;
  // Stop kills the agent process group — only meaningful for a live
  // session that actually spawned one (never the launch session, which
  // has no agent terminal, so signalling it can't touch the editor).
  if (action === "stop") return !s.discovered && id > 0 && !!s.terminalId;
  // Delete forgets any session. When it owns a worktree the worktree is
  // removed too; otherwise (launch/in-place) it's just dropped.
  if (action === "delete") return id > 0 || !!s.discovered;
  // Archive applies to any session: a worktree session moves to the
  // graveyard; a launch/in-place session is recorded at its own root.
  return id > 0 || !!s.discovered;
}

function eligibleSelected(action: BulkAction): number[] {
  return selectedSessions().filter((id) => bulkEligible(action, id));
}

// Drop checked ids whose session has vanished (closed window,
// pruned worktree) so the selection can't grow stale references.
function pruneSelection(): void {
  if (!openDialog) return;
  for (const id of [...openDialog.selectedIds]) {
    if (!orchestratorSessions.has(id)) openDialog.selectedIds.delete(id);
  }
}

// Blank-row separator used inside the Sessions column between
// the filter, the new-session button, and the list.
function sessionsSeparator(): WidgetSpec {
  return spacer(0);
}

// Smallest list height we'll show even when there are only a
// couple of sessions — keeps the preview pane (which matches the
// list height) usable rather than collapsing to a sliver.
const MIN_LIST_ROWS = 6;

// Upper bound on session rows for this terminal — the list height
// when the panel is at its full `heightPct: 90` budget. Sized off
// the full terminal (not the active buffer's viewport — that
// shrinks with vertical splits and made the picker collapse to
// ~half its budget).
function maxListRowsForScreen(): number {
  const screen = editor.getScreenSize();
  const h = screen.height > 0 ? screen.height : 30;
  const panelH = Math.floor(h * 0.9);
  // Chrome that isn't list rows: panel borders (2) + title (1) +
  // spacer (1) + footer (1) + sessions-section borders (2) +
  // column chrome above the list (New + Project + Worktree-filter +
  // Trivial-filter + Filter + separator + header = 7) = 14. Floor at
  // MIN_LIST_ROWS so a tiny terminal still shows something.
  return Math.max(MIN_LIST_ROWS, panelH - 14);
}

// Inner width (cells) of the modal picker's session column, used to
// size name/tag truncation. The panel is 90% of the terminal and the
// sessions `labeledSection` is `widthPct: 34` of that; subtract the
// section's border (2) + inner padding (2). Floored so a narrow terminal
// still renders a usable column.
function modalSessionColWidth(): number {
  const screen = editor.getScreenSize();
  const w = screen.width > 0 ? screen.width : 80;
  const panelW = Math.floor(w * 0.9);
  const sectionW = Math.floor(panelW * 0.34);
  return Math.max(dockContentCols(DOCK_MIN_WIDTH_COLS), sectionW - 4);
}

// Compose the right-hand preview pane. Normally it shows info
// + action buttons (Stop, Archive, Delete); when a destructive
// action is pending confirmation it swaps to a "Confirm
// <action>?" panel with [ Confirm <action> ] / [ Cancel ]
// buttons. Cancel is default-focused for safety.
function buildPreviewPane(s: AgentSession | undefined): WidgetSpec {
  // In-flight overlay: when the selected session is currently
  // being archived/deleted, swap the preview pane for a
  // non-interactive status panel. The git operations take a few
  // hundred ms; without this the user clicks Confirm Archive and
  // sees no visible reaction until the editor's `window_closed`
  // hook eventually fires and drops the row. The overlay makes
  // the in-flight state explicit and hides the action buttons so
  // a second click can't double-fire.
  if (openDialog?.inFlight && s && openDialog.inFlight.sessionId === s.id) {
    const label = openDialog.inFlight.action === "archive"
      ? editor.t("preview.archiving")
      : editor.t("preview.deleting");
    return labeledSection({
      label,
      child: col(
        {
          kind: "raw",
          entries: [
            styledRow([
              {
                text: editor.t("preview.inflight_row", { label, id: String(s.id), name: s.label }),
                style: { bold: true, fg: "ui.menu_disabled_fg" },
              },
            ]),
            styledRow([{ text: "" }]),
            styledRow([
              {
                text: editor.t("preview.waiting_for_git"),
                style: { fg: "ui.menu_disabled_fg", italic: true },
              },
            ]),
          ],
        },
      ),
    });
  }
  // Confirmation panel — single-row Stop/Archive/Delete or a bulk
  // batch. Independent of the cursor row: the confirmed ids live in
  // `pendingConfirm`, so it renders whenever a confirm is pending.
  if (openDialog?.pendingConfirm) {
    return buildConfirmPane(openDialog.pendingConfirm);
  }
  // Bulk selection bar: two or more rows checked (or a bulk action
  // in flight) → operate on the whole batch rather than the cursor
  // row.
  if (selectedSessions().length >= 2 || openDialog?.bulkInFlight) {
    return buildBulkPane();
  }
  // Match the sessions column's content height so the two panes'
  // bottom borders land on the same row. Sessions column inside its
  // borders = New (1) + Project (1) + Worktree-filter (1) +
  // Trivial-filter (1) + Filter (1) + separator (1) + header (1) +
  // list (listVisibleRows) = listVisibleRows + 7. Preview inside its
  // borders = button row (1) + spacer (1) + embedRows, so embedRows
  // must equal listVisibleRows + 5. When details ARE shown, two info
  // rows + a spacer eat three more lines — `_DETAILS_CHROME_ROWS`
  // accounts for that.
  const totalEmbedBase = (openDialog?.listVisibleRows ?? MIN_LIST_ROWS) + 5;
  const detailsOn = openDialog?.showDetails ?? false;
  const _DETAILS_CHROME_ROWS = 3; // 2 info rows + 1 spacer
  const embedRows = Math.max(
    3,
    totalEmbedBase - (detailsOn ? _DETAILS_CHROME_ROWS : 0),
  );
  // Gate the action buttons on having a session to act on. When
  // the filter matches nothing (or no session is highlighted) the
  // preview pane shows just "No session selected" + an empty
  // embed reservation — showing Stop/Archive/Delete in that state
  // is misleading because they have nothing to operate on. The
  // empty `windowEmbed({windowId: 0})` is a no-op on the host
  // side but keeps the preview pane the same height as the
  // (padded) sessions list pane so the dialog doesn't shrink
  // jarringly when the filter matches nothing.
  if (!s) {
    return labeledSection({
      label: editor.t("preview.title"),
      child: col(
        { kind: "raw", entries: buildPreviewEntries(s) },
        windowEmbed({ windowId: 0, rows: embedRows, key: "live-preview" }),
      ),
    });
  }
  // The "details" toggle: when off, the picker shows just the
  // action buttons + the live embed (compact, max embed height).
  // When on, the state/age/path metadata row appears above the
  // embed and the embed shrinks to make room. Toggle button
  // labels with the *target* state — pressing `[ Details ]`
  // turns details on, pressing `[ Preview ]` turns them off
  // (back to compact).
  const detailsToggleLabel = detailsOn ? editor.t("preview.toggle_preview") : editor.t("preview.toggle_details");
  // Discovered worktree: no live window to embed, so there's
  // nothing to Stop / Archive / Delete yet. Offer only "Open"
  // (Visit attaches a fresh session to the worktree) and describe
  // what diving will do. The empty `windowId: 0` embed keeps the
  // pane the same height as live-session previews so the dialog
  // doesn't jump when the selection moves between row kinds.
  if (s.discovered) {
    const openButtonRow = endRow(
      button(editor.t("preview.btn_open"), { intent: "primary", key: "visit" }),
      // A fixed gap: the wrap path ignores flex children.
      spacer(4),
      button(editor.t("preview.btn_stop"), { key: "stop", disabled: true }),
      spacer(2),
      button(editor.t("preview.btn_archive"), { key: "archive", disabled: true }),
      spacer(2),
      button(editor.t("preview.btn_delete"), { intent: "danger", key: "delete", disabled: true }),
    );
    const info: TextPropertyEntry[] = [
      styledRow([
        { text: editor.t("preview.on_disk_not_open"), style: { fg: "ui.menu_disabled_fg", bold: true } },
      ]),
      styledRow([{ text: "" }]),
      styledRow([{ text: editor.t("preview.field_branch"), style: { fg: "ui.menu_disabled_fg" } }, { text: s.branch || editor.t("pill.branch_detached") }]),
      styledRow([{ text: editor.t("preview.field_path"), style: { fg: "ui.menu_disabled_fg" } }, { text: s.root }]),
      styledRow([{ text: "" }]),
      styledRow([
        {
          text: editor.t("preview.click_to_open"),
          style: { fg: "ui.help_key_fg", italic: true },
        },
      ]),
    ];
    return labeledSection({
      label: editor.t("preview.label_on_disk", { name: s.label }),
      child: col(
        openButtonRow,
        spacer(0),
        { kind: "raw", entries: info },
        spacer(0),
        windowEmbed({ windowId: 0, rows: Math.max(3, embedRows - 6), key: "live-preview" }),
      ),
    });
  }
  // Per-action availability. The row always renders all four
  // buttons (no layout shift between selections), but each is
  // marked disabled when its action would be refused against the
  // current selection. Disabled buttons show in `ui.menu_disabled_fg`,
  // drop out of the Tab cycle, and reject clicks — matching the
  // same conditions that `stopSelectedSession`, `enterConfirm`,
  // and the lifecycle handlers already check internally.
  //
  //  * Stop: only a live session with an agent terminal can be
  //    stopped (the launch session has none).
  //  * Archive: every session can be archived — a worktree session moves
  //    to the graveyard; a launch/in-place session is recorded at its own
  //    root. Closing the last live window opens a replacement first.
  //  * Delete: forgets the session, removing the worktree only when one
  //    is owned (otherwise the directory is left untouched); the last
  //    live window likewise gets a replacement before it closes.
  const stopDisabled = s.discovered || !s.terminalId;
  const archiveDisabled = false;
  const deleteDisabled = false;
  // `endRow`: flush right while the actions fit, reflowing on a narrow pane
  // instead of clipping. The wrap path ignores flex spacers, hence `spacer(4)`.
  const buttonRow = endRow(
    button(editor.t("preview.btn_visit"), { intent: "primary", key: "visit" }),
    spacer(4),
    button(detailsToggleLabel, { key: "toggle-details" }),
    spacer(2),
    button(editor.t("preview.btn_stop"), { key: "stop", disabled: stopDisabled }),
    spacer(2),
    button(editor.t("preview.btn_archive"), { key: "archive", disabled: archiveDisabled }),
    spacer(2),
    button(editor.t("preview.btn_delete"), {
      intent: "danger",
      key: "delete",
      disabled: deleteDisabled,
    }),
  );
  // Placeholder and on-disk rows have no window of their own: an embed
  // keyed on their synthetic (negative) id would fall back to the active
  // window and show an unrelated workspace under this row's header.
  const hasWindow = s.id > 0 && !s.pending;
  const embedWidget = windowEmbed({
    windowId: hasWindow ? s.id : 0,
    rows: embedRows,
    key: "live-preview",
  });
  const body = detailsOn || !hasWindow
    ? col(
        buttonRow,
        spacer(0),
        { kind: "raw", entries: buildPreviewEntries(s) },
        spacer(0),
        embedWidget,
      )
    : col(buttonRow, spacer(0), embedWidget);
  // Surface the launch session in the preview label so it's always
  // visible (the list-row badge gets truncated at 25% column width).
  // It's the dir the editor was started in — informational only; it's
  // deletable like any other session once another window exists.
  const sectionLabel = s.id === 1
    ? editor.t("preview.label_launch", { name: s.label })
    : s.label;
  return labeledSection({
    label: sectionLabel,
    child: body,
  });
}

// The per-action bullet lines shown in the confirmation panel.
// `delete` adds a separate red "uncommitted changes" line in the
// caller because it needs distinct styling.
//
// The list is exhaustive on purpose: a careful reader takes it as "and
// nothing else happens", so anything the action does belongs here. There
// used to be a fifth line disclosing a `<user>/fresh-sessions` branch that
// archive and delete wrote into the user's own repository. That mechanism is
// gone, so the line is too — the list is true again without it.
// The Delete confirmation's "also remove the worktree" choice, for as long as
// one confirmation is open. It lives here rather than on `pendingConfirm`
// because the dock's context menu reaches the same pane through
// `dockMenuState`, and a confirmation is modal — there is never a second one to
// confuse it with. Both entry points reset it, so it never carries a previous
// decision into a new dialog.
let confirmRemoveWorktree = true;

// Does this confirmation have a worktree to offer a choice about? True when
// any target has one — a mixed bulk selection still gets the checkbox, and the
// sessions without a worktree simply have nothing for it to do.
function confirmTouchesWorktree(ids: number[]): boolean {
  return ids.some((id) => {
    const s = orchestratorSessions.get(id);
    return !!s && hasRemovableWorktree(s);
  });
}

// Is any target a remote worktree the delete will *not* be able to reach? A
// disconnected host has no authority to route `git worktree remove` through
// (see `remoteWorktreeReachable`), so promising it would be the same kind of
// lie the rest of this dialog was fixed for — the pane says the worktree stays
// put and why, instead.
function confirmHasUnreachableRemote(ids: number[]): boolean {
  return ids.some((id) => {
    const s = orchestratorSessions.get(id);
    return !!s && looksLikeOurRemoteWorktree(s) && !remoteWorktreeReachable(s);
  });
}

function confirmActionLines(action: BulkAction, worktree = true, unreachable = false): string[] {
  switch (action) {
    case "stop":
      return [
        editor.t("confirm.stop_line1"),
        editor.t("confirm.stop_line2"),
        "",
        editor.t("confirm.stop_note"),
      ];
    case "archive":
      return [
        editor.t("confirm.archive_line1"),
        editor.t("confirm.archive_line2"),
        editor.t("confirm.archive_line3"),
        "",
        editor.t("confirm.archive_note"),
      ];
    case "delete":
      // The fourth line is the one the dialog used to leave out. Everything
      // else about this confirmation is exhaustive, which is exactly what
      // makes an omission read as "this is all that happens" — and the branch
      // outliving the workspace then turns up later as an unexplained ref.
      // Keeping it is the right default; saying nothing about it is not.
      // **The worktree lines are conditional, because they were not always
      // true.** An in-place or shared-tree session has no worktree, and a
      // dialog that still announced `git worktree remove` and a surviving
      // branch described an action it was not about to take. Now the list says
      // what will happen to *this* selection: the worktree removed, the
      // worktree kept, or neither line at all.
      return [
        editor.t("confirm.delete_line1"),
        ...(worktree
          ? confirmRemoveWorktree
            ? unreachable
              ? [editor.t("confirm.delete_worktree_unreachable")]
              : [editor.t("confirm.delete_line2"), editor.t("confirm.delete_line4")]
            : [editor.t("confirm.delete_keep_worktree")]
          : []),
        editor.t("confirm.delete_line3"),
      ];
  }
}

// Localized, capitalized verb for an action (Stop / Archive / Delete),
// used in confirmation headers and button labels.
function capAction(action: BulkAction): string {
  switch (action) {
    case "stop":
      return editor.t("confirm.cap_stop");
    case "archive":
      return editor.t("confirm.cap_archive");
    case "delete":
      return editor.t("confirm.cap_delete");
  }
}

// Localized gerund for an action (Stopping / Archiving / Deleting),
// used in the bulk progress line.
function gerundAction(action: BulkAction): string {
  switch (action) {
    case "stop":
      return editor.t("confirm.ger_stop");
    case "archive":
      return editor.t("confirm.ger_archive");
    case "delete":
      return editor.t("confirm.ger_delete");
  }
}

// Confirmation panel for a Stop/Archive/Delete over one or many
// sessions. A single id renders the familiar per-session prompt; two
// or more render a batch prompt that lists the targets. The Confirm
// button reuses the same `confirm-<action>` key the single path
// always used, so the existing widget_event handlers fire for both —
// they read `pendingConfirm.ids`.
function buildConfirmPane(
  confirm: { action: BulkAction; ids: number[] },
): WidgetSpec {
  return labeledSection({
    label: confirmTitle(confirm),
    child: buildConfirmBody(confirm),
  });
}

// The confirmation's heading ("Confirm Delete", "Confirm Delete (3)"). The
// picker draws it as the pane's `labeledSection` border; the dock's popup
// hands it to the host as the modal frame's native title instead.
function confirmTitle(confirm: { action: BulkAction; ids: number[] }): string {
  const cap = capAction(confirm.action);
  const existing = confirm.ids.filter((id) => orchestratorSessions.has(id));
  return existing.length > 1
    ? editor.t("confirm.label_bulk", { cap, count: String(existing.length) })
    : editor.t("confirm.label_single", { cap });
}

// The confirmation's contents without a frame of its own. The dock's popup
// renders this directly: the host already frames that panel, and a
// `labeledSection` inside it drew a second, content-hugging box in the
// top-left corner of the first.
function buildConfirmBody(
  confirm: { action: BulkAction; ids: number[] },
): WidgetSpec {
  const { action, ids } = confirm;
  const cap = capAction(action);
  const existing = ids.filter((id) => orchestratorSessions.has(id));
  const bulk = existing.length > 1;
  const diskNote = (id: number): string =>
    orchestratorSessions.get(id)?.discovered ? editor.t("confirm.disk_note") : "";
  const entries: TextPropertyEntry[] = [];
  if (bulk) {
    entries.push(
      styledRow([
        { text: editor.t("confirm.bulk_header", { cap, count: String(existing.length) }), style: { bold: true } },
      ]),
      styledRow([{ text: "" }]),
    );
    for (const id of existing.slice(0, 8)) {
      const ss = orchestratorSessions.get(id)!;
      entries.push(
        styledRow([
          { text: `  ${sessionShortName(ss)}` },
          { text: diskNote(id), style: { fg: "ui.menu_disabled_fg", italic: true } },
        ]),
      );
    }
    if (existing.length > 8) {
      entries.push(
        styledRow([
          {
            text: editor.t("confirm.and_more", { count: String(existing.length - 8) }),
            style: { fg: "ui.menu_disabled_fg", italic: true },
          },
        ]),
      );
    }
  } else {
    const id = existing[0];
    const ss = id !== undefined ? orchestratorSessions.get(id) : undefined;
    entries.push(
      styledRow([
        {
          text: editor.t("confirm.single_header", {
            cap,
            name: ss ? sessionShortName(ss) : "",
          }),
          style: { bold: true },
        },
      ]),
    );
  }
  const worktree = action === "delete" && confirmTouchesWorktree(existing);
  const unreachable = worktree && confirmHasUnreachableRemote(existing);
  entries.push(
    styledRow([{ text: "" }]),
    styledRow([{ text: bulk ? editor.t("confirm.for_each") : editor.t("confirm.this_will") }]),
  );
  for (const line of confirmActionLines(action, worktree, unreachable)) {
    entries.push(styledRow([{ text: line }]));
  }
  // **Only when files are actually going.** Delete removes nothing on disk for
  // an in-place session, and nothing when the worktree is being kept, so in
  // both of those the warning describes a loss that does not happen — and a
  // warning that cries wolf is worse than none, because the one that matters
  // stops being read.
  if (action === "delete" && worktree && confirmRemoveWorktree && !unreachable) {
    entries.push(
      styledRow([{ text: "" }]),
      styledRow([
        {
          text: editor.t("confirm.uncommitted_lost"),
          style: { fg: "diagnostic.error_fg", bold: true },
        },
      ]),
    );
  }
  return col(
    { kind: "raw", entries },
    // Only rendered when there is a worktree to remove: on an in-place or
    // shared-tree session the control would be a switch wired to nothing.
    // Checked by default, because removing it is what Delete has always
    // done — this adds a way to keep the files, it does not quietly change
    // what the button means.
    ...(worktree
      ? [
        spacer(0),
        toggle(confirmRemoveWorktree, editor.t("confirm.remove_worktree"), {
          key: "confirm-worktree",
        }),
      ]
      : []),
    spacer(0),
    // `endRow`: flush right, reflowing instead of clipping on a narrow pane.
    // No leading flex spacer; the wrap path ignores flex.
    endRow(
      button(editor.t("confirm.btn_cancel"), { key: "confirm-cancel" }),
      spacer(2),
      button(editor.t("confirm.btn_confirm", { cap }), { intent: "danger", key: `confirm-${action}` }),
    ),
  );
}

// The dedicated bulk selection bar (Layout B). Shown in place of the
// per-session preview when two or more rows are checked. The bulk
// action buttons sit at the *top* of the pane; the list of affected
// sessions renders below as a scrollable `list` widget (so a long
// selection scrolls — keyboard, wheel, and the draggable scrollbar —
// rather than overflowing the pane). Each action's count is the
// number of *eligible* members; an action with no eligible members is
// disabled.
function buildBulkPane(): WidgetSpec {
  const sel = selectedSessions();
  const stopN = eligibleSelected("stop").length;
  const archiveN = eligibleSelected("archive").length;
  const deleteN = eligibleSelected("delete").length;

  const inflight = openDialog?.bulkInFlight ?? null;
  const actionRow = inflight
    ? row(
        {
          kind: "raw",
          entries: [
            styledRow([
              {
                text: editor.t("confirm.bulk_progress", {
                  verb: gerundAction(inflight.action),
                  done: String(inflight.done),
                  total: String(inflight.total),
                }),
                style: { fg: "ui.menu_disabled_fg", italic: true },
              },
            ]),
          ],
        },
        flexSpacer(),
      )
    : // `endRow`: flush right while the actions fit, reflowing on a narrow
      // pane instead of clipping. The wrap path ignores flex spacers, so a
      // fixed `spacer(4)` keeps a gap between the destructive actions and
      // "Clear" while still wrapping cleanly.
      endRow(
        button(editor.t("confirm.bulk_btn_stop", { count: String(stopN) }), { key: "bulk-stop", disabled: stopN === 0 }),
        spacer(2),
        button(editor.t("confirm.bulk_btn_archive", { count: String(archiveN) }), {
          key: "bulk-archive",
          disabled: archiveN === 0,
        }),
        spacer(2),
        button(editor.t("confirm.bulk_btn_delete", { count: String(deleteN) }), {
          intent: "danger",
          key: "bulk-delete",
          disabled: deleteN === 0,
        }),
        spacer(4),
        button(editor.t("confirm.bulk_btn_clear"), { key: "bulk-clear" }),
      );

  // Affected-sessions list. Flag the rows a destructive action will
  // skip so the count discrepancy explains itself.
  const items: TextPropertyEntry[] = sel.map((id) => {
    const ss = orchestratorSessions.get(id)!;
    const rowParts: StyledSegment[] = [{ text: `  ${sessionShortName(ss)}` }];
    if (!ss.discovered && !ownsWorktree(ss)) {
      rowParts.push({
        text: editor.t("confirm.row_in_place"),
        style: { fg: "ui.menu_disabled_fg", italic: true },
      });
    } else if (ss.discovered) {
      rowParts.push({
        text: editor.t("confirm.row_on_disk"),
        style: { fg: "ui.menu_disabled_fg", italic: true },
      });
    }
    return styledRow(rowParts);
  });
  const itemKeys = sel.map((id) => `bulksel-${id}`);
  // Match the preview pane's height: content = action row (1) +
  // spacer (1) + list, and the embed pane reserves `listVisibleRows
  // + 4` for its body — so the list takes that height and the two
  // panes' bottom borders line up.
  const listRows = Math.max(3, (openDialog?.listVisibleRows ?? MIN_LIST_ROWS) + 4);

  return labeledSection({
    label: editor.t("confirm.bulk_label", { count: String(sel.length) }),
    child: col(
      actionRow,
      spacer(0),
      list({
        items,
        itemKeys,
        // Display-only: no highlighted row, and out of the Tab cycle
        // (focus belongs on the action buttons). Up/Down still scroll
        // it via the host's smart-key forwarding, and the scrollbar
        // drags it.
        selectedIndex: -1,
        visibleRows: listRows,
        focusable: false,
        key: "bulk-list",
      }),
    ),
  });
}

function buildOpenSpec(): WidgetSpec {
  if (!openDialog) return col();
  const filtered = openDialog.filteredIds;
  // Fill the panel's full height budget (the list pads with blank
  // rows when there are few sessions) so the dialog stays
  // vertically full rather than collapsing to a short floating box.
  openDialog.listVisibleRows = maxListRowsForScreen();
  const activeId = editor.activeWindow();
  // Cards size themselves to the host-laid-out width (flex right-align),
  // so no per-column width estimate is needed here.
  const itemSpecs = filtered.map((id) => renderPillSpec(id, activeId));
  const itemKeys = filtered.map(String);
  const selIdx = filtered.length === 0
    ? -1
    : Math.max(0, Math.min(openDialog.selectedIndex, filtered.length - 1));
  // Gate on the *index* (selIdx < 0 means "filter matched nothing"),
  // not the sign of the id: discovered worktrees carry negative ids
  // and must still resolve to their row here.
  const selectedSession = selIdx >= 0
    ? orchestratorSessions.get(filtered[selIdx])
    : undefined;

  // The "New Session" button advertises Alt+N (or whatever the
  // user re-bound `orchestrator_open_new_from_picker` to). The
  // label reads the binding dynamically through the host's
  // `getKeybindingLabel` so a re-bound key shows correctly, and
  // the host's `format_keybinding` already renders Mac-native
  // symbols (⌥, ⌘, …) when running on macOS — no plugin-side
  // platform detection needed.
  //
  // The button is the *first* tabbable in the dialog (top of the
  // sessions column, before the filter input) so default focus
  // lands on it directly — Enter creates a new session without
  // requiring the user to navigate first.
  const newKey = editor.getKeybindingLabel(
    "orchestrator_open_new_from_picker",
    OPEN_MODE,
  );
  const newLabel = newKey ? editor.t("list.new_btn_key", { key: newKey }) : editor.t("list.new_btn");
  const inConfirm = openDialog.pendingConfirm !== null;
  // While a confirmation prompt is up the filter is rendered
  // without a `key`. The host's `collect_tabbable` only adds
  // widgets that carry a non-empty key, so a keyless text widget
  // is unreachable by Tab and doesn't receive `mode_text_input`
  // — the bracketed input still paints normally, just inert.
  // Keeping the visual chrome (instead of swapping it for a
  // "(disabled)" label) means the dialog doesn't reflow under
  // the user's eyes when the confirm view opens / closes.
  const filterInput = text({
    value: openDialog.filter.value,
    cursorByte: openDialog.filter.cursor,
    label: editor.t("list.filter_label"),
    placeholder: editor.t("list.filter_placeholder"),
    fullWidth: true,
    key: inConfirm ? undefined : "filter",
  });
  const errorBanner: WidgetSpec | null = openDialog.lastError
    ? {
        kind: "raw",
        entries: [
          styledRow([
            {
              text: editor.t("list.warn_prefix"),
              style: { fg: "diagnostic.error_fg", bold: true },
            },
            {
              text: openDialog.lastError,
              style: { fg: "diagnostic.error_fg" },
            },
          ]),
        ],
      }
    : null;

  // Scope chrome. The `Project:` control below is the clickable scope
  // switch; the current scope now reads off that button rather than a
  // title suffix (the dialog title is native modal-frame chrome).
  const scope = openDialog.scope;
  const curKey = currentProjectKey();
  const scopeKey = editor.getKeybindingLabel("orchestrator_toggle_scope", OPEN_MODE);
  const sectionLabel = editor.t("list.section_label");
  // `Project:` control — a visible, clickable scope switch with the
  // Alt+P hint baked into the button label. Shows the current
  // project's name when scoped, "All" when showing every project.
  // Inert while a confirm prompt is up so it can't steal focus.
  const scopeWord = scope === "current" ? editor.pathBasename(curKey) : editor.t("list.scope_all");
  const scopeButtonLabel = scopeKey
    ? editor.t("list.scope_btn_key", { word: scopeWord, key: scopeKey })
    : editor.t("list.scope_btn", { word: scopeWord });
  const scopeButton = button(scopeButtonLabel, {
    key: openDialog.pendingConfirm !== null ? undefined : "scope-toggle",
  });
  const projectControlRow = row(
    {
      kind: "raw",
      entries: [
        styledRow([{ text: editor.t("list.project_prefix"), style: { fg: "ui.menu_disabled_fg" } }]),
      ],
    },
    scopeButton,
    flexSpacer(),
  );
  // Per-project filter checkbox, on its own row under the Project
  // control: opt-in toggle that surfaces the discovered on-disk
  // worktree rows. A `toggle` (single `[ ]`/`[v]` — no double
  // bracket) that's clickable and bound to Alt+T
  // (`orchestrator_toggle_worktrees`, rebindable). The label carries
  // the live keybinding hint, mirroring the Project control's
  // "(Alt+P)". Inert while a confirm prompt is up.
  const worktreeKey = editor.getKeybindingLabel(
    "orchestrator_toggle_worktrees",
    OPEN_MODE,
  );
  const worktreeLabel = worktreeKey
    ? editor.t("list.show_worktrees_key", { key: worktreeKey })
    : editor.t("list.show_worktrees");
  const worktreeFilterRow = row(
    toggle(openDialog.showWorktrees, worktreeLabel, {
      key: openDialog.pendingConfirm !== null ? undefined : "worktree-show",
    }),
    flexSpacer(),
  );
  // Content filter checkbox, beneath the worktree one. The flag is
  // `hideTrivial`, but the checkbox reads as an opt-in "show" toggle to
  // match the worktree row: unchecked (default) hides the empty /
  // single-file shells, checking it reveals them. Inert during confirm.
  const trivialKey = editor.getKeybindingLabel(
    "orchestrator_toggle_trivial",
    OPEN_MODE,
  );
  const trivialLabel = trivialKey
    ? editor.t("list.show_trivial_key", { key: trivialKey })
    : editor.t("list.show_trivial");
  const trivialFilterRow = row(
    toggle(!openDialog.hideTrivial, trivialLabel, {
      key: openDialog.pendingConfirm !== null ? undefined : "hide-trivial",
    }),
    flexSpacer(),
  );

  return col(
    // The "ORCHESTRATOR :: Workspaces" title is native modal-frame chrome
    // now (set on the panel at mount — see `openControlRoom`), so the spec
    // starts straight at the error banner / two-pane body.
    ...(errorBanner ? [errorBanner] : []),
    spacer(0),
    // Two-pane: sessions list | preview. Renderer's `row()`
    // horizontally zips multi-line children so this composes
    // the wireframed shape directly. Width split 25 / 75 —
    // the preview pane carries the action buttons and the
    // (Phase 7) live-window render, so it earns the bulk of
    // the dialog.
    row(
      labeledSection({
        label: sectionLabel,
        // 34% (was 25%): wide enough that the per-row project tag in
        // the all-projects view (`· <project>`) and longer session
        // labels render without truncating to `· tmp_o…`. The preview
        // pane still keeps the majority for the live window embed.
        widthPct: 34,
        // Sessions column: New button, Project (scope) control,
        // Filter, separator, column header, list. The button is
        // first so it gets initial focus (Enter immediately opens the
        // new session form). Separators are long `─` strings that the
        // renderer truncates to the column's inner width — no need to
        // measure cells from the plugin side.
        child: col(
          row(
            button(newLabel, {
              intent: "primary",
              // Drop the key while a confirm prompt is up so the
              // button is non-tabbable and click-inert — same
              // pattern the filter input uses. Otherwise it stays
              // the first tabbable in the panel and the confirm
              // view's "first-tabbable wins" focus fallback lands
              // here instead of on Cancel.
              key: inConfirm ? undefined : "new-session",
            }),
            flexSpacer(),
          ),
          projectControlRow,
          worktreeFilterRow,
          trivialFilterRow,
          filterInput,
          sessionsSeparator(),
          sessionsColumnHeader(),
          list({
            items: [],
            itemSpecs,
            itemKeys,
            selectedIndex: selIdx,
            // `listVisibleRows` is the fitted list height; the 5 rows
            // of column chrome above it (New / Project / Filter /
            // separator / header) and the matching preview embed are
            // accounted for separately so both panes stay the same
            // height and the footer hint stays on-screen.
            visibleRows: openDialog.listVisibleRows,
            // Excluded from the Tab cycle — Up/Down on the
            // filter input forwards to this list via host
            // smart-keys, so Tab jumps straight to the action
            // buttons instead of stopping here.
            focusable: false,
            // Drop the `key` while a confirmation prompt is up so
            // `find_scrollable_widget_key` (`plugin_dispatch.rs`)
            // can't find this list — Up/Down on the focused Cancel
            // button would otherwise forward to the list and let
            // the user move the selection off the session being
            // confirmed (which would break the confirm view because
            // it only renders when the selected row matches
            // `pendingConfirm.sessionId`).
            key: inConfirm ? undefined : "sessions",
          }),
        ),
      }),
      // Preview pane has no explicit width — picks up the
      // remaining width by default since the sessions list took 34%.
      buildPreviewPane(selectedSession),
    ),
    row(
      flexSpacer(),
      hintBar([
        { keys: "↑↓", label: editor.t("hint.nav") },
        { keys: "Enter", label: editor.t("hint.dive") },
        {
          keys: editor.getKeybindingLabel("orchestrator_toggle_select", OPEN_MODE) ||
            "Space",
          label: editor.t("hint.select"),
        },
        {
          keys: scopeKey || "⌥P",
          label: scope === "current" ? editor.t("hint.all_projects") : editor.t("hint.current_only"),
        },
        { keys: "Tab", label: editor.t("hint.focus") },
        { keys: "Esc", label: editor.t("hint.close") },
      ]),
      flexSpacer(),
    ),
  );
}

// Surface a lifecycle-action refusal in two places: the dialog
// itself (a coloured banner above the filter, hard to miss while
// the user's attention is on the dialog) and the status bar
// (matches the long-standing convention and survives if the
// dialog closes). Pass the bare reason — the picker prepends
// "Orchestrator: " for the status bar.
function setDialogError(msg: string): void {
  if (openDialog) {
    openDialog.lastError = msg;
  }
  editor.setStatus(editor.t("status.prefix", { msg }));
}

function clearDialogError(): void {
  if (openDialog?.lastError) {
    openDialog.lastError = null;
  }
}

function refreshOpenDialog(): void {
  if (!openPanel || !openDialog) return;
  pruneSelection();
  openDialog.filteredIds = filterSessions(openDialog.filter.value);
  // Ensure the background probe poll is running (idempotent; it stops
  // itself when the panel closes). PR/git info is gathered on that
  // loop's own cadence, never synchronously from this refresh.
  startProbePolling();
  // Clamp the selection into range so a fresh filter or a
  // session vanishing under us doesn't leave us pointing past
  // the end of the list.
  if (openDialog.filteredIds.length === 0) {
    openDialog.selectedIndex = 0;
  } else if (openDialog.selectedIndex >= openDialog.filteredIds.length) {
    openDialog.selectedIndex = openDialog.filteredIds.length - 1;
  } else if (openDialog.selectedIndex < 0) {
    openDialog.selectedIndex = 0;
  }
  openPanel.update(dockMode ? buildDockSpec() : buildOpenSpec());
  // The list/tree widget's `selectedIndex` in the spec is initial-only;
  // pin it via mutation so re-renders don't snap back to 0. In the dock
  // (a tree) the pin follows the highlighted node key, which
  // `buildDockSpec` just reconciled; in the modal (a list) it follows
  // the `filteredIds` index.
  if (dockMode) {
    const idx = openDialog.dockSelKey
      ? openDialog.dockKeys.indexOf(openDialog.dockSelKey)
      : -1;
    if (idx >= 0) openPanel.setSelectedIndex("sessions", idx);
  } else if (openDialog.filteredIds.length > 0) {
    openPanel.setSelectedIndex("sessions", openDialog.selectedIndex);
  }
  // `filteredIds` is the single source of truth for the dock's visible list.
  // While the dock is open, make Next/Prev Window cycle through exactly that
  // list (its live windows, in display order) instead of every open window —
  // so paging sessions matches what the dock shows. Discovered worktrees
  // (negative ids) aren't windows, so they're dropped here; the host also
  // skips any id that isn't currently open. Cleared in `closeOpenDialog`.
  if (dockMode) {
    editor.setWindowCycleOrder(openDialog.filteredIds.filter((id) => id > 0));
    // The tree's `expandedKeys` is a seed too, and a rebuild can change
    // what it should be (a search opening every folder, or clearing).
    applyDockExpansion();
  }
}

// Move the dock's highlighted row onto the active window. Used when the
// active session changes from *outside* the dock's own ↑/↓ live-switch —
// a new session is created, or another window is focused — so the dock,
// which is a passive mirror while blurred, highlights the session the
// editor actually switched to instead of stranding the highlight on the
// previously-active row. No-op when the active window isn't in the
// (filtered) list.
// Move the dock's highlight onto one session's row. A no-op when the dock
// isn't showing, or when the row isn't in the tree (filtered out, or inside a
// collapsed folder) — the highlight is a pointer into the rendered list.
function selectDockRow(id: number): void {
  if (!openDialog || !openPanel || !dockMode) return;
  const key = sessionNodeKey(id);
  const idx = openDialog.dockKeys.indexOf(key);
  if (idx < 0) return;
  openDialog.dockSelKey = key;
  openPanel.setSelectedIndex("sessions", idx);
}

function syncDockSelectionToActive(): void {
  if (!openDialog || !openPanel || !dockMode) return;
  const activeKey = sessionNodeKey(editor.activeWindow());
  const idx = openDialog.dockKeys.indexOf(activeKey);
  if (idx < 0) return;
  openDialog.dockSelKey = activeKey;
  openPanel.setSelectedIndex("sessions", idx);
}

// =============================================================================
// PR probe — opportunistic `gh` integration for the pill's second line
//
// Best-effort and non-blocking: each visible session's branch is looked
// up against `gh pr view`; results are cached on the session with a TTL
// so holding ↑/↓ doesn't fan out a probe per row, and any failure (`gh`
// missing, not a GitHub remote, unauthenticated, or no PR for the
// branch) degrades silently to the "no PR" / branch fallback.
// =============================================================================

const PR_PROBE_TTL_MS = 90_000;
const prProbesInFlight = new Set<number>();
// Git is local + cheap, so refresh it more often than the PR (network) probe.
const GIT_PROBE_TTL_MS = 15_000;
const gitProbesInFlight = new Set<number>();
// Ceiling on git probes running at once. Each probe spawns two subprocesses
// (`git status` + `git diff`), and the poll loop kicks one per *filtered*
// session every tick — so a dock listing many worktrees would otherwise fan
// out dozens of concurrent spawns on the same tick (a spawn storm that spiked
// render latency). A session skipped because the cap is full is retried on the
// next poll (~5s), comfortably inside the 15s freshness TTL, so nothing goes
// stale — the bursts just get spread across a few ticks.
const MAX_CONCURRENT_GIT_PROBES = 6;

// Sessions whose worktree is being moved or removed. Every probe runs with its
// cwd inside the worktree, and Windows refuses to delete (or rename) a
// directory a live process is sitting in: a poll-tick `git status` or
// `gh pr view` still running in the next row of a bulk Delete failed it with
// "Permission denied". `holdProbesOff` stops a session's probes from spawning,
// kills the ones already running, and waits for them to exit before the
// caller touches the directory.
const probesHeldOff = new Set<number>();
const probeProcs = new Map<number, Set<ProcessHandle<SpawnResult>>>();

// Every probe subprocess goes through here, so `holdProbesOff` can find it.
// A held session spawns nothing: its probe sees a failed command.
async function probeSpawn(s: AgentSession, command: string, args: string[]): Promise<SpawnResult> {
  if (probesHeldOff.has(s.id)) return { stdout: "", stderr: "", exit_code: -1 };
  const handle = editor.spawnProcess(command, args, s.root);
  let running = probeProcs.get(s.id);
  if (!running) {
    running = new Set();
    probeProcs.set(s.id, running);
  }
  running.add(handle);
  try {
    return await handle;
  } finally {
    running.delete(handle);
    if (running.size === 0 && probeProcs.get(s.id) === running) probeProcs.delete(s.id);
  }
}

async function holdProbesOff<T>(id: number, action: () => Promise<T>): Promise<T> {
  probesHeldOff.add(id);
  try {
    const running = [...(probeProcs.get(id) ?? [])];
    for (const handle of running) void handle.kill();
    // A killed spawn settles once the child has been reaped, so after this
    // nothing of the probe's is left in the directory.
    await Promise.allSettled(running.map((handle) => handle.result));
    return await action();
  } finally {
    probesHeldOff.delete(id);
  }
}

// Resolve (and cache) a session's branch. Live sessions don't carry
// `branch` up front, so ask git in the worktree once.
async function sessionBranch(s: AgentSession): Promise<string> {
  if (s.branch) return s.branch;
  try {
    const r = await probeSpawn(s, "git", ["rev-parse", "--abbrev-ref", "HEAD"]);
    if (r.exit_code === 0) {
      const b = (r.stdout || "").trim();
      if (b && b !== "HEAD") {
        s.branch = b;
        return b;
      }
    }
  } catch (_e) {
    // ignore — branch stays unknown, probe will report "none"
  }
  return s.branch || "";
}

// Tally a gh `statusCheckRollup` array into pass / fail / pending.
// Handles both CheckRun (status/conclusion) and StatusContext (state).
function rollupCounts(
  rollup: unknown,
): { pass: number; fail: number; pending: number } {
  let pass = 0;
  let fail = 0;
  let pending = 0;
  if (Array.isArray(rollup)) {
    for (const c of rollup as Record<string, unknown>[]) {
      const status = String(c.status ?? "").toUpperCase();
      if (status && status !== "COMPLETED") {
        pending++;
        continue;
      }
      const concl = String(c.conclusion ?? c.state ?? "").toUpperCase();
      if (["SUCCESS", "NEUTRAL", "SKIPPED"].includes(concl)) pass++;
      else if (
        ["FAILURE", "ERROR", "CANCELLED", "TIMED_OUT", "ACTION_REQUIRED"]
          .includes(concl)
      ) fail++;
      else pending++;
    }
  }
  return { pass, fail, pending };
}

async function probePr(s: AgentSession): Promise<void> {
  if (prProbesInFlight.has(s.id) || probesHeldOff.has(s.id)) return;
  const now = Date.now();
  if (s.pr && s.pr.status !== "loading" && now - s.pr.fetchedAt < PR_PROBE_TTL_MS) {
    return;
  }
  prProbesInFlight.add(s.id);
  const prior = s.pr;
  // Keep any prior info visible while re-checking (avoids a flicker
  // back to the branch fallback on refresh).
  s.pr = { status: "loading", fetchedAt: s.pr?.fetchedAt ?? 0, info: s.pr?.info };
  try {
    const branch = await sessionBranch(s);
    if (!branch) {
      s.pr = { status: "none", fetchedAt: Date.now() };
      return;
    }
    const fields =
      "number,state,isDraft,reviewDecision,mergeable,statusCheckRollup,comments";
    const r = await probeSpawn(s, "gh", ["pr", "view", branch, "--json", fields]);
    if (r.exit_code !== 0) {
      // No PR for this branch, or `gh` unavailable / not a GH remote.
      s.pr = { status: "none", fetchedAt: Date.now() };
      return;
    }
    const j = JSON.parse(r.stdout || "{}") as Record<string, unknown>;
    const counts = rollupCounts(j.statusCheckRollup);
    const comments = Array.isArray(j.comments)
      ? j.comments.length
      : typeof j.comments === "number"
      ? j.comments
      : 0;
    s.pr = {
      status: "ok",
      fetchedAt: Date.now(),
      info: {
        number: Number(j.number),
        state: j.state ? String(j.state) : undefined,
        isDraft: Boolean(j.isDraft),
        reviewDecision: j.reviewDecision ? String(j.reviewDecision) : "",
        mergeable: j.mergeable ? String(j.mergeable) : undefined,
        checksPass: counts.pass,
        checksFail: counts.fail,
        checksPending: counts.pending,
        comments,
      },
    };
  } catch (_e) {
    s.pr = { status: "none", fetchedAt: Date.now() };
  } finally {
    // Killed (or never run) for a move/remove: that says nothing about the
    // PR, so keep what was known in case the action fails and the row stays.
    if (probesHeldOff.has(s.id)) s.pr = prior;
    prProbesInFlight.delete(s.id);
    // Surface the freshly-gathered badge (debounced so a batch of
    // probes finishing together collapses into one render).
    scheduleProbeRefresh();
  }
}

// Parse `git status --porcelain=v2 --branch` into a GitStat. Counts any
// non-`#` line as a dirty path (changed/staged/unmerged/untracked).
function parsePorcelainV2(stdout: string): GitStat {
  const g: GitStat = {};
  let dirty = 0;
  for (const line of (stdout || "").split(/\r?\n/)) {
    if (line.startsWith("# branch.head ")) {
      const b = line.slice("# branch.head ".length).trim();
      if (b && b !== "(detached)") g.branch = b;
    } else if (line.startsWith("# branch.ab ")) {
      const m = line.match(/\+(\d+)\s+-(\d+)/);
      if (m) {
        g.ahead = Number(m[1]);
        g.behind = Number(m[2]);
      }
    } else if (line && !line.startsWith("#")) {
      dirty++;
    }
  }
  g.dirty = dirty;
  return g;
}

// Opportunistic local-git summary for the pill's second line. Two cheap
// git calls (status + diffstat), throttled like the PR probe.
// Kick git probes for the open dialog's filtered sessions up to the
// concurrency cap. `probeGit` self-skips fresh / in-flight sessions, so this
// only spends slots on sessions that would actually spawn. Called from the
// poll tick and re-invoked as each probe completes, giving a continuously
// draining bounded pool: at most MAX_CONCURRENT_GIT_PROBES spawn at once, but
// freed slots refill immediately, so a large dock still refreshes promptly
// without a same-tick storm.
function drainGitProbes(): void {
  if (!openDialog) return;
  for (const id of openDialog.filteredIds) {
    if (gitProbesInFlight.size >= MAX_CONCURRENT_GIT_PROBES) break;
    const s = orchestratorSessions.get(id);
    if (s) void probeGit(s);
  }
}

async function probeGit(s: AgentSession): Promise<void> {
  if (gitProbesInFlight.has(s.id) || probesHeldOff.has(s.id)) return;
  const now = Date.now();
  if (s.git && s.git.status === "ok" && now - s.git.fetchedAt < GIT_PROBE_TTL_MS) {
    return;
  }
  // Bound concurrent git spawns (see MAX_CONCURRENT_GIT_PROBES). Check this
  // *after* the freshness gate so an up-to-date session is still a free no-op;
  // only sessions that would actually spawn count against the cap. `drainGitProbes`
  // refills the slot this holds as soon as the probe finishes.
  if (gitProbesInFlight.size >= MAX_CONCURRENT_GIT_PROBES) return;
  gitProbesInFlight.add(s.id);
  s.git = { status: "loading", fetchedAt: s.git?.fetchedAt ?? 0, info: s.git?.info };
  try {
    const st = await probeSpawn(s, "git", ["status", "--porcelain=v2", "--branch"]);
    if (st.exit_code !== 0) {
      // `git status` failed. This is usually transient — an agent holding
      // `.git/index.lock`, a mid-checkout worktree, etc. — so KEEP the last
      // known summary instead of blanking it (a genuine non-git dir simply
      // never had `info`, so this stays empty there). Dropping it made the
      // card's git segment blink on every failed poll (TUI + web churn).
      s.git = { status: "ok", fetchedAt: Date.now(), info: s.git?.info };
      return;
    }
    const info = parsePorcelainV2(st.stdout || "");
    if (info.branch && !s.branch) s.branch = info.branch;
    // Uncommitted line churn vs HEAD (staged + unstaged). `BIG_FILE_ARGS`
    // because this runs on the session poll: `--shortstat` prints one line
    // either way, but without the cap git still diffs a multi-megabyte blob
    // in full to count it, once per session per tick.
    const diff = await probeSpawn(s, "git", [...BIG_FILE_ARGS, "diff", "--shortstat", "HEAD"]);
    if (diff.exit_code === 0) {
      const ins = (diff.stdout || "").match(/(\d+) insertion/);
      const del = (diff.stdout || "").match(/(\d+) deletion/);
      if (ins) info.added = Number(ins[1]);
      if (del) info.deleted = Number(del[1]);
    }
    s.git = { status: "ok", fetchedAt: Date.now(), info };
  } catch (_e) {
    // Spawn/parse error (git missing, killed, etc.) — same as above: keep the
    // last known summary rather than blanking the card on a transient failure.
    s.git = { status: "ok", fetchedAt: Date.now(), info: s.git?.info };
  } finally {
    gitProbesInFlight.delete(s.id);
    // Refill the slot this probe just freed FIRST, so the pool keeps draining
    // between polls (preserves throughput under the concurrency cap) and, more
    // importantly, so the quiescence check in `scheduleProbeRefresh` sees the
    // newly-started probes — otherwise the last completion of a wave would look
    // idle while more sessions are still queued, and refresh mid-batch.
    drainGitProbes();
    scheduleProbeRefresh();
  }
}

// Probe lifecycle: a single low-frequency poll loop, NOT action-driven.
// It ticks every PROBE_POLL_INTERVAL_MS while a panel is open and kicks
// the per-session probes, which each self-throttle to their TTL (git
// 15s, pr 90s) — so a session is hit at most once per TTL regardless of
// how often the panel re-renders (e.g. a busy agent spamming
// terminal_output no longer fans out probes). The loop stops itself when
// the panel closes.
const PROBE_POLL_INTERVAL_MS = 5_000;
let probePollActive = false;

function startProbePolling(): void {
  if (probePollActive) return;
  probePollActive = true;
  const tick = (): void => {
    if (!openPanel || !openDialog) {
      probePollActive = false;
      return;
    }
    for (const id of openDialog.filteredIds) {
      const s = orchestratorSessions.get(id);
      if (!s) continue;
      void probePr(s);
    }
    // Git probes drain at bounded concurrency (see `drainGitProbes`) rather
    // than all firing on this tick — each completion refills the freed slot,
    // so throughput is preserved without the same-tick spawn burst.
    drainGitProbes();
    void editor.delay(PROBE_POLL_INTERVAL_MS).then(tick);
  };
  tick();
}

// Coalesce the re-renders triggered by probe completions into ONE atomic
// update per batch. A poll cycle can re-probe many sessions (git + pr), and
// they finish at different times — a bounded git pool drains in waves, gh is
// network-latent. Refreshing per completion trickled a frame each, so the
// dock visibly repainted several times per cycle (flicker, and any in-flight
// scroll gesture dropped). Instead we hold the refresh until every probe has
// settled (`gitProbesInFlight` and `prProbesInFlight` both empty) and then
// repaint once, so the whole batch of new git/pr summaries lands together.
// The `finally` blocks call this AFTER re-draining, so a still-queued session
// keeps the pool non-empty and defers the refresh to the true end of the wave.
//
// On top of batching, the probe-driven repaint is RATE-LIMITED: a fresh round
// starts at most once per `PROBE_REFRESH_MIN_INTERVAL_MS`. Even if waves keep
// settling back-to-back, the dock never repaints from probes more often than
// this, which caps any residual churn to a slow, unnoticeable cadence. Only
// this probe path is throttled — interactive updates call `refreshOpenDialog`
// directly and stay instant.
const PROBE_REFRESH_MIN_INTERVAL_MS = 4000;
let probeRefreshPending = false;
let lastProbeRefreshAt = 0;
function scheduleProbeRefresh(): void {
  // Not yet quiescent — a later completion will call back in and land the one
  // refresh once the batch fully settles.
  if (gitProbesInFlight.size > 0 || prProbesInFlight.size > 0) return;
  if (probeRefreshPending) return;
  probeRefreshPending = true;
  // Honour both the coalescing debounce (150ms) and the minimum spacing since
  // the last probe refresh, whichever is longer.
  const sinceLast = Date.now() - lastProbeRefreshAt;
  const wait = Math.max(150, PROBE_REFRESH_MIN_INTERVAL_MS - sinceLast);
  void editor.delay(wait).then(() => {
    probeRefreshPending = false;
    lastProbeRefreshAt = Date.now();
    if (openPanel) refreshOpenDialog();
  });
}

function openControlRoom(
  opts: { dock?: boolean; blurred?: boolean } = {},
): void {
  const asDock = opts?.dock === true;
  if (asDock) noteLayoutChange();
  const startBlurred = asDock && opts?.blurred === true;
  if (openPanel) {
    // If the dock is showing and the user asked for the modal picker
    // (Orchestrator: Open), float the
    // picker *over* the dock instead of replacing it: keep the dock
    // mounted in its own host slot (PanelSlot::Dock) and build the picker
    // as a fresh panel in the Floating slot, exactly as the New-Session
    // form coexists with the dock. The host renders both slots, so the
    // dock stays put in its left column — dimmed and passive — and the
    // picker lays into `chrome_area` beside it. Closing the picker hands
    // control back to the dock (`restoreDockBehindPicker`). An `asDock`
    // re-entry (Toggle Dock) never reaches here — `toggleDock` handles it
    // first; and a modal picker that is already up has nothing to do.
    if (!asDock && dockMode) {
      dockPanel = openPanel; // dock stays mounted behind the picker
      openPanel = null; // fall through builds the picker as a new panel
      dockBlurred = true; // the dock is now the inert background
      // dockMode flips to false in the (asDock === false) branch below.
    } else {
      return;
    }
  }
  reconcileSessions();
  // Summarise on-disk session content up front so the trivial filter
  // has data on the first render.
  scanSessionContent();
  const activeId = editor.activeWindow();
  // Seed with the screen-max; buildOpenSpec refits to the session
  // count on the first render (and every render after).
  const listVisibleRows = maxListRowsForScreen();
  openDialog = {
    filter: { value: "", cursor: 0 },
    filteredIds: [],
    selectedIndex: 0,
    originalActiveSession: activeId,
    pendingConfirm: null,
    listVisibleRows,
    embedRows: Math.max(3, listVisibleRows + 3),
    dockTreeTop: 0,
    showDetails: false,
    inFlight: null,
    lastError: null,
    // Restore the last-used scope (defaults to "all"); the Project
    // control / Alt+P updates it for next time.
    scope: lastOpenScope,
    selectedIds: new Set<number>(),
    showWorktrees: configuredShowWorktrees(),
    hideTrivial: configuredHideTrivial(),
    bulkInFlight: null,
    projectFilter: asDock ? lastDockProjectFilter : null,
    projectMenuOpen: false,
    projectMenuIndex: 0,
    searchOpen: false,
    dockMenu: null,
    dockSelKey: null,
    dockNodes: [],
    dockKeys: [],
  };
  // Set `dockMode` BEFORE the initial `filterSessions("")`. The sort
  // inside `filterSessions` keys off `pinCurrentFirst = !dockMode`: the
  // dock wants stable lex order, the modal picker wants current-first.
  // Doing the filter first (when `dockMode` is still its previous /
  // initial `false` value) made the dock's INITIAL render use current-
  // first ordering, while every subsequent `refreshOpenDialog`
  // (active_window_changed, window_created, …) used the stable lex
  // sort. Switching the active project then visibly reordered the
  // dock list — precisely what the dock comment forbids.
  openPanel = new FloatingWidgetPanel();
  if (asDock) {
    dockMode = true;
    dockBlurred = false;
    // Adopt the configured density on every open (unless the "view"
    // button already picked one this session), so editing the setting
    // and reopening the dock is enough to see the change.
    dockView = configuredDockView();
  } else {
    dockMode = false;
  }
  openDialog.filteredIds = filterSessions("");
  const activeIdx = openDialog.filteredIds.indexOf(activeId);
  openDialog.selectedIndex = activeIdx >= 0 ? activeIdx : 0;
  if (asDock) {
    // Persistent, non-modal full-height left column. Mount, then
    // re-anchor to the dock (which sets the content-wrap width to the
    // dock columns) and re-render so the spec lays out at dock width.
    // Mount straight into the host's dedicated dock slot so it
    // coexists with a centered modal (the New-Session form) instead
    // of being replaced by it. `asDock` carves the left column and
    // wraps the content to the dock width.
    openPanel.mount(buildDockSpec(), {
      widthPct: 100,
      heightPct: 100,
      asDock: true,
      mode: DOCK_MODE,
      // "Stay put" callers (autoOpenDock, placeholder rows) must never
      // put the keyboard in the dock, not even for the tick between a
      // focused mount and a follow-up blur command.
      startBlurred,
    });
    // The column's width is the host's; nothing to re-issue.
    openPanel.update(buildDockSpec());
    applyDockExpansion();
  } else {
    // 90% × 90% of the terminal — the open dialog wants room for
    // a real session list + preview pane, unlike the new-session
    // form which stays compact.
    openPanel.mount(buildOpenSpec(), {
      widthPct: 90,
      heightPct: 90,
      // Native modal-frame chrome replaces the in-body "ORCHESTRATOR ::
      // Workspaces" title row; `closable` renders a native `[×]` that
      // dismisses via the same cancel path as Esc. Chrome is only drawn
      // for Centered placement, so the dock mount above never gets it.
      title: editor.t("list.title"),
      closable: true,
      mode: OPEN_MODE,
    });
    // The control room is a global orchestrator feature: render it over
    // the full screen (covering its own dimmed dock) rather than cramped
    // into the chrome area beside the dock. A no-op when no dock is up
    // (the chrome area already is the whole frame then).
    editor.floatingPanelControl(openPanel.id(), "fullscreen", 1);
  }
  if (openDialog.filteredIds.length > 0) {
    openPanel.setSelectedIndex("sessions", openDialog.selectedIndex);
  }
  // Visit is the dialog's primary action — land focus there on
  // mount so Enter immediately opens the selected session. The
  // tabbable order is unchanged (new-session → filter → preview-
  // pane buttons); we just override the default-first-tabbable
  // selection. The host clamps to the first tabbable when "visit"
  // isn't in the spec (empty filter result, no session), which is
  // safe — there's nothing to act on then anyway.
  // In the dock the focusable session list is the default focus
  // (↑↓ switch, Enter blurs to editor). The modal lands on Visit.
  const initialFocus = asDock ? "sessions" : "visit";
  openPanel.setFocusKey(initialFocus);

  // Discover worktrees that exist on disk but aren't open yet and
  // fold them into the list. Async (it shells out to git per
  // project); the dialog renders immediately with live sessions and
  // gains the discovered rows when the scan lands.
  void refreshDiscoveredWorktrees();
  // The external sessions group, the same way: what the feed already has now, a
  // fresh listing when it lands.
  if (asDock) refreshExternal();
}

// When the modal Open picker was floated over a still-mounted dock,
// dropping the picker hands keyboard control back to the dock (which
// stayed mounted in the Dock slot the whole time) instead of tearing
// everything down. Returns true when it restored the dock — callers
// then stop, treating the picker as "closed to the dock". The shared
// `openDialog` may have been filtered/reselected by the picker, so reset
// it to the full list before the dock re-renders.
function restoreDockBehindPicker(): boolean {
  if (!dockPanel) return false;
  openPanel = dockPanel;
  dockPanel = null;
  dockMode = true;
  dockBlurred = false;
  if (openDialog) {
    openDialog.filter = { value: "", cursor: 0 };
    const activeId = editor.activeWindow();
    openDialog.filteredIds = filterSessions("");
    const activeIdx = openDialog.filteredIds.indexOf(activeId);
    openDialog.selectedIndex = activeIdx >= 0 ? activeIdx : 0;
  }
  refreshOpenDialog();
  editor.floatingPanelControl(openPanel.id(), "focus", 0);
  focusDockControl("sessions");
  return true;
}

function closeOpenDialog(): void {
  noteLayoutChange();
  // A dropped move still playing out is filed now: the preview goes with
  // the panel, and so would its `movepreviewend`.
  flushCommittedDockDrops();
  // A pick waiting for a folder, and a drag the dock was drawing, belong to
  // the panel going away: neither may come back with the next one. (A drag's
  // `dragend` cannot reach a panel that is gone, nor a drop preview's
  // `movepreviewend`.)
  movePick = null;
  dockDrag = null;
  pendingDockDrop = null;
  if (openPanel) {
    openPanel.unmount();
    openPanel = null;
  }
  // If a dock was kept behind the picker, hand control back to it rather
  // than dropping to the bare editor. (It re-publishes its own cycle order
  // on the next refresh, so leave the override in place here.)
  if (restoreDockBehindPicker()) return;
  openDialog = null;
  dockMode = false;
  dockBlurred = false;
  // The dock is gone — restore the default Next/Prev Window cycling (every
  // window, by id).
  editor.setWindowCycleOrder([]);
}

// ---------------------------------------------------------------------
// Global left dock
//
// The dock reuses the open-dialog state/panel but is mounted as a
// full-height, non-modal left column (host `floatingPanelControl`
// "dock"). It renders a single-column session list (the modal's
// two-pane picker would be unreadable at dock width). Navigating the
// list switches the active window live (debounced), so the editor to
// the dock's right *is* the preview.
// ---------------------------------------------------------------------

// Lifecycle actions, bulk-select, and per-session confirmations now
// live in the modal picker (reached via `Orchestrator: Open`);
// the dock itself is a lean switcher with no destructive controls.

// Option keys for the dock's project dropdown, in display order. Index 0
// is always "All projects" (the empty-string key); the rest are the
// projects with a session in the worktree/trivial-filtered set. The
// project menu's keyboard cursor (`projectMenuIndex`) and the list's
// `select`/`activate` handlers index into this list, so it's the single
// source of truth for both render and navigation.
function projectMenuKeys(): string[] {
  return ["", ...dockProjectOptions()];
}

// The dock's project dropdown as a list: "All projects" plus every project
// with a session in the worktree/trivial-filtered set, anchored just under
// the toolbar via `overlay` so it paints over the rows below without
// reflowing them. The `●` marks the *applied* filter; the list's selection
// is the keyboard cursor (`projectMenuIndex`) — two separate signals so ↑/↓
// can move the cursor over options without yet applying them, the way a
// standard dropdown behaves. Rows are keyed by option so a click on one
// names it.
function dockProjectMenu(): WidgetSpec {
  const cur = openDialog?.projectFilter ?? null;
  const keys = projectMenuKeys();
  const cursor = clampMenuIndex(openDialog?.projectMenuIndex ?? 0, keys.length);
  const items = keys.map((key) => {
    const applied = key === "" ? cur === null : key === cur;
    const label = key === "" ? editor.t("dock.all_projects") : projectLabel(key);
    return { text: (applied ? "● " : "  ") + label };
  });
  return overlay(
    labeledSection({
      label: editor.t("dock.menu_label"),
      child: list({
        items,
        itemKeys: keys.map((key) => `${PROJECT_MENU_KEY}:${key}`),
        selectedIndex: cursor,
        visibleRows: Math.max(1, keys.length),
        key: PROJECT_MENU_KEY,
      }),
    }),
    { key: DOCK_PROJECT_OVERLAY_KEY },
  );
}

// Clamp a menu cursor into `[0, len)`, tolerating an empty list.
function clampMenuIndex(idx: number, len: number): number {
  if (len <= 0) return 0;
  return Math.max(0, Math.min(idx, len - 1));
}

// Open the dock's project dropdown and hand it the keyboard. Seeds the
// cursor on the *applied* option (so ↑/↓ start from where you are) and
// moves panel focus onto that option's button — which is the signal the
// host uses to route nav keys here instead of the session list.
function openProjectMenu(): void {
  if (!openDialog || !openPanel) return;
  const keys = projectMenuKeys();
  const applied = openDialog.projectFilter;
  const idx = applied === null ? 0 : Math.max(0, keys.indexOf(applied));
  // One dropdown at a time: the scope list replaces the Menu it may
  // have been picked from.
  openDialog.dockMenu = null;
  openDialog.projectMenuOpen = true;
  openDialog.projectMenuIndex = clampMenuIndex(idx, keys.length);
  // Render the menu first so its list exists in the spec, *then* move
  // focus onto it — otherwise the host re-clamps an unknown focus key
  // back to the first tabbable.
  openPanel.update(buildDockSpec());
  focusDockControl(PROJECT_MENU_KEY);
}

// Close the dropdown and return the keyboard to the session list.
function closeProjectMenu(): void {
  if (!openDialog || !openPanel) return;
  openDialog.projectMenuOpen = false;
  openPanel.update(buildDockSpec());
  focusDockControl("sessions");
}

// The list's cursor moved (↑/↓, or a click on a row): mirror it, and a
// click picks the row outright, the way a menu row answers a click.
function projectMenuSelected(index: number, click: boolean): void {
  if (!openDialog || !openDialog.projectMenuOpen) return;
  const keys = projectMenuKeys();
  openDialog.projectMenuIndex = clampMenuIndex(index, keys.length);
  if (click) pickProject(keys[openDialog.projectMenuIndex] ?? "");
}

// Commit the cursor's option as the active project filter and close.
function acceptProjectMenu(index?: number): void {
  if (!openDialog || !openDialog.projectMenuOpen) return;
  const keys = projectMenuKeys();
  const at = clampMenuIndex(index ?? openDialog.projectMenuIndex, keys.length);
  pickProject(keys[at] ?? "");
}

// Apply a project-dropdown option (empty = "All projects") as the dock's
// project filter, re-filter the session list, close the menu, and return
// focus to the list. Shared by mouse clicks on a row, Enter on the
// keyboard cursor, and any programmatic pick.
function pickProject(optionKey: string): void {
  if (!openDialog) return;
  applyProjectFilter(optionKey);
  closeProjectMenu();
  if (openPanel && openDialog.filteredIds.length > 0) {
    openPanel.setSelectedIndex("sessions", openDialog.selectedIndex);
  }
}

// Set the dock's project filter (empty = "All projects") and re-filter
// the session list, leaving focus where it is.
function applyProjectFilter(optionKey: string): void {
  if (!openDialog) return;
  openDialog.projectFilter = optionKey === "" ? null : optionKey;
  lastDockProjectFilter = openDialog.projectFilter;
  // Re-filter to the chosen project and keep the active session selected
  // when it's still in view.
  const activeId = editor.activeWindow();
  const next = filterSessions(openDialog.filter.value);
  openDialog.filteredIds = next;
  const activeIdx = next.indexOf(activeId);
  openDialog.selectedIndex = activeIdx >= 0 ? activeIdx : 0;
  refreshOpenDialog();
}

// The dock's attention line (§2.3): how many workspaces need the user
// and how many finished unseen work, in the same glyph + colour the rows
// use. Both halves are optional; the separator only appears between two.
function dockAttentionRow(att: { blocked: number; done: number }): WidgetSpec {
  const parts: WidgetSpec[] = [];
  if (att.blocked > 0) {
    const sym = STATE_SYMBOL.blocked;
    parts.push(
      label(`${sym.glyph} ${editor.t("dock.need_you", { n: String(att.blocked) })}`, {
        style: { fg: sym.fg, bold: true },
      }),
    );
  }
  if (att.done > 0) {
    if (parts.length > 0) {
      parts.push(label(" · ", { style: { fg: "ui.menu_disabled_fg" } }));
    }
    const sym = STATE_SYMBOL.done;
    parts.push(
      label(`${sym.glyph} ${editor.t("dock.done_count", { n: String(att.done) })}`, {
        style: { fg: sym.fg, bold: true },
      }),
    );
  }
  // Counts only: the way to the workspace that needs you is `Orchestrator:
  // Jump to Attention` (F8 by default) or the row itself.
  return row(spacer(1), ...parts, spacer(1));
}

// The dock's title bar: "Orchestrator" as a menu-bar strip spanning the dock,
// with the hide `×` pinned to the right edge (mouse-only, like the file
// explorer's; the keyboard has Toggle Dock). The accelerator that focuses
// the dock supplies the mnemonic: its letter in the title is underlined
// when the binding really is a single letter that appears in the title.
// The title strip is the Menu's button: `Orchestrator  Menu ▾`, padded to the
// dock's width so a press anywhere on it drops the Menu, with the `×` that
// hides the dock at its end. The dock narrows with the terminal, so on a
// narrow one the label shortens — `Orchestrator ▾`, then `Menu ▾` — rather
// than being cut off along with the `×`.
function dockTitleRow(): WidgetSpec {
  const base = { fg: "ui.menu_fg", bg: "ui.menu_bg" };
  const title = editor.t("dock.title");
  const menu = editor.t("dock.menu_button");
  // The `×` and the gap before it take the last three columns.
  const room = dockWidth() - 3;
  const caret = menu.slice(menu.lastIndexOf(" ") + 1);
  const text =
    [`${title}  ${menu}`, `${title} ${caret}`, menu].find(
      (label) => editor.stringWidth(label) <= room,
    ) ?? menu;
  const width = Math.max(editor.stringWidth(text), room);
  return row(
    button(text + " ".repeat(Math.max(0, width - editor.stringWidth(text))), {
      key: "dock-menu",
      bare: true,
      style: { ...base, bold: true },
      hoverStyle: { ...base, bold: true, fg: "ui.help_key_fg" },
    }),
    flexSpacer(),
    button(DOCK_CLOSE_GLYPH, {
      key: "dock-close",
      focusable: false,
      bare: true,
      hoverStyle: { fg: "ui.tab_close_hover_fg" },
    }),
  );
}

function buildDockSpec(): WidgetSpec {
  if (!openDialog) return col();
  const filtered = openDialog.filteredIds;
  const activeId = editor.activeWindow();
  const dockTree = buildDockTree(filtered);
  // Mirror the emitted node model so selection / activation / context
  // can resolve `dockSelKey` back to a folder or session.
  openDialog.dockNodes = dockTree.model;
  openDialog.dockKeys = dockTree.keys;
  // The dock has one highlight, and what it means depends on whether the
  // dock has the keyboard:
  //
  //   * Blurred — the dock is a passive mirror of the editor, so the
  //     highlight is pinned to the active session every paint. There is no
  //     cursor to preserve: nothing here is taking keys, and a highlight
  //     left on a row you are not in is a lie about where you are. This is
  //     a *re-assertion*, not a fallback — a stale key from before the dock
  //     lost focus would otherwise survive and strand the highlight.
  //   * Focused — the highlight is the cursor, and moving it live-switches
  //     the active session, so the two converge by themselves. It is left
  //     alone here so a deliberate move isn't undone mid-debounce.
  //
  // Either way one row is highlighted and it is the one whose buffers are
  // on screen (or about to be), which is why no row needs an "active"
  // marker of its own.
  //   * A row's menu is open — the menu took the keyboard, so the dock is
  //     blurred, but the highlight is the menu's target and stays on it
  //     (snapping it to the active session would point away from the row
  //     the menu is about).
  const activeKey = sessionNodeKey(activeId);
  if (dockBlurred && !dockMenuState && dockTree.keys.includes(activeKey)) {
    openDialog.dockSelKey = activeKey;
  }
  // Keep the highlighted node key pointing at something real: default to
  // the active session's node, else the first node.
  if (!openDialog.dockSelKey || !dockTree.keys.includes(openDialog.dockSelKey)) {
    openDialog.dockSelKey = dockTree.keys.includes(activeKey)
      ? activeKey
      : (dockTree.keys[0] ?? null);
  }
  const selIdx = openDialog.dockSelKey
    ? dockTree.keys.indexOf(openDialog.dockSelKey)
    : -1;

  // The action row: `[ + New ]` on the left, `/ search` and `Menu ▾` on the
  // right. Four header controls collapse to two: `+ New` goes straight to
  // the dialog (folder creation moved into `Menu ▾`, where the rare thing costs
  // the extra click), and every *setting* lives behind `Menu ▾`.
  const dockCols = dockContentCols(dockWidth());
  // Search on demand: the filter row appears when asked for, or while a
  // filter applies (the row says what the list is filtered by).
  const searchVisible = openDialog.searchOpen || openDialog.filter.value !== "";
  // `/ [field]`, the match count when a needle is typed.
  const searchField = Math.max(10, dockCols - 14);
  const total = openDialog.filter.value === "" ? filtered.length : filterSessions("").length;
  const searchRow: WidgetSpec[] = searchVisible
    ? [row(
      text({
        value: openDialog.filter.value,
        cursorByte: openDialog.filter.cursor,
        label: "/",
        placeholder: editor.t("dock.filter_placeholder"),
        fieldWidth: searchField,
        key: "filter",
      }),
      flexSpacer(),
      label(
        openDialog.filter.value === ""
          ? ""
          : editor.t("dock.search_count", { n: String(filtered.length), total: String(total) }),
        { style: { fg: "ui.menu_disabled_fg" } },
      ),
    )]
    : [];
  // The hints belong to the dock only while it has keyboard focus
  // (req: hide them when the editor owns the keyboard). A blurred dock
  // gives the row back to the tree.
  const showHints = !dockBlurred;
  const menuOpen = openDialog.projectMenuOpen || openDialog.dockMenu !== null;
  // While a dropdown owns the keyboard, the hints describe the dropdown
  // (choose/select/cancel), not the session tree. The tree's own hints
  // take two rows — the dock is too narrow for four hints on one line —
  // so the context-menu key (Shift+F10 / the Menu key, the only keyboard
  // route to "Move to Folder…" and the folder actions) is discoverable
  // instead of a mouse-only secret.
  const centered = (entries: Parameters<typeof hintBar>[0]): WidgetSpec =>
    row(flexSpacer(), hintBar(entries), flexSpacer());
  const bottom: WidgetSpec[] = !showHints
    ? []
    : menuOpen
      ? [centered([
          { keys: "↑↓", label: editor.t("dock.hint_choose") },
          { keys: "Enter", label: editor.t("dock.hint_select") },
          { keys: "Esc", label: editor.t("dock.hint_cancel") },
        ])]
      : [
        centered([
          { keys: "↑↓", label: editor.t("dock.hint_switch") },
          { keys: "→←", label: editor.t("dock.hint_fold") },
        ]),
        centered([
          { keys: "Enter", label: editor.t("dock.hint_edit") },
          { keys: "F2", label: editor.t("dock.hint_menu") },
        ]),
      ];
  const bottomRows = bottom.length;

  // Size the tree to fill the dock. Top chrome is the action row, the
  // search row while it is open, and the divider. The tree soaks up the
  // rest.
  const screen = editor.getScreenSize();
  const innerH = Math.max(8, screen.height > 0 ? screen.height : 30);
  // §2.3 attention line: `● 2 need you · ✓ 1 done`, only when there is
  // something to say — a dock with nothing pending stays as tall as before.
  const att = attentionCounts(orchestratorSessions.keys());
  const attentionRow: WidgetSpec[] = att.blocked > 0 || att.done > 0 ? [dockAttentionRow(att)] : [];
  // A failed workspace is reported on its own page — the one the user is
  // looking at, since creating it takes them there — not a second time here.
  // The row keeps its one-line summary, which is the list's job: *which*
  // workspace is unhappy. What it says and what to do about it belong
  // together, on the page, and having them in both places meant reading the
  // same error twice and two sets of Retry / Dismiss buttons.
  const failureRowCount = 0;
  // Top chrome: the title bar, the action row, the search row while it is
  // open, the attention line when there is one, and the divider.
  const pickRows = dockPickRows();
  const chromeRows = 3 + searchRow.length + attentionRow.length + pickRows.length + bottomRows + failureRowCount;
  const listRows = Math.max(MIN_LIST_ROWS, innerH - chromeRows);
  openDialog.listVisibleRows = listRows;
  // Rows of chrome above the tree (everything in chromeRows except the
  // bottom hint row) — where the first tree row lands on screen.
  openDialog.dockTreeTop = chromeRows - bottomRows - failureRowCount;

  const expandedSeed = dockTreeExpandedKeys(dockTree);

  // Pin the hint bar to the dock's bottom edge. The host tree renders
  // only its actual content rows (it does not pad itself out to
  // `visibleRows`), so with few sessions the hints used to sit directly
  // under the last card with dead space *below* them. Measure the rows
  // the visible tree content occupies and fill the gap with blank,
  // non-interactive rows so `bottom` always lands on the dock's last
  // rows. Zero when the tree fills or overflows its budget.
  const treeRows = Math.min(listRows, dockTreeContentRows(dockTree, expandedSeed));
  const padRows = bottomRows + failureRowCount > 0 ? Math.max(0, listRows - treeRows) : 0;
  const bottomPad: WidgetSpec[] = padRows > 0
    ? [raw(Array.from({ length: padRows }, () => ({ text: "" })))]
    : [];

  return col(
    dockTitleRow(),
    row(
      button(editor.t("dock.new"), { intent: "primary", key: "new-session" }),
      flexSpacer(),
      // `/ search`: the key and the word. Mouse-only — the keyboard has
      // `/` — so the Tab ring stays the title (the Menu), `+ New`, the field,
      // the list.
      button(editor.t("dock.search_btn"), {
        key: "search-toggle",
        bare: true,
        focusable: false,
        style: { fg: "ui.menu_disabled_fg" },
        hoverStyle: { fg: "ui.help_key_fg" },
      }),
    ),
    // The project (scope) dropdown floats just under the action row. The
    // Menu is a panel of its own (see `openMainMenu`).
    ...(openDialog.projectMenuOpen ? [dockProjectMenu()] : []),
    ...searchRow,
    ...attentionRow,
    ...pickRows,
    // Host-rendered full-width rule: it spans whatever width the dock is
    // actually drawn at (incl. a user drag), so it can't drift from the
    // chrome the way a plugin-computed `"─".repeat(width)` did.
    divider({ style: { fg: "ui.menu_disabled_fg" } }),
    tree({
      nodes: dockTree.nodes,
      itemKeys: dockTree.keys,
      selectedIndex: selIdx,
      visibleRows: listRows,
      expandedKeys: expandedSeed,
      // "card" density renders each session as a 3-content-row card
      // inside a rounded border (the pill look the pre-tree dock had);
      // "compact" keeps single-line rows. The host keeps
      // scroll/selection in node units either way.
      itemHeight: dockView === "card" ? DOCK_CARD_HEIGHT : 1,
      cardBorders: dockView === "card",
      // One column per level, not two: the dock is narrow, a row's first
      // columns are already the ▼/▶ gutter and its state glyph, and a
      // folder's rows read as its own at one column in from its name.
      indentCols: 1,
      // In the dock (unlike the modal, where Up/Down forward from the
      // filter) the tree itself is the default focus — trees are always
      // focusable — so ↑↓ drive live-switch, →← fold, and Enter dives /
      // toggles a folder.
      key: "sessions",
    }),
    ...bottomPad,
    ...bottom,
  );
}

// Screen rows the dock tree's *visible* content occupies, mirroring the
// host renderer's accounting: descendants of a collapsed folder are
// skipped (same ancestor-stack walk as the host's `visible_indices`,
// against the same expansion set the tree is seeded/reconciled with), a
// folder header is one row, and a session leaf is a bordered card
// (`DOCK_CARD_HEIGHT` content rows + 2 border rows) in card density or
// a single row in compact.
function dockTreeContentRows(t: DockTree, expandedKeys: string[]): number {
  const card = dockView === "card";
  const open = new Set(expandedKeys);
  const ancestorOpen: boolean[] = [];
  let rows = 0;
  for (let i = 0; i < t.nodes.length; i++) {
    const depth = t.nodes[i].depth ?? 0;
    // Truncate the ancestor stack to this node's depth, then the node
    // is visible iff every remaining ancestor folder is open.
    ancestorOpen.length = Math.min(ancestorOpen.length, depth);
    if (ancestorOpen.every((o) => o)) {
      rows += card && t.model[i].kind !== "folder" ? DOCK_CARD_HEIGHT + 2 : 1;
    }
    // Push this node's own openness so descendants see it; leaves act
    // as open (they have no descendants to hide).
    ancestorOpen.push(t.model[i].kind !== "folder" || open.has(t.keys[i]));
  }
  return rows;
}

// The folder keys to seed the tree's expansion with. During a search
// every folder is force-open so matches aren't hidden; otherwise the
// user's persisted expansion set is used.
function dockTreeExpandedKeys(t: DockTree): string[] {
  const searching = (openDialog?.filter.value ?? "") !== "";
  if (searching) return t.keys.filter((k) => k.startsWith(FOLDER_NODE_PREFIX));
  return dockExpandedKeys();
}

// The header's Menu offers its options as `MenuOption`s, grouped below. The
// `●` / `[✓]` marks the applied choice.

interface MenuOption {
  key: string; // action key, e.g. "main:folder"
  label: string;
  marked?: boolean;
}

// The header's Menu, as groups: actions on the left (they open something),
// the dock's settings on the right (they flip in place, marked as the
// controls they are: `(•)` for the one view, `[✓]` for each switch), and
// hiding the dock on its own below.
interface DockMenuGroup {
  heading: string;
  side: "left" | "right";
  opts: MenuOption[];
}

function dockMainGroups(): DockMenuGroup[] {
  if (!openDialog) return [];
  const projWord = openDialog.projectFilter === null
    ? editor.t("dock.all_projects")
    : editor.pathBasename(openDialog.projectFilter);
  const radio = (on: boolean): string => (on ? "(•) " : "( ) ");
  const check = (on: boolean): string => (on ? "[✓] " : "[ ] ");
  return [
    {
      heading: editor.t("dock.menu_h_create"),
      side: "left",
      opts: [{ key: "main:folder", label: editor.t("dock.new_menu_folder") }],
    },
    {
      heading: editor.t("dock.menu_h_manage"),
      side: "left",
      opts: [
        { key: "main:machines", label: editor.t("dock.menu_machines") },
        { key: "main:discover", label: editor.t("dock.menu_discover") },
      ],
    },
    {
      heading: editor.t("dock.menu_h_view"),
      side: "right",
      opts: [
        { key: "main:view:compact", label: radio(dockView === "compact") + editor.t("dock.menu_view_compact") },
        { key: "main:view:card", label: radio(dockView === "card") + editor.t("dock.menu_view_card") },
      ],
    },
    {
      heading: editor.t("dock.menu_h_show"),
      side: "right",
      opts: [
        { key: "main:empty", label: check(!openDialog.hideTrivial) + editor.t("dock.show_empty") },
        { key: "main:worktrees", label: check(openDialog.showWorktrees) + editor.t("dock.all_worktrees") },
        // The external sessions source that reads the Claude CLI's sign-in and a
        // private API, switchable here rather than only in Settings.
        ...(externalFeed()
          ? [{
            key: "main:claude-cloud",
            label: check(externalFeed()!.claudeCloudEnabled()) + editor.t("dock.claude_cloud"),
          }]
          : []),
      ],
    },
  ];
}

// A dropdown/context-menu row. Menu entries are *rows in a list*, not
// framed actions: a `[ ]` frame around every line turns the popup into a
// column of ragged brackets and leaves the highlight hugging the label
// instead of the popup. `bare` drops the frame, and `fullWidth` makes the
// row's band span whatever width the menu turns out to have.
//
// The one column of air on each side is an inset, not alignment: it is the
// same on every row and at every width.
function menuItemButton(
  label: string,
  key: string,
  opts?: { intent?: "primary" | "danger"; disabled?: boolean },
): WidgetSpec {
  return button(" " + label + " ", {
    key,
    bare: true,
    fullWidth: true,
    intent: opts?.intent ?? "normal",
    disabled: opts?.disabled ?? false,
  });
}

// Lay out a set of menu entries so every row's focus/hover band spans the
// whole menu row rather than hugging its label.
//
// **Every row says `fullWidth` and nothing here measures anything.** This
// used to pad each label out to the widest one — with a second mode that
// handed the padding to the host instead — because `fullWidth` was itself
// padding, applied at the enclosing panel's width: filling inside an
// anchored popup stretched the popup to the panel. It is a width now (the
// host sizes the box to its content and lets the column stretch it), so a
// popup still hugs its widest row and every row's band still reaches that
// row's end. Both modes were the same request all along.
function menuRows(
  items: { label: string; key: string; intent?: "primary" | "danger"; disabled?: boolean }[],
): WidgetSpec[] {
  return items.map((it) =>
    menuItemButton(it.label, it.key, { intent: it.intent, disabled: it.disabled })
  );
}

// The project dropdown floats over the dock's rows as a keyed overlay: the
// host reports a press outside it as a `dismiss` on its key, which closes it
// (the press still lands where it was aimed — a row click both closes the
// menu and selects the row).
const DOCK_PROJECT_OVERLAY_KEY = "dock-project-overlay";

// The Menu: a small panel of its own, anchored under the dock's header and
// wider than the dock, so it hangs over the editor. Two columns of groups —
// actions on the left, settings on the right — a rule, and Hide dock. Every
// entry is a bare full-width button, so the one with focus is the one lit,
// and Tab / ↑↓ walk them in reading order.
let mainMenuPanel: FloatingWidgetPanel | null = null;

// Buttons are keyed `mm:<option key>`.
const MAIN_MENU_PREFIX = "mm:";
// The Menu's project dropdown.
const MAIN_MENU_PROJECT_KEY = "mm-project";

function buildMainMenuSpec(): WidgetSpec {
  const groups = dockMainGroups();
  const colW = (which: DockMenuGroup["side"]): number => Math.max(
    ...groups.filter((g) => g.side === which)
      .flatMap((g) => [editor.stringWidth(g.heading), ...g.opts.map((o) => editor.stringWidth(o.label))]),
  ) + 3;
  const leftW = colW("left");
  const rightW = colW("right");
  const text = (t: string, w: number, style?: Partial<OverlayOptions>): WidgetSpec =>
    ({ kind: "raw", entries: [styledRow([style ? { text: t.padEnd(w), style } : { text: t.padEnd(w) }])] });
  const column = (which: DockMenuGroup["side"], w: number): WidgetSpec[] => {
    const out: WidgetSpec[] = [];
    groups.filter((g) => g.side === which).forEach((g, i) => {
      if (i > 0) out.push(text("", w));
      out.push(text(` ${g.heading.toUpperCase()}`, w, SECTION_STYLE));
      out.push(...g.opts.map((o) =>
        button(` ${o.label}`.padEnd(w), { key: MAIN_MENU_PREFIX + o.key, bare: true })));
    });
    return out;
  };
  const left = column("left", leftW);
  const right = column("right", rightW);
  // The project filter is a real dropdown: it drops its list where it
  // sits, over the panel, and scrolls when there are many projects.
  const projects = dockProjectOptions();
  const cur = openDialog?.projectFilter ?? null;
  const at = cur === null ? 0 : projects.indexOf(cur) + 1;
  right.push(text("", rightW));
  right.push(text(` ${editor.t("dock.menu_h_project").toUpperCase()}`, rightW, SECTION_STYLE));
  right.push(row(spacer(1), dropdown([editor.t("dock.all_projects"), ...projects.map(projectLabel)], {
    selectedIndex: Math.max(0, at),
    key: MAIN_MENU_PROJECT_KEY,
  })));
  // Two columns side by side, one rule between them: each line is a row of
  // single-line cells, so the panel stays as wide as its content.
  const rule = text(" │ ", 3, { fg: "ui.popup_border_fg" });
  const lines: WidgetSpec[] = [];
  for (let i = 0; i < Math.max(left.length, right.length); i++) {
    lines.push(row(left[i] ?? text("", leftW), rule, right[i] ?? text("", rightW)));
  }
  return col(...lines);
}

function openMainMenu(): void {
  if (!openDialog) return;
  openDialog.dockMenu = { kind: "main" };
  if (!mainMenuPanel) mainMenuPanel = new FloatingWidgetPanel();
  // Sizes to its content; the percentages are unused for an anchored panel.
  mainMenuPanel.mount(buildMainMenuSpec(), { widthPct: 50, heightPct: 44 });
  // Under the title strip, which is its button.
  editor.floatingPanelControl(mainMenuPanel.id(), "anchor", packCell(0, 1));
  mainMenuPanel.setFocusKey(MAIN_MENU_PREFIX + "main:folder");
}

function renderMainMenu(): void {
  if (mainMenuPanel) mainMenuPanel.update(buildMainMenuSpec());
}

// Close the Menu. The host hands the keyboard back to the dock control
// that opened it.
function closeMainMenu(): void {
  if (mainMenuPanel) {
    mainMenuPanel.unmount();
    mainMenuPanel = null;
  }
  if (!openDialog) return;
  openDialog.dockMenu = null;
  if (openPanel && dockMode) refreshOpenDialog();
}

function closeDockMenu(): void {
  if (openDialog?.dockMenu?.kind === "main") return closeMainMenu();
  if (!openDialog || !openPanel) return;
  openDialog.dockMenu = null;
  openPanel.update(buildDockSpec());
  focusDockControl("sessions");
}

// Apply a Menu choice.
function runDockMenuOption(optKey: string): void {
  if (!openDialog) return;
  if (optKey === "main:folder") {
    closeDockMenu();
    openCreateFolderDialog(null);
    return;
  }
  if (optKey === "main:machines") {
    closeDockMenu();
    openMachinesDialog();
    return;
  }
  if (optKey === "main:discover") {
    closeDockMenu();
    (editor.getPluginApi("agent-discovery") as { open(): void } | null)?.open();
    return;
  }
  // The settings flip in place and the menu stays up, so a second choice
  // is one key away; its `●` marks move with the flip. Each goes through
  // the published verb, so the menu and a script take the same path.
  if (optKey === "main:view:compact" || optKey === "main:view:card") {
    apiSetDockView(optKey === "main:view:card" ? "card" : "compact");
    renderMainMenu();
    return;
  }
  if (optKey === "main:empty") {
    toggleHideTrivial();
    renderMainMenu();
    return;
  }
  if (optKey === "main:claude-cloud") {
    const feed = externalFeed();
    if (feed) {
      // Saved like any setting; the checkmark follows once it has landed.
      void feed.setClaudeCloud(!feed.claudeCloudEnabled()).then(renderMainMenu);
    }
    return;
  }
  if (optKey === "main:worktrees") {
    toggleShowWorktrees();
    renderMainMenu();
    return;
  }
  closeDockMenu();
}

// ---------------------------------------------------------------------
// Dock tree selection resolution. The tree is host-owned; `dockSelKey`
// (updated from every `select` event, seeded in `buildDockSpec`) is the
// plugin's mirror of the highlighted node.
// ---------------------------------------------------------------------

function dockSelectedNode(): DockNode | null {
  if (!openDialog || !openDialog.dockSelKey) return null;
  const idx = openDialog.dockKeys.indexOf(openDialog.dockSelKey);
  return idx >= 0 ? openDialog.dockNodes[idx] ?? null : null;
}

function dockSelectedSessionId(): number | null {
  const node = dockSelectedNode();
  return node && node.kind === "session" ? node.sessionId : null;
}

// ---------------------------------------------------------------------
// Folder operations.
// ---------------------------------------------------------------------

// Open the "New Folder" dialog. `parent` is the parent folder (null =
// top level). `assignSession` names a specific session to file under the
// new folder (the "Move to → New folder…" path); when omitted the dialog
// offers to organize the *current* (active) session instead. The dialog
// itself commits the folder on "Create Folder" — see `submitCreateFolder`.
function openCreateFolderDialog(
  parent: string | null,
  assignSession?: number,
  assignLive?: string,
): void {
  // The session the "organize under this folder" checkbox targets: the
  // explicitly-moved session when given, else the active window — unless
  // an external session row is being filed, which the checkbox then names.
  const candidate = typeof assignSession === "number"
    ? assignSession
    : editor.activeWindow();
  const sessionId = assignLive === undefined && candidate > 0 && orchestratorSessions.has(candidate)
    ? candidate
    : null;
  createFolderDialog = {
    // Start empty with the default shown as a placeholder, so the first
    // keystroke types a name cleanly (no pre-filled text to clear first).
    // An empty submit falls back to the default name (see submitCreateFolder).
    name: { value: "", cursor: 0 },
    organizeCurrent: true,
    parent,
    sessionId,
    renameId: null,
    renameSessionId: null,
    liveKey: assignLive ?? null,
  };
  mountFolderDialog();
}

// UTF-8 byte length of a JS (UTF-16) string — text-input cursors are
// byte offsets host-side.
function utf8Len(s: string): number {
  let b = 0;
  for (let i = 0; i < s.length; i++) {
    const c = s.codePointAt(i)!;
    if (c > 0xffff) i++; // surrogate pair consumed both units
    b += c <= 0x7f ? 1 : c <= 0x7ff ? 2 : c <= 0xffff ? 3 : 4;
  }
  return b;
}

// Open the folder dialog in rename mode for an existing folder — the
// same centered dialog as "New Folder" (per-issue: rename used to drop
// into the bottom minibuffer prompt, inconsistent with create).
function openRenameFolderDialog(id: string): void {
  const f = folderById(id);
  if (!f) return;
  createFolderDialog = {
    // Pre-fill the current name with the cursor at its end so the user
    // can edit it in place. (Cursor offsets are UTF-8 bytes host-side.)
    name: { value: f.name, cursor: utf8Len(f.name) },
    organizeCurrent: false,
    parent: null,
    sessionId: null,
    renameId: id,
    renameSessionId: null,
    liveKey: null,
  };
  mountFolderDialog();
}

// Open the shared centered dialog in workspace-rename mode for a session.
// Pre-fills the current display name so the user edits it in place; an
// emptied-out name clears the manual rename and restores the auto-name /
// host label.
function openRenameWorkspaceDialog(id: number): void {
  const s = orchestratorSessions.get(id);
  if (!s) return;
  // Seed with the manual name if one exists, else the plain host label
  // (root basename) — a cleaner starting point than the long auto-name.
  const current = workspaceCustomName(s) ?? s.hostLabel;
  createFolderDialog = {
    name: { value: current, cursor: utf8Len(current) },
    organizeCurrent: false,
    parent: null,
    sessionId: null,
    renameId: null,
    renameSessionId: id,
    liveKey: null,
  };
  mountFolderDialog();
}

// Shared mount path for the create / rename folder dialog.
function mountFolderDialog(): void {
  // The host blurs the dock as the dialog mounts and records the control
  // that opened it, so closing the dialog hands the keyboard back there.
  // Blurring it here first would leave the host no opener to return to.
  const d0 = createFolderDialog!;
  const title = d0.renameSessionId !== null
    ? editor.t("dock.rename_workspace_dialog_title")
    : d0.renameId !== null
      ? editor.t("dock.rename_folder_dialog_title")
      : editor.t("dock.new_folder_dialog_title");
  createFolderPanel = new FloatingWidgetPanel();
  createFolderPanel.mount(buildCreateFolderSpec(), {
    widthPct: 50,
    heightPct: 42,
    focusMarker: true,
    labelAlign: "right",
    // The dialog's title + border are now native modal-frame chrome
    // (drawn by the host around the WidgetSpec), and `closable` renders
    // a native `[×]` that dismisses via the same cancel path as Esc.
    title,
    closable: true,
    mode: CREATE_FOLDER_MODE,
  });
  editor.floatingPanelControl(createFolderPanel.id(), "fullscreen", 1);
  // Land focus in the name field so typing goes straight to it; the
  // whole value starts selected-for-overwrite feel via a full cursor.
  createFolderPanel.setFocusKey("folder-name");
}

// The dialog spec: a titled section with a "Folder name:" field, an
// optional "organize <session> under this folder" checkbox, and the
// Cancel / Create Folder buttons.
function buildCreateFolderSpec(): WidgetSpec {
  const d = createFolderDialog!;
  const renamingSession = d.renameSessionId !== null;
  const renaming = d.renameId !== null || renamingSession;
  const sess = d.sessionId != null ? orchestratorSessions.get(d.sessionId) : undefined;
  const organizeName = sess?.label ?? (d.liveKey ? liveByKey(d.liveKey)?.title : undefined);
  const promptLabel = renamingSession
    ? editor.t("dock.rename_workspace_prompt")
    : editor.t("dock.new_folder_prompt");
  // The same shape as the other forms: a padded field with its label in a
  // right-aligned column, the checkbox under the field, and a footer rule
  // over Cancel and the primary button with their keys.
  const labelW = editor.stringWidth(promptLabel);
  const children: WidgetSpec[] = [
    spacer(0),
    text({
      value: d.name.value,
      cursorByte: d.name.cursor,
      label: promptLabel,
      placeholder: renamingSession ? "" : editor.t("dock.new_folder_default"),
      fullWidth: true,
      labelWidth: labelW,
      key: "folder-name",
    }),
  ];
  if (organizeName !== undefined) {
    children.push(
      toggle(d.organizeCurrent, editor.t("dock.new_folder_organize", { name: organizeName }), {
        key: "folder-organize",
        labelWidth: labelW,
      }),
    );
  }
  children.push(
    spacer(0),
    footerRule(),
    spacer(0),
    row(
      flexSpacer(),
      withAccel(button(editor.t("dock.new_folder_btn_cancel"), { key: "folder-cancel" }), "Esc"),
      spacer(3),
      withAccel(
        button(
          renaming
            ? editor.t("dock.rename_folder_btn")
            : editor.t("dock.new_folder_btn_create"),
          { intent: "primary", key: "folder-create" },
        ),
        "⏎",
      ),
      spacer(2),
    ),
    spacer(0),
  );
  // The dialog's title + border come from the native modal-frame chrome
  // (see `mountFolderDialog`), so the spec is just the content column.
  return col(...children);
}

// Commit the dialog: create the folder and (when the checkbox is on)
// file the target session under it. No-op on an empty name, so the
// dialog stays open for the user to type one.
// Every branch below goes through a published API verb rather than calling
// the folder/name stores directly, so the dialog and a script share one
// implementation of each operation — including the guards (a workspace with
// no window yet has nothing to file a name or a folder against, so it can be
// neither renamed nor moved) and the dock refresh.
function submitCreateFolder(): void {
  const d = createFolderDialog;
  if (!d) return;
  if (d.renameSessionId !== null) {
    // Workspace rename: an empty name clears the manual name and lets the
    // auto-name / host label take back over.
    apiRenameWorkspace(d.renameSessionId, d.name.value);
    closeCreateFolderDialog();
    return;
  }
  if (d.renameId !== null) {
    // Rename mode: an emptied-out name keeps the current one (renaming
    // to nothing is never what the user meant), so the verb — which rejects
    // an empty name — is only called when there is one.
    const trimmed = d.name.value.trim();
    if (trimmed) apiRenameFolder(d.renameId, trimmed);
    closeCreateFolderDialog();
    return;
  }
  // Empty name ⇒ the default ("New Folder"), matching the placeholder. The
  // verb rejects an empty name, so the dialog's own default is applied here
  // rather than inside it — a script passing "" meant something else.
  const name = d.name.value.trim() || editor.t("dock.new_folder_default");
  const id = apiCreateFolder(name, d.parent);
  if (d.organizeCurrent && d.sessionId != null) {
    apiMoveWorkspace(d.sessionId, id);
  }
  const liveKey = d.organizeCurrent ? d.liveKey : null;
  closeCreateFolderDialog();
  // An external session is filed, not opened: the row moves into the folder.
  if (liveKey) setExternalFolder(liveKey, id);
}

// Tear down the dialog. The host hands the keyboard back to whatever
// opened it.
function closeCreateFolderDialog(): void {
  if (createFolderPanel) {
    createFolderPanel.unmount();
    createFolderPanel = null;
  }
  createFolderDialog = null;
}

// Flip one folder's expansion in the persisted set and push it to the
// host-owned tree state.
function toggleDockFolderExpansion(folderKey: string): void {
  if (!openPanel) return;
  const group = externalGroupOfKey(folderKey);
  if (group) {
    setExternalCollapsed(group, !externalCollapsed(group));
  } else {
    const set = loadExpanded();
    if (set.has(folderKey)) set.delete(folderKey);
    else set.add(folderKey);
    saveExpanded();
  }
  // Through the reconciler: while a search holds every folder open, the
  // flip is remembered for later rather than drawn.
  applyDockExpansion();
  // Re-render so the hint-bar padding tracks the tree's new height
  // (see the `expand` widget_event mirror for the host-owned fold path).
  if (dockMode && openDialog) openPanel.update(buildDockSpec());
}

// Reconcile the tree's host-owned expansion with the plugin's intent:
// every folder open while a search is active, the user's persisted set
// otherwise. Call after a rebuild (so `dockKeys` is current).
function applyDockExpansion(): void {
  if (!openPanel || !openDialog) return;
  const searching = openDialog.filter.value !== "";
  const keys = searching
    ? openDialog.dockKeys.filter((k) => k.startsWith(FOLDER_NODE_PREFIX))
    : dockExpandedKeys();
  openPanel.setExpandedKeys("sessions", keys);
}

// ---------------------------------------------------------------------
// Dock session context menu (right-click).
//
// A centered, dimmed floating modal (its own host slot, so the dock
// stays visible behind it) offering Visit / Archive / Delete against a
// single right-clicked session. The destructive actions (Archive,
// Delete) swap the same panel to a confirmation pane — reusing the
// modal picker's `buildConfirmPane` — before they run. Visit acts
// immediately.
// ---------------------------------------------------------------------

// Visit the session behind the context menu: switch the active window to
// it and hand keyboard focus to the editor (the dock stays visible). A
// discovered on-disk worktree has no live window, so attach a fresh
// session to it instead — mirrors the dock's Enter (`dock_activate`).
function dockMenuVisit(id: number): void {
  const s = orchestratorSessions.get(id);
  if (!s) return;
  if (s.discovered) {
    // Visit "dives in" (like the live path below, which blurs to the
    // editor), so attach with dive: true.
    void attachToWorktree({
      root: s.root,
      projectPath: s.projectPath ?? s.root,
      label: s.label,
      branch: s.branch,
      discoveredId: s.id,
      dive: true,
    });
    return;
  }
  if (id > 0 && id !== editor.activeWindow()) editor.setActiveWindow(id);
  if (openPanel && dockMode) {
    dockBlurred = true;
    editor.floatingPanelControl(openPanel.id(), "blur", 0);
  }
}

function buildDockMenuSpec(state: DockMenuState): WidgetSpec {
  if (state.stage === "confirm") {
    // Reuse the picker's confirmation contents (single-session form),
    // unframed: the popup's own frame carries the title (see
    // `dockMenuEnterConfirm`). Its buttons are keyed `confirm-cancel` /
    // `confirm-<action>`, handled in the dock-menu `widget_event` block.
    return buildConfirmBody({ action: state.action, ids: [state.target.id] });
  }
  // The external sessions group: nothing to organise, but a way to re-list now, and
  // what went wrong with a source, if anything did (a sign-in that expired).
  if (state.target.kind === "folder" && isExternalFolder(state.target.id)) {
    const group = externalGroupOf(state.target.id);
    return contextMenuSpec(
      externalGroupName(group),
      [{ label: editor.t("dock.ctx_refresh"), key: "ctx-external-refresh", intent: "primary" }],
      externalGroupProblems(group),
    );
  }
  // An external session row: open it (attach, or its folder), file it into a
  // folder (the row moves there; nothing opens), or open its page on the web.
  if (state.target.kind === "live") {
    const s = liveByKey(state.target.key);
    // What opening it here does comes first (none when it only opens
    // outside the editor); then the places outside it, each named: this
    // menu is also what a click on such a row opens.
    const items: { label: string; key: string; intent?: "primary" | "danger" }[] = [];
    const plan = s ? externalPlan(s) : null;
    // Already copied here: going to that copy comes first; another teleport
    // (a second copy) is still there, below it.
    const copy = s ? teleportedWorkspace(s) : undefined;
    if (copy) {
      items.push({ label: editor.t("dock.ctx_goto_workspace", { name: copy.label }), key: "ctx-live-goto", intent: "primary" });
    }
    if (plan?.kind === "teleport") {
      // A cloud session: look at it where it runs first, then fork it here.
      if (s?.url) {
        items.push({ label: editor.t("dock.ctx_open_browser"), key: "ctx-live-browser", ...(copy ? {} : { intent: "primary" as const }) });
      }
      items.push({ label: editor.t("dock.ctx_teleport"), key: "ctx-live-teleport" });
    } else if (plan?.kind === "ssh" || (plan?.kind === "workspace" && plan.takeover)) {
      items.push({ label: editor.t("dock.ctx_take_over"), key: "ctx-live-open", intent: "primary" });
    } else if (plan && plan.kind !== "browser") {
      items.push({ label: editor.t("dock.ctx_open"), key: "ctx-live-open", intent: "primary" });
    }
    if (s && desktopLink(s)) {
      items.push({ label: editor.t("dock.ctx_open_desktop"), key: "ctx-live-desktop", ...(items.length ? {} : { intent: "primary" as const }) });
    }
    if (s?.url && plan?.kind !== "teleport") {
      items.push({ label: editor.t("dock.ctx_open_browser"), key: "ctx-live-browser", ...(items.length ? {} : { intent: "primary" as const }) });
    }
    items.push({ label: editor.t("dock.ctx_move"), key: "ctx-live-move" });
    return contextMenuSpec(s ? s.title : state.target.key, items, [], s ? liveInfoLines(s) : []);
  }
  // A folder's context menu: organise actions (Rename / New Subfolder /
  // Delete Folder).
  if (state.target.kind === "folder") {
    const f = folderById(state.target.id);
    const label = f?.name ?? `[${state.target.id}]`;
    return contextMenuSpec(label, [
      { label: editor.t("dock.ctx_rename"), key: "ctx-rename", intent: "primary" },
      { label: editor.t("dock.ctx_new_subfolder"), key: "ctx-new-subfolder" },
      { label: editor.t("dock.ctx_delete_folder"), key: "ctx-delete-folder", intent: "danger" },
    ]);
  }
  const sid = state.target.id;
  const s = orchestratorSessions.get(sid);
  const label = s?.label ?? `[${sid}]`;
  // A workspace whose build hasn't finished is still a workspace: it can be
  // visited, renamed, filed into a folder and thrown away exactly like a
  // finished one, because it owns a real window from the moment the user
  // asked for it. Only two things differ — Retry appears once the build has
  // failed or been interrupted, and Archive is inert while there is no
  // worktree yet to archive.
  //
  // A *windowless* placeholder (a remote create, whose window is born by the
  // connect) genuinely has nothing to visit or rename, so it keeps the
  // narrow retry/dismiss menu.
  if (s?.pending && sid <= 0) {
    const items: { label: string; key: string; intent?: "primary" | "danger" }[] = [];
    if (pendingActionable(s.pending)) {
      items.push({ label: editor.t("dock.ctx_retry"), key: "ctx-retry", intent: "primary" });
    }
    items.push({ label: editor.t("dock.ctx_dismiss"), key: "ctx-dismiss", intent: "danger" });
    return contextMenuSpec(label, items);
  }
  const pending = s?.pending;
  const canArchive = !pending && bulkEligible("archive", sid);
  const canDelete = pending ? true : bulkEligible("delete", sid);
  const items: { label: string; key: string; intent?: "primary" | "danger"; disabled?: boolean }[] =
    [
      { label: editor.t("dock.ctx_visit"), key: "ctx-visit", intent: "primary" },
      { label: editor.t("dock.ctx_rename"), key: "ctx-rename-session" },
      { label: editor.t("dock.ctx_move"), key: "ctx-move" },
    ];
  if (pending && pendingActionable(pending)) {
    items.push({ label: editor.t("dock.ctx_retry"), key: "ctx-retry" });
  }
  items.push({ label: editor.t("dock.ctx_archive"), key: "ctx-archive", disabled: !canArchive });
  // Deleting a workspace that is still being created cancels the build and
  // clears up after it (`ctx-dismiss` — the same teardown the placeholder
  // menu offered), so the entry means what it says on either kind of row.
  items.push({
    label: editor.t("dock.ctx_delete"),
    key: pending ? "ctx-dismiss" : "ctx-delete",
    intent: "danger",
    disabled: !canDelete,
  });
  return contextMenuSpec(label, items);
}

// One anchored context menu: a bold title row, the actions, and the Esc
// hint. Rows are `menuRows` — bare, uniform-width entries — so the popup
// reads as a menu rather than a stack of `[ bracketed ]` buttons and the
// focus/hover highlight spans each row edge to edge.
//
// Intentionally intrinsic-width content only: NO `labeledSection`,
// `flexSpacer` at the top level, or `fullWidth` widgets — those expand to
// the panel width and would blow the anchored popup up to ~half the screen.
// The host frames the box (its border) and sizes it to the widest row, so
// the popup hugs its items like a real context menu.
function contextMenuSpec(
  title: string,
  items: { label: string; key: string; intent?: "primary" | "danger"; disabled?: boolean }[],
  // Warning lines under the actions (the external sessions group's source problems).
  notes: string[] = [],
  // Read-only lines under the title, before the actions: what the target is
  // (an external session row's source, folder, state).
  info: string[] = [],
): WidgetSpec {
  return col(
    { kind: "raw", entries: [styledRow([{ text: " " + title, style: { bold: true } }])] },
    ...info.map((n): WidgetSpec => ({
      kind: "raw",
      entries: [styledRow([{ text: " " + n, style: { fg: "ui.menu_disabled_fg" } }])],
    })),
    ...menuRows(items),
    ...notes.map((n): WidgetSpec => ({
      kind: "raw",
      entries: [styledRow([{ text: " " + n, style: { fg: "diagnostic.warning_fg" } }])],
    })),
    { kind: "raw", entries: [
      styledRow([
        { text: " " + editor.t("dock.ctx_esc_close"), style: { fg: "ui.menu_disabled_fg" } },
      ]),
    ] },
  );
}

function renderDockMenu(): void {
  if (dockMenuPanel && dockMenuState) {
    dockMenuPanel.update(buildDockMenuSpec(dockMenuState));
  }
}

// Pack a screen cell into the single numeric arg `floatingPanelControl`
// takes (the host unpacks `y << 16 | x`). Both coords fit a u16.
function packCell(col: number, row: number): number {
  return (Math.max(0, row) * 65536) + Math.max(0, col);
}

// Anchor the menu popup at its stored right-click cell — an unobtrusive,
// content-sized popup with no background dim.
function anchorDockMenu(): void {
  if (!dockMenuPanel || !dockMenuState) return;
  editor.floatingPanelControl(
    dockMenuPanel.id(),
    "anchor",
    packCell(dockMenuState.anchorCol, dockMenuState.anchorRow),
  );
}

// Open the right-click context menu for the tree node at flat `index`,
// anchored at the click cell `(col, row)`. The dock stays mounted in its
// own slot behind the popup. A folder node gets folder-organise actions;
// a session node gets Visit / Move / Archive / Delete.
function openDockContextMenu(index: number, col: number, row: number): void {
  if (!openDialog) return;
  const node = openDialog.dockNodes[index];
  if (!node) return;
  const target: DockMenuTarget = node.kind === "folder"
    ? { kind: "folder", id: node.folderId }
    : node.kind === "live"
    ? { kind: "live", key: node.liveKey }
    : { kind: "session", id: node.sessionId };
  // Align the dock's highlighted row with the right-clicked one so the
  // menu and the tree agree on the target.
  openDialog.dockSelKey = openDialog.dockKeys[index] ?? openDialog.dockSelKey;
  if (openPanel) openPanel.setSelectedIndex("sessions", index);
  dockMenuState = { target, anchorCol: col, anchorRow: row, stage: "menu" };
  if (!dockMenuPanel) dockMenuPanel = new FloatingWidgetPanel();
  mountDockMenu();
}

// Mount the menu stage: an untitled, content-sized popup anchored at the
// click cell. A mount rather than an update, because the confirm stage
// mounts a titled frame and the menu must not inherit that title when
// Cancel brings it back.
function mountDockMenu(): void {
  if (!dockMenuPanel || !dockMenuState) return;
  // The anchored menu sizes to content; widthPct/heightPct are unused.
  dockMenuPanel.mount(buildDockMenuSpec(dockMenuState), {
    widthPct: 50,
    heightPct: 44,
  });
  anchorDockMenu();
}

// Keyboard-opened context menu (Menu key / Shift+F10 on the dock tree):
// same popup as a right-click, anchored at an estimate of the
// highlighted node's screen cell. The estimate assumes an unscrolled
// tree (the plugin doesn't mirror host scroll), clamped into the list
// area — for short lists it lands exactly on the row, for scrolled ones
// it stays inside the dock, which is all a popup anchor needs.
function openDockContextMenuFromKeyboard(): void {
  if (!openDialog || !dockMode) return;
  const key = openDialog.dockSelKey;
  const idx = key ? openDialog.dockKeys.indexOf(key) : -1;
  if (idx < 0) return;
  // Rows are variable in card density: a session card is a bordered
  // DOCK_CARD_HEIGHT + 2 rows tall, a folder header a single row.
  const card = dockView === "card";
  const nodeRows = (n: DockNode | undefined): number =>
    card && n !== undefined && n.kind !== "folder" ? DOCK_CARD_HEIGHT + 2 : 1;
  let estRow = openDialog.dockTreeTop;
  for (let i = 0; i < idx; i++) estRow += nodeRows(openDialog.dockNodes[i]);
  const maxRow = openDialog.dockTreeTop +
    Math.max(0, openDialog.listVisibleRows - 1);
  const row = Math.min(estRow, maxRow);
  const col = Math.min(6, Math.max(2, dockWidth() - 4));
  openDockContextMenu(idx, col, row);
}

// Moving something to a folder, the dock's own way: the dock asks for the
// target and the user clicks it. Rows that are not a target (workspaces,
// external sessions, the product groups) go dim; a folder row is the target;
// a banner above the tree names what is moving and offers Top level, a new
// folder and Cancel. Enter on a folder picks it too, Esc cancels.
type MovePick =
  | { kind: "session"; id: number; name: string }
  | { kind: "live"; key: string; name: string };
let movePick: MovePick | null = null;

function startMovePick(p: MovePick): void {
  if (!openDialog || !openPanel || !dockMode) return;
  closeDockContextMenu();
  if (openDialog.dockMenu) openDialog.dockMenu = null;
  movePick = p;
  // The dock takes the keyboard, so Enter/Esc answer the pick.
  dockBlurred = false;
  editor.floatingPanelControl(openPanel.id(), "focus", 0);
  openPanel.update(buildDockSpec());
  focusDockControl("sessions");
}

function endMovePick(): void {
  movePick = null;
  if (openPanel && dockMode) openPanel.update(buildDockSpec());
}

// File what is moving under `folderId` (null = top level: a workspace's own
// top level, an external session's product group), and leave the pick.
function applyMovePick(folderId: string | null): void {
  const p = movePick;
  movePick = null;
  if (!p) return;
  fileDockRow(p.kind === "session" ? { kind: "session", sessionId: p.id } : { kind: "live", liveKey: p.key }, folderId);
}

/** File a workspace or external session row under a folder (`null`: the top
 *  level for a workspace, its product's group for an external session). */
function fileDockRow(row: DockNode, folderId: string | null): void {
  if (row.kind === "session") apiMoveWorkspace(row.sessionId, folderId);
  else if (row.kind === "live") setExternalFolder(row.liveKey, folderId);
  refreshDockTree();
}

/** Where a row dropped on the dock row `to` goes: the folder that row
 *  stands for — the folder itself, or the one a workspace or external
 *  session row sits in. `undefined` when `to` is no place for `row`: a
 *  workspace does not go into an external sessions group, nor beside a row
 *  that is only in one. */
function dropFolderFor(row: DockNode, to: DockNode): string | null | undefined {
  const external = row.kind === "live";
  switch (to.kind) {
    case "folder":
      if (!isExternalFolder(to.folderId)) return to.folderId;
      return external ? null : undefined;
    case "session":
      return folderOfSession(to.sessionId);
    case "live": {
      const f = externalFolderOf(to.liveKey);
      return f !== null || external ? f : undefined;
    }
  }
}

// ── A row being dragged ────────────────────────────────────────────────────
// Set while a draggable dock row is dragged with the mouse, from the host's
// `drag` events: the row lifted and the row under the pointer (null off every
// row). The dock draws the one lifted and lights the folder a drop there
// would file it into; `dragend` clears it, dropped or not.
let dockDrag: { key: string; target: string | null } | null = null;

function dockNodeAt(key: string): DockNode | null {
  const d = openDialog;
  if (!d) return null;
  const i = d.dockKeys.indexOf(key);
  return i >= 0 ? d.dockNodes[i] ?? null : null;
}

/** The row (its node key) standing for where a drop right now would file the
 *  dragged row: the folder it names, or for an external session sent home,
 *  its product's group. None over a row it cannot go to, or back on itself,
 *  and none for a workspace's top level, which has no row. */
function dockDropTargetKey(): string | null {
  if (!dockDrag?.target || dockDrag.target === dockDrag.key) return null;
  const from = dockNodeAt(dockDrag.key);
  const to = dockNodeAt(dockDrag.target);
  if (!from || !to || from.kind === "folder") return null;
  const folderId = dropFolderFor(from, to);
  if (folderId === undefined) return null;
  if (folderId !== null) return folderNodeKey(folderId);
  if (from.kind !== "live") return null;
  const s = liveByKey(from.liveKey);
  return s ? externalGroupKey(s.agent) : null;
}

/** The row being dragged: lifted out of the list — its text inverted and
 *  slanted, a chip in hand rather than a row in place. Inverted rather than
 *  dimmed: a dim colour on the selection band (the row dragged is often the
 *  selected one) is lifted back to a legible one, and would not show. */
function liftedEntry(e: TextPropertyEntry): TextPropertyEntry {
  return restyleEntry(e, { italic: true, reversed: true });
}

/** The folder a drop would land in: the list drop-target colour across the
 *  whole row. Its own theme key, not the tab drop zone's: in several themes
 *  that one is the selection colour, and the selected row is on screen too. */
function dropTargetEntry(e: TextPropertyEntry): TextPropertyEntry {
  return {
    ...e,
    style: { ...(e.style ?? {}), bg: "ui.list_drop_target_bg", bold: true, extendToLineEnd: true },
  };
}

// ── A move being previewed ────────────────────────────────────────────────
// While a row is dragged over a folder the host shows the move a drop there
// would make (an empty row opens in the folder and the row's name is typed
// into it while it ghosts out of the row — the file explorer's preview); a
// new folder starts it over there. A drop commits it: the host lets it
// finish, fires `movepreviewend`, and the row is filed then. This is the move
// being shown: the rows it names, the row it lands under (lit meanwhile, as
// the drop target is during the drag), and whether it was dropped.
let pendingDockDrop: {
  fromKey: string;
  toKey: string;
  landKey: string | null;
  committed: boolean;
} | null = null;

// Every dropped move not yet filed, by the row that moves: where it was
// dropped. More than one when a second drag starts before the first has
// played out (the host then makes the first at once).
const committedDockDrops = new Map<string, string>();

/** File every dropped move now — the dock is going away, and its previews
 *  with it. */
function flushCommittedDockDrops(): void {
  for (const [fromKey, toKey] of [...committedDockDrops]) dropOnDockRow(fromKey, toKey);
  committedDockDrops.clear();
}

/** What dropping `fromKey` on `toKey` would show: the row it would be listed
 *  under and the name typed across. Null when the drop would move nothing,
 *  or is no place for the row. */
function dockMoveFor(fromKey: string, toKey: string): { landKey: string | null; label: string } | null {
  const from = dockNodeAt(fromKey);
  const to = dockNodeAt(toKey);
  if (!from || !to || from.kind === "folder") return null;
  const folderId = dropFolderFor(from, to);
  if (folderId === undefined) return null;
  const current = from.kind === "session" ? folderOfSession(from.sessionId) : externalFolderOf(from.liveKey);
  const label = from.kind === "session"
    ? orchestratorSessions.get(from.sessionId)?.label
    : liveByKey(from.liveKey)?.title;
  if (folderId === current || !label) return null;
  // The folder, or for an external session sent home, its product's group. A
  // workspace's top level has no row; it opens at the top of the tree, where
  // unfiled workspaces are listed.
  if (folderId !== null) return { landKey: folderNodeKey(folderId), label };
  if (from.kind !== "live") return { landKey: null, label };
  const s = liveByKey(from.liveKey);
  return { landKey: s ? externalGroupKey(s.agent) : null, label };
}

/** Keep the previewed move on the folder the drag is over, or drop it when
 *  the drag is over no place for the row or has ended without a drop. */
function syncDockMovePreview(): void {
  const drag = dockDrag;
  // A dropped move plays out on its own; only a new target replaces it.
  if (!openPanel || (pendingDockDrop?.committed && !drag?.target)) return;
  const move = drag?.target ? dockMoveFor(drag.key, drag.target) : null;
  if (!drag?.target || !move) {
    if (pendingDockDrop && !pendingDockDrop.committed) openPanel.endTreeMovePreview("sessions", false);
    pendingDockDrop = null;
    return;
  }
  pendingDockDrop = { fromKey: drag.key, toKey: drag.target, landKey: move.landKey, committed: false };
  // The host keeps playing a move it is already showing.
  openPanel.previewTreeMove("sessions", drag.key, move.landKey, move.label);
}

/** A row dropped on another dock row: commit the move the drag has been
 *  showing, to be filed when it has played out (`movepreviewend`). A drop
 *  that would not move it is filed at once — there is nothing to show. */
function commitDockDrop(fromKey: string, toKey: string): void {
  const move = dockMoveFor(fromKey, toKey);
  if (!move || !openPanel) {
    if (pendingDockDrop && !pendingDockDrop.committed && openPanel) {
      openPanel.endTreeMovePreview("sessions", false);
    }
    pendingDockDrop = null;
    dropOnDockRow(fromKey, toKey);
    return;
  }
  openPanel.previewTreeMove("sessions", fromKey, move.landKey, move.label);
  pendingDockDrop = { fromKey, toKey, landKey: move.landKey, committed: true };
  committedDockDrops.set(fromKey, toKey);
  openPanel.endTreeMovePreview("sessions", true);
}

/** A row dragged onto another dock row with the mouse. */
function dropOnDockRow(fromKey: string, toKey: string): void {
  const d = openDialog;
  if (!d) return;
  const at = (k: string): DockNode | null => {
    const i = d.dockKeys.indexOf(k);
    return i >= 0 ? d.dockNodes[i] ?? null : null;
  };
  const from = at(fromKey);
  const to = at(toKey);
  if (!from || !to || from.kind === "folder") return;
  const folderId = dropFolderFor(from, to);
  if (folderId === undefined) return;
  endMovePick();
  fileDockRow(from, folderId);
}

function movePickNew(): void {
  const p = movePick;
  endMovePick();
  if (!p) return;
  if (p.kind === "session") openCreateFolderDialog(null, p.id);
  else openCreateFolderDialog(null, undefined, p.key);
}

// The banner above the tree while a pick is on.
function dockPickRows(): WidgetSpec[] {
  if (!movePick) return [];
  return [
    label(editor.t("dock.pick_folder", { name: movePick.name }), {
      style: { fg: "diagnostic.info_fg", bold: true },
    }),
    row(
      button(editor.t("dock.move_root"), { key: "pick-root" }),
      button(editor.t("dock.new_menu_folder"), { key: "pick-new" }),
      flexSpacer(),
      button(editor.t("form.btn_cancel"), { key: "pick-cancel" }),
    ),
  ];
}

// A row that is not a move target, drawn dim while a pick is on.
function dimEntry(e: TextPropertyEntry): TextPropertyEntry {
  return restyleEntry(e, { fg: "ui.menu_disabled_fg" });
}

/** `e` with all its text in one `style`, and everything else it carries kept
 *  — a card row's `properties` (the split that holds its agent name against
 *  the right edge) above all. Rebuilding the entry from its text alone lost
 *  them, and a dimmed or lifted card ran its columns together. Its own
 *  overlays go: they colour the text the style now colours whole. */
function restyleEntry(e: TextPropertyEntry, style: Partial<OverlayOptions>): TextPropertyEntry {
  const segments = (e.segments ?? []).map((s) => ({ text: s.text, style }));
  // Keys left out rather than set to `undefined`: the bridge sends that as
  // `null`, which the host's optional fields do not take.
  const { inlineOverlays: _dropped, ...rest } = e;
  return segments.length
    ? { ...rest, segments }
    : { ...rest, text: "", segments: [{ text: e.text, style }] };
}

// "Move to Folder…" for the current row — the same pick the row context
// menu's Move option starts. Targets the dock's highlighted node when it is a
// workspace or an external session, else the active window's workspace. The
// palette command's, which first opens the dock when it isn't showing: the
// pick is made in its tree.
function openMoveToFolderForCurrent(): void {
  if (!openPanel || !dockMode) {
    if (openPanel) return; // a centered modal is up — leave it alone
    openControlRoom({ dock: true });
  }
  if (!openPanel || !openDialog || !dockMode) return;
  let id: number | null = null;
  const selKey = openDialog.dockSelKey;
  // An external session row is filed as it is: the row moves, nothing opens.
  if (selKey?.startsWith(LIVE_NODE_PREFIX)) {
    const key = selKey.slice(LIVE_NODE_PREFIX.length);
    startMovePick({ kind: "live", key, name: liveByKey(key)?.title ?? key });
    return;
  }
  if (selKey?.startsWith(SESSION_NODE_PREFIX)) {
    const sel = Number(selKey.slice(SESSION_NODE_PREFIX.length));
    if (orchestratorSessions.has(sel)) id = sel;
  }
  if (id === null) {
    const active = editor.activeWindow();
    if (orchestratorSessions.has(active)) id = active;
  }
  if (id === null) return;
  // Highlight the targeted workspace; the pick gives the dock the keyboard,
  // so ↑↓ and Enter on a folder work at once.
  openDialog.dockSelKey = sessionNodeKey(id);
  startMovePick({ kind: "session", id, name: orchestratorSessions.get(id)?.label ?? String(id) });
}
registerHandler("orchestrator_move", openMoveToFolderForCurrent);

// Switch the popup to the centered, full-screen-dimmed confirmation for a
// destructive action. Reuses the same panel; only the placement + spec
// change.
function dockMenuEnterConfirm(action: "archive" | "delete"): void {
  if (!dockMenuPanel || !dockMenuState) return;
  if (dockMenuState.target.kind !== "session") return;
  confirmRemoveWorktree = true;
  dockMenuState = {
    target: dockMenuState.target,
    anchorCol: dockMenuState.anchorCol,
    anchorRow: dockMenuState.anchorRow,
    stage: "confirm",
    action,
  };
  // Remount rather than re-center: the frame's title is a mount option, and
  // the confirmation is a titled modal like the rename dialog, not a popup
  // with a second box drawn inside it. Same panel id, so the widget_event
  // routing is unchanged; the mount centers it.
  dockMenuPanel.mount(buildDockMenuSpec(dockMenuState), {
    widthPct: 50,
    heightPct: 44,
    title: confirmTitle({ action, ids: [dockMenuState.target.id] }),
    closable: true,
  });
  editor.floatingPanelControl(dockMenuPanel.id(), "fullscreen", 1);
  // Pin Cancel, exactly as the modal picker's `enterConfirm` does. Today the
  // host would land here anyway (the outgoing `ctx-delete` focus key isn't
  // tabbable in the confirm spec, so it falls back to the first one), but
  // relying on that makes the safe default a property of the button *order* —
  // swap the pair and a destructive action becomes one Enter away. State the
  // intent instead of inheriting it.
  dockMenuPanel.setFocusKey("confirm-cancel");
}

function closeDockContextMenu(): void {
  if (dockMenuPanel) {
    dockMenuPanel.unmount();
    dockMenuPanel = null;
  }
  dockMenuState = null;
}

// Commit the highlighted session as the active window after a short
// debounce, so holding ↑/↓ to traverse the list doesn't thrash through
// every session in between. `fromEdge` drives the directional wipe.
function scheduleDockSwitch(fromEdge: "top" | "bottom" | null): void {
  const token = ++dockSwitchToken;
  void (async () => {
    await editor.delay(30);
    // Superseded by a later keystroke — let the latest one win.
    if (token !== dockSwitchToken) return;
    if (!openDialog || !openPanel || !dockMode || dockBlurred) return;
    const id = dockSelectedSessionId();
    if (typeof id !== "number") return;
    const sess = orchestratorSessions.get(id);
    // A being-created workspace switches like any other — its window exists
    // and shows the build's progress. Only a *windowless* placeholder (a
    // remote create, whose window is born by the connect) has nothing to
    // switch to; arrow-nav must never spawn/retry from one, which would fire
    // on every scroll-past during the debounce.
    if (sess?.pending && id <= 0) return;
    // A discovered (on-disk) worktree has no window to switch to — in the
    // dock's live-switch model the highlighted row *is* the active
    // session, so opening it means attaching a fresh session at the
    // worktree. Do that without diving (keep the dock focused) so it
    // matches switching to a live row, and you can keep arrowing. The
    // 30 ms debounce above means scrolling *past* it without pausing
    // never spawns a session.
    if (sess?.discovered) {
      void attachToWorktree({
        root: sess.root,
        projectPath: sess.projectPath ?? sess.root,
        label: sess.label,
        branch: sess.branch,
        discoveredId: sess.id,
        dive: false,
      });
      return;
    }
    if (id <= 0) return;
    if (id === editor.activeWindow()) return;
    // Switching to a not-yet-connected remote (a dormant row restored from a
    // previous run, or one whose link dropped) is non-blocking: the host
    // commits into a placeholder "Connecting…" page and connects in the
    // background (`ensure_dormant_shell` + `bring_dormant_remote_online`, the
    // #2570 path). So arrow-nav is free to open it — the 30 ms debounce above
    // already means only *pausing* on a row (not scrolling past it) triggers
    // the switch, so a held ↑/↓ never fans out connects to every remote in the
    // list. The dock keeps the row highlighted and the user can arrow away at
    // any time while it connects.
    if (fromEdge) editor.setActiveWindowAnimated(id, fromEdge);
    else editor.setActiveWindow(id);
  })();
}

/** What activating a dock row *means* — the one place that decides it.
 *
 *  This used to be an inline predicate, written out three times (click,
 *  Enter, and the tree's own activate), each with its own comment restating
 *  the rule. When the rule changed — a workspace being built now owns a
 *  window and a page, so it is entered like any other rather than retried
 *  from the row — every copy had to change, and a copy left behind is a row
 *  that highlights and then does nothing. That is not a rule anyone can keep
 *  in three places; it is one answer, so it is computed once here and the
 *  callers switch on it.
 *
 *  The union is the point: adding a row kind makes every caller fail to
 *  compile until it says what activating that kind does, rather than falling
 *  through whichever inline `if` happened not to match.
 *
 *  It leans on the id's sign, which is the deeper problem and not this
 *  function's to fix: live windows own the positive id space, synthetic rows
 *  (discovered worktrees, and any placeholder that never got a window) the
 *  negative. "Does this row own a window" being the sign of an integer is
 *  what let the three call sites disagree in the first place.
 */
type RowActivation =
  | { kind: "enter"; windowId: number }
  | { kind: "attach"; session: AgentSession }
  | { kind: "inert" };

function rowActivation(sess: AgentSession | undefined): RowActivation {
  if (!sess) return { kind: "inert" };
  // A discovered on-disk worktree has no window yet: opening it means
  // attaching a session to it first.
  if (sess.discovered) return { kind: "attach", session: sess };
  if (sess.id > 0) return { kind: "enter", windowId: sess.id };
  // A placeholder that owns no window: nothing to enter, and the caller must
  // not blur to the editor — that would drop focus onto whatever buffer sits
  // behind the phantom row.
  return { kind: "inert" };
}

// A click on a dock row is a deliberate "open this session" gesture, so
// it both switches the active window *and* hands keyboard focus to the
// editor — exactly like pressing Enter (`dock_activate`). This differs
// from arrow-nav, which only live-switches and keeps focus on the dock
// so you can keep arrowing. The switch is done synchronously here (the
// 30 ms debounce in `scheduleDockSwitch` exists only to absorb held
// arrow keys; a click has no such stream) and the pending debounce token
// is bumped so any in-flight arrow switch can't clobber this one.
function diveDockSelectionFromClick(fromEdge: "top" | "bottom" | null): void {
  if (!openDialog || !openPanel || !dockMode) return;
  dockSwitchToken++;
  const id = dockSelectedSessionId();
  if (typeof id !== "number") return;
  const act = rowActivation(orchestratorSessions.get(id));
  if (act.kind === "inert") return;
  if (act.kind === "attach") {
    // A discovered (on-disk) worktree has no live window — attach a fresh
    // session and dive in (attachToWorktree hands focus to the editor).
    const sess = act.session;
    void attachToWorktree({
      root: sess.root,
      projectPath: sess.projectPath ?? sess.root,
      label: sess.label,
      branch: sess.branch,
      discoveredId: sess.id,
      dive: true,
    });
    return;
  }
  if (act.windowId !== editor.activeWindow()) {
    if (fromEdge) editor.setActiveWindowAnimated(act.windowId, fromEdge);
    else editor.setActiveWindow(act.windowId);
  }
  // Hand keyboard focus to the activated window (mirror `dock_activate`).
  // Picking a row is not "leaving the dock", so the search filter that
  // produced this row survives the blur (see `dockDiveBlur`).
  dockDiveBlur = true;
  dockBlurred = true;
  editor.floatingPanelControl(openPanel.id(), "blur", 0);
}

// Toggle command (bind to a key of choice; reachable as
// "Orchestrator: Toggle Dock" in the command palette). Simple
// 2-state: visible → hide, hidden → show + focus. (A blurred-but-
// visible dock is re-focused by clicking it.) A 3-state toggle can't
// work reliably because invoking the toggle via a chord first blurs
// the focused dock — the toggle would then always see "blurred".
function toggleDock(): void {
  if (openPanel && dockMode) {
    closeOpenDialog();
    rememberDockOpen(false);
    return;
  }
  // A centered modal picker is open — leave it alone.
  if (openPanel) return;
  openControlRoom({ dock: true });
  rememberDockOpen(true);
}

registerHandler("orchestrator_dock_toggle", toggleDock);

// `autoOpenDock` as the host reads it at startup (`DockOpenPolicy::read`):
// the pre-#3442 booleans are `false` → never, `true` → auto, and anything
// unrecognised is auto. The host rewrites a boolean on disk at startup, but
// this module can load before that rewrite lands in memory.
function configuredDockMode(): "auto" | "always" | "never" {
  const v = dockSettings().autoOpenDock as unknown;
  if (v === false || v === "never") return "never";
  if (v === "always") return "always";
  return "auto";
}

// The user's last explicit open or close is what the next start follows, so
// it is written to `autoOpenDock` as `always` / `never` — the setting the host
// obeys before the first frame (`Editor::apply_startup_dock_chrome`) and the
// Settings UI shows. Without this, `never` silently undid an open from the
// View menu at every restart, and `always` a close.
//
// Called only from the routes that *are* the user saying so: the toggle
// command (View ▸ Orchestrator Dock, the palette, `toggle_dock_focus` on a
// hidden dock) and the dock's `×`. Not from the opens and closes the plugin
// does for itself (attaching to a discovered worktree, a new or recovered
// workspace via `showDockUnfocused`): those are events, not preferences.
function rememberDockOpen(open: boolean): void {
  const mode = open ? "always" : "never";
  // Deduped against `lastDockMode`, never against `configuredDockMode()`:
  // `saveSetting` only queues the write, so the config snapshot reads the old
  // value for a tick or two, and a second toggle inside that window would
  // compare against a value already superseded and skip its write.
  if (lastDockMode === mode) return;
  lastDockMode = mode;
  editor.saveSetting("plugins.orchestrator.settings.autoOpenDock", mode);
}

// The last mode this plugin wrote or adopted, so a `config_changed` that did
// not touch `autoOpenDock` is not mistaken for one that did.
let lastDockMode = configuredDockMode();

// Stop every process one session owns. Sends SIGTERM first via the
// host's `signalWindow` (which fans out through the window's
// process-group tracker), then follows up with SIGKILL after a short
// grace period so ill-behaved agents that ignore SIGTERM still get
// reaped. The session record stays put — Stop only kills processes,
// it doesn't touch the worktree or the editor session. Returns false
// for ids it can't stop (base session, discovered worktrees with no
// live window).
function stopOne(id: number): boolean {
  const s = orchestratorSessions.get(id);
  if (!s || id <= 0 || s.discovered || !s.terminalId) return false;
  editor.signalWindow(id, "SIGTERM");
  // SIGKILL fallback for agents that ignore SIGTERM. The host's
  // signalWindow is idempotent on already-exited process groups, so
  // the second call is safe whether or not the first one took.
  // QuickJS has no `setTimeout`; `editor.delay(ms)` is the async
  // sleep primitive, which we kick off but don't await.
  void editor.delay(2000).then(() => {
    editor.signalWindow(id, "SIGKILL");
  });
  return true;
}

// ---------------------------------------------------------------------
// Archive manifest — `<XDG>/orchestrator/<repo-slug>/archived.json`.
// Records sessions that have been archived (stopped + worktree moved
// to `.archived/`). Written by the Archive action, read back by
// `listArchived` / `unarchiveWorkspace` on the plugin API. No dock UI
// surfaces archived rows yet; when one does it reads the same two
// functions rather than re-walking the manifests.
// ---------------------------------------------------------------------

interface ArchivedSession {
  label: string;
  /** Current path of the moved worktree, under `.archived/`. */
  root: string;
  /** Path the worktree lived at before archiving. */
  original_root: string;
  /** Branch the worktree was on. */
  branch: string;
  /** ISO 8601 timestamp of when the session was archived. */
  archived_at: string;
  /**
   * Repo the entry belongs to. The manifest lives under a *slug* of this
   * path, and slugging is one-way, so without it a reader that found the
   * file by scanning the data directory cannot name the repo the entry
   * came from — which `git worktree move` needs to put it back. Absent in
   * manifests written before this field existed; `archivedRepoRoot`
   * recovers it from the archived worktree itself in that case.
   */
  repo_root?: string;
}

interface ArchiveManifest {
  version: number;
  sessions: ArchivedSession[];
}

function archiveManifestPath(repoRoot: string): string {
  return editor.pathJoin(
    editor.getDataDir(),
    "orchestrator",
    slugify(repoRoot),
    "archived.json",
  );
}

function loadArchiveManifest(repoRoot: string): ArchiveManifest {
  const path = archiveManifestPath(repoRoot);
  const raw = editor.readFile(editor.localPath(path));
  if (!raw) return { version: 1, sessions: [] };
  try {
    const parsed = JSON.parse(raw);
    if (
      parsed && typeof parsed === "object" &&
      Array.isArray(parsed.sessions)
    ) {
      return parsed as ArchiveManifest;
    }
  } catch (_) {
    // Fall through to fresh manifest — bad data shouldn't
    // brick the dialog.
  }
  return { version: 1, sessions: [] };
}

function saveArchiveManifest(repoRoot: string, m: ArchiveManifest): boolean {
  const path = archiveManifestPath(repoRoot);
  const dir = editor.pathDirname(path);
  if (!editor.createDir(editor.localPath(dir))) return false;
  return editor.replaceFile(editor.localPath(path), JSON.stringify(m, null, 2));
}

/// Every archive manifest on this machine, paired with the entries it holds.
///
/// The manifests are keyed by a *slug* of the repo root, and slugging is
/// one-way, so the scan cannot name the repo from the directory name. Newer
/// entries carry `repo_root`; for older ones the repo is recovered from the
/// archived worktree itself (`archivedRepoRoot`) at the point it is needed,
/// which is the one place that needs it.
function scanArchiveManifests(): { slug: string; manifest: ArchiveManifest }[] {
  const base = editor.pathJoin(editor.getDataDir(), "orchestrator");
  const out: { slug: string; manifest: ArchiveManifest }[] = [];
  let entries: DirEntry[];
  try {
    entries = editor.readDir(editor.localPath(base));
  } catch (_) {
    return out;
  }
  // A machine that has never archived anything has no directory here at all;
  // both shapes of "nothing to read" have to be tolerated (see
  // `scanSessionContent`, which reads its directory the same way).
  if (!entries) return out;
  for (const e of entries) {
    // A dot-directory here is orchestrator bookkeeping (the `.archived`
    // graveyard), not a per-repo state directory.
    if (!e.is_dir || e.name.startsWith(".")) continue;
    const path = editor.pathJoin(base, e.name, "archived.json");
    const raw = editor.readFile(editor.localPath(path));
    if (!raw) continue;
    try {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === "object" && Array.isArray(parsed.sessions)) {
        out.push({ slug: e.name, manifest: parsed as ArchiveManifest });
      }
    } catch (_) {
      // A corrupt manifest hides its own repo's archive rather than
      // failing the whole listing — same tolerance as `loadArchiveManifest`.
    }
  }
  return out;
}

/// The repo an archived entry belongs to: the recorded `repo_root` when the
/// entry has one, else resolved from the archived worktree on disk (a linked
/// worktree still points at its main checkout, even from the graveyard).
/// `null` when neither is available — a manifest entry whose directory is
/// gone, which unarchive cannot act on anyway.
async function archivedRepoRoot(e: ArchivedSession): Promise<string | null> {
  if (e.repo_root) return e.repo_root;
  if (!editor.fileExists(editor.localPath(e.root))) return null;
  return await resolveCanonicalRepoRoot(e.root);
}

/// Move an archived worktree back to where it came from and drop its manifest
/// entry. Reverses `archiveOne`'s graveyard move; an entry archived in place
/// (`original_root === root`, no move happened) just leaves the manifest, and
/// the directory is already where it belongs.
///
/// Does NOT trigger sync — the caller batches that, matching the other
/// lifecycle cores.
async function unarchiveOne(e: ArchivedSession): Promise<LifecycleResult> {
  const repoRoot = await archivedRepoRoot(e);
  if (!repoRoot) return { ok: false, err: editor.t("err.not_git_repo") };

  const moved = e.original_root !== e.root;
  if (moved) {
    if (!editor.fileExists(editor.localPath(e.root))) {
      return { ok: false, err: `archived worktree is gone: ${e.root}`, repoRoot };
    }
    // Refuse rather than clobber: something else already occupies the path
    // this worktree wants back, and `git worktree move` would fail anyway —
    // with a message about a destination the user never named.
    if (editor.fileExists(editor.localPath(e.original_root))) {
      return {
        ok: false,
        err: `something already exists at ${e.original_root}`,
        repoRoot,
      };
    }
    const parent = editor.pathDirname(e.original_root);
    if (!editor.createDir(editor.localPath(parent))) {
      return { ok: false, err: editor.t("err.could_not_create", { path: parent }), repoRoot };
    }
    const res = await spawnCollect(
      "git",
      ["-C", repoRoot, "worktree", "move", e.root, e.original_root],
      repoRoot,
    );
    if (res.exit_code !== 0) {
      return {
        ok: false,
        err: lastNonEmptyLine(res.stderr) || editor.t("err.worktree_move_failed"),
        repoRoot,
      };
    }
  }

  const manifest = loadArchiveManifest(repoRoot);
  manifest.sessions = manifest.sessions.filter((x) => x.root !== e.root);
  saveArchiveManifest(repoRoot, manifest);
  // Nothing re-adds the row to the model here: the worktree is back on disk,
  // so the discovered-worktree scan picks it up as an unopened row the next
  // time it runs (and `focusWorkspace` / Enter opens it). Forcing a window
  // open would make unarchive mean "restore *and* launch", which is not what
  // the archive action's inverse should do.
  void refreshDiscoveredWorktrees();
  return { ok: true, repoRoot };
}

// Pick a session id to make active so that `excludeId` can be
// closed. `close_window` refuses to close the active window, so
// archive/delete of the currently-active session needs to switch
// away first. Prefers a session already visible in the open
// dialog's current filter (keeps the user in roughly the same
// project context they were browsing), falls back to the base
// session — which always exists and can't itself be archived /
// deleted, so this is guaranteed to return a valid target.
function pickNextActiveSession(excludeId: number): number {
  if (openDialog) {
    const inFilter = openDialog.filteredIds.find(
      (sid) => sid !== excludeId && sid > 0,
    );
    if (typeof inFilter === "number") return inFilter;
  }
  for (const sid of orchestratorSessions.keys()) {
    if (sid !== excludeId && sid > 0) return sid;
  }
  // No other live window. Callers guard against closing the last
  // window before reaching here, so this is a safe no-op swap (id 1
  // is no longer guaranteed to exist — it's deletable like any other).
  return excludeId;
}

// Number of real editor windows. Discovered on-disk rows have negative
// ids and are not windows. The editor must always host at least one
// window; archiving/deleting the last live window therefore opens a
// replacement first (see `ensureReplacementWindow`).
function liveWindowCount(): number {
  let n = 0;
  for (const s of orchestratorSessions.values()) {
    if (s.id > 0) n += 1;
  }
  return n;
}

// Closing the last live window would leave the editor with nothing to
// show, so before archiving/deleting the sole remaining session we open
// a fresh terminal session in `projectRoot` — the project that session
// belonged to, i.e. "the last project" — and dive into it. The new
// window becomes active, so the caller can then close the old one
// normally. No-op when another live window already exists (the caller
// just switches to it instead). Returns true when a replacement opened.
async function ensureReplacementWindow(projectRoot: string): Promise<boolean> {
  if (liveWindowCount() > 1) return false;
  const label = editor.pathBasename(projectRoot) || "session";
  try {
    const result = await editor.createWindowWithTerminal({
      root: projectRoot,
      label,
      cwd: projectRoot,
      // Always mint the workspace's capability token (see runLocalCreate).
      allowScript: FRESH_CLI_ALLOW_SCRIPT,
    });
    // `createWindowWithTerminal` fires `window_created`, which reconciles
    // the new window into the model; set it eagerly too so the immediate
    // close-and-switch below sees a second live window.
    orchestratorSessions.set(result.windowId, {
      id: result.windowId,
      stableId: result.stableId || undefined,
      label,
      hostLabel: label,
      root: projectRoot,
      projectPath: projectRoot,
      sharedWorktree: false,
      terminalId: result.terminalId,
      state: "idle",
      lastOutputAt: null,
      createdAt: Date.now(),
    });
    return true;
  } catch (e) {
    editor.setStatus(
      editor.t("status.replacement_failed", {
        error: e instanceof Error ? e.message : String(e),
      }),
    );
    return false;
  }
}

// Resolve the *main* repo root a session's worktree belongs to, so
// `git worktree move/remove` runs from a stable directory (never from
// inside the tree being moved/removed). Prefers the canonical
// `projectPath` recorded at create/discovery time, falling back to
// resolving from the worktree itself.
async function worktreeRepoRoot(s: AgentSession): Promise<string | null> {
  // `projectPath` is the canonical repo root when the session is a
  // worktree of a separate project, and equals `root` otherwise (the
  // host normalises absence → root). Resolve once; if the canonical
  // path is unavailable (non-git, etc.), fall back to `root` so the
  // caller still gets something to dedupe against.
  const r = await resolveCanonicalRepoRoot(s.projectPath);
  if (r) return r;
  if (s.projectPath !== s.root) {
    return await resolveCanonicalRepoRoot(s.root);
  }
  return null;
}

interface LifecycleResult {
  ok: boolean;
  err?: string;
  repoRoot?: string;
  // Something that succeeded but is worth saying — today, a remote worktree
  // left on its host. Not an `err`: the delete did what it could, and failing
  // the row would misreport it. Carried out to the batch rather than written
  // to the status bar here, because the batch sets its own summary afterwards
  // and would overwrite anything this wrote.
  note?: string;
}

// Archive a single session: SIGKILL its processes (archive is a
// "done with this for now" action — no graceful teardown needed since
// the worktree stays on disk), close the editor session, move the
// worktree to the `.archived/` graveyard, and append a manifest
// entry so Unarchive can reverse it. Handles both live sessions and
// discovered on-disk worktrees (the latter have no window to close).
// Does NOT trigger sync — the caller batches one sync per repo after
// the whole run.
// Where a workspace's worktree goes when it is archived.
//
// **The name is the worktree's own directory, not the row's label.** A
// workspace's `label` is a *display* string — `workspaceDisplayName` composes
// it from the workspace name and the terminal's live tab title — so filing
// one produced directories like `gamma-…-test · bash — root@vm: ~/…`: spaces,
// a middle dot, an em dash, a colon, and the `/`s of the title's path, which
// `git worktree move` read as further directory levels and nested the
// graveyard under (sinelaw/fresh#1971). The basename of `s.root` is the name
// git already gave the directory, so it is a valid single component by
// construction and the archived copy keeps the name it had while it was live.
//
// The manifest still records `s.label`, which is what the archive listing
// shows and what `unarchiveWorkspace` matches a human's name against; it
// resolves the directory from the recorded `root`, never by rebuilding this
// path, so what the directory is called is this function's business alone.
//
// A repeat archive of the same workspace name would land on a directory that
// is already there — `git worktree move` refuses that — so an occupied name
// takes the next free `-2`, `-3`, … instead of failing the archive.
function archivedPathFor(repoRoot: string, s: AgentSession): string {
  const graveyard = editor.pathJoin(
    editor.getDataDir(),
    "orchestrator",
    slugify(repoRoot),
    ".archived",
  );
  // `s.hostLabel` is NOT a fallback here: it is a display string too (the
  // reconcile sites write it from the window's own label, and the rename path
  // overwrites it), so falling back to it would put the very characters this
  // function exists to keep out of a path back into one. A root with no
  // basename is a filesystem root, which owns no workspace; the constant is
  // the honest answer.
  const name = editor.pathBasename(s.root) || "workspace";
  let candidate = editor.pathJoin(graveyard, name);
  for (let n = 2; editor.fileExists(editor.localPath(candidate)); n++) {
    candidate = editor.pathJoin(graveyard, `${name}-${n}`);
  }
  return candidate;
}

function archiveOne(id: number): Promise<LifecycleResult> {
  return holdProbesOff(id, () => archiveOneNow(id));
}

async function archiveOneNow(id: number): Promise<LifecycleResult> {
  const s = orchestratorSessions.get(id);
  if (!s) return { ok: false, err: editor.t("err.workspace_gone") };
  const removable = ownsWorktree(s);

  // Live session: the editor must always host a window. If this is the
  // only one, open a replacement in its project first; then switch away
  // (close_window refuses the active window), SIGKILL the process group
  // so pty children release any worktree locks, and close the session.
  if (!s.discovered && id > 0) {
    await ensureReplacementWindow(s.projectPath ?? s.root);
    if (id === editor.activeWindow()) {
      editor.setActiveWindow(pickNextActiveSession(id));
    }
    if (s.terminalId) editor.signalWindow(id, "SIGKILL");
    // Tombstone before the (async) close so a mid-archive
    // `refreshOpenDialog` doesn't reconcile the workspace back in from the
    // still-stale window snapshot.
    closingWindowIds.add(id);
    editor.closeWindow(id);
    // Brief settle so the filesystem reflects the pty's exit before we
    // move the worktree out from under it.
    if (removable) await editor.delay(250);
  }

  if (removable) {
    // Owns a worktree: move it to the `.archived/` graveyard so git's
    // bookkeeping stays consistent and Unarchive can move it back.
    const repoRoot = await worktreeRepoRoot(s);
    if (!repoRoot) return { ok: false, err: editor.t("err.not_git_repo") };
    const archivedRoot = archivedPathFor(repoRoot, s);
    const parent = editor.pathDirname(archivedRoot);
    if (!editor.createDir(editor.localPath(parent))) {
      return { ok: false, err: editor.t("err.could_not_create", { path: parent }), repoRoot };
    }
    const moveRes = await spawnCollect(
      "git",
      ["-C", repoRoot, "worktree", "move", s.root, archivedRoot],
      repoRoot,
    );
    if (moveRes.exit_code !== 0) {
      return {
        ok: false,
        err: lastNonEmptyLine(moveRes.stderr) || editor.t("err.worktree_move_failed"),
        repoRoot,
      };
    }
    const manifest = loadArchiveManifest(repoRoot);
    manifest.sessions.push({
      label: s.label,
      root: archivedRoot,
      original_root: s.root,
      branch: s.branch || s.label,
      archived_at: new Date().toISOString(),
      repo_root: repoRoot,
    });
    saveArchiveManifest(repoRoot, manifest);
    // A discovered row has no window_closed hook to drop it — remove it
    // from the model directly.
    if (s.discovered) {
      orchestratorSessions.delete(id);
      discoveredIdByPath.delete(s.root);
    }
    // The worktree moved to the graveyard, so the original root is gone;
    // forget its now-dangling persisted workspace explicitly rather than
    // leaning on boot-time GC to notice the directory vanished.
    editor.deleteWorkspace(s.root);
    return { ok: true, repoRoot };
  }

  // In-place / launch session: there's no separate worktree to move, so
  // archiving just records the session at its own root (original_root ===
  // root, no graveyard move) — listing it as archived and letting a
  // future Unarchive reopen a window there — then drops the live record.
  // The window was already closed above.
  const repoRoot = (await resolveCanonicalRepoRoot(s.root)) ?? s.root;
  const manifest = loadArchiveManifest(repoRoot);
  manifest.sessions.push({
    label: s.label,
    root: s.root,
    original_root: s.root,
    branch: s.branch || s.label,
    archived_at: new Date().toISOString(),
    repo_root: repoRoot,
  });
  saveArchiveManifest(repoRoot, manifest);
  orchestratorSessions.delete(id);
  // In-place archive leaves the directory on disk, so its persisted
  // workspace must be forgotten too — otherwise discovery re-adds it as a
  // live session on the next launch, double-listed with its archive entry.
  // Unarchive reopens from the manifest, so the dropped layout is expendable.
  editor.deleteWorkspace(s.root);
  return { ok: true, repoRoot };
}

// Delete a single session: close the editor session, then — only when
// the session owns a worktree — `git worktree remove --force` to drop
// it from disk (and prune any archive-manifest entry). A launch or
// in-place session owns no worktree, so Delete just forgets it: the
// window closes and the directory is left untouched (a fresh session
// can always be opened there again). Handles discovered on-disk
// worktrees (no window to close). Does NOT trigger sync — the caller
// batches it.
function deleteOne(
  id: number,
  // Whether to remove the worktree as well as the workspace record. The
  // confirm dialog offers this as a checkbox; every other caller (the plugin
  // API, in particular) gets the long-standing behaviour by default, so the
  // choice cannot leak out of the dialog that asked for it.
  removeWorktree = true,
): Promise<LifecycleResult> {
  return holdProbesOff(id, () => deleteOneNow(id, removeWorktree));
}

async function deleteOneNow(id: number, removeWorktree: boolean): Promise<LifecycleResult> {
  const s = orchestratorSessions.get(id);
  if (!s) return { ok: false, err: editor.t("err.workspace_gone") };
  const removable = ownsWorktree(s);

  // **The remote worktree goes first, while its own window is still here.**
  // The confirm dialog promises `git worktree remove`, and for a remote
  // workspace nothing used to run it: `ownsWorktree` answers on
  // `projectPath !== root`, which the host does not record for a remote
  // session, so every delete left a directory behind on the far side. The
  // removal has to happen before the teardown below, because that closes the
  // very window this spawn routes through.
  let remoteLeftBehind: string | null = null;
  if (removeWorktree && !s.discovered && id > 0 && looksLikeOurRemoteWorktree(s)) {
    if (!remoteWorktreeReachable(s)) {
      // Disconnected: there is no authority to route through, and forcing one
      // open here would race the connect (see `remoteWorktreeReachable`).
      remoteLeftBehind = editor.t("err.remote_disconnected");
    } else {
      if (id !== editor.activeWindow()) editor.setActiveWindow(id);
      remoteLeftBehind = await removeRemoteWorktree(s);
      if (!orchestratorSessions.has(id)) return { ok: false, err: editor.t("err.workspace_gone") };
    }
  }

  if (!s.discovered && id > 0) {
    // The editor must keep at least one window. If this is the only live
    // one, open a replacement in its project first (so a removable
    // session can't `git worktree remove` the tree the editor is still
    // sitting in, and the editor never goes empty). Then swap away
    // (close_window refuses the active window), SIGKILL only when there's
    // an agent terminal — a launch/in-place session has none — and close.
    await ensureReplacementWindow(s.projectPath ?? s.root);
    if (id === editor.activeWindow()) {
      editor.setActiveWindow(pickNextActiveSession(id));
    }
    if (s.terminalId) editor.signalWindow(id, "SIGKILL");
    // Tombstone before the (async) close so any `refreshOpenDialog` that
    // runs before the host processes it doesn't reconcile the workspace
    // straight back in from the still-stale window snapshot.
    closingWindowIds.add(id);
    editor.closeWindow(id);
    if (removable) await editor.delay(250);
  }

  let repoRoot: string | undefined;
  if (removable) {
    const rr = await worktreeRepoRoot(s);
    if (!rr) return { ok: false, err: editor.t("err.not_git_repo") };
    repoRoot = rr;
    // The repo root is resolved either way — the manifest entry below and the
    // session-list sync both need it — but the removal itself is the part the
    // user chose.
    if (removeWorktree) {
      // `--force` because the worktree may have unstaged changes the user
      // explicitly chose to discard via the confirm step.
      const removeRes = await spawnCollect(
        "git",
        ["-C", rr, "worktree", "remove", "--force", s.root],
        rr,
      );
      if (removeRes.exit_code !== 0) {
        return {
          ok: false,
          err: lastNonEmptyLine(removeRes.stderr) || editor.t("err.worktree_remove_failed"),
          repoRoot,
        };
      }
    }

    // Drop the matching manifest entry too, in case the session was
    // already archived (delete-from-archived drops dormant sessions).
    const manifest = loadArchiveManifest(rr);
    const before = manifest.sessions.length;
    manifest.sessions = manifest.sessions.filter((e) => e.label !== s.label);
    if (manifest.sessions.length !== before) {
      saveArchiveManifest(rr, manifest);
    }
  }

  if (s.discovered) {
    orchestratorSessions.delete(id);
    discoveredIdByPath.delete(s.root);
  } else if (id > 0) {
    // Drop the live record explicitly. `close_window` fires
    // `window_closed` → reconcile, which also prunes it, but an in-place
    // / launch session left the directory untouched, so without this it
    // could linger in the model and "come back" when the dialog reopens.
    orchestratorSessions.delete(id);
  }
  // Permanently forget the persisted workspace so boot-time session
  // discovery can't resurrect this row on the next launch. A worktree
  // session already had its directory removed above (discovery GCs the
  // now-dangling file), but an in-place / launch session keeps its
  // directory, so its `workspaces/<root>.json` must be dropped explicitly
  // or the row reappears after a restart.
  editor.deleteWorkspace(s.root);
  // A host that could not be reached does not block the delete — the row goes
  // either way — but it is said out loud, with the path, so the user knows
  // what is still sitting on the far side.
  return {
    ok: true,
    repoRoot,
    ...(remoteLeftBehind
      ? { note: editor.t("err.remote_worktree_kept", { path: s.root, error: remoteLeftBehind }) }
      : {}),
  };
}

/// Outcome of a lifecycle batch: how many targets the action ran on
/// successfully, and the last failure reason when some did not.
interface LifecycleBatchResult {
  ran: number;
  ok: number;
  lastErr: string;
  // The first "succeeded, but…" note any member produced (see
  // `LifecycleResult.note`). One is enough for a status line; the rest of the
  // batch is reported by the counts.
  note?: string;
}

/// Run Archive / Delete over `targets`, batching one sync per touched repo.
///
/// This is the single execution path for the destructive lifecycle actions:
/// the picker's confirmed action calls it with its whole selection, and the
/// plugin API's `archiveWorkspace` / `deleteWorkspace` call it with one id.
/// `onProgress` is how the picker drives its "Archiving 2/3…" markers without
/// this core knowing anything about the dialog — a headless caller passes
/// nothing.
///
/// Targets are NOT re-filtered here: both callers check eligibility first (the
/// picker to report "nothing eligible", the API to throw the reason), and
/// silently dropping an ineligible id would turn the API's refusal into a
/// success.
async function runLifecycleBatch(
  action: "archive" | "delete",
  targets: number[],
  onProgress?: (doneIndex: number, id: number) => void,
  removeWorktree = true,
): Promise<LifecycleBatchResult> {
  const touchedRepos = new Set<string>();
  let okCount = 0;
  let lastErr = "";
  let note = "";
  for (let i = 0; i < targets.length; i++) {
    const id = targets[i];
    const res = action === "archive"
      ? await archiveOne(id)
      : await deleteOne(id, removeWorktree);
    if (res.ok) {
      okCount += 1;
      if (res.repoRoot) touchedRepos.add(res.repoRoot);
      if (res.note && !note) note = res.note;
    } else {
      lastErr = res.err ?? editor.t("err.failed");
    }
    onProgress?.(i, id);
  }
  // The cores deliberately skip this so a batch pushes once per repo rather
  // than once per workspace.
  return { ran: targets.length, ok: okCount, lastErr, ...(note ? { note } : {}) };
}

/// Signal the agent process groups of `targets`. Shared by the picker's
/// confirmed Stop and the API's `stopWorkspace`; returns how many were
/// signalled.
function runStopBatch(targets: number[]): number {
  let n = 0;
  for (const id of targets) if (stopOne(id)) n += 1;
  return n;
}

// Unified runner for a confirmed Stop / Archive / Delete over one or
// many ids. Re-filters to eligible targets at execution time (the
// selection or single row may have gone stale between confirm and
// run), drives the in-flight progress markers, runs the shared batch
// cores, and prunes acted-on ids from the selection.
async function runConfirmedAction(
  action: BulkAction,
  ids: number[],
): Promise<void> {
  if (!openDialog) return;
  const targets = ids.filter((id) => bulkEligible(action, id));
  if (targets.length === 0) {
    setDialogError(editor.t("err.nothing_eligible", { action }));
    refreshOpenDialog();
    return;
  }

  if (action === "stop") {
    const n = runStopBatch(targets);
    editor.setStatus(editor.t("status.stop_sent", { count: String(n) }));
    // Stop leaves sessions in place; drop them from the selection so
    // the bulk bar reflects that the action ran.
    for (const id of targets) openDialog.selectedIds.delete(id);
    refreshOpenDialog();
    return;
  }

  const single = targets.length === 1;
  if (single) {
    openDialog.inFlight = { action, sessionId: targets[0] };
  } else {
    openDialog.bulkInFlight = { action, total: targets.length, done: 0 };
  }
  refreshOpenDialog();

  // Read the checkbox once, here: the batch below runs across several awaits
  // and the dialog it came from is already gone.
  const removeWorktree = action === "delete" ? confirmRemoveWorktree : true;
  const { ok: okCount, lastErr, note } = await runLifecycleBatch(
    action,
    targets,
    (i, id) => {
      openDialog?.selectedIds.delete(id);
      if (openDialog?.bulkInFlight) openDialog.bulkInFlight.done = i + 1;
      refreshOpenDialog();
    },
    removeWorktree,
  );
  if (openDialog) {
    openDialog.inFlight = null;
    openDialog.bulkInFlight = null;
  }

  const verb = action === "archive" ? editor.t("status.verb_archived") : editor.t("status.verb_deleted");
  if (okCount === 0) {
    setDialogError(editor.t("err.action_failed", { action, error: lastErr || editor.t("err.unknown_error") }));
  } else if (lastErr) {
    setDialogError(editor.t("err.partial_done", { verb, ok: String(okCount), total: String(targets.length), error: lastErr }));
  } else if (note) {
    // Succeeded, with something the user needs to know — say that instead of
    // the bare count, which would read as "all done" while a directory is
    // still sitting on a host.
    editor.setStatus(editor.t("status.prefix", { msg: note }));
  } else {
    editor.setStatus(editor.t("status.bulk_done", { verb, count: String(okCount) }));
  }
  refreshOpenDialog();
  // The batch emptied the selection, so the pane is back in
  // single-preview mode — restore focus to Visit (the bulk buttons
  // it may have been on are gone).
  if (openPanel && selectedSessions().length < 2 && !openDialog.pendingConfirm) {
    openPanel.setFocusKey("visit");
  }
}

// `Alt+N` from inside the picker opens the new-session form — saves
// the user the "Esc, Ctrl+P, type Orchestrator: New Session, Enter"
// dance when they realise mid-picker that they want to spawn another
// agent. All other keys (Up/Down/Enter/Tab/Esc/printable chars)
// route through `dispatch_floating_widget_key`'s smart-key defaults
// since OPEN_MODE doesn't claim them here.
editor.defineMode(
  OPEN_MODE,
  [
    ["M-n", "orchestrator_open_new_from_picker"],
    // Scope toggle: flip the list between "current project only"
    // and "all projects". Registered as a mode chord so it's
    // user-rebindable and renders cross-platform (⌥P / Alt+P).
    ["M-p", "orchestrator_toggle_scope"],
    // `/` jumps focus to the filter input — the familiar
    // search-focus shortcut. Declared a dialog-wide shortcut, so it runs
    // ahead of the focused control, the filter included: `/` can't be
    // typed as filter text; session names don't contain `/`, so that's
    // an acceptable trade for the quick-focus.
    ["/", "orchestrator_focus_filter", "shortcut"],
    // Space toggles the highlighted row's membership in the bulk
    // selection, whichever control holds focus — a dialog-wide shortcut
    // for the same reason (the list itself is not focusable, so no
    // control of its own could take it). The trade (same as `/`) is that
    // Space can't be typed into the filter while the picker is open;
    // session names don't contain spaces, so that's acceptable.
    ["Space", "orchestrator_toggle_select", "shortcut"],
    // Alt+T toggles "Show all worktrees" — the opt-in filter that
    // surfaces discovered on-disk worktree rows. Rebindable, same as
    // the scope toggle.
    ["M-t", "orchestrator_toggle_worktrees"],
    // Alt+I toggles "Show empty/1-file sessions" — reveals the trivial
    // restored shells hidden by default. Rebindable, same as the others.
    // (Alt+E is unavailable: it's the Edit menu's mnemonic, which the
    // menu bar claims before the picker's mode keymap sees it.)
    ["M-i", "orchestrator_toggle_trivial"],
  ],
  true,
  true,
);

// The dock's Enter / Esc / Space / "/" are handled at the host's
// floating-panel layer (see dispatch_floating_widget_key), not via an
// editor mode — `defineMode` bindings resolve against the active
// buffer's mode, which the dock floats over, so a session with a
// buffer-local mode would shadow them. Up/Down use the host's generic
// list smart-keys, which fire the `select` event we live-switch on.

registerHandler("orchestrator_open_new_from_picker", () => {
  if (!openDialog) return;
  // The New-Session form is a centered modal in the host's dedicated
  // floating slot, which coexists with the dock's own slot. From the
  // dock, leave the dock mounted underneath (it keeps showing the live
  // session list); from the centered picker, replace it with the form.
  if (dockMode) {
    // Hand keyboard focus to the form by blurring the dock; the host
    // routes keys to the focused centered modal first.
    dockBlurred = true;
    openForm({ fromPicker: true });
    return;
  }
  closeOpenDialog();
  openForm({ fromPicker: true });
});

registerHandler("orchestrator_focus_filter", () => {
  if (!openDialog || !openPanel) return;
  if (dockMode) {
    openDockSearch();
    return;
  }
  openPanel.setFocusKey("filter");
});

// Space (rebindable): toggle the highlighted row in/out of the bulk
// selection. Manages focus across the single↔bulk transition: when
// the second row is checked the preview pane swaps to the bulk bar
// (so the now-absent "visit" focus would otherwise be clamped to a
// random tabbable), and when the selection drops back below two the
// per-session preview — with its "visit" button — returns.
function toggleSelectCurrent(): void {
  if (!openDialog || !openPanel) return;
  // Inert while a confirm prompt is up — the selection is frozen
  // behind the confirmation panel.
  if (openDialog.pendingConfirm) return;
  // Context-sensitive Space dispatch. OPEN_MODE binds Space to
  // `orchestrator_toggle_select` *unconditionally* — it must, to keep
  // Space out of the filter text input (the host's
  // dispatch_floating_widget_key defers any explicitly-bound mode key
  // before the text-input path). We branch on the focused widget so
  // Space on the filter checkboxes / scope chip toggles *that*
  // control rather than the list multi-select. Other focused widgets
  // (sessions list, Visit button, +New, the filter input itself) fall
  // through to the list multi-select — preserving today's behaviour
  // for widgets that don't expose a natural toggle.
  switch (pickerFocusKey()) {
    case "worktree-show":
      toggleShowWorktrees();
      return;
    case "hide-trivial":
      toggleHideTrivial();
      return;
    case "scope-toggle":
      toggleScope();
      return;
  }
  const id = openDialog.filteredIds[openDialog.selectedIndex];
  if (typeof id !== "number") return;
  const wasBulk = selectedSessions().length >= 2;
  if (openDialog.selectedIds.has(id)) {
    openDialog.selectedIds.delete(id);
  } else {
    openDialog.selectedIds.add(id);
  }
  clearDialogError();
  refreshOpenDialog();
  // The dock has no bulk preview pane / Visit button; just toggle the
  // checkbox and keep focus on the list.
  if (dockMode) {
    openPanel.setSelectedIndex("sessions", openDialog.selectedIndex);
    return;
  }
  const isBulk = selectedSessions().length >= 2;
  if (!wasBulk && isBulk) {
    // Entering bulk mode — land focus on a bulk button (the list is
    // one Shift+Tab or ↑/↓ walk away).
    openPanel.setFocusKey("bulk-archive");
  } else if (wasBulk && !isBulk) {
    // Back to single preview — restore focus to Visit.
    openPanel.setFocusKey("visit");
  }
}
registerHandler("orchestrator_toggle_select", toggleSelectCurrent);

// Flip the picker between "this project" and "all projects". Through the
// published verb, which remembers the choice for the next open and keeps the
// highlighted session selected across the flip. The filter value is untouched
// — toggling scope with an active filter just widens/narrows the search base.
function toggleScope(): void {
  if (!openDialog) return;
  apiSetDockFilter({ scope: openDialog.scope === "current" ? "all" : "current" });
}

registerHandler("orchestrator_toggle_scope", toggleScope);

// Flip "Show all worktrees" — reveal/hide the discovered on-disk worktree
// rows. Shared by the Alt+T chord and the checkbox click, and both go
// through the published `setDockFilter`, which owns writing the flag,
// re-filtering, preserving the highlighted row and pruning the selection.
function toggleShowWorktrees(): void {
  if (!openDialog) return;
  apiSetDockFilter({ worktrees: !openDialog.showWorktrees });
}

registerHandler("orchestrator_toggle_worktrees", toggleShowWorktrees);

// Flip "Show empty/1-file sessions" — reveal/hide the trivial restored
// shells. `showEmpty` is the inverse of the stored `hideTrivial`, so
// flipping the flag means passing the *current* `hideTrivial` through.
function toggleHideTrivial(): void {
  if (!openDialog) return;
  apiSetDockFilter({ showEmpty: openDialog.hideTrivial });
}

registerHandler("orchestrator_toggle_trivial", toggleHideTrivial);

// =============================================================================
// New-session floating form
// =============================================================================

function slugify(p: string): string {
  // Drop any leading separator so the slug isn't anchored to the
  // filesystem root; replace remaining separators with underscores.
  return p.replace(/^[\\\/]+/, "").replace(/[\\\/]+/g, "_");
}

// =============================================================================
// Input history (Up / Down) for the new-session form
//
// Per-field MRU lists keyed under `orchestrator.history.<field>` in
// the editor's global plugin-state store (persisted across editor
// restarts). Submit appends the resolved value to each field's
// history; Up/Down on a focused input walks the list (saving the
// user's in-progress draft on the first ↑ so ↓ can return to it).
// Capped at 100 entries per field, MRU-trimmed.
// =============================================================================

type HistoryField = "project_path" | "name" | "cmd" | "branch";
const HISTORY_FIELDS: HistoryField[] = ["project_path", "name", "cmd", "branch"];
const HISTORY_CAP = 100;

/// Which of the form's controls holds the keyboard — the host's fact,
/// read when a binding needs it (the history arrows).
function formFocusedKey(): string {
  return formPanel?.focusKey() ?? "";
}

function historyKey(field: HistoryField): string {
  return `orchestrator.history.${field}`;
}

function readHistory(field: HistoryField): string[] {
  const raw = editor.getGlobalState(historyKey(field));
  if (Array.isArray(raw)) {
    return raw.filter((v): v is string => typeof v === "string");
  }
  return [];
}

function writeHistory(field: HistoryField, items: string[]): void {
  editor.setGlobalState(historyKey(field), items as unknown as object);
}

function appendHistory(field: HistoryField, value: string): void {
  const v = (value || "").trim();
  if (!v) return;
  const prev = readHistory(field).filter((x) => x !== v);
  prev.unshift(v);
  if (prev.length > HISTORY_CAP) prev.length = HISTORY_CAP;
  writeHistory(field, prev);
}

/// Map a focused widget key to its history field, or null if the
/// key isn't a history-bearing input.
function focusToHistoryField(focusKey: string): HistoryField | null {
  return (HISTORY_FIELDS as readonly string[]).includes(focusKey)
    ? (focusKey as HistoryField)
    : null;
}

/// Walk the history of `field` by `delta` (-1 = older / ↑, +1 =
/// newer / ↓). Updates the form's value, cursor, and history
/// cursor in place. No-op when the history is empty (or when ↓
/// is hit past the bottom of the stack).
function walkHistory(field: HistoryField, delta: -1 | 1): void {
  if (!form) return;
  const history = readHistory(field);
  if (history.length === 0) return;
  const slot = formSlot(field);
  if (!slot) return;

  const curr = form.historyCursor[field];
  let next = curr + delta; // -1 → 0 for first ↑

  if (next < -1) {
    // Already at the draft slot, ↓ does nothing more.
    return;
  }
  if (next >= history.length) {
    // Past the oldest entry — stay put.
    return;
  }

  if (curr === -1 && delta === -1) {
    // First ↑: save the in-progress draft so the user can ↓
    // back to whatever they were typing.
    form.historyDraft[field] = slot.value;
  }

  if (next === -1) {
    // ↓ off the top of the stack → restore the saved draft.
    slot.value = form.historyDraft[field];
  } else {
    slot.value = history[next];
  }
  slot.cursor = slot.value.length;
  form.historyCursor[field] = next;

  // Sync the rendered widget so cursor + value match (the host
  // tracks text input state separately from the spec).
  if (formPanel) {
    formPanel.setValue(field, slot.value, slot.cursor);
  }
  // Re-probe defaults if the user just rolled history into the
  // Project Path field.
  if (field === "project_path") scheduleProjectPathReprobe();
  renderForm();
}

function formSlot(field: HistoryField): { value: string; cursor: number } | null {
  if (!form) return null;
  switch (field) {
    case "project_path": return form.projectPath;
    case "name": return form.name;
    case "cmd": return form.cmd;
    case "branch": return form.branch;
  }
}

function lastNonEmptyLine(s: string): string {
  const lines = (s || "").split(/\r?\n/).filter((l) => l.trim().length > 0);
  return lines.length ? lines[lines.length - 1].trim() : "";
}

/// Split the user's "Agent Command" string into an argv suitable for
/// `editor.createTerminal({ command })`. Honours single- and
/// double-quoted segments so `claude --append "hello world"` parses
/// as three args rather than four. Backslash escaping is intentionally
/// *not* supported — agent commands are short typed-in strings; if
/// they need that level of escaping the user should write a wrapper
/// shell script.
///
/// Returns `[]` for an empty or whitespace-only input.
function splitAgentCmd(s: string): string[] {
  const out: string[] = [];
  let cur = "";
  let quote: '"' | "'" | null = null;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (quote) {
      if (c === quote) {
        quote = null;
      } else {
        cur += c;
      }
      continue;
    }
    if (c === '"' || c === "'") {
      quote = c;
      continue;
    }
    if (c === " " || c === "\t") {
      if (cur.length > 0) {
        out.push(cur);
        cur = "";
      }
      continue;
    }
    cur += c;
  }
  if (cur.length > 0) out.push(cur);
  return out;
}


// Whether a workspace's spawned agent gets a capability token at all. Passed to
// the host as `allowScript` on *every* workspace creation, which mints a
// `FRESH_CMD_TOKEN` bound to the new window — the token is always present; the
// "Teach Fresh CLI" toggle only controls whether the agent is *told* about it
// (the system-prompt injection).
//
// The grant is all-or-nothing: a script can call anything the plugin API
// exposes, so there is no narrower honest setting. What bounds an agent is the
// window its token is bound to, not a list of verbs.
const FRESH_CLI_ALLOW_SCRIPT = true;

// Contract injected on launch when "Teach Fresh CLI" is on.
// Deliberately a pointer, not a manual: it names no API at all, because the
// editor surface is thousands of lines and moves. It teaches the loop —
// read the guide, look each call up, then act — and carries only what the
// guide cannot: the sandbox escape, the queued-mutation trap, and the policy
// for working in a workspace someone is watching.
const FRESH_CLI_SYSTEM_PROMPT = [
  "You are running inside a Fresh editor workspace and can drive it \u2014 arrange panes, open files, show output, start other agents \u2014 by submitting TypeScript to the editor's plugin runtime.",
  "Always invoke the CLI through $FRESH_BIN: that variable is the exact binary running this workspace, which a `fresh` on PATH may not be.",
  "",
  "Learn before you act. Both of these are ordinary local reads \u2014 they work anywhere, including inside a sandbox, and never touch the editor:",
  "    \"$FRESH_BIN\" --skill                   the verbs, the calling convention, worked examples",
  "    \"$FRESH_BIN\" --cmd script api <query>  search this build's API by name and description",
  "Look up every call before you use it. Do not guess names or signatures, and do not read this message as an inventory \u2014 it lists no API. Prefer `script api` over opening the declaration files, which are thousands of lines and will bury your context.",
  "",
  "Only `script run` reaches the editor. If it fails saying the control socket cannot be reached, you are sandboxed rather than editor-less \u2014 the socket lives outside the workspace \u2014 so re-run that command outside your sandbox instead of concluding the editor is gone.",
  "Pipe scripts in on stdin; do not leave scratch .ts files behind in the user's repository.",
  "Mutations are queued, so a read in the same script sees the state from before them \u2014 await the mutation, or `await editor.flush()`. Inside a script FRESH_WINDOW_ID is a predefined constant naming your window, not an environment variable; prefer calls taking an explicit id over whatever happens to be focused.",
  "You are changing a workspace a human is watching: prefer reversible moves, do not close or overwrite panes you were not asked to touch, and read back what you changed before reporting success.",
].join("\n");

// Fold the contract into an agent's launch prompt, for agents with no
// append-system-prompt flag. A bare contract with no user prompt would leave
// the agent with nothing to do, so it is told to acknowledge and wait.
function combineFreshCliPrompt(contract: string, userPrompt: string): string {
  if (!userPrompt) {
    return `${contract}\n\nAcknowledge in one line, then wait for the user's request.`;
  }
  return `${contract}\n\n---\n\n${userPrompt}`;
}

// The registry entry a typed command resolves to (by argv0 basename), or null
// for a bare terminal / unknown command. Drives which agent-only controls
// (Auto mode, Start prompt) the form surfaces.
function agentEntryForCmd(cmd: string): AgentEntry | null {
  const argv = splitAgentCmd(cmd);
  if (argv.length === 0) return null;
  const base = editor.pathBasename(argv[0]) || argv[0];
  return agentEntryForBase(base);
}

// The agent (if any) the form's current command resolves to.
function activeAgentEntry(): AgentEntry | null {
  return form ? agentEntryForCmd(form.cmd.value) : null;
}

// Build the argv fragment that hands `prompt` to an agent per its prompt style.
function agentPromptArgs(spec: AgentPromptArg, prompt: string): string[] {
  return spec.style === "flag" ? [spec.flag, prompt] : [prompt];
}

// Presets for the New Session "Agent Command" dropdown: the plain shell
// (default), every registry agent (which a restart will resume), and a
// "custom…" entry that just hands focus to the free-text field so the user can
// type any command. Built from the registry so adding an agent surfaces it in
// the UI automatically. `custom` presets leave the command untouched.
interface AgentPreset {
  label: string;
  cmd: string;
  key: string;
  resumes: boolean;
  custom?: boolean;
  // The `Choose an agent…` placeholder, listed only until a choice is made.
  unset?: boolean;
}
function agentPresets(): AgentPreset[] {
  const presets: AgentPreset[] = [
    ...(form?.agentUnset
      ? [{ label: editor.t("form.agent_choose"), cmd: "", key: "agent-preset-unset", resumes: false, unset: true }]
      : []),
    { label: editor.t("form.agent_terminal"), cmd: "", key: "agent-preset-terminal", resumes: false },
  ];
  for (const e of AGENT_REGISTRY) {
    presets.push({
      label: e.label ?? e.id,
      cmd: e.id,
      key: `agent-preset-${e.id}`,
      resumes: true,
    });
  }
  presets.push({
    label: editor.t("form.agent_custom"),
    cmd: "",
    key: "agent-preset-custom",
    resumes: false,
    custom: true,
  });
  return presets;
}

// Which preset the current command text corresponds to: an exact match on a
// known agent / the empty shell, else "custom…" (covers a typed command or an
// agent with extra args). Drives the dropdown's active highlight.
function activeAgentPresetKey(): string {
  if (form?.agentUnset) return "agent-preset-unset";
  if (form?.agentCustom) return "agent-preset-custom";
  const current = form ? form.cmd.value.trim() : "";
  const match = agentPresets().find((p) => !p.custom && p.cmd === current);
  return match ? match.key : "agent-preset-custom";
}

// Apply a dropdown choice: a normal preset fills the command field; the
// "custom…" entry reveals that field and moves focus to it so the user can
// type, leaving any existing text in place.
function applyAgentPreset(p: AgentPreset): void {
  if (!form) return;
  if (p.custom) {
    form.agentCustom = true;
    // Focus must be set *after* the re-render — the field has to exist
    // before it can be focused, and re-mounting the spec resets host focus.
    renderForm();
    formPanel?.setFocusKey("cmd");
    return;
  }
  form.agentCustom = false;
  form.cmd.value = p.cmd;
  form.cmd.cursor = p.cmd.length;
  // The Text widget's content is host-authoritative; push the new value into
  // it (re-rendering the spec alone won't change an already-mounted input).
  formPanel?.setValue("cmd", form.cmd.value, form.cmd.cursor);
  renderForm();
}

// A v4-style unique id for an agent session handle. Not security-sensitive
// (it just names a conversation), so `Math.random` is fine — we never need
// unpredictability, only uniqueness within a user's session store.
function agentSessionUuid(): string {
  const hex = "0123456789abcdef";
  let s = "";
  for (let i = 0; i < 32; i++) {
    if (i === 8 || i === 12 || i === 16 || i === 20) s += "-";
    if (i === 12) {
      s += "4"; // version
    } else if (i === 16) {
      s += hex[8 + Math.floor(Math.random() * 4)]; // variant 8–b
    } else {
      s += hex[Math.floor(Math.random() * 16)];
    }
  }
  return s;
}

// Resolve a user's agent argv into the argv to *launch* and the argv to run on
// *restore* (resume), per the registry. Unknown commands (plain shells, custom
// agents) pass through unchanged with no resume — i.e. today's behaviour.
function resolveAgentLaunch(
  argv: string[],
  opts?: { auto?: boolean; prompt?: string; systemPrompt?: string },
): { launch: string[]; resume?: string[] } {
  if (argv.length === 0) return { launch: argv };
  const argv0 = argv[0];
  const base = editor.pathBasename(argv0) || argv0;
  const entry = agentEntryForBase(base);
  // Unknown command (a plain shell / custom binary): pass through untouched.
  // Auto mode and the start prompt are agent-registry features, so there's
  // nothing to inject here.
  if (!entry) return { launch: argv };

  // Auto-mode flags ride on *both* launch and resume — a resumed session
  // keeps the approval posture the user chose. Prompt is launch-only: it seeds
  // the first turn and must never be replayed when rejoining the conversation.
  const autoArgs = opts?.auto && entry.auto ? entry.auto : [];
  const prompt = (opts?.prompt ?? "").trim();
  // "Teach Fresh CLI" rides launch only — like the start prompt, it seeds the
  // first turn and must not replay on resume. Flag-style agents (claude) get
  // it behind their flag; prompt-style agents (codex/opencode) get it in front
  // of the user's first message, which is why it must stay short.
  const sysPrompt = (opts?.systemPrompt ?? "").trim();
  const sysPromptArgs = sysPrompt && entry.systemPrompt?.via === "flag"
    ? [entry.systemPrompt.flag, sysPrompt]
    : [];
  const launchPrompt = sysPrompt && entry.systemPrompt?.via === "prompt"
    ? combineFreshCliPrompt(sysPrompt, prompt)
    : prompt;
  const promptArgs = launchPrompt && entry.prompt
    ? agentPromptArgs(entry.prompt, launchPrompt)
    : [];
  // Flags first (auto + system prompt), then the (trailing) positional prompt
  // so a positional start-prompt stays last.
  const withAuto = [...argv, ...autoArgs, ...sysPromptArgs];

  if (entry.spec.provision) {
    const { idFlag, resumeArgs } = entry.spec.provision;
    // The command already names its session (an imported `claude --resume
    // <id>`, a hand-typed `--session-id`): minting another id alongside it is
    // rejected by the agent, so launch it as given and resume by the id it
    // names — or, with none (`--continue`), by the agent's continue form.
    const named = namedSession(argv, entry.spec.provision);
    if (named) {
      const resume = named.id
        ? [argv0, ...resumeArgs.map((a) => a.replace("{id}", named.id!)), ...autoArgs]
        : entry.spec.continue
        ? [argv0, ...entry.spec.continue.resumeArgs, ...autoArgs]
        : undefined;
      return { launch: [...withAuto, ...promptArgs], resume };
    }
    const id = agentSessionUuid();
    return {
      launch: [...withAuto, idFlag, id, ...promptArgs],
      resume: [argv0, ...resumeArgs.map((a) => a.replace("{id}", id)), ...autoArgs],
    };
  }
  if (entry.spec.continue) {
    return {
      launch: [...withAuto, ...promptArgs],
      resume: [argv0, ...entry.spec.continue.resumeArgs, ...autoArgs],
    };
  }
  return { launch: [...withAuto, ...promptArgs] };
}

async function spawnCollect(
  command: string,
  args: string[],
  cwd: string,
): Promise<SpawnResult> {
  return await editor.spawnProcess(command, args, cwd);
}

/// Resolve the origin's default branch as `"origin/<name>"` from
/// the locally-cached symbolic-ref. Returns `"HEAD"` when there's
/// no `origin` remote (purely-local repos) or the symbolic ref is
/// missing — the caller treats that as the silent fallback.
///
/// Deliberately does NOT fetch: `refs/remotes/origin/HEAD` is set
/// at clone time and only changes when the remote renames its
/// default branch (rare). A network round-trip per dialog open
/// is too high a cost for that case.
async function detectDefaultBranch(repoRoot: string): Promise<string> {
  return (await detectDefaultBranchWithFallback(repoRoot)).ref;
}

/// Like `detectDefaultBranch` but also reports whether we had to
/// fall back to bare `HEAD` because no `origin` is configured. The
/// caller uses that to surface a context note in the placeholder
/// ("HEAD  (no origin configured)") so the user isn't confused
/// about why their repo's default isn't being detected.
async function detectDefaultBranchWithFallback(
  repoRoot: string,
): Promise<{ ref: string; isHeadFallback: boolean }> {
  const res = await spawnCollect(
    "git",
    ["-C", repoRoot, "symbolic-ref", "refs/remotes/origin/HEAD"],
    repoRoot,
  );
  if (res.exit_code === 0) {
    const trimmed = (res.stdout || "").trim();
    const prefix = "refs/remotes/";
    if (trimmed.startsWith(prefix)) {
      // e.g. "refs/remotes/origin/main" → "origin/main". This is
      // what the new worktree is forked off, so the user sees the
      // exact ref name they'd otherwise have to type by hand.
      return { ref: trimmed.slice(prefix.length), isHeadFallback: false };
    }
  }
  return { ref: "HEAD", isHeadFallback: true };
}

/// Resolve a directory to the *main* worktree's root if it's
/// inside a git working tree. Returns `null` for non-git paths
/// so the caller can pick the no-git path explicitly.
async function resolveCanonicalRepoRoot(
  cwd: string,
): Promise<string | null> {
  const top = await spawnCollect(
    "git",
    ["rev-parse", "--show-toplevel"],
    cwd,
  );
  if (top.exit_code !== 0) return null;
  const toplevel = (top.stdout || "").trim();
  if (!toplevel) return null;
  // `--git-common-dir` returns the shared `.git` dir even when
  // we're inside a linked worktree. `dirname(...)` gives the
  // main worktree's root, which is what we want as the
  // canonical project identifier.
  const common = await spawnCollect(
    "git",
    ["rev-parse", "--path-format=absolute", "--git-common-dir"],
    toplevel,
  );
  if (common.exit_code === 0) {
    const parent = editor.pathDirname((common.stdout || "").trim());
    if (parent) return parent;
  }
  return toplevel;
}

/// Is `path` inside a git working tree? Returns `null` on any
/// error so the caller can keep its UI in a "in-flight / unknown"
/// state rather than flipping to a wrong answer.
async function pathIsInsideGitWorkTree(
  path: string,
): Promise<boolean | null> {
  if (!path) return null;
  const res = await spawnCollect(
    "git",
    ["-C", path, "rev-parse", "--is-inside-work-tree"],
    path,
  );
  if (res.exit_code !== 0) return false; // non-zero = not a repo
  return (res.stdout || "").trim() === "true";
}

// =============================================================================
// Worktree classification & discovery
//
// Two distinct git facts drive the "attach to an existing worktree"
// flows:
//
//   * `classifyWorktree(path)` answers "is this path a *linked*
//     worktree, and if so what repo does it belong to?" — used by
//     the new-session form to attach (rather than fork) when the
//     user points Project Path at an existing worktree.
//   * `listLinkedWorktrees(repoRoot)` enumerates every linked
//     worktree of a repo (via `git worktree list --porcelain`) —
//     used to surface on-disk worktrees in the Open dialog without
//     the user adding them by hand.
// =============================================================================

interface WorktreeInfo {
  // `git rev-parse --show-toplevel` for the path.
  toplevel: string;
  // Canonical main-worktree root (dirname of `--git-common-dir`).
  // This is the repo the worktree belongs to, used as the
  // session's `projectPath` so attached worktrees group under
  // their repo in the picker.
  mainRoot: string;
  // `true` when the path is a *linked* worktree (its per-worktree
  // git dir differs from the shared common dir), i.e. a tree
  // created by `git worktree add` rather than the main checkout.
  isLinked: boolean;
  // Branch checked out there (`refs/heads/<name>` short form), or
  // empty when detached.
  branch: string;
}

/// Classify `path` as a git worktree. Returns `null` when `path`
/// is not inside any git work tree (the caller then treats it as a
/// plain directory / shared root).
async function classifyWorktree(path: string): Promise<WorktreeInfo | null> {
  if (!path) return null;
  const top = await spawnCollect("git", ["-C", path, "rev-parse", "--show-toplevel"], path);
  if (top.exit_code !== 0) return null;
  const toplevel = (top.stdout || "").trim();
  if (!toplevel) return null;

  // The per-worktree git dir vs. the shared common dir: they are
  // equal for the main worktree and differ for every linked
  // worktree (`<common>/worktrees/<id>`). That difference is the
  // canonical "is this a linked worktree?" test.
  const [gitDir, commonDir] = await Promise.all([
    spawnCollect("git", ["-C", toplevel, "rev-parse", "--path-format=absolute", "--git-dir"], toplevel),
    spawnCollect(
      "git",
      ["-C", toplevel, "rev-parse", "--path-format=absolute", "--git-common-dir"],
      toplevel,
    ),
  ]);
  const gd = gitDir.exit_code === 0 ? (gitDir.stdout || "").trim() : "";
  const cd = commonDir.exit_code === 0 ? (commonDir.stdout || "").trim() : "";
  const isLinked = gd !== "" && cd !== "" && gd !== cd;
  const mainRoot = cd ? editor.pathDirname(cd) : toplevel;

  const head = await spawnCollect(
    "git",
    ["-C", toplevel, "rev-parse", "--abbrev-ref", "HEAD"],
    toplevel,
  );
  let branch = head.exit_code === 0 ? (head.stdout || "").trim() : "";
  if (branch === "HEAD") branch = ""; // detached

  return { toplevel, mainRoot, isLinked, branch };
}

interface ParsedWorktree {
  path: string;
  branch: string;
  detached: boolean;
}

/// Parse `git worktree list --porcelain` output. Blocks are
/// separated by blank lines; the first block is the main worktree,
/// the rest are linked. Each block has a `worktree <path>` line
/// plus `branch refs/heads/<name>` or `detached`.
function parseWorktreePorcelain(stdout: string): ParsedWorktree[] {
  const out: ParsedWorktree[] = [];
  let cur: ParsedWorktree | null = null;
  for (const raw of (stdout || "").split(/\r?\n/)) {
    const line = raw.trimEnd();
    if (line.startsWith("worktree ")) {
      if (cur) out.push(cur);
      cur = { path: line.slice("worktree ".length), branch: "", detached: false };
    } else if (cur && line.startsWith("branch ")) {
      const ref = line.slice("branch ".length);
      cur.branch = ref.replace(/^refs\/heads\//, "");
    } else if (cur && line === "detached") {
      cur.detached = true;
    } else if (line === "" && cur) {
      out.push(cur);
      cur = null;
    }
  }
  if (cur) out.push(cur);
  return out;
}

/// Enumerate the *linked* worktrees of `repoRoot` (excludes the
/// main worktree, which is the repo's own checkout). Returns the
/// parsed entries with the main-repo root resolved so callers can
/// tag discovered sessions with the right `projectPath`.
async function listLinkedWorktrees(
  repoRoot: string,
): Promise<{ mainRoot: string; worktrees: ParsedWorktree[] } | null> {
  const res = await spawnCollect(
    "git",
    ["-C", repoRoot, "worktree", "list", "--porcelain"],
    repoRoot,
  );
  if (res.exit_code !== 0) return null;
  const all = parseWorktreePorcelain(res.stdout || "");
  if (all.length === 0) return null;
  // The first entry is always the main worktree.
  const mainRoot = all[0].path;
  const worktrees = all.slice(1);
  return { mainRoot, worktrees };
}

/// Slugify a project basename into a git-ref-safe, label-friendly stem
/// for auto session names. git refs forbid spaces, `~^:?*[\` etc., so
/// collapse anything outside `[A-Za-z0-9._-]` to a dash; the name
/// doubles as the worktree branch.
function sessionNameBaseFor(repoRoot: string): string {
  const raw = editor.pathBasename(repoRoot) || "";
  const slug = raw.replace(/[^A-Za-z0-9._-]+/g, "-").replace(/^-+|-+$/g, "");
  return slug.length > 0 ? slug : "session";
}

// Advance the persisted counter past `name` when it is one of this project's
// `<base>-N` auto-names. Idempotent and monotonic: a name the user typed, or
// one from another project, leaves the counter alone, and a re-submit of the
// same name cannot walk it backwards.
function claimAutoSessionName(name: string): void {
  // **Only a name this counter issued.** The counter is global across
  // projects, so a *typed* name that merely ends in digits — `release-2026`,
  // a ticket number, a date — would drive every later auto-name in every
  // project past it. The caller establishes provenance by passing the name
  // only when it is the one the form generated; all this does is advance the
  // counter past its number, monotonically, so a re-submit cannot walk it
  // backwards.
  const m = /-(\d+)$/.exec(name);
  if (!m) return;
  const n = parseInt(m[1], 10);
  const cur = (editor.getGlobalState("orchestrator.session_counter") as number | undefined) ?? 0;
  if (n > cur) editor.setGlobalState("orchestrator.session_counter", n);
}

async function nextAutoSessionName(
  repoRoot: string,
  options?: { persist?: boolean },
): Promise<string> {
  // Root the auto-name in the project (`<project>-1`, `<project>-2`, …)
  // rather than a bare `session-N`, so a dock row tells you which
  // project the session belongs to (F6). The name also seeds the
  // worktree branch.
  //
  // Persisted counter so consecutive empty submits keep incrementing
  // even across plugin reloads. But the counter alone isn't
  // sufficient: a previous run may have left a branch / worktree behind
  // (orchestrator's archive / external git delete / interrupted
  // submit), so `<project>-${counter+1}` can collide and
  // `git worktree add` would fail with the noisy "already used by
  // worktree at …" message. Probe the local git refs once and
  // increment past any reserved `<project>-N` name before returning.
  //
  // `persist: false` (the default) computes the name without
  // advancing the persisted counter — for placeholder previews
  // that happen on every Project Path keystroke. The submit
  // path passes `persist: true` so consecutive submissions
  // increment normally.
  const persist = options?.persist === true;
  const base = sessionNameBaseFor(repoRoot);
  const counterBefore = (editor.getGlobalState("orchestrator.session_counter") as
    | number
    | undefined) ?? 0;
  let next = counterBefore + 1;

  // Collect existing branch names that look like `<project>-N` so we
  // can skip past them. `git for-each-ref` is faster and tighter
  // than parsing `git worktree list` output. `.` is the only
  // regex-special char the slug can contain, so escape it.
  const refs = await spawnCollect(
    "git",
    ["-C", repoRoot, "for-each-ref", "--format=%(refname:short)", "refs/heads/"],
    repoRoot,
  );
  const taken = new Set<number>();
  if (refs.exit_code === 0) {
    const re = new RegExp(`^${base.replace(/[.]/g, "\\.")}-(\\d+)$`);
    for (const line of (refs.stdout || "").split(/\r?\n/)) {
      const m = re.exec(line.trim());
      if (m) {
        taken.add(parseInt(m[1], 10));
      }
    }
  }
  while (taken.has(next)) {
    next += 1;
  }
  if (persist) {
    editor.setGlobalState("orchestrator.session_counter", next);
  }
  return `${base}-${next}`;
}

// Subtitle splits the static prefix "Project:" from the project
// path so each gets its own foreground — matching the three-tier
// (label / label-value / input) palette the design calls for.
const SUBTITLE_LABEL_STYLE = { fg: "ui.menu_disabled_fg" } as const;
const SUBTITLE_VALUE_STYLE = { fg: "ui.help_key_fg", bold: true } as const;

// The first input of a backend's body — where the form lands focus on open.
function firstBodyFieldKey(backend: FormBackend): string {
  switch (backend) {
    case "local":
    case "devcontainer":
      return "project_path";
    case "ssh":
      return "ssh_path";
    case "kubernetes":
      return "k8s_workspace";
  }
}

// The key of the one Project Path field, whichever backend it roots.
function pathFieldKey(backend: FormBackend): string {
  switch (backend) {
    case "local":
    case "devcontainer":
      return "project_path";
    case "ssh":
      return "ssh_path";
    case "kubernetes":
      return "k8s_workspace";
  }
}

// =============================================================================
// Machines — Fresh's own registry of hosts to run workspaces on (design §5).
//
// The registry is Fresh state in the platform data dir; `~/.ssh/config` is
// read for the host picker and never written, so a host saved here is a Fresh
// machine and a host there is an ssh host. A machine is tested before it is
// saved and the result is reported beside the fields that caused it — an
// error naming neither the cause nor the field is what this dialog avoids.
// =============================================================================

type MachineKind = "ssh" | "kubernetes";

// The outcome of the last `Test connection`, kept with the machine.
interface MachineTest {
  ok: boolean;
  at: number;
  summary: string;
}

interface Machine {
  id: string;
  name: string;
  kind: MachineKind;
  // ssh: `[user@]host[:port]`, an identity file, extra ssh arguments.
  target: string;
  identity: string;
  options: string;
  // kubernetes: kubeconfig context, namespace, a pod name or `-l` selector.
  context: string;
  namespace: string;
  pod: string;
  // Where a workspace on this machine is rooted unless the form says otherwise.
  path: string;
  lastTest: MachineTest | null;
}

type Field = { value: string; cursor: number };

// Machines live one JSON file per machine under
// `<data dir>/orchestrator/machines/<id>.json`, not in a single registry file.
//
// **Why a directory.** This is editor-wide state, so every concurrent `fresh`
// writes it, and a single file made each of those writes a whole-registry
// rewrite built from a snapshot the process had read earlier. Two sessions
// adding different machines lost one of them; worse, a connection test
// finishing in one session rewrote every machine from a list that could be
// minutes old. With a file per machine a write touches only the machine it is
// about, so those two sessions no longer collide at all. It also bounds the
// damage of a bad write to one machine rather than the registry, and makes
// delete an `unlink` instead of a rewrite-everything-minus-one.
//
// It is the shape the rest of the editor already uses, for the same reason —
// see `DirectoryContext::project_state_dir`: "Using a directory per project —
// rather than one shared file — keeps concurrent `fresh` processes on
// different projects from contending over a single file."
// The state namespace machines live in. The editor owns the on-disk layout;
// this names entries, not files.
const MACHINES_NS = "machines";

// Marks the one-time import out of `machinesDir()`. It shares the namespace
// with the machines themselves and its shape passes `isSafeMachineId`, so
// `loadMachines` skips it by name rather than relying on `parseMachine`
// happening to reject the value.
const MACHINES_IMPORTED_KEY = "_imported";

// Where machines lived before the state store. Read once, by
// `importLegacyMachines`, and never written again.
function machinesDir(): string {
  return editor.pathJoin(editor.getDataDir(), "orchestrator", "machines");
}

// An id is a path segment, so it has to be one that cannot escape the
// directory or collide with the temp files `writeMachineFile` makes.
// `newMachineId` only ever produces `m-<base36>-<base36>`; this is the guard
// that keeps a hand-edited or future id from being load-bearing on the
// filesystem.
function isSafeMachineId(id: string): boolean {
  return /^[A-Za-z0-9._-]{1,64}$/.test(id) && !id.startsWith(".");
}

let machinesCache: Machine[] | null = null;

// Forget the in-memory copy so the next read comes off disk.
//
// The cache exists because `loadMachines` is called from render paths. It is
// dropped at the two moments another session's change could matter to this
// one: opening the Machines dialog, and opening the New Workspace form. That
// is deliberately not live-watching — a machine added elsewhere while one of
// those is already on screen still will not appear until it is reopened — but
// neither is ever opened showing a list this session cached earlier.
function invalidateMachines(): void {
  machinesCache = null;
}

function parseMachine(raw: string): Machine | null {
  try {
    const x = JSON.parse(raw) as Partial<Machine>;
    if (typeof x.id !== "string" || typeof x.name !== "string") return null;
    if (x.kind !== "ssh" && x.kind !== "kubernetes") return null;
    return {
      id: x.id,
      name: x.name,
      kind: x.kind,
      target: x.target ?? "",
      identity: x.identity ?? "",
      options: x.options ?? "",
      context: x.context ?? "",
      namespace: x.namespace ?? "",
      pod: x.pod ?? "",
      path: x.path ?? "",
      lastTest: x.lastTest ?? null,
    };
  } catch {
    return null;
  }
}

// Every saved machine, by name. A file that will not parse is skipped rather
// than fatal, and now costs only itself: the single-file version had to throw
// the whole registry away to stay usable.
function loadMachines(): Machine[] {
  if (machinesCache) return machinesCache;
  importLegacyMachines();
  const out: Machine[] = [];
  for (const id of editor.stateKeys(MACHINES_NS)) {
    if (id === MACHINES_IMPORTED_KEY) continue;
    if (!isSafeMachineId(id)) continue;
    const raw = editor.stateGet(MACHINES_NS, id);
    if (!raw) continue;
    const m = parseMachine(raw);
    // The key is the id, so an entry whose contents disagree is not one this
    // code wrote; ignore it rather than serve two identities.
    if (m && isSafeMachineId(m.id) && m.id === id) out.push(m);
  }
  out.sort((a, b) => a.name.localeCompare(b.name));
  machinesCache = out;
  return out;
}

// Copy machines written by the version that kept its own directory into the
// editor's state store, once.
//
// The marker is what makes it once: the old files stay where they are, because
// a plugin can no longer delete a path it names, and without the marker a
// machine the user deleted after the import would come back on the next load.
// The leftovers are inert — nothing reads that directory any more — and a user
// who wants the disk space back can remove it themselves.
function importLegacyMachines(): void {
  if (editor.stateGet(MACHINES_NS, MACHINES_IMPORTED_KEY)) return;
  for (const e of editor.readDir(editor.localPath(machinesDir()))) {
    if (!e.is_file || !e.name.endsWith(".json") || e.name.startsWith(".")) continue;
    const raw = editor.readFile(editor.localPath(editor.pathJoin(machinesDir(), e.name)));
    if (!raw) continue;
    const m = parseMachine(raw);
    if (m && isSafeMachineId(m.id) && `${m.id}.json` === e.name) {
      editor.stateSet(MACHINES_NS, m.id, raw);
    }
  }
  editor.stateSet(MACHINES_NS, MACHINES_IMPORTED_KEY, "1");
}

// Write one machine.
//
// The editor's state store owns the file: it writes a temp alongside and
// renames, so a reader sees either the old machine or the new one and never a
// half-written file. This used to do that dance here, which meant holding
// `renamePath` — a general "move any path onto any other path" primitive —
// for the sake of one atomic write.
function writeMachineFile(m: Machine): boolean {
  if (!isSafeMachineId(m.id)) return false;
  return editor.stateSet(MACHINES_NS, m.id, JSON.stringify(m, null, 2));
}

function machineById(id: string): Machine | null {
  return loadMachines().find((m) => m.id === id) ?? null;
}

// Add or replace one machine. Unlike the registry-rewriting version this
// replaced, it neither reads nor rewrites anybody else's machine, so a
// concurrent session editing a different one cannot be clobbered.
function upsertMachine(m: Machine): void {
  writeMachineFile(m);
  invalidateMachines();
}

function removeMachine(id: string): void {
  if (!isSafeMachineId(id)) return;
  editor.stateDelete(MACHINES_NS, id);
  invalidateMachines();
}

function newMachineId(): string {
  return `m-${Date.now().toString(36)}-${Math.floor(Math.random() * 1e6).toString(36)}`;
}

// The short identity a row shows beside the name: where ssh connects, or
// which pods kubectl execs into.
function machineSummary(m: Machine): string {
  if (m.kind === "ssh") return m.target;
  const where = `${m.namespace || "?"} / ${m.pod || "?"}`;
  return m.context ? `${where}  (${m.context})` : where;
}

function machineKindTag(m: Machine): string {
  return m.kind === "ssh" ? "ssh" : "k8s";
}

function machineWorkspaceCount(m: Machine): number {
  let n = 0;
  for (const s of orchestratorSessions.values()) {
    if (s.discovered || !s.remote) continue;
    if (m.kind === "ssh" && s.remote.kind === "ssh") {
      const bare = m.target.replace(/^ssh:\/\//, "").replace(/:\d+$/, "");
      if (s.remote.detail === bare || s.remote.detail === m.target) n++;
    } else if (m.kind === "kubernetes" && s.remote.kind === "kubernetes") {
      if (s.remote.detail === `${m.namespace}/${m.pod}`) n++;
    }
  }
  return n;
}

// `[user@]host[:port]` (or a pasted `ssh://…`) → the part ssh takes as the
// destination and the port for `-p`.
//
// **An IPv6 literal is all colons, so the port cannot be "after the colon".**
// A greedy `(.+):(\d+)$` reads `::1` as host `:` port `1`, and `2001:db8::1`
// as host `2001:db8:` port `1` — then reports "could not resolve hostname :",
// which points the user at the wrong field. A port therefore only counts when
// what precedes it is bracketed, or contains no colon at all.
function parseSshTarget(t: string): { dest: string; port: string | null } {
  const raw = t.trim().replace(/^ssh:\/\//, "").replace(/\/.*$/, "");
  const at = raw.lastIndexOf("@");
  const user = at >= 0 ? raw.slice(0, at + 1) : "";
  const host = at >= 0 ? raw.slice(at + 1) : raw;

  const bracketed = /^\[([^\]]*)\](?::(\d+))?$/.exec(host);
  if (bracketed) {
    return { dest: `${user}[${bracketed[1]}]`, port: bracketed[2] ?? null };
  }
  const m = /^([^:]*):(\d+)$/.exec(host);
  return m ? { dest: user + m[1], port: m[2] } : { dest: raw, port: null };
}

// A leading `~` is the user's, not the shell's: nothing in this plugin runs
// through a shell — `spawnCollect` and `readDir` exec and syscall directly —
// so a typed `~/src/repo` reaches `git -C` and `readDir` as a literal tilde
// and simply fails. Bare `~` counts as well as `~/`.
function expandHome(p: string): string {
  if (p === "~") return homeDir() || p;
  if (!p.startsWith("~/")) return p;
  const home = homeDir();
  return home ? `${home}/${p.slice(2)}` : p;
}

// Quote one argument for a POSIX remote shell. **ssh runs its command
// through the remote `sh`**, unlike `spawnHostProcess`, which execs — so a
// path with a space, a quote or a `$` is the remote shell's to mis-split
// unless it arrives quoted.
function shQuote(s: string): string {
  return `'${s.replace(/'/g, "'\\''")}'`;
}

// The ssh argv for a form's current connection, up to and including the
// destination: what a remote command is appended to. `BatchMode` so a host
// that wants a password fails instead of hanging on a prompt no dialog can
// answer, and a connect timeout so an unreachable one does not wedge the
// form.
//
// **A machine saved from a `~/.ssh/config` host keeps the alias as its
// target**, so ssh still matches the `Host` block and applies every directive
// in it (`IdentityFile`, `ProxyJump`, …), not just the three the Machines
// dialog shows. The probe, the worktree and the session all reach the host by
// this one route and cannot disagree about how.
function formSshArgv(f: NewSessionForm, connectTimeout: number): string[] | null {
  return f.machineId ? machineKeySshArgv(f.machineId, connectTimeout) : null;
}

interface RemoteGitProbe {
  // `null` when the host could not be reached or the answer was not
  // usable — distinct from `false`, which is a host that answered and is
  // not a repository.
  isGit: boolean | null;
  repoRoot: string;
  defaultBranch: string;
  error: string;
}

// **One round trip, not four.** The local form asks git four separate
// questions per path settle (inside-work-tree, toplevel, default branch,
// next session name), which is cheap against a local filesystem and four
// ssh connections against a remote one. This asks once and parses the
// lines; a host that is slow, down or wants a password costs one timeout
// rather than four.
async function probeRemoteGit(argv: string[], path: string): Promise<RemoteGitProbe> {
  const empty = { isGit: null as boolean | null, repoRoot: "", defaultBranch: "", error: "" };
  const dir = path.trim();
  if (!dir) return empty;
  // **The remote always exits 0, so a non-zero status is ssh's own.** `ssh`
  // passes the remote command's exit status through, which makes "the path is
  // not a repository" and "the host could not be reached" the same number —
  // and the form has to tell them apart, because they send the user to fix
  // different things. Reading them apart from stderr was a regex over ssh's
  // prose; swallowing the remote's failures instead makes the status itself
  // unambiguous: non-zero is the transport, and the answer is on stdout.
  //
  // A path that does not exist reads as "not a repository", which is what it
  // is from here. `symbolic-ref` is allowed to fail (a detached HEAD has no
  // branch name) without costing the rest.
  const remote = [
    // `~/…` expands on the far side (a quoted `~` would not).
    `cd ${remoteShellPath(dir)} 2>/dev/null || exit 0`,
    "root=$(git rev-parse --show-toplevel 2>/dev/null) || exit 0",
    'printf "%s\\n" "$root"',
    "git symbolic-ref --short HEAD 2>/dev/null || true",
  ].join("; ");
  const r = await editor.spawnHostProcess("ssh", [...argv, remote]);
  if (r.exit_code !== 0) {
    const err = (r.stderr || "").split(/\r?\n/).map((l) => l.trim()).filter(Boolean).pop() || "";
    return { ...empty, error: err || editor.t("err.connection_failed") };
  }
  const lines = (r.stdout || "").split(/\r?\n/);
  const repoRoot = (lines[0] || "").trim();
  if (!repoRoot) return { ...empty, isGit: false };
  return { isGit: true, repoRoot, defaultBranch: (lines[1] || "").trim(), error: "" };
}

// Create the worktree on the remote host and answer with the absolute path
// it landed at.
//
// **The remote resolves its own `$HOME`.** The local flow puts a worktree
// under the editor's data dir; there is no editor on the far side, so this
// mirrors the convention at `~/.fresh/worktrees/<repo>/<name>` and lets the
// remote shell expand it — this side does not know the remote's home, and a
// guess would be a path that silently works for one user and not another.
//
// Idempotent for the same reason the local one is: a worktree left behind by
// an interrupted attempt is reused rather than re-added, since `git worktree
// add` onto an existing directory fails and would error the row on retry.
async function createRemoteWorktree(
  plan: RemoteWorktreePlan,
): Promise<{ ok: true; root: string } | { ok: false; error: string }> {
  // `"$REPO"` and `"$ROOT"` are the remote shell's own variables, so they go
  // in already quoted for *that* shell rather than through `shQuote`, which
  // would quote them as literal text. Everything that came from this side is
  // quoted; the only bare tokens are the ones the remote owns.
  //
  // **Both refs empty is a real case, not a degenerate one.** The form only
  // renders `Checkout branch` and `New branch name` once the remote has said
  // it is a repository, so a create against a host that never answered — the
  // one the "unreachable" row deliberately still allows — carries neither.
  // That leaves bare `git worktree add "$ROOT"`, and git then cuts a branch
  // named for the worktree directory, which is `plan.name`: the workspace the
  // user just named. Letting git's own default stand is what makes the
  // unreachable path work at all; inventing a ref here would be this side
  // guessing at a repository it could not reach.
  const add = [
    "git", "-C", '"$REPO"', "worktree", "add", '"$ROOT"',
    ...(plan.newBranch ? ["-b", shQuote(plan.newBranch)] : []),
    ...(plan.base ? [shQuote(plan.base)] : []),
  ].join(" ");
  const remote = [
    `cd ${remoteShellPath(plan.path)} || exit 1`,
    "REPO=$(git rev-parse --show-toplevel) || exit 1",
    `ROOT="$HOME"/.fresh/worktrees/"$(basename "$REPO")"/${shQuote(plan.name)}`,
    `if [ ! -d "$ROOT" ]; then mkdir -p "$(dirname "$ROOT")" && ${add} >&2 || exit 1; fi`,
    'printf "%s\\n" "$ROOT"',
  ].join("; ");
  const r = await editor.spawnHostProcess("ssh", [...plan.ssh, remote]);
  const root = (r.stdout || "").split(/\r?\n/).map((l) => l.trim()).filter(Boolean).pop() || "";
  if (r.exit_code !== 0 || !root) {
    const err = (r.stderr || "").split(/\r?\n/).map((l) => l.trim()).filter(Boolean).pop() ||
      editor.t("err.remote_worktree_failed");
    return { ok: false, error: err };
  }
  return { ok: true, root };
}

// The ssh argv for a captured spec — the same shape `formSshArgv` builds, but
// from the transport, so a retry or a row restored after a restart does not
// need the form that made it. `null` for a transport that is not ssh.
function specSshArgv(spec: RemoteAgentSpec, connectTimeout: number): string[] | null {
  const t = spec.transport;
  if (t.kind !== "ssh") return null;
  const host = t.host?.trim() ?? "";
  if (!host) return null;
  return [
    "-o", "BatchMode=yes",
    "-o", `ConnectTimeout=${connectTimeout}`,
    ...(t.port ? ["-p", String(t.port)] : []),
    ...(t.identity_file ? ["-i", expandHome(t.identity_file)] : []),
    ...(t.extra_args ?? []),
    "--",
    t.user ? `${t.user}@${host}` : host,
  ];
}

// === Host-key trust (trust on first use) ====================================
//
// ssh refuses a host key it has never seen, and every ssh call the
// orchestrator makes runs under `BatchMode=yes` — a carrier with piped stdio
// and a probe behind a dialog both have nowhere to put an interactive prompt.
// So a host the user has never connected to fails with a bare
// `Host key verification failed.` and no way forward inside the editor: the
// remedy is a shell, which is exactly what a workspace dialog exists to save
// the user. Every other ssh client answers this with a yes/no prompt showing
// the key's fingerprint. This is that prompt.
//
// **Accepting re-runs ssh rather than writing `known_hosts` here.** Which file
// the line belongs in is the user's config to decide (`UserKnownHostsFile`,
// possibly several, possibly hashed by `HashKnownHosts`), and reimplementing
// that lookup would be a second answer to a question ssh already answers.
// `StrictHostKeyChecking=accept-new` on one throwaway connection makes ssh
// record it, in the right file, in the right form.

// A scan is a direct TCP dial; it should not outlive the form's own probe.
const HOSTKEY_SCAN_TIMEOUT_S = 6;

// True when `err` is ssh refusing to continue because it does not trust the
// host key. Deliberately the one error the trust flow triggers on: a broad
// `Err(_)` retry would re-run creates that failed for reasons a fingerprint
// dialog cannot fix.
function isHostKeyFailure(err: string): boolean {
  return /host key verification failed/i.test(err);
}

// What ssh itself resolves for a destination (`ssh -G`), lowercased keyword →
// value. Read instead of re-parsing `~/.ssh/config` because the file's real
// grammar — `Match`, `Include`, canonicalisation, system-wide defaults, the
// first-value-wins rule across all of them — is ssh's to interpret; the
// plugin's own parser reads only enough to list aliases.
async function sshEffectiveConfig(argv: string[]): Promise<Map<string, string>> {
  const out = new Map<string, string>();
  const r = await editor.spawnHostProcess("ssh", ["-G", ...argv]);
  if (r.exit_code !== 0) return out;
  for (const line of (r.stdout || "").split(/\r?\n/)) {
    const i = line.indexOf(" ");
    if (i <= 0) continue;
    const key = line.slice(0, i).toLowerCase();
    if (!out.has(key)) out.set(key, line.slice(i + 1).trim());
  }
  return out;
}

// The fingerprints of the keys a host presents, as `ssh-keygen -l` renders
// them (`256 SHA256:… (ED25519)`).
//
// Empty is a legitimate answer, not a failure: `ssh-keyscan` dials the address
// directly, so a host reached through `ProxyJump` / `ProxyCommand` has no
// fingerprint to show from here. The dialog says so rather than inventing one.
async function scanHostKeyFingerprints(host: string, port: string): Promise<string[]> {
  if (!host) return [];
  const scan = await editor.spawnHostProcess("ssh-keyscan", [
    "-T", String(HOSTKEY_SCAN_TIMEOUT_S),
    ...(port ? ["-p", port] : []),
    "--", host,
  ]);
  const keys = (scan.stdout || "")
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l && !l.startsWith("#"));
  if (keys.length === 0) return [];
  // `ssh-keygen -l` reads a *file*, and `spawnHostProcess` execs rather than
  // running a shell, so there is no pipe to hand it — the scan goes through a
  // staging directory the editor hands out and takes back.
  const token = editor.scratchCreate("hostkey");
  if (!token) return [];
  const dir = editor.scratchPath(token);
  if (!dir) return [];
  const tmp = editor.pathJoin(dir, "keys");
  if (!editor.writeFile(editor.localPath(tmp), `${keys.join("\n")}\n`)) {
    editor.scratchDiscard(token);
    return [];
  }
  const fp = await editor.spawnHostProcess("ssh-keygen", ["-l", "-f", tmp]);
  editor.scratchDiscard(token);
  if (fp.exit_code !== 0) return [];
  return (fp.stdout || "")
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean)
    .map(trimFingerprintComment);
}

// `ssh-keygen -l` prints `<bits> <fingerprint> <comment> (<TYPE>)`, and for a
// scanned key the comment is the address — which the dialog already states on
// its own line. Drop it so the line the user has to *compare* is the
// fingerprint and nothing else. Anything that does not match the shape is
// left exactly as ssh-keygen wrote it.
function trimFingerprintComment(line: string): string {
  const m = /^(\S+\s+\S+)\s+.*\s(\([^()]*\))$/.exec(line);
  return m ? `${m[1]} ${m[2]}` : line;
}

// Everything the trust dialog states about the host being trusted.
interface HostKeyOffer {
  // The destination as the user named it (an alias, or `user@host`).
  target: string;
  // Where ssh will actually connect, from `ssh -G`.
  where: string;
  // `ssh-keygen -l` lines; empty when the key could not be read from here.
  fingerprints: string[];
  // The `known_hosts` the accept will write to, for the consequence line.
  knownHosts: string;
}

// Gather what the dialog needs to show. Two cheap host processes, run only on
// the failure path — nothing here happens on a host that is already trusted.
async function hostKeyOffer(argv: string[], target: string): Promise<HostKeyOffer> {
  const cfg = await sshEffectiveConfig(argv);
  const host = cfg.get("hostname") ?? "";
  const port = cfg.get("port") ?? "";
  // `UserKnownHostsFile` may name several files; ssh writes the first.
  const knownHosts = (cfg.get("userknownhostsfile") ?? "").split(/\s+/)[0] ?? "";
  return {
    target,
    where: host ? (port && port !== "22" ? `${host} port ${port}` : host) : target,
    fingerprints: await scanHostKeyFingerprints(host, port),
    knownHosts,
  };
}

// Put the fingerprint in front of the user and, if they accept, make ssh
// record the key. Resolves `true` once the host is trusted.
async function offerHostKeyTrust(argv: string[], target: string): Promise<boolean> {
  const offer = await hostKeyOffer(argv, target);
  if (!(await askHostKeyTrust(offer))) return false;
  // The exit status is not the answer: host-key verification happens before
  // authentication, so a host that records its key and *then* rejects our
  // credentials has still been trusted — and the caller's real command is
  // about to report that authentication failure in its own words.
  await editor.spawnHostProcess("ssh", [
    "-o", "StrictHostKeyChecking=accept-new",
    ...argv,
    "true",
  ]);
  return true;
}

// The dialog itself: a centered, dimmed modal over whatever asked for it.
// Cancel sits first — the safe option in the first position, as the delete
// confirmation does — and Esc / click-outside is Cancel too.
const HOSTKEY_MODE = "orchestrator-hostkey";
let hostKeyPanel: FloatingWidgetPanel | null = null;
let hostKeyState: { offer: HostKeyOffer; settle: (trust: boolean) => void } | null = null;

function buildHostKeySpec(offer: HostKeyOffer): WidgetSpec {
  const dim = { fg: "ui.menu_disabled_fg" };
  const parts: WidgetSpec[] = [
    label(editor.t("hostkey.headline", { host: offer.target }), { wrap: true }),
    spacer(0),
    label([
      { text: `  ${editor.t("hostkey.field_where")}  `, style: dim },
      { text: offer.where, style: { bold: true } },
    ]),
  ];
  if (offer.fingerprints.length > 0) {
    for (const fp of offer.fingerprints) {
      parts.push(label([
        { text: `  ${editor.t("hostkey.field_key")}    `, style: dim },
        { text: fp, style: { bold: true } },
      ], { elide: "tail" }));
    }
  } else {
    parts.push(label(`  ${editor.t("hostkey.no_fingerprint")}`, {
      style: { ...dim, italic: true },
      wrap: true,
    }));
  }
  parts.push(
    spacer(0),
    label(
      offer.knownHosts
        ? editor.t("hostkey.records_in", { file: offer.knownHosts })
        : editor.t("hostkey.records"),
      { style: dim, wrap: true },
    ),
    label(editor.t("hostkey.warning"), {
      style: { fg: "diagnostic.error_fg" },
      wrap: true,
    }),
    spacer(0),
    endRow(
      withAccel(button(editor.t("hostkey.btn_cancel"), { key: "hostkey-cancel" }), "Esc"),
      spacer(2),
      button(editor.t("hostkey.btn_trust"), { intent: "primary", key: "hostkey-trust" }),
    ),
  );
  return col(...parts);
}

// Resolve the pending ask exactly once and tear the panel down. `unmount`
// is skipped when the host already did it (an Esc / click-outside `cancel`).
function settleHostKey(trust: boolean, unmount: boolean): void {
  const st = hostKeyState;
  if (unmount && hostKeyPanel) hostKeyPanel.unmount();
  hostKeyPanel = null;
  hostKeyState = null;
  if (st) st.settle(trust);
}

function askHostKeyTrust(offer: HostKeyOffer): Promise<boolean> {
  // A second ask while one is open would strand the first promise; remote
  // creates are serialised (`pumpRemoteQueue`), so this is belt-and-braces.
  if (hostKeyState) settleHostKey(false, true);
  return new Promise<boolean>((resolve) => {
    hostKeyState = { offer, settle: resolve };
    hostKeyPanel = new FloatingWidgetPanel();
    hostKeyPanel.mount(buildHostKeySpec(offer), {
      widthPct: 64,
      heightPct: 40,
      focusMarker: true,
      title: editor.t("hostkey.title"),
      closable: true,
      mode: HOSTKEY_MODE,
    });
    editor.floatingPanelControl(hostKeyPanel.id(), "fullscreen", 1);
    // The safe option holds the keyboard, so Enter never trusts by reflex.
    hostKeyPanel.setFocusKey("hostkey-cancel");
  });
}

editor.defineMode(HOSTKEY_MODE, [], true, true);

function handleHostKeyEvent(e: WidgetEvt): void {
  if (e.event_type === "cancel") {
    settleHostKey(false, false);
    return;
  }
  if (e.event_type !== "activate") return;
  if (e.widget_key === "hostkey-trust") settleHostKey(true, true);
  else if (e.widget_key === "hostkey-cancel") settleHostKey(false, true);
}

// The directory every remote worktree the orchestrator makes lives under, as
// `createRemoteWorktree` writes it (`$HOME/.fresh/worktrees/<repo>/<name>`).
// The `$HOME` prefix is the remote's, so only the tail is matched.
const REMOTE_WORKTREE_MARKER = "/.fresh/worktrees/";

// Is this session a worktree *we* cut on a remote host — as opposed to a
// remote directory the user pointed a session at with the worktree toggle off?
//
// The distinction is the whole safety of the teardown below: the first is ours
// to remove, the second is the user's actual project and must never be touched.
// A local session answers this with `projectPath !== root`, which a remote one
// cannot — the host records no separate project for it — so the two facts that
// *are* checkable at delete time stand in, and both must hold: the path is
// under Fresh's own `~/.fresh/worktrees/`, and git says it is a *linked*
// worktree rather than a main checkout. Neither alone is enough; together they
// match only what `createRemoteWorktree` made.
function looksLikeOurRemoteWorktree(s: AgentSession): boolean {
  return s.remote?.kind === "ssh" && s.root.includes(REMOTE_WORKTREE_MARKER);
}

// Can the removal actually reach the host *right now*?
//
// **This is a safety check, not an optimisation.** The removal routes through
// the active authority, and `setActiveWindow` on a dormant remote session
// installs an empty local shell and starts the connect *afterwards*
// (`PluginCommand::SetActiveWindow`), so a spawn issued straight after the
// switch races that connect and is served by the LOCAL spawner instead. It
// would then run `git worktree remove --force` against a remote absolute path
// on this machine — a no-op if nothing is there, and a deletion of the user's
// files if anything is. Only a session the host already reports as connected
// is safe to act on; everything else is left alone and said out loud.
function remoteWorktreeReachable(s: AgentSession): boolean {
  // **Asked of the host, not of our own facet.** `s.remote.state` is a display
  // badge: a freshly created session keeps the `"starting"` its create stamped
  // on it and nothing promotes it, so testing it here refused the live
  // sessions this is meant to allow. `WindowInfo.remote.connected` is the
  // host's own answer and is recomputed every time it is asked.
  return editor.listWindows().find((w) => w.id === s.id)?.remote?.connected === true;
}

// Remove a remote worktree over the session's **own** connection.
//
// **This runs while the session's window is still active, and that is the
// point.** `spawnProcess` routes through the active authority, so with the
// remote window in front the `git` below executes on the far side with no ssh
// argv to rebuild — the plugin never sees a live session's transport
// (`WindowInfo.remote` carries a display identity, not an identity file), and
// reconstructing one would be guessing. It is the exact inverse of
// `createRemoteWorktree`, which also ran on the far side.
//
// `git -C <worktree> worktree remove <worktree>` is deliberate: a worktree can
// remove itself through its own common dir, so the repository root — which
// this side does not know — is never needed.
//
// Answers `null` on success, or the reason it could not, which the caller
// reports *without* failing the delete: a host that is down must not leave the
// user unable to drop the row.
async function removeRemoteWorktree(s: AgentSession): Promise<string | null> {
  const linked = await spawnCollect(
    "git",
    ["-C", s.root, "rev-parse", "--path-format=absolute", "--git-dir", "--git-common-dir"],
    s.root,
  );
  const lines = (linked.stdout || "").split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  if (linked.exit_code !== 0 || lines.length < 2) {
    return lastNonEmptyLine(linked.stderr) || editor.t("err.remote_worktree_remove_failed");
  }
  // A main checkout has `--git-dir` === `--git-common-dir`; only a linked
  // worktree has its own. Refusing here is what keeps a user's project safe if
  // the path check above ever matched something it should not.
  if (lines[0] === lines[1]) return editor.t("err.remote_not_linked_worktree");
  const rm = await spawnCollect(
    "git",
    // `--force` for the same reason the local path uses it: the confirm step
    // is where the user chose to discard whatever is uncommitted.
    ["-C", s.root, "worktree", "remove", "--force", s.root],
    s.root,
  );
  if (rm.exit_code !== 0) {
    return lastNonEmptyLine(rm.stderr) || editor.t("err.remote_worktree_remove_failed");
  }
  return null;
}

// Why an ssh test failed, said beside the field that caused it.
function sshFailureHint(err: string): string {
  if (/permission denied/i.test(err)) return editor.t("machine.hint_denied");
  if (/could not resolve|name or service not known|nodename nor servname/i.test(err)) {
    return editor.t("machine.hint_resolve");
  }
  if (/connection refused|timed out|no route to host|network is unreachable/i.test(err)) {
    return editor.t("machine.hint_unreachable");
  }
  if (/host key verification failed/i.test(err)) return editor.t("machine.hint_hostkey");
  return "";
}

interface MachineTestResult {
  ok: boolean;
  summary: string;
  detail: string;
}

// Try the connection the machine describes, without touching the editor's
// authority: ssh in batch mode (no prompts, a short timeout) and read what
// the box is; kubectl lists the pods the selector matches.
async function testMachine(m: Machine): Promise<MachineTestResult> {
  if (m.kind === "ssh") {
    const { dest, port } = parseSshTarget(m.target);
    if (!dest) return { ok: false, summary: editor.t("machine.err_target"), detail: "" };
    const args = [
      "-o", "BatchMode=yes",
      "-o", "ConnectTimeout=8",
      ...(port ? ["-p", port] : []),
      ...(m.identity.trim() ? ["-i", expandHome(m.identity.trim())] : []),
      ...(m.options.trim() ? m.options.trim().split(/\s+/) : []),
      "--",
      dest,
      "uname -sr; git --version 2>/dev/null; nproc 2>/dev/null",
    ];
    const r = await editor.spawnHostProcess("ssh", args);
    if (r.exit_code === 0) {
      const lines = r.stdout.split("\n").map((l) => l.trim()).filter(Boolean);
      const os = lines[0] ?? "";
      const git = (lines[1] ?? "").replace(/^git version /, "git ");
      const cores = lines[2] ? editor.t("machine.cores", { n: lines[2] }) : "";
      return { ok: true, summary: [os, git, cores].filter(Boolean).join(" · "), detail: "" };
    }
    const err = r.stderr
      .split("\n")
      .map((l) => l.trim())
      .filter((l) => l && !/^warning:/i.test(l))
      .pop() ?? editor.t("machine.err_exit", { code: String(r.exit_code) });
    // `ssh: connect to host X port N: Connection refused` → the reason; the
    // target is on the field above and the hint below says what to check.
    const summary = err
      .replace(/^ssh: /, "")
      .replace(/^[^ :]+@[^ :]+: /, "")
      .replace(/^connect to host \S+ port \d+: /, "")
      .replace(/\.$/, "");
    return { ok: false, summary, detail: sshFailureHint(err) };
  }
  if (!m.namespace.trim() || !m.pod.trim()) {
    return { ok: false, summary: editor.t("machine.err_ns_pod"), detail: "" };
  }
  const pod = m.pod.trim();
  // `--` before the operand, as the ssh probe above does before its
  // destination. Without it a pod field beginning with a hyphen is read by
  // kubectl as one of its own flags — `--kubeconfig=…` names a different
  // cluster, `--as` a different identity — and the registry this comes from
  // is a plain JSON file that the form, the CLI verbs and a text editor all
  // write. `-l` stays a selector because the field documents it as one.
  const selector = pod.startsWith("-l");
  const args = [
    ...(m.context.trim() ? ["--context", m.context.trim()] : []),
    "-n", m.namespace.trim(),
    "get", "pods",
    ...(selector ? ["-l", pod.slice(2).trim()] : []),
    "-o", "name",
    // As for ssh: a test against an unreachable cluster has to come back
    // with a failure, not sit on `… testing` with nothing to cancel.
    "--request-timeout=8s",
    ...(selector ? [] : ["--", pod]),
  ];
  const r = await editor.spawnHostProcess("kubectl", args);
  if (r.exit_code === 0) {
    const n = r.stdout.split("\n").filter((l) => l.trim()).length;
    if (n === 0) return { ok: false, summary: editor.t("machine.err_no_pods"), detail: "" };
    return { ok: true, summary: editor.t("machine.pods_match", { n: String(n) }), detail: "" };
  }
  const err = r.stderr.split("\n").map((l) => l.trim()).filter(Boolean).pop() ??
    editor.t("machine.err_exit", { code: String(r.exit_code) });
  return { ok: false, summary: err.replace(/^error: /i, ""), detail: "" };
}

// Cut by display width, never by code units: a resolved target can be CJK
// or emoji, and the machines table's columns have to hold.
function clipToWidth(s: string, cols: number): string {
  if (cols <= 0) return "";
  if (editor.stringWidth(s) <= cols) return s;
  let out = "";
  for (const ch of s) {
    if (editor.stringWidth(out + ch) > cols) break;
    out += ch;
  }
  return out;
}

// How long ago, for the Machines rows: `2m ago`, `3h ago`, `5d ago`.
function agoText(at: number): string {
  const s = Math.max(0, Math.floor((Date.now() - at) / 1000));
  if (s < 60) return editor.t("machine.ago_now");
  if (s < 3600) return editor.t("machine.ago", { t: `${Math.floor(s / 60)}m` });
  if (s < 86400) return editor.t("machine.ago", { t: `${Math.floor(s / 3600)}h` });
  return editor.t("machine.ago", { t: `${Math.floor(s / 86400)}d` });
}

function applyTextChange(slot: Field, payload: unknown): void {
  const p = (payload ?? {}) as Record<string, unknown>;
  if (typeof p.value === "string") slot.value = p.value;
  if (typeof p.cursorByte === "number") slot.cursor = p.cursorByte;
}

function fieldOf(value: string): Field {
  return { value, cursor: utf8Len(value) };
}

// =============================================================================
// Repositories — what a workspace works on, apart from where it runs.
//
// A repository is a remote plus, per machine, the **main clone** new worktrees
// are cut from. It lives in the editor's state store next to machines, one
// entry per repository, for the same reason machines do (see `MACHINES_NS`).
// Nothing here searches a machine for clones: a main clone is only ever a path
// the user typed or browsed to, and Fresh checks that path and no other.
// =============================================================================

interface Repository {
  id: string;
  name: string;
  // The clone URL. Empty for a local-only repository, which can be pointed at
  // but never cloned.
  remote: string;
  // Where a new main clone goes when one is made; `<name>` is the repository's
  // name.
  cloneNewTo: string;
  // Machine key (see `machineOptionKey`) → that machine's main clone.
  clones: Record<string, string>;
  // A plain folder rather than a git repository: no remote, no worktrees —
  // a workspace opens in the folder itself. Absent means git.
  kind?: "folder";
}

const REPOS_NS = "repositories";
const DEFAULT_CLONE_NEW_TO = "~/src/<name>";

let reposCache: Repository[] | null = null;

function invalidateRepositories(): void {
  reposCache = null;
}

function parseRepository(raw: string): Repository | null {
  try {
    const x = JSON.parse(raw) as Partial<Repository>;
    if (typeof x.id !== "string" || typeof x.name !== "string") return null;
    const clones: Record<string, string> = {};
    for (const [k, v] of Object.entries(x.clones ?? {})) {
      if (typeof v === "string" && v) clones[k] = v;
    }
    return {
      id: x.id,
      name: x.name,
      remote: typeof x.remote === "string" ? x.remote : "",
      cloneNewTo: typeof x.cloneNewTo === "string" && x.cloneNewTo ? x.cloneNewTo : DEFAULT_CLONE_NEW_TO,
      clones,
      ...(x.kind === "folder" ? { kind: "folder" as const } : {}),
    };
  } catch {
    return null;
  }
}

function loadRepositories(): Repository[] {
  if (reposCache) return reposCache;
  const out: Repository[] = [];
  for (const id of editor.stateKeys(REPOS_NS)) {
    if (!isSafeMachineId(id)) continue;
    const raw = editor.stateGet(REPOS_NS, id);
    const r = raw ? parseRepository(raw) : null;
    if (r && r.id === id) out.push(r);
  }
  out.sort((a, b) => a.name.localeCompare(b.name));
  reposCache = out;
  return out;
}

function repoById(id: string | null): Repository | null {
  if (!id) return null;
  return loadRepositories().find((r) => r.id === id) ?? null;
}

function upsertRepository(r: Repository): void {
  if (!isSafeMachineId(r.id)) return;
  editor.stateSet(REPOS_NS, r.id, JSON.stringify(r, null, 2));
  invalidateRepositories();
}

function removeRepository(id: string): void {
  if (!isSafeMachineId(id)) return;
  editor.stateDelete(REPOS_NS, id);
  invalidateRepositories();
}

function newRepoId(): string {
  return `r-${Date.now().toString(36)}-${Math.floor(Math.random() * 1e6).toString(36)}`;
}

// The path a new main clone of `r` goes to.
function repoCloneTarget(r: Repository): string {
  return r.cloneNewTo.replace(/<name>/g, r.name);
}

// `git@github.com:sinelaw/fresh.git` → `fresh`.
function repoNameFromRemote(url: string): string {
  const tail = url.trim().replace(/\/+$/, "").split(/[/:]/).pop() ?? "";
  return tail.replace(/\.git$/, "");
}

// `github.com/sinelaw/fresh` for any of the ways one remote is spelled (ssh,
// https, with or without `.git`), so two spellings compare equal.
function remoteIdentity(url: string): string {
  let s = url.trim().toLowerCase();
  s = s.replace(/^[a-z+]+:\/\//, "").replace(/^[^@/]+@/, "");
  s = s.replace(/^([^/:]+):(?!\d+\/)/, "$1/");
  s = s.replace(/^([^/:]+):\d+\//, "$1/");
  return s.replace(/\.git$/, "").replace(/\/+$/, "");
}

function sameRemote(a: string, b: string): boolean {
  return !!a.trim() && !!b.trim() && remoteIdentity(a) === remoteIdentity(b);
}

// The remote as a row shows it: `github.com/sinelaw/fresh`, or `local only`.
function repoRemoteLabel(r: Repository): string {
  if (r.remote) return remoteIdentity(r.remote);
  // Nothing to clone from, so where it is says what it is: the path on this
  // machine, or `machine:path` elsewhere.
  const at = cloneMachineKeys()
    .filter((k) => r.clones[k])
    .map((k) => (k === "local" ? tildePath(expandHome(r.clones[k])) : `${machineKeyLabel(k)}:${r.clones[k]}`));
  if (at.length) return at.join(" · ");
  return r.kind === "folder" ? editor.t("repo.plain_folder") : editor.t("repo.local_only");
}

// A machine's key in `Repository.clones`: Local or a saved machine. The
// devcontainer has no clone of its own.
function machineOptionKey(o: MachineOption | undefined): string | null {
  if (!o) return null;
  return o.kind === "local" || o.kind === "machine" ? o.key : null;
}

function machineKeyLabel(key: string): string {
  if (key === "local") return editor.t("machine.local");
  return machineById(key)?.name ?? key;
}

// Every machine a main clone can live on, in the Machine control's order.
function cloneMachineKeys(): string[] {
  return ["local", ...loadMachines().map((m) => m.id)];
}

// A remote path for a remote shell: `~/x` stays expandable there (quoting the
// tilde would make it literal), everything else is quoted.
function remoteShellPath(p: string): string {
  if (p === "~") return '"$HOME"';
  if (p.startsWith("~/")) return `"$HOME"/${shQuote(p.slice(2))}`;
  return shQuote(p);
}

// How a main-clone path checks out. Only the path given is looked at.
interface ClonePathCheck {
  state: "ok" | "missing" | "wrong_remote" | "not_git" | "unreachable" | "empty";
  branch: string;
  dirty: boolean;
  origin: string;
  error: string;
  // The clone's top folder, when the path is inside one.
  top?: string;
}

// Ask one machine about one path: does it exist, is it a repository, what is
// its origin and branch. Local runs git directly; a remote asks once over ssh.
async function checkClonePath(
  machineKey: string,
  path: string,
  remote: string,
): Promise<ClonePathCheck> {
  const none: ClonePathCheck = { state: "empty", branch: "", dirty: false, origin: "", error: "" };
  const p = path.trim();
  if (!p) return none;
  const script = [
    `cd ${machineKey === "local" ? shQuote(expandHome(p)) : remoteShellPath(p)} 2>/dev/null || { echo MISSING; exit 0; }`,
    "git rev-parse --show-toplevel >/dev/null 2>&1 || { echo NOTGIT; exit 0; }",
    "echo GIT",
    "git remote get-url origin 2>/dev/null || echo",
    "git symbolic-ref --short HEAD 2>/dev/null || echo",
    "git rev-parse --show-toplevel 2>/dev/null || echo",
    "git status --porcelain 2>/dev/null | head -1",
  ].join("; ");
  let r: SpawnResult;
  if (machineKey === "local") {
    r = await editor.spawnHostProcess("sh", ["-c", script]);
  } else {
    const argv = machineKeySshArgv(machineKey, REMOTE_PROBE_TIMEOUT_S);
    if (!argv) return { ...none, state: "unreachable", error: editor.t("repo.err_no_ssh") };
    r = await editor.spawnHostProcess("ssh", [...argv, script]);
  }
  if (r.exit_code !== 0) {
    const err = (r.stderr || "").split(/\r?\n/).map((l) => l.trim()).filter(Boolean).pop() || "";
    return { ...none, state: "unreachable", error: err || editor.t("err.connection_failed") };
  }
  const lines = (r.stdout || "").split(/\r?\n/);
  if (lines[0] === "MISSING") return { ...none, state: "missing" };
  if (lines[0] === "NOTGIT") return { ...none, state: "not_git" };
  const origin = (lines[1] || "").trim();
  const out: ClonePathCheck = {
    state: "ok",
    branch: (lines[2] || "").trim(),
    top: (lines[3] || "").trim(),
    dirty: !!(lines[4] || "").trim(),
    origin,
    error: "",
  };
  if (remote && !sameRemote(remote, origin)) out.state = "wrong_remote";
  return out;
}

// The ssh argv for a saved ssh machine's key.
function machineKeySshArgv(key: string, timeout: number): string[] | null {
  const base = ["-o", "BatchMode=yes", "-o", `ConnectTimeout=${timeout}`];
  const m = machineById(key);
  if (!m || m.kind !== "ssh") return null;
  const { dest, port } = parseSshTarget(m.target);
  if (!dest) return null;
  return [
    ...base,
    ...(port ? ["-p", port] : []),
    ...(m.identity.trim() ? ["-i", expandHome(m.identity.trim())] : []),
    ...(m.options.trim() ? m.options.trim().split(/\s+/) : []),
    "--",
    dest,
  ];
}

// `git clone <remote> <path>` on a machine. The handle is kept by the caller
// so Cancel can kill it; a partial directory is removed on failure.
function startClone(machineKey: string, remote: string, path: string): ProcessHandle<SpawnResult> | null {
  if (machineKey === "local") {
    return editor.spawnHostProcess("git", ["clone", "--quiet", remote, expandHome(path)]);
  }
  const argv = machineKeySshArgv(machineKey, REMOTE_CREATE_TIMEOUT_S);
  if (!argv) return null;
  return editor.spawnHostProcess("ssh", [
    ...argv,
    `git clone --quiet ${shQuote(remote)} ${remoteShellPath(path)}`,
  ]);
}

// Remove what an interrupted clone left behind — only a directory that is
// not a finished repository, so a clone that raced to completion is kept.
async function cleanupPartialClone(machineKey: string, path: string): Promise<void> {
  const q = machineKey === "local" ? shQuote(expandHome(path)) : remoteShellPath(path);
  const script = `[ -d ${q} ] && ! git -C ${q} rev-parse HEAD >/dev/null 2>&1 && rm -rf ${q}; exit 0`;
  if (machineKey === "local") {
    await editor.spawnHostProcess("sh", ["-c", script]);
    return;
  }
  const argv = machineKeySshArgv(machineKey, REMOTE_PROBE_TIMEOUT_S);
  if (argv) await editor.spawnHostProcess("ssh", [...argv, script]);
}

// The last line a failed git or ssh wrote, as the reason to show.
function lastErrorLine(r: SpawnResult): string {
  return (r.stderr || r.stdout || "").split(/\r?\n/).map((l) => l.trim()).filter(Boolean).pop() || "";
}

// ── The form's Project control ───────────────────────────────────────────────

// Project dropdown entries: every repository, then `Folder…` and
// `Manage repositories…`.
function projectOptionLabels(): string[] {
  return [
    ...loadRepositories().map((r) => r.name),
    editor.t("form.project_folder"),
    editor.t("form.project_manage"),
  ];
}

function projectPickIndex(f: NewSessionForm): number {
  const repos = loadRepositories();
  const i = f.repoId ? repos.findIndex((r) => r.id === f.repoId) : -1;
  return i >= 0 ? i : repos.length;
}

function formRepo(f: NewSessionForm): Repository | null {
  return repoById(f.repoId);
}

function formMachineKey(f: NewSessionForm): string | null {
  return machineOptionKey(machineOptions()[f.machinePick]);
}

// The main clone the form's (repository, machine) resolves to; "" when that
// machine has none yet.
function formMainClone(f: NewSessionForm): string {
  const r = formRepo(f);
  const key = formMachineKey(f);
  return r && key ? r.clones[key] ?? "" : "";
}

// A project is picked but this machine doesn't know where it is yet: Launch
// asks (§4.17) — clone it, or name the folder it's already in.
function formNeedsPlace(f: NewSessionForm): boolean {
  return !!formRepo(f) && !!formMachineKey(f) && !formMainClone(f);
}

// What stops a project launch outright: a machine typed by hand, which has
// no identity to remember a folder under.
function formRepoBlocker(f: NewSessionForm): string {
  const r = formRepo(f);
  if (!r) return "";
  if (!formMachineKey(f)) return editor.t("form.repo_needs_saved_machine");
  return "";
}

// Point the backend's path slot at the repository's main clone on the chosen
// machine (or where a new one would go), and re-ask the probes about it. The
// slot is what the create reads, so a repository launch goes through exactly
// the folder path below it.
function syncRepoPath(): void {
  if (!form) return;
  const r = formRepo(form);
  if (!r) return;
  const p = formMainClone(form) || cloneTarget(r, formMachineKey(form) ?? "local");
  const slot = { value: p, cursor: p.length };
  if (form.backend === "ssh") {
    form.sshPath = slot;
    scheduleRemoteReprobe();
  } else if (form.backend === "kubernetes") {
    form.k8sWorkspace = slot;
  } else {
    form.projectPath = slot;
    scheduleProjectPathReprobe();
  }
}

// Leaving a repository for `Folder…`: the path slots go back to their
// defaults so the folder field starts where a plain launch would.
function clearRepoPath(): void {
  if (!form) return;
  form.projectPath = { value: "", cursor: 0 };
  form.sshPath = { value: "", cursor: 0 };
  form.k8sWorkspace = { value: "", cursor: 0 };
  formPanel?.setValue(pathFieldKey(form.backend), "", 0);
  scheduleProjectPathReprobe();
  scheduleRemoteReprobe();
}

// The folder's relation to a known repository, from its origin (local folders
// only; the probe reads `origin` alongside the git checks).
function folderKnownRepo(f: NewSessionForm): Repository | null {
  if (f.repoId || !f.folderOrigin) return null;
  return loadRepositories().find((r) => sameRemote(r.remote, f.folderOrigin)) ?? null;
}

// The folder as the create will read it.
function formFolderPath(f: NewSessionForm): string {
  return expandHome(f.projectPath.value.trim() || f.defaultProjectPath || localProjectDefault());
}

// --- Add / Edit Machine (§5.3) ----------------------------------------------

interface MachineDialogState {
  id: string | null;
  kind: MachineKind;
  // Seeded from a `~/.ssh/config` host that is not saved: the form sets it
  // up as a machine, so it reads "Set up" and saves with "Add".
  fromHost: boolean;
  // The hosts `~/.ssh/config` names: a Host that is one of them shows what
  // it resolves to.
  hosts: SshConfigHost[];
  // The last test before this form opened; a test run here replaces it.
  lastTest: MachineTest | null;
  // Remove… was pressed and waits for a yes.
  confirmRemove: boolean;
  // What the machine reached when the form opened (host or pod): while it
  // stays, the machine keeps its name.
  origReach: string;
  // Identity file: typed, or picked with Browse… beside it — the shared path
  // picker, on this computer (ssh reads the key locally), picking a file.
  identityPicker: PathPicker;
  name: Field;
  target: Field;
  identity: Field;
  options: Field;
  context: Field;
  namespace: Field;
  pod: Field;
  path: Field;
  test: { state: "idle" | "running" | "ok" | "fail"; summary: string; detail: string };
  // Which test's answer is still wanted: an edit after a test started makes
  // its result stale.
  testToken: number;
  error: string;
  returnTo: MachineDialogReturn;
  // The machine Save wrote, for a dialog that goes back to a picker.
  savedKey?: string;
  // Where a `"discover"` return goes: the Import sessions dialog, handed the
  // machine saved (null after a cancel).
  onDone?: (savedKey: string | null) => void;
}

// Where the Add / Edit Machine dialog goes when it closes: the list or picker
// that opened it.
type MachineDialogReturn = "machines" | "form" | "repos" | "discover" | null;

const MACHINE_DIALOG_MODE = "orchestrator-machine-dialog";
let machineDialog: MachineDialogState | null = null;
let machinePanel: FloatingWidgetPanel | null = null;
const MACHINE_DIALOG_WIDTH_PCT = 60;

/** Open Add Machine (`existing` null) or Edit Machine. `fromHost` seeds it
 *  from a `~/.ssh/config` entry; `template` from a machine known only by its
 *  address, such as the host of an open window. */
function openMachineDialog(
  existing: Machine | null,
  returnTo: MachineDialogReturn,
  fromHost?: SshConfigHost,
  template?: Partial<Machine>,
  onDone?: (savedKey: string | null) => void,
): void {
  const m = existing ?? (template ? { ...blankMachine(), ...template } : null);
  const d: MachineDialogState = {
    id: existing?.id ?? null,
    kind: m?.kind ?? "ssh",
    fromHost: !!fromHost,
    hosts: sshConfigHosts(),
    lastTest: existing?.lastTest ?? (fromHost ? sshHostTests.get(fromHost.alias) ?? null : null),
    confirmRemove: false,
    name: fieldOf(m?.name ?? fromHost?.alias ?? ""),
    origReach: m ? (m.kind === "ssh" ? (sshTargetParts(m.target).host || m.target) : m.pod) : "",
    identityPicker: new PathPicker({
      source: browseSource,
      key: "machine-identity",
      browseKey: "machine-identity-browse",
      listKey: "machine-browse-list",
      label: splitLabel("form.ssh_identity_label").label,
      labelWidth: FORM_LABEL_W,
      value: () => d.identity,
      // From the typed file's folder, or `~/.ssh`.
      start: (typed) => ({ machineKey: "local", dir: typed ? parentDir(typed) : "~/.ssh", files: true }),
      onPick: (path) => {
        d.identity = fieldOf(tildePath(path));
      },
      // What sits beside the keys in `~/.ssh` but is not one: the public
      // halves, and ssh's own files. Listed, but dimmed.
      dim: (name) => name.endsWith(".pub") || SSH_DIR_NON_KEYS.has(name),
      hint: (value) => (value.endsWith(".pub") ? editor.t("machine.identity_pub_hint") : null),
      render: () => {
        if (machineDialog === d) renderMachineDialog();
      },
      panel: () => (machineDialog === d ? machinePanel : null),
    }),
    target: fieldOf(m?.target ?? fromHost?.alias ?? ""),
    identity: fieldOf(m?.identity ?? ""),
    options: fieldOf(m?.options ?? ""),
    context: fieldOf(m?.context ?? ""),
    namespace: fieldOf(m?.namespace ?? ""),
    pod: fieldOf(m?.pod ?? ""),
    path: fieldOf(m?.path ?? ""),
    test: { state: "idle", summary: "", detail: "" },
    testToken: 0,
    error: "",
    returnTo,
    onDone,
  };
  machineDialog = d;
  machinePanel = new FloatingWidgetPanel();
  machinePanel.mount(buildMachineDialogSpec(), {
    widthPct: MACHINE_DIALOG_WIDTH_PCT,
    heightPct: 70,
    focusMarker: true,
    labelAlign: "right",
    title: existing
      ? editor.t("machine.form_title", { name: existing.name })
      : fromHost
      ? editor.t("machine.setup_title", { name: fromHost.alias })
      : editor.t("machine.add_title"),
    closable: true,
    mode: MACHINE_DIALOG_MODE,
  });
  editor.floatingPanelControl(machinePanel.id(), "fullscreen", 1);
  // Straight to what the machine reaches. For a new ssh machine the Host
  // field is a combo box of the config hosts, closed until asked: typing,
  // ↓ / Alt+↓, or its arrow opens it (`completion_request`) — a list that
  // opened on focus would cover the fields under it as the form is walked.
  const first = machineDialog.kind === "ssh" ? "machine-target" : "machine-context";
  machinePanel.setFocusKey(first);
}

/** Files `~/.ssh` holds that are not a private key. */
const SSH_DIR_NON_KEYS = new Set(["known_hosts", "known_hosts.old", "config", "authorized_keys", "environment"]);

function blankMachine(): Machine {
  return {
    id: "",
    name: "",
    kind: "ssh",
    target: "",
    identity: "",
    options: "",
    context: "",
    namespace: "",
    pod: "",
    path: "",
    lastTest: null,
  };
}

function closeMachineDialog(reopen: boolean): void {
  const returnTo = machineDialog?.returnTo ?? null;
  const savedKey = machineDialog?.savedKey ?? null;
  const onDone = machineDialog?.onDone;
  if (machinePanel) {
    machinePanel.unmount();
    machinePanel = null;
  }
  machineDialog = null;
  if (reopen && returnTo === "machines") {
    openMachinesDialog();
    return;
  }
  if (reopen && returnTo === "repos") {
    resumeRepoDialogAfterMachine(savedKey);
    return;
  }
  if (reopen && returnTo === "discover" && onDone) {
    onDone(savedKey);
    return;
  }
  if (reopen && returnTo === "form") {
    // Back to the New Workspace form, on the machine just saved (or on
    // whatever it was on, after a cancel) — the form as it was, when it was
    // set aside rather than closed.
    if (resumeSuspendedForm()) return;
    // A rejoin whose machine had to be added first, then was not: opening
    // the form anyway would put the session on whatever machine was last
    // used. Nothing is launched.
    if (savedKey === null && pendingFormPrefill) {
      pendingFormPrefill = null;
      return;
    }
    dockBlurred = true;
    openForm({ fromPicker: true });
    return;
  }
}

// A machine is named by what it reaches: the ssh host (a config alias as
// written, else the host of `user@host:port`), or the pod. An existing
// machine keeps the name it has while that stays the same.
function machineDialogName(d: MachineDialogState): string {
  const reach = d.kind === "ssh"
    ? (sshTargetParts(d.target.value.trim()).host || d.target.value.trim())
    : d.pod.value.trim();
  if (d.id !== null && d.name.value.trim() && reach === d.origReach) return d.name.value.trim();
  return reach;
}

function machineFromDialog(d: MachineDialogState): Machine {
  return {
    id: d.id ?? newMachineId(),
    name: machineDialogName(d),
    kind: d.kind,
    target: d.target.value.trim(),
    identity: d.identity.value.trim(),
    options: d.options.value.trim(),
    context: d.context.value.trim(),
    namespace: d.namespace.value.trim(),
    pod: d.pod.value.trim(),
    path: d.path.value.trim(),
    lastTest: d.test.state === "ok" || d.test.state === "fail"
      ? { ok: d.test.state === "ok", at: Date.now(), summary: d.test.summary }
      : d.lastTest,
  };
}

// One machine, as a plain form: right-aligned labels, the editable fields,
// what is known about it (what a config name resolves to, the last test)
// in the same column without brackets, and the buttons in one footer.
function buildMachineDialogSpec(): WidgetSpec {
  const d = machineDialog!;
  const isNew = d.id === null;
  const children: WidgetSpec[] = [spacer(0)];
  // Only a new machine picks its kind; an existing one or a config host is
  // what it is.
  if (isNew && !d.fromHost) {
    children.push(
      radio([editor.t("backend.ssh"), editor.t("backend.kubernetes")], {
        selectedIndex: d.kind === "ssh" ? 0 : 1,
        label: editor.t("machine.kind"),
        labelWidth: FORM_LABEL_W,
        key: "machine-kind",
      }),
      spacer(0),
    );
  }
  if (d.kind === "ssh") {
    children.push(
      ...field(formLabel("machine.host"), d.target, {
        key: "machine-target",
        // A new SSH machine's Host offers the `~/.ssh/config` hosts not yet
        // added (`suggestMachineHosts`): say so with the combo arrow.
        combo: d.id === null && unaddedSshHosts().length > 0,
      }),
    );
    const h = d.hosts.find((x) => x.alias === d.target.value.trim());
    if (h) children.push(machineFact("machine.resolves_to", [{ text: sshResolvedTarget(h) }]));
    // The key file: typed, or picked with the shared browser beside it. The
    // field fills what the row leaves beside the button — the host sizes it
    // from the width it is laid out at.
    children.push(
      ...d.identityPicker.rows(),
      ...field(splitLabel("form.ssh_options_label").label, d.options, { key: "machine-options" }),
    );
  } else {
    children.push(
      ...field(splitLabel("form.k8s_context_label").label, d.context, { key: "machine-context" }),
      ...field(formLabel("form.k8s_namespace_label"), d.namespace, { key: "machine-namespace" }),
      ...field(formLabel("form.k8s_pod_label"), d.pod, {
        key: "machine-pod",
        note: editor.t("machine.pod_note"),
      }),
    );
  }
  children.push(
    ...field(editor.t("machine.path"), d.path, { key: "machine-path" }),
    machineFact("machine.last_test", machineTestSegments(d)),
    fieldColumnRow(withAccel(button(editor.t("machine.btn_test"), { key: "machine-test" }), "^T")),
  );
  if (d.test.state === "fail" && d.test.detail) {
    children.push(label(d.test.detail, { labelWidth: FORM_LABEL_W, style: NOTE_STYLE, wrap: true }));
  }
  if (d.error) {
    children.push(label(`✗ ${d.error}`, {
      labelWidth: FORM_LABEL_W,
      style: { fg: "diagnostic.error_fg", bold: true },
    }));
  }
  children.push(spacer(0), footerRule(), spacer(0));
  if (d.confirmRemove) {
    children.push(
      label(`  ⚠ ${editor.t("machine.remove_confirm", { name: d.name.value.trim() })}`, {
        style: WARN_STYLE,
        wrap: true,
      }),
      endRow(
        button(editor.t("form.btn_cancel_short"), { key: "machine-remove-no" }),
        spacer(3),
        button(editor.t("machine.btn_remove"), { intent: "danger", key: "machine-remove-yes" }),
        spacer(2),
      ),
    );
    return col(...children);
  }
  const save = button(editor.t(d.fromHost ? "machine.btn_add" : "machine.btn_save"), {
    intent: "primary",
    key: "machine-save",
  });
  // Remove on the left, away from Save; Cancel and Save on the right.
  children.push(row(
    spacer(2),
    ...(isNew ? [] : [button(editor.t("machine.btn_remove_more"), { intent: "danger", key: "machine-remove" })]),
    flexSpacer(),
    withAccel(button(editor.t("form.btn_cancel_short"), { key: "machine-cancel" }), "Esc"),
    spacer(3),
    withAccel(save, "^⏎"),
    spacer(2),
  ));
  return col(...children);
}

// A read-only row in the form's label column: `Label: value`, no brackets.
// The value is one column in, where a field's text starts after its `[`.
function machineFact(key: string, value: StyledSegment[]): WidgetSpec {
  return label([{ text: `${formLabel(key).padStart(FORM_LABEL_W)}:  ` }, ...value]);
}

// The last test: one running now, the answer it gave, or the one before.
function machineTestSegments(d: MachineDialogState): StyledSegment[] {
  if (d.test.state === "running") {
    return [{ text: editor.t("machine.testing"), style: NOTE_STYLE }];
  }
  if (d.test.state === "ok") return [{ text: `✓ ${editor.t("machine.connected")} · ${d.test.summary}`, style: { fg: "ui.help_key_fg" } }];
  if (d.test.state === "fail") return [{ text: `✗ ${d.test.summary}`, style: { fg: "diagnostic.error_fg" } }];
  const t = d.lastTest;
  if (!t) return [{ text: editor.t("machine.never_tested"), style: NOTE_STYLE }];
  const when = agoText(t.at);
  return t.ok
    ? [{ text: `✓ ${editor.t("machine.connected")} · ${t.summary} · ${when}`, style: { fg: "ui.help_key_fg" } }]
    : [{ text: `✗ ${t.summary} · ${when}`, style: { fg: "diagnostic.error_fg" } }];
}

function renderMachineDialog(): void {
  if (machinePanel && machineDialog) machinePanel.update(buildMachineDialogSpec());
}

function runMachineTest(): void {
  const d = machineDialog;
  if (!d) return;
  d.error = "";
  d.test = { state: "running", summary: "", detail: "" };
  const token = ++d.testToken;
  renderMachineDialog();
  void testMachine(machineFromDialog(d)).then((r) => {
    if (machineDialog !== d || d.testToken !== token) return;
    d.test = { state: r.ok ? "ok" : "fail", summary: r.summary, detail: r.detail };
    renderMachineDialog();
  });
}

function saveMachineDialog(): void {
  const d = machineDialog;
  if (!d) return;
  const m = machineFromDialog(d);
  d.error = m.kind === "ssh" && !parseSshTarget(m.target).dest
    ? editor.t("machine.err_target")
    : m.kind === "kubernetes" && (!m.namespace || !m.pod)
    ? editor.t("machine.err_ns_pod")
    : "";
  if (d.error) {
    renderMachineDialog();
    return;
  }
  // An existing machine keeps its last test when this session did not run one.
  if (!m.lastTest && d.id) m.lastTest = machineById(d.id)?.lastTest ?? null;
  upsertMachine(m);
  d.savedKey = m.id;
  if (d.returnTo === "form") pendingFormMachine = { kind: "option", key: m.id };
  closeMachineDialog(true);
}

const MACHINE_DIALOG_MODE_BINDINGS: string[][] = [
  ["Enter", "orchestrator_machine_enter"],
  ["C-Enter", "orchestrator_machine_save", "shortcut"],
  ["C-t", "orchestrator_machine_test"],
  // In the identity file's browser: Esc closes it (not the dialog), ⌫ goes
  // up a folder — what its hint says.
  ["Escape", "orchestrator_machine_browse_close", "on:machine-browse-list"],
  ["Backspace", "orchestrator_machine_browse_up", "on:machine-browse-list"],
];
editor.defineMode(MACHINE_DIALOG_MODE, MACHINE_DIALOG_MODE_BINDINGS, true, true);

registerHandler("orchestrator_machine_browse_close", () => {
  machineDialog?.identityPicker.close();
});
registerHandler("orchestrator_machine_browse_up", () => {
  if (machineDialog && machinePanel) machineDialog.identityPicker.up(machinePanel.focusKey());
});

// Enter that no control used: a text field's — including the Host field's
// after its suggestion list, not stepped into, closed itself. It saves.
// Buttons, the file browser's list and a highlighted suggestion answer
// their own Enter before this binding is asked.
registerHandler("orchestrator_machine_enter", () => {
  if (!machineDialog || !machinePanel) return;
  if (machinePanel.focusKey() === "machine-kind") return;
  if (machineDialog.confirmRemove) return;
  saveMachineDialog();
});
registerHandler("orchestrator_machine_save", () => saveMachineDialog());
registerHandler("orchestrator_machine_test", () => runMachineTest());

function askRemoveMachine(ask: boolean): void {
  const d = machineDialog;
  if (!d || d.id === null) return;
  d.confirmRemove = ask;
  renderMachineDialog();
  machinePanel?.setFocusKey(ask ? "machine-remove-no" : "machine-remove");
}

// Forget the machine and go back to the list; nothing on the machine changes.
function removeMachineFromDialog(): void {
  const d = machineDialog;
  if (!d || d.id === null) return;
  removeMachine(d.id);
  closeMachineDialog(true);
}

// The Host field offers the `~/.ssh/config` hosts not yet added as machines,
// narrowed by what is typed — the way the Machines dialog's hint says to add
// one. Nothing is offered once the field names a host exactly.
function suggestMachineHosts(): void {
  const d = machineDialog;
  if (!d || !machinePanel || d.kind !== "ssh" || d.id !== null) return;
  const typed = d.target.value.trim().toLowerCase();
  const items = unaddedSshHosts()
    .map((h) => h.alias)
    .filter((a) => a.toLowerCase().includes(typed) && a.toLowerCase() !== typed);
  setMachineHostSuggestions(items);
}

function setMachineHostSuggestions(items: string[]): void {
  machinePanel?.setCompletions("machine-target", items);
}

function handleMachineDialogEvent(e: WidgetEvt): void {
  const d = machineDialog!;
  if (e.event_type === "cancel") {
    // Esc / the native `[×]`: the host unmounted the panel already.
    machinePanel = null;
    closeMachineDialog(true);
    return;
  }
  if (e.event_type === "focus") {
    // Focus alone does not open the Host list; leaving Host closes it.
    if (e.widget_key !== "machine-target") setMachineHostSuggestions([]);
    // Leaving the identity file's browser closes it.
    d.identityPicker.focusMoved(e.widget_key ?? "");
    return;
  }
  if (e.event_type === "completion_request" && e.widget_key === "machine-target") {
    // ↓ / Alt+↓ or the arrow on a closed Host list.
    suggestMachineHosts();
    return;
  }
  if (e.event_type === "completion_accept" && e.widget_key === "machine-target") {
    // The host put the host name in the field and reported the `change`;
    // an accepted name needs no more suggestions.
    setMachineHostSuggestions([]);
    return;
  }
  if (d.identityPicker.handle(e)) return;
  if (e.event_type === "change" && e.widget_key === "machine-kind") {
    const idx = ((e.payload ?? {}) as Record<string, unknown>).index;
    if (typeof idx === "number") {
      d.kind = idx === 0 ? "ssh" : "kubernetes";
      d.test = { state: "idle", summary: "", detail: "" };
      d.error = "";
      renderMachineDialog();
    }
    return;
  }
  if (e.event_type === "change") {
    const slots: Record<string, Field> = {
      "machine-target": d.target,
      "machine-identity": d.identity,
      "machine-options": d.options,
      "machine-context": d.context,
      "machine-namespace": d.namespace,
      "machine-pod": d.pod,
      "machine-path": d.path,
    };
    const slot = e.widget_key ? slots[e.widget_key] : undefined;
    if (slot) {
      applyTextChange(slot, e.payload);
      // Host decides whether a "Resolves to" row shows.
      if (slot === d.target) {
        suggestMachineHosts();
        renderMachineDialog();
      }
      // An edit outdates the test's answer and any validation error.
      if (d.test.state !== "idle" || d.error) {
        d.test = { state: "idle", summary: "", detail: "" };
        d.error = "";
        d.testToken++;
        renderMachineDialog();
      }
    }
    return;
  }
  if (e.event_type === "activate") {
    if (e.widget_key === "machine-save") saveMachineDialog();
    else if (e.widget_key === "machine-test") runMachineTest();
    else if (e.widget_key === "machine-cancel") closeMachineDialog(true);
    else if (e.widget_key === "machine-remove") askRemoveMachine(true);
    else if (e.widget_key === "machine-remove-no") askRemoveMachine(false);
    else if (e.widget_key === "machine-remove-yes") removeMachineFromDialog();
  }
}

// --- The launch form, set aside while another dialog runs -------------------
//
// `Use an existing clone…`, `Manage repositories…` and `Save as repository`
// leave the form for the Repositories dialog and come back to it. The form's
// state is kept whole across that trip — the prompt, the agent, every field —
// and the form is re-mounted on it rather than rebuilt from defaults.

let suspendedForm: NewSessionForm | null = null;

function suspendForm(): void {
  if (!form || !formPanel) return;
  closeCompletion();
  suspendedForm = form;
  formPanel.unmount();
  formPanel = null;
  form = null;
}

// Bring the set-aside form back; false when there is none.
function resumeSuspendedForm(): boolean {
  const f = suspendedForm;
  if (!f) return false;
  suspendedForm = null;
  invalidateRepositories();
  invalidateMachines();
  form = f;
  formPanel = new FloatingWidgetPanel();
  // A machine saved on the way (Add Machine) is where the form goes back to.
  if (pendingFormMachine !== undefined) seedFormMachine();
  syncRepoPath();
  mountFormPanel();
  if (f.backend === "local") void probeProjectPathDefaults();
  else scheduleRemoteReprobe();
  return true;
}

// =============================================================================
// Where a project is on one machine (§4.17)
// =============================================================================
//
// A project remembers one folder per machine. Nobody has to set that up
// front: the first time a project is used on a machine that has none, Launch
// asks — clone it there, or name the folder it is already in — and the answer
// is kept. The advanced per-machine rows in Projects ask the same question.
//
// New clones go in a per-machine folder (`~/src` by default), as
// `<that folder>/<name>`; the question offers to remember a different one.

const CLONE_BASES_KEY = "orchestrator.clone_bases";
const DEFAULT_CLONE_BASE = "~/src";

function cloneBase(machineKey: string): string {
  const all = editor.getGlobalState(CLONE_BASES_KEY) as Record<string, string> | undefined;
  const b = all?.[machineKey];
  return typeof b === "string" && b.trim() ? b.trim() : DEFAULT_CLONE_BASE;
}

function setCloneBase(machineKey: string, base: string): void {
  const all = { ...((editor.getGlobalState(CLONE_BASES_KEY) as Record<string, string> | undefined) ?? {}) };
  all[machineKey] = base;
  editor.setGlobalState(CLONE_BASES_KEY, all);
}

// Where a clone of `r` goes on a machine, unless the user says otherwise.
function cloneTarget(r: Repository, machineKey: string): string {
  return `${cloneBase(machineKey).replace(/\/+$/, "")}/${r.name}`;
}

// What the shared path picker (`lib/pickers.ts`) browses through: a machine's
// folders, local or over ssh, titled with the machine's name.
const browseSource: BrowseSource = {
  list: (machineKey, dir, files) => listMachineDir(machineKey, dir, files),
  parentDir: (dir) => parentDir(dir),
  title: (machineKey, dir) =>
    `${machineKeyLabel(machineKey)} : ${machineKey === "local" ? tildePath(expandHome(dir)) : dir}`,
  t: (key) => editor.t(key),
};

// The question itself.
interface PlaceAsk {
  repoId: string;
  machineKey: string;
  how: "clone" | "existing";
  clonePath: Field;
  // The clone's parent becomes this machine's clone folder.
  rememberBase: boolean;
  folder: Field;
  check: ClonePathCheck | null;
  checking: boolean;
  token: number;
  // The Folder field, Browse… and its browser.
  browse: PathPicker;
  cloning: { path: string; handle: ProcessHandle<SpawnResult> } | null;
  error: string;
}

// What the question sits in: the launch form, or the Projects dialog.
interface PlaceHost {
  panel(): FloatingWidgetPanel | null;
  render(): void;
  // The answer was saved (true), or the question was dropped (false).
  done(saved: boolean): void;
}

function newPlaceAsk(r: Repository, machineKey: string, how: "clone" | "existing" | undefined, host: PlaceHost): PlaceAsk {
  const a: PlaceAsk = {
    repoId: r.id,
    machineKey,
    how: how ?? (r.remote ? "clone" : "existing"),
    clonePath: fieldOf(cloneTarget(r, machineKey)),
    rememberBase: false,
    folder: fieldOf(r.clones[machineKey] ?? ""),
    check: null,
    checking: false,
    token: 0,
    browse: new PathPicker({
      source: browseSource,
      key: "place_folder",
      browseKey: "place_browse",
      listKey: "place_browse_list",
      label: formLabel("repo.folder"),
      labelWidth: FORM_LABEL_W,
      fieldWidth: 44,
      value: () => a.folder,
      start: (typed) => ({
        machineKey: a.machineKey,
        dir: typed ? parentDir(typed) : "~",
        picksAny: repoById(a.repoId)?.kind === "folder",
      }),
      onPick: (path) => {
        a.folder = fieldOf(path);
        void placeRecheck(a, host);
      },
      render: () => host.render(),
      panel: () => host.panel(),
    }),
    cloning: null,
    error: "",
  };
  return a;
}

function placeParent(p: string): string {
  const t = p.trim().replace(/\/+$/, "");
  const i = t.lastIndexOf("/");
  return i > 0 ? t.slice(0, i) : t;
}

// The rows of the question, without its buttons (the host places those).
function placeAskRows(a: PlaceAsk): WidgetSpec[] {
  const r = repoById(a.repoId);
  if (!r) return [];
  const machine = machineKeyLabel(a.machineKey);
  const note = (t: string, style: Partial<OverlayOptions> = NOTE_STYLE): WidgetSpec =>
    label(t, { labelWidth: FORM_LABEL_W, style, wrap: true });
  if (a.cloning) {
    return [note(editor.t("form.cloning", { remote: remoteIdentity(r.remote), where: `${machine} : ${a.cloning.path}` }))];
  }
  const out: WidgetSpec[] = [];
  if (r.remote) {
    out.push(radio([editor.t("place.clone_it"), editor.t("place.already_there")], {
      selectedIndex: a.how === "clone" ? 0 : 1,
      label: editor.t("place.how"),
      labelWidth: FORM_LABEL_W,
      key: "place_how",
    }));
  }
  if (a.how === "clone") {
    out.push(
      ...field(formLabel("place.clone_into"), a.clonePath, { key: "place_clone_path" }),
      note(`${r.remote}  →  ${machine}`),
    );
    const parent = placeParent(a.clonePath.value);
    if (parent && parent !== cloneBase(a.machineKey)) {
      out.push(formToggle(a.rememberBase, editor.t("place.remember_base", { base: parent, machine }), "place_remember_base"));
    }
  } else {
    out.push(...a.browse.rows());
    out.push(...placeCheckRows(a, r, note));
  }
  if (a.error) out.push(note(`✗ ${a.error}`, { fg: "diagnostic.error_fg" }));
  return out;
}

function placeCheckRows(
  a: PlaceAsk,
  r: Repository,
  note: (t: string, s?: Partial<OverlayOptions>) => WidgetSpec,
): WidgetSpec[] {
  const machine = machineKeyLabel(a.machineKey);
  const bad = { fg: "diagnostic.error_fg" };
  const good = { fg: "diagnostic.info_fg" };
  if (a.checking) return [note(editor.t("repo.checking"))];
  const c = a.check;
  if (!c || c.state === "empty") return [];
  const st = { branch: c.branch || "HEAD", state: c.dirty ? editor.t("repo.dirty") : editor.t("repo.clean") };
  switch (c.state) {
    case "ok":
      return [note(`✓ ${editor.t(r.remote ? "repo.path_ok" : "repo.path_ok_local", st)}`, good)];
    case "not_git":
      return r.kind === "folder"
        ? [note(`✓ ${editor.t("repo.plain_folder_found")}`, good)]
        : [note(`✗ ${editor.t("repo.path_not_git")}`, bad)];
    case "wrong_remote":
      return [note(`✗ ${editor.t("repo.path_wrong_remote", { origin: c.origin ? remoteIdentity(c.origin) : editor.t("repo.no_origin") })}`, bad)];
    case "missing":
      return [note(`✗ ${editor.t("repo.path_missing", { machine })}`, bad)];
    case "unreachable":
      return [note(`✗ ${editor.t("repo.path_unreachable", { machine, reason: c.error })}`, bad)];
  }
  return [];
}

// Whether the primary button can go.
function placeReady(a: PlaceAsk): boolean {
  if (a.cloning || a.checking) return false;
  if (a.how === "clone") return !!a.clonePath.value.trim();
  const r = repoById(a.repoId);
  const c = a.check?.state;
  return !!a.folder.value.trim() && (c === "ok" || (c === "not_git" && r?.kind === "folder"));
}

function placeGoLabel(a: PlaceAsk, thenLaunch: boolean): string {
  if (a.how === "clone") return editor.t(thenLaunch ? "form.btn_clone_launch" : "repo.btn_clone");
  return editor.t(thenLaunch ? "place.use_and_launch" : "place.use_folder");
}

async function placeRecheck(a: PlaceAsk, host: PlaceHost): Promise<void> {
  const r = repoById(a.repoId);
  const p = a.folder.value.trim();
  const token = ++a.token;
  if (!r || !p) {
    a.check = null;
    a.checking = false;
    host.render();
    return;
  }
  a.checking = true;
  host.render();
  const c = await checkClonePath(a.machineKey, p, r.remote);
  if (a.token !== token) return;
  a.check = c;
  a.checking = false;
  // A folder inside the clone is the clone.
  if (c.state === "ok" && c.top && !samePath(a.machineKey, p, c.top)) {
    a.folder = fieldOf(a.machineKey === "local" ? tildePath(c.top) : c.top);
    host.panel()?.setValue("place_folder", a.folder.value, a.folder.cursor);
  }
  host.render();
}

let placeTimer = 0;
function schedulePlaceRecheck(a: PlaceAsk, host: PlaceHost): void {
  const token = ++a.token;
  const mine = ++placeTimer;
  void editor.delay(350).then(() => {
    if (a.token !== token || mine !== placeTimer) return;
    void placeRecheck(a, host);
  });
}

// Save the answer: clone first when that is the answer.
async function placeGo(a: PlaceAsk, host: PlaceHost): Promise<void> {
  const r = repoById(a.repoId);
  if (!r || !placeReady(a)) return;
  if (a.how === "existing") {
    r.clones[a.machineKey] = a.folder.value.trim();
    upsertRepository(r);
    host.done(true);
    return;
  }
  const path = a.clonePath.value.trim();
  if (a.rememberBase) setCloneBase(a.machineKey, placeParent(path));
  const handle = startClone(a.machineKey, r.remote, path);
  if (!handle) {
    a.error = editor.t("repo.err_no_ssh");
    host.render();
    return;
  }
  a.cloning = { path, handle };
  a.error = "";
  host.render();
  host.panel()?.setFocusKey("place_cancel");
  const res = await handle;
  if (!a.cloning) return;
  a.cloning = null;
  if (res.exit_code !== 0) {
    await cleanupPartialClone(a.machineKey, path);
    a.error = editor.t("form.clone_failed", { reason: lastErrorLine(res) || String(res.exit_code) });
    host.render();
    return;
  }
  const fresh = repoById(r.id) ?? r;
  fresh.clones[a.machineKey] = path;
  upsertRepository(fresh);
  host.done(true);
}

async function placeCancel(a: PlaceAsk, host: PlaceHost): Promise<void> {
  const c = a.cloning;
  a.cloning = null;
  if (c) {
    await c.handle.kill();
    await cleanupPartialClone(a.machineKey, c.path);
  }
  host.done(false);
}

// A widget event for the question; true when it was one.
function handlePlaceEvent(a: PlaceAsk, host: PlaceHost, e: WidgetEvt): boolean {
  const key = e.widget_key ?? "";
  const payload = (e.payload ?? {}) as Record<string, unknown>;
  if (a.browse.handle(e)) return true;
  if (!key.startsWith("place_")) return false;
  if (e.event_type === "change" && key === "place_how") {
    a.how = payload.index === 1 ? "existing" : "clone";
    a.error = "";
    host.render();
    if (a.how === "existing" && a.folder.value.trim()) void placeRecheck(a, host);
    return true;
  }
  if (e.event_type === "toggle" && key === "place_remember_base") {
    a.rememberBase = typeof payload.checked === "boolean" ? payload.checked : !a.rememberBase;
    host.render();
    return true;
  }
  if (e.event_type === "change" && (key === "place_clone_path" || key === "place_folder")) {
    const slot = key === "place_clone_path" ? a.clonePath : a.folder;
    const before = slot.value;
    applyTextChange(slot, e.payload);
    if (slot.value === before) return true;
    a.error = "";
    if (key === "place_folder") schedulePlaceRecheck(a, host);
    host.render();
    return true;
  }
  if (e.event_type !== "activate") return true;
  if (key === "place_go") {
    void placeGo(a, host);
  } else if (key === "place_cancel") {
    void placeCancel(a, host);
  }
  return true;
}

// =============================================================================
// Repositories dialog (§4.11–§4.16)
// =============================================================================

type RepoBrowseEntry = BrowseEntry;

interface RepoDialogState {
  // Back to the launch form when done (its state is `suspendedForm`).
  returnTo: "form" | null;
  // "add": the Add Repository shape; "manage": the list and one repository.
  mode: "manage" | "add";
  repoId: string | null;
  // Add Repository's source fields.
  url: Field;
  name: Field;
  urlCheck: { state: "idle" | "running" | "ok" | "fail"; text: string };
  // Add Project's switch: clone (or point at a clone of) a git URL, or add a
  // folder that is already on a machine.
  addFrom: "url" | "folder";
  // Whether the user has typed these themselves; until then they follow the
  // URL / the folder.
  nameTouched: boolean;
  pathTouched: boolean;
  // A folder's git clone with no origin: the remote typed for it, once
  // `Set a remote URL…` asked for one.
  setRemote: Field | null;
  // `Clone and add`: save once the clone lands.
  saveAfterClone: boolean;
  urlToken: number;
  cloneNewTo: Field;
  // MAIN CLONE: the machine being looked at and its path.
  machineKey: string;
  path: Field;
  check: ClonePathCheck | null;
  checking: boolean;
  checkToken: number;
  cloneConfirm: boolean;
  cloning: { handle: ProcessHandle<SpawnResult> } | null;
  // The Path field, Browse… and its browser.
  browse: PathPicker;
  // Adding a folder that is a clone: whether its `origin` becomes the
  // project's remote, or it stays on this machine only.
  useOrigin: boolean;
  error: string;
  // `Remove…` pressed: the repository's row asks before it goes.
  confirmRemove: boolean;
  // The advanced per-machine rows are open, and the one being answered.
  machinesOpen: boolean;
  place: PlaceAsk | null;
  // Add Project, Git URL: the Path's parent becomes the machine's clone folder.
  rememberBase: boolean;
}

const REPOS_MODE = "orchestrator-repos";
let repoDialog: RepoDialogState | null = null;
let repoPanel: FloatingWidgetPanel | null = null;

// The Add Machine dialog opened from here comes back here.
let repoDialogAfterMachine: RepoDialogState | null = null;

function repoDialogRepo(): Repository | null {
  return repoDialog ? repoById(repoDialog.repoId) : null;
}

// The remote the dialog is working with: the saved repository's, or the one
// being added.
function repoDialogRemote(d: RepoDialogState): string {
  if (d.mode === "add") {
    if (d.addFrom === "url") return d.url.value.trim();
    if (d.check?.state !== "ok") return "";
    if (d.check.origin) return d.useOrigin ? d.check.origin : "";
    return d.setRemote?.value.trim() ?? "";
  }
  return repoById(d.repoId)?.remote ?? "";
}

function openRepositoriesDialog(opts: {
  repoId?: string | null;
  machineKey?: string | null;
  returnTo?: "form" | null;
  add?: { from: "url" | "folder"; path: string } | null;
}): void {
  invalidateRepositories();
  invalidateMachines();
  const repos = loadRepositories();
  const repoId = opts.repoId && repoById(opts.repoId) ? opts.repoId : repos[0]?.id ?? null;
  const machineKey = opts.machineKey ?? "local";
  const add = opts.add ?? (repos.length === 0 ? { from: lastAddFrom(), path: "" } : null);
  const d: RepoDialogState = {
    returnTo: opts.returnTo ?? null,
    mode: add ? "add" : "manage",
    repoId: add ? null : repoId,
    url: fieldOf(""),
    name: fieldOf(""),
    urlCheck: { state: "idle", text: "" },
    addFrom: add?.from ?? "url",
    nameTouched: false,
    pathTouched: !!add?.path,
    setRemote: null,
    saveAfterClone: false,
    urlToken: 0,
    cloneNewTo: fieldOf(add ? DEFAULT_CLONE_NEW_TO : repoById(repoId)?.cloneNewTo ?? DEFAULT_CLONE_NEW_TO),
    machineKey,
    path: fieldOf(add?.path ?? (repoById(repoId)?.clones[machineKey] ?? "")),
    check: null,
    checking: false,
    checkToken: 0,
    cloneConfirm: false,
    cloning: null,
    browse: new PathPicker({
      source: browseSource,
      key: "repo_path",
      browseKey: "repo_browse",
      listKey: "repo_browse_list",
      label: formLabel("repo.path"),
      labelWidth: FORM_LABEL_W,
      fieldWidth: 44,
      value: () => d.path,
      // The typed path's folder when it names one, else home. A clone (or a
      // path still to be made) is looked at from its parent, so it shows
      // among its neighbours.
      start: (typed) => ({
        machineKey: d.machineKey,
        dir: typed ? (d.check?.state === "missing" || d.check?.state === "ok" ? parentDir(typed) : typed) : "~",
        picksAny: browsePicksAnyFolder(d),
      }),
      onPick: (path) => {
        d.pathTouched = true;
        d.path = fieldOf(path);
        void recheckRepoPath();
      },
      render: () => {
        if (repoDialog === d) renderRepoDialog();
      },
      panel: () => (repoDialog === d ? repoPanel : null),
    }),
    error: "",
    confirmRemove: false,
    useOrigin: true,
    machinesOpen: false,
    place: null,
    rememberBase: false,
  };
  repoDialog = d;
  // From New Workspace's `Change…`: that machine's row, asking.
  const r = repoById(repoId);
  if (!add && opts.returnTo === "form" && r && opts.machineKey) {
    repoDialog.machinesOpen = true;
    repoDialog.place = newPlaceAsk(r, opts.machineKey, "existing", repoPlaceHost(repoDialog));
  }
  mountRepoPanel();
  if (repoDialog.place) {
    repoPanel?.setFocusKey("place_folder");
    void placeRecheck(repoDialog.place, repoPlaceHost(repoDialog));
  } else {
    void recheckRepoPath();
  }
}

// Git URL: until the user picks a Path, it is the machine's clone folder
// plus the name (`~/src/<name>`).
function urlPathFollowsName(d: RepoDialogState): void {
  const name = d.name.value.trim();
  d.path = fieldOf(name ? `${cloneBase(d.machineKey).replace(/\/+$/, "")}/${name}` : "");
  repoPanel?.setValue("repo_path", d.path.value, d.path.cursor);
  scheduleRepoPathCheck();
}

// Whether two spellings name the same folder on a machine (`~` expanded
// locally; trailing slashes aside).
function samePath(machineKey: string, a: string, b: string): boolean {
  const norm = (x: string) => (machineKey === "local" ? expandHome(x) : x).replace(/\/+$/, "");
  const [x, y] = [norm(a), norm(b)];
  if (x === y) return true;
  // A remote `~/…` cannot be expanded here; the machine answered with the
  // absolute path, which ends the same way.
  return machineKey !== "local" && x.startsWith("~/") && y.endsWith(x.slice(1));
}

// The Add Project switch opens where it was last left.
const ADD_FROM_KEY = "orchestrator.last_add_from";
function lastAddFrom(): "url" | "folder" {
  return editor.getGlobalState(ADD_FROM_KEY) === "folder" ? "folder" : "url";
}

function mountRepoPanel(): void {
  const d = repoDialog;
  if (!d) return;
  if (repoPanel) repoPanel.unmount();
  repoPanel = new FloatingWidgetPanel();
  repoPanel.mount(buildRepoDialogSpec(), {
    widthPct: FORM_WIDTH_PCT,
    heightPct: FORM_HEIGHT_PCT,
    focusMarker: true,
    labelAlign: "right",
    title: d.mode === "add" ? editor.t("repo.add_title") : editor.t("repo.title"),
    closable: true,
    mode: REPOS_MODE,
  });
  editor.floatingPanelControl(repoPanel.id(), "fullscreen", 1);
  const focus = d.mode === "add"
    ? (d.addFrom === "url" ? "repo_url" : d.path.value ? "repo_name" : "repo_path")
    : "repo_list";
  repoPanel.setFocusKey(focus);
}

function renderRepoDialog(): void {
  if (!repoPanel || !repoDialog) return;
  repoPanel.update(buildRepoDialogSpec());
  const i = loadRepositories().findIndex((r) => r.id === repoDialog!.repoId);
  if (repoDialog.mode === "manage" && i >= 0) repoPanel.setSelectedIndex("repo_list", i);
}

// Close, and go back where the dialog was opened from.
function closeRepoDialog(): void {
  const d = repoDialog;
  if (d?.cloning) void d.cloning.handle.kill();
  if (repoPanel) {
    repoPanel.unmount();
    repoPanel = null;
  }
  repoDialog = null;
  if (d?.returnTo === "form" && resumeSuspendedForm()) return;
}

// Opened from the launch form: keep the form, come back to it.
function openRepositoriesFromForm(repoId: string | null, machineKey: string | null): void {
  suspendForm();
  openRepositoriesDialog({ repoId, machineKey, returnTo: "form" });
}

// `Save as project` on the form's folder: Add Project on that machine and
// folder, as a folder.
function openAddRepositoryFromForm(path: string, machineKey: string | null): void {
  suspendForm();
  openRepositoriesDialog({ machineKey, returnTo: "form", add: { from: "folder", path } });
}

// Each machine a main clone can live on, marked with this repository's state
// on it: `✓ Local` has a main clone, `· build-01` has none. (A dropdown cell is
// 20 columns wide, so the path itself is left to the Path row.)
function repoMachineOptions(d: RepoDialogState): { key: string; label: string }[] {
  const r = d.mode === "manage" ? repoById(d.repoId) : null;
  return cloneMachineKeys().map((k) => {
    const name = machineKeyLabel(k);
    if (d.mode === "add") return { key: k, label: name };
    return { key: k, label: `${r?.clones[k] ? "✓" : "·"} ${name}` };
  });
}


function buildRepoDialogSpec(): WidgetSpec {
  const d = repoDialog;
  if (!d) return col();
  const kids: WidgetSpec[] = [...gap()];
  const repos = loadRepositories();
  if (d.mode === "manage") {
    kids.push(
      row(spacer(2), actionButton(`+ ${editor.t("repo.add")}`, "repo_add")),
      ...gap(),
    );
    if (repos.length === 0) {
      kids.push(label(`  ${editor.t("repo.none_yet")}`, { style: NOTE_STYLE }));
    } else {
      const w = Math.max(12, ...repos.map((r) => r.name.length)) + 3;
      // Boxed, like Browse, so it reads as a list to pick from.
      kids.push(row(spacer(2), labeledSection({
        label: editor.t("repo.list_title", { count: String(repos.length) }),
        child: list({
          items: repos.map((r) => ({ text: `${r.name.padEnd(w)}${repoRemoteLabel(r)}` })),
          itemKeys: repos.map((r) => r.id),
          selectedIndex: Math.max(0, repos.findIndex((r) => r.id === d.repoId)),
          visibleRows: Math.min(6, repos.length),
          key: "repo_list",
        }),
      })));
    }
    kids.push(...gap());
    const r = repoById(d.repoId);
    if (r) {
      kids.push(
        label(`  ${r.name.toUpperCase()} ${"─".repeat(400)}`, { style: SECTION_STYLE }),
        ...gap(),
        ...repoActionRows(d, r),
        ...gap(),
        label(`${formLabel("repo.remote").padStart(FORM_LABEL_W)}: ${r.remote || (r.kind === "folder" ? editor.t("repo.remote_none_folder") : editor.t("repo.remote_none_local"))}`),
        ...repoWhereSummaryRows(d, r),
      );
    }
  } else {
    kids.push(...addProjectRows(d));
  }
  kids.push(...gap(), footerRule(), ...gap());
  if (d.error) kids.push(label(`  ${d.error}`, { style: { fg: "diagnostic.error_fg", bold: true }, wrap: true }));
  kids.push(repoFooterRow(d), ...gap());
  return col(...kids);
}

// The Machine row and the Path row under it — the same pair in Add Project's
// two shapes and in a project's own section.
function repoMachinePathRows(d: RepoDialogState, pathLabel: string): WidgetSpec[] {
  const opts = repoMachineOptions(d);
  const idx = Math.max(0, opts.findIndex((o) => o.key === d.machineKey));
  return [
    machinePicker({
      options: opts.map((o) => o.label),
      selectedIndex: idx,
      label: formLabel("form.machine"),
      labelWidth: FORM_LABEL_W,
      key: "repo_machine",
      addKey: "repo_add_machine",
      addLabel: `+ ${editor.t("machine.add")}`,
    }),
    ...d.browse.rows(formLabel(pathLabel)),
  ];
}

// Add Project (§4.16): what it is added from, then only that source's fields.
function addProjectRows(d: RepoDialogState): WidgetSpec[] {
  const out: WidgetSpec[] = [
    radio([editor.t("repo.from_url"), editor.t("repo.from_folder")], {
      selectedIndex: d.addFrom === "url" ? 0 : 1,
      label: editor.t("repo.add_from"),
      labelWidth: FORM_LABEL_W,
      key: "repo_add_from",
    }),
    ...gap(),
  ];
  const note = (txt: string, style: Partial<OverlayOptions> = NOTE_STYLE): WidgetSpec =>
    label(txt, { labelWidth: FORM_LABEL_W, style, wrap: true });
  if (d.addFrom === "url") {
    out.push(...field(formLabel("repo.url"), d.url, { key: "repo_url", placeholder: editor.t("repo.url_placeholder") }));
    const st = d.urlCheck.state;
    if (st !== "idle") {
      out.push(note(
        st === "running" ? editor.t("repo.checking")
          : st === "ok" ? `✓ ${d.urlCheck.text ? editor.t("repo.url_ok_branch", { branch: d.urlCheck.text }) : editor.t("repo.url_ok")}`
          : `✗ ${d.urlCheck.text}`,
        st === "fail" ? { fg: "diagnostic.error_fg" } : st === "ok" ? { fg: "diagnostic.info_fg" } : NOTE_STYLE,
      ));
    }
    out.push(
      ...field(formLabel("repo.name"), d.name, { key: "repo_name" }),
      ...gap(),
      sectionHeader("repo.section_main_clone"),
      ...gap(),
      ...repoMachinePathRows(d, "repo.path"),
      ...addUrlPathRows(d, note),
    );
    return out;
  }
  out.push(...repoMachinePathRows(d, "repo.folder"), ...addFolderRows(d, note));
  return out;
}

// Git URL: what the Path is, and so what the primary button will do there.
function addUrlPathRows(d: RepoDialogState, note: (t: string, s?: Partial<OverlayOptions>) => WidgetSpec): WidgetSpec[] {
  const machine = machineKeyLabel(d.machineKey);
  // A clone somewhere other than the machine's clone folder can make that
  // its clone folder.
  const parent = placeParent(d.path.value);
  const remember = d.check?.state === "missing" && !d.cloning && parent && parent !== cloneBase(d.machineKey)
    ? [formToggle(d.rememberBase, editor.t("place.remember_base", { base: parent, machine }), "repo_remember_base")]
    : [];
  if (d.cloning) {
    return [note(editor.t("repo.cloning")), fieldColumnRow(actionButton(editor.t("form.btn_cancel_short"), "repo_clone_cancel"))];
  }
  if (d.checking) return [note(editor.t("repo.checking"))];
  const c = d.check;
  if (!c || c.state === "empty") return [];
  const bad = { fg: "diagnostic.error_fg" };
  switch (c.state) {
    case "missing":
      return [note(editor.t("repo.will_clone_here")), ...remember];
    case "ok":
      return [note(`✓ ${editor.t("repo.existing_clone", {
        branch: c.branch || "HEAD",
        state: c.dirty ? editor.t("repo.dirty") : editor.t("repo.clean"),
      })}`, { fg: "diagnostic.info_fg" })];
    case "wrong_remote":
      return [note(`✗ ${editor.t("repo.path_wrong_remote", { origin: c.origin ? remoteIdentity(c.origin) : editor.t("repo.no_origin") })}`, bad)];
    case "not_git":
      return [note(`✗ ${editor.t("repo.path_taken")}`, bad)];
    case "unreachable":
      return [note(`✗ ${editor.t("repo.path_unreachable", { machine, reason: c.error })}`, bad)];
  }
  return [];
}

// Folder on a machine: what is there, and — for a clone — which remote the
// project gets.
function addFolderRows(d: RepoDialogState, note: (t: string, s?: Partial<OverlayOptions>) => WidgetSpec): WidgetSpec[] {
  const machine = machineKeyLabel(d.machineKey);
  const bad = { fg: "diagnostic.error_fg" };
  const name = [...gap(), ...field(formLabel("repo.name"), d.name, { key: "repo_name" })];
  if (d.checking) return [note(editor.t("repo.checking"))];
  const c = d.check;
  if (!c || c.state === "empty") return [];
  switch (c.state) {
    case "missing":
      return [note(`✗ ${editor.t("repo.path_missing", { machine })}`, bad)];
    case "unreachable":
      return [note(`✗ ${editor.t("repo.path_unreachable", { machine, reason: c.error })}`, bad)];
    case "not_git":
      return [
        note(`✓ ${editor.t("repo.plain_folder_found")}`, { fg: "diagnostic.info_fg" }),
        note(editor.t("repo.plain_folder_means")),
        ...name,
      ];
  }
  // A git clone (a wrong remote cannot happen here: nothing is asked of it).
  const out: WidgetSpec[] = [
    note(`✓ ${editor.t("repo.path_ok_local", {
      branch: c.branch || "HEAD",
      state: c.dirty ? editor.t("repo.dirty") : editor.t("repo.clean"),
    })}`, { fg: "diagnostic.info_fg" }),
    ...gap(),
    sectionHeader("repo.section_its_remote"),
    ...gap(),
  ];
  if (c.origin) {
    out.push(
      note(editor.t("repo.origin_is", { remote: c.origin })),
      radio([
        editor.t("repo.use_origin_choice"),
        editor.t("repo.keep_local_choice"),
      ], {
        selectedIndex: d.useOrigin ? 0 : 1,
        label: editor.t("repo.remote_choice"),
        labelWidth: FORM_LABEL_W,
        key: "repo_remote_choice",
      }),
    );
  } else if (d.setRemote) {
    out.push(
      note(editor.t("repo.no_origin_set")),
      ...field(formLabel("repo.remote_url"), d.setRemote, { key: "repo_set_remote", placeholder: editor.t("repo.url_placeholder") }),
    );
  } else {
    out.push(
      note(editor.t("repo.no_origin_stays")),
      fieldColumnRow(actionButton(editor.t("repo.set_remote"), "repo_set_remote_btn")),
    );
  }
  out.push(...name);
  return out;
}

// A path the primary action may save. Managing: a matching clone, a plain
// folder's folder, or nothing (which forgets the machine's). Adding: what
// the chosen source can take — a clone of the URL, or a folder that is there.
function repoPathSavable(d: RepoDialogState): boolean {
  if (d.checking || d.cloning || d.cloneConfirm) return false;
  const c = d.check;
  if (d.mode === "add") {
    if (d.addFrom === "url") return d.urlCheck.state === "ok" && c?.state === "ok";
    return c?.state === "ok" || c?.state === "not_git";
  }
  if (repoById(d.repoId)?.kind === "folder" && c?.state === "not_git") return true;
  return !c || c.state === "empty" || c.state === "ok";
}

// The selected repository's own actions, under its name: start a workspace
// on it, or remove it — which asks first, in place.
function repoActionRows(d: RepoDialogState, r: Repository): WidgetSpec[] {
  if (d.confirmRemove) {
    return [
      label(`⚠ ${editor.t("repo.remove_confirm", { name: r.name })}`, { labelWidth: FORM_LABEL_W, style: WARN_STYLE }),
      fieldColumnRow(
        actionButton(editor.t("form.btn_cancel_short"), "repo_remove_no"),
        spacer(4),
        button(editor.t("repo.remove_yes"), { intent: "danger", key: "repo_remove_yes" }),
      ),
    ];
  }
  return [
    fieldColumnRow(
      actionButton(editor.t("repo.new_here_btn"), "repo_new_here"),
      spacer(4),
      actionButton(editor.t("repo.remove_btn"), "repo_remove"),
    ),
  ];
}


// Where the project is: one line, and — behind `▹ Machines` — a row per
// machine to set, change or forget it by hand (§4.11). Nobody needs those
// rows to get going: New Workspace asks the first time (§4.17).
function repoWhereSummaryRows(d: RepoDialogState, r: Repository): WidgetSpec[] {
  const on = cloneMachineKeys().filter((k) => r.clones[k]).map((k) => machineKeyLabel(k));
  const out: WidgetSpec[] = [
    label(
      `${formLabel("repo.on").padStart(FORM_LABEL_W)}: ${on.length ? on.join(" · ") : editor.t("repo.on_none")}`,
      { wrap: true },
    ),
    ...gap(),
    fieldColumnRow(actionButton(editor.t(d.machinesOpen ? "repo.machines_hide" : "repo.machines_show"), "repo_machines_toggle")),
  ];
  if (!d.machinesOpen) return out;
  out.push(...gap());
  // The paths as one column, so each row's buttons line up.
  const shown = (k: string) => (r.clones[k] ? tildePath(r.clones[k]) : "—");
  const pathW = Math.max(12, ...cloneMachineKeys().map((k) => shown(k).length));
  for (const k of cloneMachineKeys()) {
    const name = machineKeyLabel(k);
    const path = r.clones[k];
    if (d.place && d.place.machineKey === k) {
      out.push(
        label(`${name.padStart(FORM_LABEL_W)}:`, { style: { bold: true } }),
        ...placeAskRows(d.place),
        fieldColumnRow(
          actionButton(editor.t("form.btn_cancel_short"), "place_cancel"),
          spacer(4),
          button(`  ${placeGoLabel(d.place, false)}  `, { intent: "primary", key: "place_go", disabled: !placeReady(d.place) }),
        ),
        ...gap(),
      );
      continue;
    }
    const kids: WidgetSpec[] = [label(`${name.padStart(FORM_LABEL_W)}: ${shown(k).padEnd(pathW)}`), spacer(3)];
    if (path) {
      kids.push(actionButton(editor.t("repo.m_change"), `repo_m_change:${k}`), spacer(2), actionButton(editor.t("repo.m_forget"), `repo_m_forget:${k}`));
    } else {
      if (r.remote) kids.push(actionButton(editor.t("repo.m_clone"), `repo_m_clone:${k}`), spacer(2));
      kids.push(actionButton(editor.t("repo.m_pick"), `repo_m_pick:${k}`));
    }
    out.push(row(...kids));
  }
  out.push(fieldColumnRow(actionButton(`+ ${editor.t("repo.add_machine")}`, "repo_add_machine")));
  return out;
}

function repoPlaceHost(d: RepoDialogState): PlaceHost {
  return {
    panel: () => (repoDialog === d ? repoPanel : null),
    render: () => {
      if (repoDialog === d) renderRepoDialog();
    },
    done: () => {
      const k = d.place?.machineKey;
      d.place = null;
      if (repoDialog !== d) return;
      renderRepoDialog();
      if (k) repoPanel?.setFocusKey(repoById(d.repoId)?.clones[k] ? `repo_m_change:${k}` : `repo_m_pick:${k}`);
    },
  };
}

function repoFooterRow(d: RepoDialogState): WidgetSpec {
  const ok = repoPathSavable(d);
  if (d.mode === "add") {
    // A URL whose Path is not there yet is cloned by the primary button,
    // and the button says so.
    const cloneFirst = d.addFrom === "url" && !d.checking && !d.cloning && d.check?.state === "missing";
    const primary = cloneFirst
      ? button(`  ${editor.t("repo.btn_clone_add")}  `, {
        intent: "primary",
        key: "repo_clone_add",
        disabled: d.urlCheck.state !== "ok" || !d.name.value.trim(),
      })
      : button(`  ${editor.t("repo.btn_add")}  `, { intent: "primary", key: "repo_save", disabled: !ok || !d.name.value.trim() });
    return endRow(
      actionButton(editor.t("form.btn_cancel_short"), "repo_cancel"),
      spacer(5),
      primary,
      spacer(3),
    );
  }
  // Managing saves per row, so the footer only leaves: back to the form that
  // opened it, or out.
  const done = d.returnTo === "form" ? editor.t("repo.back_to_form_btn") : editor.t("repo.done");
  return endRow(button(`  ${done}  `, { intent: "primary", key: "repo_done" }), spacer(3));
}

// ── Checks ───────────────────────────────────────────────────────────────────

// Re-check the Path on the selected machine. Debounced by the caller; a newer
// check makes an older answer stale.
async function recheckRepoPath(): Promise<void> {
  const d = repoDialog;
  if (!d) return;
  const token = ++d.checkToken;
  const p = d.path.value.trim();
  if (!p) {
    d.check = null;
    d.checking = false;
    renderRepoDialog();
    return;
  }
  d.checking = true;
  renderRepoDialog();
  // Adding a folder asks only what is there; everything else checks the
  // path against the project's remote.
  const folder = d.mode === "add" && d.addFrom === "folder";
  const c = await checkClonePath(d.machineKey, p, folder ? "" : repoDialogRemote(d));
  if (repoDialog !== d || d.checkToken !== token) return;
  const originBefore = d.check?.origin ?? "";
  d.check = c;
  d.checking = false;
  if (folder && c.state === "ok" && c.top && !samePath(d.machineKey, p, c.top)) {
    // A folder inside a clone is that clone: the Folder becomes its top.
    d.path = fieldOf(d.machineKey === "local" ? tildePath(c.top) : c.top);
    repoPanel?.setValue("repo_path", d.path.value, d.path.cursor);
  }
  if (folder) {
    // A clone's origin is offered as the remote; the name follows it, or
    // the folder's own name, until the user types one.
    if (c.origin !== originBefore) d.useOrigin = !!c.origin;
    if (c.state !== "ok" || c.origin) d.setRemote = null;
    if (!d.nameTouched && (c.state === "ok" || c.state === "not_git")) {
      const n = c.origin ? repoNameFromRemote(c.origin) : editor.pathBasename(p.replace(/\/+$/, ""));
      d.name = fieldOf(n);
      repoPanel?.setValue("repo_name", d.name.value, d.name.cursor);
    }
  }
  renderRepoDialog();
}

let repoPathTimer = 0;
function scheduleRepoPathCheck(): void {
  const d = repoDialog;
  if (!d) return;
  d.checkToken++;
  const token = d.checkToken;
  const mine = ++repoPathTimer;
  void editor.delay(350).then(() => {
    if (repoDialog !== d || d.checkToken !== token || mine !== repoPathTimer) return;
    void recheckRepoPath();
  });
}

// Add Repository's source (§4.16): a URL is asked with `git ls-remote`; a
// local path is a repository whose origin becomes the remote and which
// becomes the Local main clone.
async function checkRepoUrl(): Promise<void> {
  const d = repoDialog;
  if (!d || d.mode !== "add") return;
  const token = ++d.urlToken;
  const v = d.url.value.trim();
  if (!v) {
    d.urlCheck = { state: "idle", text: "" };
    renderRepoDialog();
    return;
  }
  // A path to a working tree is a folder on this machine — the other source;
  // any other path (a bare repository, say) is a remote like a URL.
  const looksLocal = v.startsWith("/") || v.startsWith("~") || v.startsWith(".");
  const inside = looksLocal && (await pathIsInsideGitWorkTree(expandHome(v)));
  if (repoDialog !== d || d.urlToken !== token) return;
  if (inside) {
    d.urlCheck = { state: "fail", text: editor.t("repo.url_is_folder") };
    renderRepoDialog();
    return;
  }
  d.urlCheck = { state: "running", text: "" };
  renderRepoDialog();
  const r = await editor.spawnHostProcess("git", ["ls-remote", "--symref", v, "HEAD"]);
  if (repoDialog !== d || d.urlToken !== token) return;
  if (r.exit_code !== 0) {
    d.urlCheck = { state: "fail", text: lastErrorLine(r) || editor.t("repo.url_unreachable") };
  } else {
    const m = /ref:\s+refs\/heads\/(\S+)\s+HEAD/.exec(r.stdout || "");
    d.urlCheck = { state: "ok", text: m ? m[1] : "" };
  }
  renderRepoDialog();
}

let repoUrlTimer = 0;
function scheduleRepoUrlCheck(): void {
  const d = repoDialog;
  if (!d) return;
  const mine = ++repoUrlTimer;
  void editor.delay(500).then(() => {
    if (repoDialog !== d || mine !== repoUrlTimer) return;
    void checkRepoUrl();
  });
}

// ── Browse… ──────────────────────────────────────────────────────────────────

// The folders of `dir` on the dialog's machine, with a `git` tag on those that
// hold a `.git`. Local reads the directory; a remote lists it over ssh.
async function listMachineDir(
  machineKey: string,
  dir: string,
  files = false,
): Promise<{ entries: RepoBrowseEntry[]; error: string }> {
  if (machineKey === "local") {
    const base = expandHome(dir);
    // A folder that is not there lists as nothing at all; say so, as the
    // remote listing's `NODIR` does, so the browser can go up to one that is.
    if (!editor.fileExists(editor.localPath(base))) {
      return { entries: [], error: editor.t("repo.no_such_dir") };
    }
    const out: RepoBrowseEntry[] = [];
    const found: RepoBrowseEntry[] = [];
    for (const e of editor.readDir(editor.localPath(base))) {
      // Picking a file shows dotfiles: the key lives in `~/.ssh`.
      if (!files && e.name.startsWith(".")) continue;
      if (!e.is_dir) {
        if (files) found.push({ name: e.name, git: false, file: true });
        continue;
      }
      const p = editor.pathJoin(base, e.name);
      out.push({ name: e.name, git: editor.fileExists(editor.localPath(editor.pathJoin(p, ".git"))) });
    }
    out.sort((a, b) => a.name.localeCompare(b.name));
    found.sort((a, b) => a.name.localeCompare(b.name));
    return { entries: [...out, ...found], error: "" };
  }
  const script = [
    `cd ${remoteShellPath(dir)} 2>/dev/null || { echo NODIR; exit 0; }`,
    'for d in */; do [ -d "$d" ] || continue; n=${d%/}; if [ -e "$n/.git" ]; then echo "G $n"; else echo "D $n"; fi; done',
  ].join("; ");
  const argv = machineKeySshArgv(machineKey, REMOTE_PROBE_TIMEOUT_S);
  if (!argv) return { entries: [], error: editor.t("repo.err_no_ssh") };
  const r = await editor.spawnHostProcess("ssh", [...argv, script]);
  if (r.exit_code !== 0) return { entries: [], error: lastErrorLine(r) || editor.t("err.connection_failed") };
  const lines = (r.stdout || "").split(/\r?\n/).filter(Boolean);
  if (lines[0] === "NODIR") return { entries: [], error: editor.t("repo.no_such_dir") };
  return {
    entries: lines.map((l) => ({ name: l.slice(2), git: l.startsWith("G ") })),
    error: "",
  };
}

function parentDir(dir: string): string {
  const t = dir.replace(/\/+$/, "");
  if (t === "" || t === "/") return "/";
  if (t === "~") return expandHome("~").replace(/\/[^/]+$/, "") || "/";
  const i = t.lastIndexOf("/");
  return i <= 0 ? "/" : t.slice(0, i);
}

// Whether Browse can pick a folder that is not a clone: Add Project's
// Folder source, and a plain-folder project's folder.
function browsePicksAnyFolder(d: RepoDialogState): boolean {
  if (d.mode === "add") return d.addFrom === "folder";
  return repoById(d.repoId)?.kind === "folder";
}

// ── Clone (§4.15) ────────────────────────────────────────────────────────────

async function runRepoClone(): Promise<void> {
  const d = repoDialog;
  if (!d) return;
  const remote = repoDialogRemote(d);
  const path = d.path.value.trim();
  if (!remote || !path) return;
  const handle = startClone(d.machineKey, remote, path);
  d.cloneConfirm = false;
  if (!handle) {
    d.error = editor.t("repo.err_no_ssh");
    renderRepoDialog();
    return;
  }
  d.cloning = { handle };
  d.error = "";
  renderRepoDialog();
  repoPanel?.setFocusKey("repo_clone_cancel");
  const res = await handle;
  if (repoDialog !== d || !d.cloning) return;
  d.cloning = null;
  if (res.exit_code !== 0) {
    await cleanupPartialClone(d.machineKey, path);
    if (repoDialog !== d) return;
    d.error = editor.t("form.clone_failed", { reason: lastErrorLine(res) || String(res.exit_code) });
  }
  await recheckRepoPath();
  const thenSave = d.saveAfterClone;
  d.saveAfterClone = false;
  if (thenSave && repoDialog === d && d.check?.state === "ok") {
    saveRepoDialog();
    return;
  }
  repoPanel?.setFocusKey("repo_save");
}

async function cancelRepoClone(): Promise<void> {
  const d = repoDialog;
  if (!d) return;
  d.cloneConfirm = false;
  d.saveAfterClone = false;
  const c = d.cloning;
  d.cloning = null;
  renderRepoDialog();
  if (c) {
    await c.handle.kill();
    await cleanupPartialClone(d.machineKey, d.path.value.trim());
    await recheckRepoPath();
  }
}


// ── Save ─────────────────────────────────────────────────────────────────────

function saveRepoDialog(): void {
  const d = repoDialog;
  if (!d || !repoPathSavable(d)) return;
  const path = d.path.value.trim();
  const cloneNewTo = d.cloneNewTo.value.trim() || DEFAULT_CLONE_NEW_TO;
  if (d.mode === "add") {
    const name = d.name.value.trim();
    const remote = repoDialogRemote(d);
    if (!name) {
      d.error = editor.t("repo.err_name");
      renderRepoDialog();
      return;
    }
    if (!path || (d.addFrom === "url" && d.urlCheck.state !== "ok")) {
      d.error = editor.t("repo.err_source");
      renderRepoDialog();
      return;
    }
    const plain = d.addFrom === "folder" && d.check?.state === "not_git";
    const existing = remote ? loadRepositories().find((r) => sameRemote(r.remote, remote)) : null;
    // A name picks a repository in the Project list, so two cannot share one.
    if (loadRepositories().some((o) => o.name === name && o.id !== existing?.id)) {
      d.error = editor.t("repo.err_name_taken", { name });
      renderRepoDialog();
      return;
    }
    const r: Repository = existing ?? { id: newRepoId(), name, remote, cloneNewTo, clones: {} };
    r.name = name;
    r.cloneNewTo = cloneNewTo;
    if (plain) r.kind = "folder";
    r.clones[d.machineKey] = path;
    if (d.addFrom === "url" && d.rememberBase) setCloneBase(d.machineKey, placeParent(path));
    upsertRepository(r);
    editor.setGlobalState(ADD_FROM_KEY, d.addFrom);
    if (d.returnTo === "form" && suspendedForm) {
      suspendedForm.repoId = r.id;
      closeRepoDialog();
      return;
    }
    d.mode = "manage";
    d.repoId = r.id;
    d.error = "";
    mountRepoPanel();
  }
}

// Switch the dialog to another repository or machine: the Path shows that
// pair's main clone.
function repoDialogShow(repoId: string | null, machineKey: string): void {
  const d = repoDialog;
  if (!d) return;
  d.repoId = repoId;
  d.machineKey = machineKey;
  const r = repoById(repoId);
  d.cloneNewTo = fieldOf(r?.cloneNewTo ?? DEFAULT_CLONE_NEW_TO);
  d.path = fieldOf(r?.clones[machineKey] ?? "");
  d.cloneConfirm = false;
  d.confirmRemove = false;
  d.place = null;
  d.browse.reset();
  d.error = "";
  repoPanel?.setValue("repo_path", d.path.value, d.path.cursor);
  repoPanel?.setValue("repo_clone_new_to", d.cloneNewTo.value, d.cloneNewTo.cursor);
  void recheckRepoPath();
}

// Each gets only what the focused control left: an open dropdown closes on
// its own Esc, a list row and a button take their own Enter, a field its
// own Backspace.
const REPOS_MODE_BINDINGS: string[][] = [
  ["Enter", "orchestrator_repos_enter"],
  ["C-Enter", "orchestrator_repos_save", "shortcut"],
  ["Escape", "orchestrator_repos_escape"],
  ["Backspace", "orchestrator_repos_backspace"],
];
editor.defineMode(REPOS_MODE, REPOS_MODE_BINDINGS, true, true);

// Ctrl+Enter: Add Repository saves; managing has nothing to save, so it is Done.
registerHandler("orchestrator_repos_save", () => {
  const d = repoDialog;
  if (d?.place) void placeGo(d.place, repoPlaceHost(d));
  else if (d?.mode === "manage") closeRepoDialog();
  else saveRepoDialog();
});
registerHandler("orchestrator_repos_enter", () => {
  const d = repoDialog;
  if (!d || !repoPanel) return;
  const focus = repoPanel.focusKey();
  // In a machine row's question, Enter on its text answers it.
  if (d.place && (focus === "place_folder" || focus === "place_clone_path")) {
    void placeGo(d.place, repoPlaceHost(d));
    return;
  }
  // Enter on a text field saves (Add Repository) or checks the path now
  // (managing, which saves once the check passes). A button, the dropdown
  // and a list row answered their own Enter before this binding.
  if (["repo_path", "repo_url", "repo_name", "repo_clone_new_to"].includes(focus)) {
    if (focus === "repo_url") {
      void checkRepoUrl();
      return;
    }
    if (d.mode === "manage") {
      if (focus === "repo_path") void recheckRepoPath();
      return;
    }
    saveRepoDialog();
  }
});
registerHandler("orchestrator_repos_escape", () => {
  const d = repoDialog;
  if (!d || !repoPanel) return;
  // Esc closes a folder browser first, then drops the question.
  if (d.place) {
    if (!d.place.browse.close()) void placeCancel(d.place, repoPlaceHost(d));
    return;
  }
  if (d.browse.close()) return;
  if (d.cloneConfirm || d.cloning) {
    void cancelRepoClone();
    return;
  }
  closeRepoDialog();
});
registerHandler("orchestrator_repos_backspace", () => {
  const d = repoDialog;
  if (!d || !repoPanel) return;
  // In a browser, Backspace goes up a folder.
  const focus = repoPanel.focusKey();
  if (d.place?.browse.up(focus)) return;
  d.browse.up(focus);
});

function handleRepoDialogEvent(e: WidgetEvt): void {
  const d = repoDialog!;
  if (e.event_type === "cancel") {
    // Esc / the native `[×]`: the host unmounted the panel already.
    repoPanel = null;
    closeRepoDialog();
    return;
  }
  if (e.event_type === "focus") {
    // Leaving a folder browser closes it.
    d.browse.focusMoved(e.widget_key ?? "");
    d.place?.browse.focusMoved(e.widget_key ?? "");
    return;
  }
  if (d.place && handlePlaceEvent(d.place, repoPlaceHost(d), e)) return;
  const payload = (e.payload ?? {}) as Record<string, unknown>;
  if (e.event_type === "activate" && e.widget_key?.startsWith("repo_m_")) {
    // A machine row's button: `repo_m_<action>:<machine key>`.
    const [action, ...rest] = e.widget_key.slice("repo_m_".length).split(":");
    const k = rest.join(":");
    const r = repoById(d.repoId);
    if (!r) return;
    if (action === "forget") {
      delete r.clones[k];
      upsertRepository(r);
      renderRepoDialog();
      repoPanel?.setFocusKey(`repo_m_pick:${k}`);
      return;
    }
    d.place = newPlaceAsk(r, k, action === "clone" ? "clone" : "existing", repoPlaceHost(d));
    renderRepoDialog();
    const first = d.place.how === "clone" ? "place_clone_path" : "place_folder";
    repoPanel?.setFocusKey(first);
    if (d.place.how === "existing" && d.place.folder.value) void placeRecheck(d.place, repoPlaceHost(d));
    return;
  }
  if (e.event_type === "activate" && e.widget_key === "repo_machines_toggle") {
    d.machinesOpen = !d.machinesOpen;
    d.place = null;
    renderRepoDialog();
    return;
  }
  if (isListEvent(e as { event_type: string; widget_key?: string; payload?: unknown }, "repo_list")) {
    const idx = typeof payload.index === "number" ? payload.index : -1;
    const r = loadRepositories()[idx];
    if (!r) return;
    if (e.event_type === "select" && r.id !== d.repoId) {
      d.place = null;
      repoDialogShow(r.id, d.machineKey);
      renderRepoDialog();
    } else if (e.event_type === "activate") {
      repoDialogShow(r.id, d.machineKey);
      newWorkspaceOnRepo();
    }
    return;
  }
  if (d.browse.handle(e)) return;
  if (e.event_type === "change" && e.widget_key === "repo_add_from") {
    const next = payload.index === 1 ? "folder" : "url";
    if (next !== d.addFrom) {
      // Each source keeps what was typed into it; the Path is re-read
      // against the other source's rules.
      d.addFrom = next;
      editor.setGlobalState(ADD_FROM_KEY, next);
      d.browse.reset();
      d.error = "";
      if (next === "url" && !d.pathTouched) urlPathFollowsName(d);
      renderRepoDialog();
      void recheckRepoPath();
    }
    return;
  }
  if (e.event_type === "toggle" && e.widget_key === "repo_remember_base") {
    d.rememberBase = typeof payload.checked === "boolean" ? payload.checked : !d.rememberBase;
    renderRepoDialog();
    return;
  }
  if (e.event_type === "change" && e.widget_key === "repo_remote_choice") {
    d.useOrigin = payload.index !== 1;
    renderRepoDialog();
    return;
  }
  if (e.event_type === "change" && e.widget_key === "repo_machine") {
    const idx = payload.index;
    const opt = typeof idx === "number" ? repoMachineOptions(d)[idx] : undefined;
    if (opt && opt.key !== d.machineKey) {
      if (d.mode === "add") {
        // Adding keeps what was typed; a URL's untouched Path stays the
        // default location, now on the other machine, and a folder is
        // looked for anew.
        d.machineKey = opt.key;
        d.browse.reset();
        if (d.addFrom === "folder") {
          d.path = fieldOf("");
          d.pathTouched = false;
          repoPanel?.setValue("repo_path", "", 0);
        } else if (!d.pathTouched) {
          // The other machine's clone folder.
          urlPathFollowsName(d);
        }
        void recheckRepoPath();
      } else {
        repoDialogShow(d.repoId, opt.key);
      }
      renderRepoDialog();
    }
    return;
  }
  if (e.event_type === "change") {
    const slots: Record<string, Field> = {
      repo_path: d.path,
      repo_url: d.url,
      repo_name: d.name,
      repo_clone_new_to: d.cloneNewTo,
    };
    if (d.setRemote) slots.repo_set_remote = d.setRemote;
    const slot = e.widget_key ? slots[e.widget_key] : undefined;
    if (!slot) return;
    const before = slot.value;
    applyTextChange(slot, e.payload);
    if (slot.value === before) return;
    d.error = "";
    if (e.widget_key === "repo_path") {
      d.pathTouched = true;
      d.cloneConfirm = false;
      scheduleRepoPathCheck();
      renderRepoDialog();
    } else if (e.widget_key === "repo_url") {
      // The name follows the URL, and the Path follows the name into the
      // default clone location, until the user types their own.
      if (!d.nameTouched) {
        d.name = fieldOf(repoNameFromRemote(d.url.value));
        repoPanel?.setValue("repo_name", d.name.value, d.name.cursor);
      }
      if (!d.pathTouched) urlPathFollowsName(d);
      d.urlCheck = { state: "idle", text: "" };
      scheduleRepoUrlCheck();
      renderRepoDialog();
    } else if (e.widget_key === "repo_name") {
      d.nameTouched = true;
      if (d.addFrom === "url" && !d.pathTouched) urlPathFollowsName(d);
      renderRepoDialog();
    } else if (e.widget_key === "repo_set_remote") {
      renderRepoDialog();
    }
    return;
  }
  if (e.event_type !== "activate") return;
  switch (e.widget_key) {
    case "repo_add":
      d.mode = "add";
      d.repoId = null;
      d.url = fieldOf("");
      d.name = fieldOf("");
      d.urlCheck = { state: "idle", text: "" };
      d.addFrom = lastAddFrom();
      d.nameTouched = false;
      d.pathTouched = false;
      d.setRemote = null;
      d.useOrigin = true;
      d.cloneNewTo = fieldOf(DEFAULT_CLONE_NEW_TO);
      d.machineKey = "local";
      d.path = fieldOf("");
      d.check = null;
      d.browse.reset();
      d.error = "";
      mountRepoPanel();
      return;
    case "repo_add_machine":
      // Add Machine, then back here with the new machine selected.
      repoDialogAfterMachine = d;
      if (repoPanel) {
        repoPanel.unmount();
        repoPanel = null;
      }
      repoDialog = null;
      openMachineDialog(null, "repos");
      return;
    case "repo_clone_add":
      // The button's label already says it clones: no second question.
      d.saveAfterClone = true;
      void runRepoClone();
      return;
    case "repo_set_remote_btn":
      d.setRemote = fieldOf("");
      renderRepoDialog();
      repoPanel?.setFocusKey("repo_set_remote");
      return;
    case "repo_clone_cancel":
      void cancelRepoClone();
      return;
    case "repo_save":
      saveRepoDialog();
      return;
    case "repo_cancel":
      if (d.mode === "add" && d.returnTo !== "form" && loadRepositories().length > 0) {
        d.mode = "manage";
        d.repoId = loadRepositories()[0].id;
        repoDialogShow(d.repoId, d.machineKey);
        mountRepoPanel();
        return;
      }
      closeRepoDialog();
      return;
    case "repo_remove":
      d.confirmRemove = true;
      renderRepoDialog();
      repoPanel?.setFocusKey("repo_remove_no");
      return;
    case "repo_remove_no":
      d.confirmRemove = false;
      renderRepoDialog();
      repoPanel?.setFocusKey("repo_remove");
      return;
    case "repo_remove_yes": {
      if (!d.repoId) return;
      removeRepository(d.repoId);
      const next = loadRepositories()[0]?.id ?? null;
      repoDialogShow(next, d.machineKey);
      renderRepoDialog();
      return;
    }
    case "repo_done":
      if (d.place) void placeCancel(d.place, repoPlaceHost(d));
      closeRepoDialog();
      return;
    case "repo_new_here":
      newWorkspaceOnRepo();
      return;
  }
}

// `⏎ New workspace here`: the launch form on this repository and machine.
function newWorkspaceOnRepo(): void {
  const d = repoDialog;
  if (!d || !d.repoId) return;
  const repoId = d.repoId;
  const key = d.machineKey;
  if (d.returnTo === "form" && suspendedForm) {
    suspendedForm.repoId = repoId;
    pendingFormMachine = { kind: "option", key };
    closeRepoDialog();
    return;
  }
  if (repoPanel) {
    repoPanel.unmount();
    repoPanel = null;
  }
  repoDialog = null;
  pendingFormRepo = repoId;
  pendingFormMachine = { kind: "option", key };
  dockBlurred = true;
  openForm({ fromPicker: true });
}

// Back from Add Machine (opened by `+ Add machine…`): the dialog as it was,
// on the machine just saved.
function resumeRepoDialogAfterMachine(savedKey: string | null): void {
  const d = repoDialogAfterMachine;
  repoDialogAfterMachine = null;
  if (!d) return;
  repoDialog = d;
  invalidateMachines();
  if (savedKey) {
    d.machineKey = savedKey;
    d.path = fieldOf(repoById(d.repoId)?.clones[savedKey] ?? "");
  }
  mountRepoPanel();
  repoPanel?.setFocusKey("repo_path");
  void recheckRepoPath();
}

registerHandler("orchestrator_repositories", () => openRepositoriesDialog({}));

// --- Machines (§5.4) --------------------------------------------------------

const MACHINES_MODE = "orchestrator-machines";
let machinesPanel: FloatingWidgetPanel | null = null;
let machinesState: { index: number } | null = null;

/** A machine picked for the next form to open on. `undefined` = nobody
 *  asked, so the last one used applies. */
let pendingFormMachine: FormSeed | undefined = undefined;
/** Fields the next New Workspace form opens with, set when a discovered
 *  session is rejoined. Consumed once, like `pendingFormMachine`. */
let pendingFormPrefill:
  | {
    projectPath: string;
    cmd: string;
    createWorktree?: boolean;
    /** The session's own name, for the workspace it becomes. */
    label?: string;
    /** The Claude cloud session this workspace is a teleported copy of. */
    teleportOf?: string;
  }
  | null = null;

interface MachinesRow {
  key: string;
  machine: Machine | null;
  // A host `~/.ssh/config` names that is not a saved machine yet, listed so
  // it can be added in one step. Until it is added nothing else offers it: a
  // workspace runs only on a saved machine. Fresh does not own the entry
  // (§5.3): it can be tested and added, not edited or removed here.
  host?: SshConfigHost;
}

// Results of `Test connection` on ssh-config hosts, kept for this run only:
// the config file is not Fresh's to write a result into.
const sshHostTests = new Map<string, MachineTest>();

// A saved machine that already stands for a config host (its target is the
// alias, or what the alias resolves to) hides the config row.
function machineCoversHost(m: Machine, h: SshConfigHost): boolean {
  if (m.kind !== "ssh") return false;
  const t = m.target.trim().replace(/^ssh:\/\//, "");
  return t === h.alias || t === sshResolvedTarget(h);
}

function machinesRows(): MachinesRow[] {
  const saved = loadMachines();
  return saved.map((m) => ({ key: m.id, machine: m }));
}

// The `~/.ssh/config` hosts no saved machine covers. They are not listed —
// the list is the machines — only counted in a hint under it.
function unaddedSshHosts(): SshConfigHost[] {
  const saved = loadMachines();
  return sshConfigHosts().filter((h) => !saved.some((m) => machineCoversHost(m, h)));
}

// The machine a config host stands for, for a test: ssh
// resolves user, port and identity from the entry, so the alias is the
// whole target.
function machineForHost(h: SshConfigHost): Machine {
  return {
    id: `host:${h.alias}`,
    name: h.alias,
    kind: "ssh",
    target: h.alias,
    identity: "",
    options: "",
    context: "",
    namespace: "",
    pod: "",
    path: "",
    lastTest: sshHostTests.get(h.alias) ?? null,
  };
}

/** The transport that reaches `m`, or null when its record is too incomplete. */
function machineTransport(m: Machine): RemoteAgentTransport | null {
  if (m.kind === "kubernetes") {
    if (!m.namespace || !m.pod) return null;
    return {
      kind: "kubectl-exec",
      context: m.context || null,
      namespace: m.namespace,
      pod: m.pod,
      container: null,
      workspace: m.path || null,
    };
  }
  const { user, host, port } = sshTargetParts(m.target);
  if (!host) return null;
  return {
    kind: "ssh",
    user: user || null,
    host,
    port,
    identity_file: m.identity || null,
    remote_path: m.path || null,
    extra_args: m.options ? m.options.split(/\s+/).filter(Boolean) : [],
  };
}

/** `[user@]host[:port]` split up. Built on `parseSshTarget`, which knows an
 *  IPv6 literal is all colons. */
function sshTargetParts(target: string): { user: string; host: string; port: number | null } {
  const { dest, port } = parseSshTarget(target);
  const at = dest.lastIndexOf("@");
  const user = at >= 0 ? dest.slice(0, at) : "";
  const host = (at >= 0 ? dest.slice(at + 1) : dest).replace(/^\[(.*)\]$/, "$1");
  return { user, host, port: port === null ? null : Number(port) };
}

/** The identity `m` attaches as, built like a session's `remote.detail` so a
 *  configured machine can be recognised among the open windows. */
function machineFacetKey(m: Machine): string {
  if (m.kind === "kubernetes") return `kubernetes:${m.namespace}/${m.pod}`;
  // The facet carries no port, so it is dropped here too.
  const { user, host } = sshTargetParts(m.target);
  return `ssh:${user ? `${user}@${host}` : host}`;
}

/** Machines with an open window first, then configured machines without one. */
function scanTargets(): DiscoverTarget[] {
  const active = editor.activeWindow();
  const saved = loadMachines();
  const byMachine = new Map<string, DiscoverTarget>();
  for (const s of orchestratorSessions.values()) {
    // Discovered worktrees and placeholders have no window to borrow.
    if (s.id <= 0 || s.pending) continue;
    const key = s.remote ? `${s.remote.kind}:${s.remote.detail}` : "local";
    const label = s.remote ? `${s.remote.detail} · ${s.remote.kind}` : editor.t("machine.local");
    const seen = byMachine.get(key);
    const seenWindow =
      seen && seen.spec && "kind" in seen.spec && seen.spec.kind === "window"
        ? (seen.spec.window ?? active)
        : null;
    // The active window wins, then the lowest id, so the choice is stable.
    if (!seen || s.id === active || (seenWindow !== active && s.id < seenWindow!)) {
      byMachine.set(key, {
        key,
        label,
        spec: { kind: "window", window: s.id },
        connects: false,
        reach: discoverReachOf(s.remote, saved),
      });
    }
  }
  // With no orchestrator session, the active window is still scannable.
  if (byMachine.size === 0) {
    byMachine.set("active", {
      key: "active",
      label: editor.getAuthorityLabel() || editor.t("machine.local"),
      spec: { kind: "window", window: active },
      connects: false,
      reach: { kind: "option", key: "local" },
    });
  }
  const targets = [...byMachine.values()].sort((a, b) => {
    const aHere = a.key === "local" || a.key === "active";
    const bHere = b.key === "local" || b.key === "active";
    if (aHere !== bHere) return aHere ? -1 : 1;
    return a.label.localeCompare(b.label);
  });
  for (const m of saved) {
    if (byMachine.has(machineFacetKey(m))) continue;
    // No window, so the scan dials it. Core builds that connection with
    // trust blocked, so it is read-only.
    const transport = machineTransport(m);
    targets.push({
      key: `machine:${m.id}`,
      label: m.name,
      spec: transport,
      connects: transport !== null,
      reach: { kind: "option", key: m.id },
    });
  }
  // "All machines" goes last because it is the expensive choice, and only
  // when there is more than one machine to scan.
  if (targets.filter((t) => t.spec !== null).length > 1) {
    targets.push({
      key: DISCOVER_ALL_KEY,
      label: editor.t("machine.all"),
      spec: null,
      connects: false,
      all: true,
    });
  }
  return targets;
}

/** Where the form opens for a window's machine: the saved machine matching
 *  its facet, else the window's own host or pod. Only a window with no
 *  remote is Local. */
function discoverReachOf(
  remote: AgentSession["remote"],
  saved: Machine[],
): FormSeed {
  if (!remote) return { kind: "option", key: "local" };
  const facet = `${remote.kind}:${remote.detail}`;
  const match = saved.find((m) => machineFacetKey(m) === facet);
  if (match) return { kind: "option", key: match.id };
  if (remote.kind === "kubernetes") {
    const slash = remote.detail.indexOf("/");
    return slash >= 0
      ? { kind: "kubernetes", namespace: remote.detail.slice(0, slash), pod: remote.detail.slice(slash + 1) }
      : { kind: "kubernetes", namespace: "", pod: remote.detail };
  }
  if (remote.kind === "ssh") return { kind: "ssh", target: remote.detail };
  // A devcontainer is located from the project path in the prefill.
  return { kind: "option", key: remote.kind === "devcontainer" ? "devcontainer" : "local" };
}

function openMachinesDialog(): void {
  // Another `fresh` may have added, edited or removed a machine since this
  // session last read them. Re-read before the list goes on screen.
  invalidateMachines();
  const idx = machinesState?.index ?? 0;
  machinesState = { index: Math.max(0, Math.min(idx, machinesRows().length - 1)) };
  machinesPanel = new FloatingWidgetPanel();
  // The Projects dialog's frame and grid, so the two managers read alike.
  machinesPanel.mount(buildMachinesSpec(), {
    widthPct: FORM_WIDTH_PCT,
    heightPct: 70,
    focusMarker: true,
    labelAlign: "right",
    title: editor.t("machine.list_title"),
    closable: true,
    mode: MACHINES_MODE,
  });
  editor.floatingPanelControl(machinesPanel.id(), "fullscreen", 1);
  machinesPanel.setFocusKey("machines");
  machinesPanel.setSelectedIndex("machines", machinesState.index);
}

function closeMachinesDialog(): void {
  if (machinesPanel) {
    machinesPanel.unmount();
    machinesPanel = null;
  }
  machinesState = null;
}

// The list's columns, sized to what they hold: the longest name and the
// longest address, each plus a gap.
interface MachinesCols {
  name: number;
  addr: number;
}

function machinesCols(rows: MachinesRow[]): MachinesCols {
  const w = (s: string): number => editor.stringWidth(s);
  return {
    name: Math.max(0, ...rows.map((r) => w(machineRowName(r)))) + 3,
    addr: Math.max(0, ...rows.map((r) => w(machineRowAddress(r)))) + 3,
  };
}

function machineRowName(r: MachinesRow): string {
  return r.machine?.name ?? r.host?.alias ?? "";
}

function machineRowAddress(r: MachinesRow): string {
  return r.host ? sshResolvedTarget(r.host) : r.machine ? machineSummary(r.machine) : "";
}

// `name  kind  address  state`: the state is the last test's answer, with
// the workspaces open on it, or `not added` for a config host.
function machinesRowEntry(r: MachinesRow, cols: MachinesCols): TextPropertyEntry {
  const dim = { fg: "ui.menu_disabled_fg" };
  const pad = (s: string, n: number): string => s + " ".repeat(Math.max(0, n - editor.stringWidth(s)));
  const m = r.machine ?? machineForHost(r.host!);
  const state: StyledSegment[] = [];
  if (r.host) {
    state.push({ text: editor.t("machine.not_added"), style: { fg: "diagnostic.warning_fg" } });
  } else {
    const t = m.lastTest;
    state.push(
      t === null
        ? { text: "—", style: dim }
        : t.ok
        ? { text: editor.t("machine.test_ok"), style: { fg: "ui.help_key_fg" } }
        : { text: `✗ ${agoText(t.at)}`, style: { fg: "diagnostic.error_fg" } },
    );
    const n = machineWorkspaceCount(m);
    if (n > 0) state.push({ text: ` · ${editor.t("machine.workspaces", { n: String(n) })}`, style: dim });
  }
  return styledRow([
    { text: pad(machineRowName(r), cols.name) },
    { text: pad(machineKindTag(m), 5), style: dim },
    { text: pad(machineRowAddress(r), cols.addr), style: dim },
    ...state,
  ]);
}

// The machines in a box, and one footer: add a machine, open the selected
// one, close. Local is not listed: there is nothing to set up about it, and
// every machine picker offers it first.
function buildMachinesSpec(): WidgetSpec {
  const st = machinesState!;
  const rows = machinesRows();
  const sel = rows[st.index] ?? null;
  const cols = machinesCols(rows);
  return col(
    spacer(0),
    row(spacer(2), labeledSection({
      label: rows.length
        ? editor.t("machine.list_count", { count: String(rows.length) })
        : editor.t("machine.list_title"),
      child: list({
        items: rows.map((r) => machinesRowEntry(r, cols)),
        itemKeys: rows.map((r) => r.key),
        selectedIndex: st.index,
        // Three rows even when empty, so the box reads as a list.
        visibleRows: Math.max(3, Math.min(8, rows.length)),
        key: "machines",
      }),
    })),
    ...machinesHint(),
    spacer(0),
    footerRule(),
    spacer(0),
    row(
      spacer(2),
      button(`+ ${editor.t("machine.add")}`, { key: "machines-add" }),
      spacer(3),
      // Opens the selected row: a saved machine to edit, a config host to
      // set up. Inert with nothing selected.
      withAccel(
        button(editor.t(sel?.host ? "machine.btn_setup" : "machine.btn_edit_more"), {
          key: "machines-open",
          disabled: !sel,
        }),
        "⏎",
      ),
      flexSpacer(),
      withAccel(button(editor.t("machine.btn_close"), { key: "machines-close" }), "Esc"),
      spacer(2),
    ),
    spacer(0),
  );
}

// Under the list, in the list's inner column: how many config hosts are
// waiting to be added, and how.
function machinesHint(): WidgetSpec[] {
  const n = unaddedSshHosts().length;
  if (n === 0) return [];
  return [label(`  ${editor.t("machine.hosts_not_added", { count: String(n) })}`, { style: NOTE_STYLE })];
}

function renderMachinesDialog(): void {
  if (machinesPanel && machinesState) {
    machinesPanel.update(buildMachinesSpec());
    machinesPanel.setSelectedIndex("machines", machinesState.index);
  }
}

function machinesSelected(): MachinesRow | null {
  return machinesState ? machinesRows()[machinesState.index] ?? null : null;
}

// Open the selected row: a config host is set up as a machine, a saved
// machine is edited.
function openSelectedMachine(): void {
  const row = machinesSelected();
  if (!row) return;
  closeMachinesDialogKeepDock();
  if (row.host) openMachineDialog(null, "machines", row.host);
  else if (row.machine) openMachineDialog(row.machine, "machines");
}

// Enter on the list or a button is the control's own; this is Enter with
// nothing focused, which opens the highlighted machine.
const MACHINES_MODE_BINDINGS: string[][] = [
  ["Enter", "orchestrator_machines_enter"],
];
editor.defineMode(MACHINES_MODE, MACHINES_MODE_BINDINGS, true, true);

registerHandler("orchestrator_machines_enter", () => {
  if (!machinesPanel || !machinesState) return;
  const focus = machinesPanel.focusKey();
  if (focus === "machines" || focus === "") openSelectedMachine();
});

function handleMachinesEvent(e: WidgetEvt): void {
  const st = machinesState!;
  if (e.event_type === "cancel") {
    machinesPanel = null;
    closeMachinesDialog();
    return;
  }
  if (isListEvent(e as { event_type: string; widget_key?: string; payload?: unknown }, "machines")) {
    const payload = (e.payload ?? {}) as Record<string, unknown>;
    const idx = typeof payload.index === "number" ? payload.index : -1;
    if (e.event_type === "select" && idx >= 0) {
      const changed = idx !== st.index;
      st.index = idx;
      // The open button's label follows the row.
      if (changed) renderMachinesDialog();
    } else if (e.event_type === "activate") {
      if (idx >= 0) st.index = idx;
      openSelectedMachine();
    }
    return;
  }
  if (e.event_type !== "activate") return;
  switch (e.widget_key) {
    case "machines-add":
      closeMachinesDialogKeepDock();
      openMachineDialog(null, "machines");
      return;
    case "machines-open":
      openSelectedMachine();
      return;
    case "machines-close":
      closeMachinesDialog();
      return;
  }
}

// Close the list on the way to a dialog that comes back to it: the dock
// stays blurred meanwhile.
function closeMachinesDialogKeepDock(): void {
  if (machinesPanel) {
    machinesPanel.unmount();
    machinesPanel = null;
  }
}

registerHandler("orchestrator_machines", () => {
  if (machinesPanel) return;
  openMachinesDialog();
});

// === `~/.ssh/config` ========================================================
//
// Reading it is the whole of Fresh's involvement with the file: it populates
// the Host picker and is never written to (design §4.4, §5.3). A host saved
// with Fresh is a Fresh machine; a host here is an ssh host.

interface SshConfigHost {
  alias: string;
  hostName?: string;
  user?: string;
  port?: string;
}

// The editor's resolved home, not the process env: a test that redirects the
// editor's home directory must redirect what `~/.ssh/config` means with it.
function homeDir(): string {
  return editor.getHomeDir() || editor.getEnv("HOME") || editor.getEnv("USERPROFILE") || "";
}

// Expand a leading `~` and resolve a relative path against `~/.ssh`, which
// is what ssh does for `Include` and identity files.
function sshPath(p: string): string {
  const home = homeDir();
  if (p.startsWith("~/")) return `${home}/${p.slice(2)}`;
  if (p.startsWith("/") || /^[A-Za-z]:[\\/]/.test(p)) return p;
  return `${home}/.ssh/${p}`;
}

// The files a (possibly globbed) `Include` names. One `*`/`?` glob in the
// last segment is what managed setups use (`config.d/*`); anything fancier
// is matched as a literal.
function sshIncludeFiles(pattern: string): string[] {
  const full = sshPath(pattern);
  const slash = full.lastIndexOf("/");
  const dir = slash >= 0 ? full.slice(0, slash) : ".";
  const leaf = slash >= 0 ? full.slice(slash + 1) : full;
  if (!/[*?]/.test(leaf)) return editor.fileExists(editor.localPath(full)) ? [full] : [];
  const re = new RegExp("^" + leaf.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\?/g, ".") + "$");
  try {
    return editor.readDir(editor.localPath(dir))
      .filter((e) => !e.is_dir && re.test(e.name))
      .map((e) => `${dir}/${e.name}`)
      .sort();
  } catch {
    return [];
  }
}

// Parse one ssh config file into `hosts`, following `Include`. A `Host`
// line carries several aliases and every one of them gets the block's
// settings; patterns (`*`, `?`, `!`) are defaults, not hosts, and are
// dropped; ssh's first-obtained-value-wins rule is kept per alias.
// `seen` is every config path already parsed on this walk. The depth cap
// alone bounds recursion but not work: `Include config.d/*` in a file that
// the glob itself matches re-reads the whole directory at every level, so a
// user with twenty files there pays twenty to the eighth. Visiting each file
// once also makes a diamond include (two files including a third) parse it
// once, which is what OpenSSH's first-value-wins semantics assume anyway.
function parseSshConfig(
  path: string,
  hosts: SshConfigHost[],
  depth: number,
  seen: Set<string>,
): void {
  if (depth > 8 || seen.has(path)) return;
  seen.add(path);
  // The config lives on this machine even when the active window is a
  // remote one, hence `localPath`. A missing file reads back as null or
  // undefined depending on the path form; either way nothing to parse.
  const text = editor.readFile(editor.localPath(path));
  if (!text) return;
  let block: SshConfigHost[] = [];
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (line === "" || line.startsWith("#")) continue;
    const m = /^(\S+?)(?:\s*=\s*|\s+)(.*)$/.exec(line);
    if (!m) continue;
    const key = m[1].toLowerCase();
    const value = m[2].trim().replace(/^"(.*)"$/, "$1");
    if (key === "host") {
      block = [];
      for (const alias of value.split(/\s+/)) {
        if (!alias || /[*?!]/.test(alias)) continue;
        let h = hosts.find((x) => x.alias === alias);
        if (!h) {
          h = { alias };
          hosts.push(h);
        }
        block.push(h);
      }
      continue;
    }
    if (key === "match") {
      block = [];
      continue;
    }
    if (key === "include") {
      for (const pat of value.split(/\s+/)) {
        for (const file of sshIncludeFiles(pat)) parseSshConfig(file, hosts, depth + 1, seen);
      }
      continue;
    }
    for (const h of block) {
      if (key === "hostname" && h.hostName === undefined) h.hostName = value;
      else if (key === "user" && h.user === undefined) h.user = value;
      else if (key === "port" && h.port === undefined) h.port = value;
    }
  }
}

// Every named host `~/.ssh/config` configures, in file order. Empty when
// there is no config, so the form falls back to a plain Host field.
function sshConfigHosts(): SshConfigHost[] {
  const hosts: SshConfigHost[] = [];
  const home = homeDir();
  if (home) parseSshConfig(`${home}/.ssh/config`, hosts, 0, new Set());
  return hosts;
}

// What ssh will connect to for a picked host, for the note under the
// picker: `user@hostname:port`, with the alias standing in for a `HostName`
// that carries a `%h`-style token ssh expands and we cannot.
function sshResolvedTarget(h: SshConfigHost): string {
  const raw = h.hostName && !h.hostName.includes("%") ? h.hostName : h.alias;
  // An IPv6 literal is bracketed, so the `:port` this appends is still the
  // port — `::1` and `22` joined bare reads as a host of `::1:22`, which
  // `parseSshTarget` can only take whole, losing the port.
  const host = raw.includes(":") && !raw.startsWith("[") ? `[${raw}]` : raw;
  return (h.user ? `${h.user}@` : "") + host + (h.port ? `:${h.port}` : "");
}


// === The form grid ==========================================================
//
// One rule does most of the work: every control shares `FORM_LABEL_W` and the
// panel is mounted `labelAlign: "right"`, so every `[` opens on one column and
// a control without a label of its own indents into it. No boxes — the
// alignment does the grouping.

// The label column, in cells. Wide enough for the longest English label
// ("New branch name"); a longer translation is trimmed to the column with `…`.
const FORM_LABEL_W = 16;

// The form's size, as a percentage of the screen: wide enough that an
// accepted Project Path completion fits with its cursor. Both are the
// panel's mount options and nothing else may restate them — the fit test
// below reads `FORM_HEIGHT_PCT` rather than approximating it.
const FORM_WIDTH_PCT = 75;
const FORM_HEIGHT_PCT = 90;

// How long the form's remote git probe waits for a connection. Short,
// because it runs while the user is still typing and a dialog that stalls on
// an unreachable host is worse than one that says it could not tell. The
// create itself is allowed longer — by then the user has committed.
const REMOTE_PROBE_TIMEOUT_S = 6;
const REMOTE_CREATE_TIMEOUT_S = 20;

// Drop the trailing colon some labels carry — the control adds its own.
function formLabel(key: string): string {
  return editor.t(key).replace(/[:：]\s*$/, "");
}

// Several labels spell a hint in a trailing parenthetical — `Host  ([user@]
// host[:port])`, `Target  (.fresh/k8s.json — optional)` — in every locale.
// The grid has no room for it beside the label, so split it: the word goes
// in the label column and the hint under the field (design §3.7).
function splitLabel(key: string): { label: string; hint: string } {
  const s = editor.t(key);
  const m = /^(.*?)\s*[(（](.*)[)）]\s*$/.exec(s);
  return m ? { label: m[1].trim(), hint: m[2].trim() } : { label: s.trim(), hint: "" };
}

// A hint's text as a note: the `↳` / `ⓘ` some strings already lead with is
// the note's own glyph, so it is not doubled.
function noteText(s: string): string {
  return s.replace(/^\s*[↳ⓘ]\s*/, "").replace(/\s+·\s+/g, " · ");
}

// A placeholder that carries an instruction in a trailing parenthetical —
// `pod name (kubectl get pods)`, `HEAD  (no origin configured)` — splits the
// same way a label does: the example stays in the value slot, the
// instruction goes under the field. A value slot shows a value (design §3.7).
function splitPlaceholder(s: string): { placeholder: string; note: string } {
  const m = /^(.*?)\s*[(（](.*)[)）]\s*$/.exec(s);
  return m ? { placeholder: m[1].trim(), note: m[2].trim() } : { placeholder: s.trim(), note: "" };
}

const NOTE_STYLE = { fg: "ui.menu_disabled_fg", italic: true } as const;

// A button and its accelerator, as one unit: a nested row is never split by
// a wrapping row, so a narrow footer never strands an `Esc` on a line of its
// own.
function withAccel(b: WidgetSpec, k: string): WidgetSpec {
  return row(b, label(k, { style: NOTE_STYLE }));
}

// One row under a field, in the field column: `↳ hint`.
function fieldNote(text: string, style: Partial<OverlayOptions> = NOTE_STYLE): WidgetSpec {
  return label(`↳ ${noteText(text)}`, { labelWidth: FORM_LABEL_W, style });
}

// One row of the grid: `<label>: [ value ]`, plus an optional note under it.
function field(
  lbl: string,
  slot: { value: string; cursor: number },
  o: { key?: string; placeholder?: string; note?: string | undefined; combo?: boolean },
): WidgetSpec[] {
  const out: WidgetSpec[] = [
    text({
      value: slot.value,
      cursorByte: slot.cursor,
      label: lbl,
      placeholder: o.placeholder,
      fullWidth: true,
      labelWidth: FORM_LABEL_W,
      combo: o.combo,
      key: o.key,
    }),
  ];
  if (o.note) out.push(fieldNote(o.note));
  return out;
}

// A form toggle: chip-first, indented into the field column.
function formToggle(checked: boolean, lbl: string, key: string): WidgetSpec {
  return toggle(checked, lbl, { key, labelWidth: FORM_LABEL_W });
}

// === The Machine control (design §5.1, §3.8) ===============================
//
// The form's one host control, in every mode: Local, the saved machines and
// the devcontainer in this project. A remote runs only on a saved machine;
// the `+ Add machine…` button under the control is how one is added.

interface MachineOption {
  key: string;
  label: string;
  kind: "local" | "machine" | "devcontainer";
  machine?: Machine;
}

function machineOptions(): MachineOption[] {
  const out: MachineOption[] = [{ key: "local", label: editor.t("machine.local"), kind: "local" }];
  for (const m of loadMachines()) out.push({ key: m.id, label: m.name, kind: "machine", machine: m });
  out.push({ key: "devcontainer", label: editor.t("backend.devcontainer"), kind: "devcontainer" });
  // **No "Add machine…" option here.** Picking it only *armed* a choice that
  // a further, unadvertised Enter completed. Adding a machine is the
  // `+ Add machine…` button under the control, which does what it says.
  return out;
}

// What the picked option resolves to, for the note under the control.
function machineOptionNote(o: MachineOption): string {
  switch (o.kind) {
    case "local":
      return editor.t("machine.local_summary");
    case "machine":
      return `${machineKindTag(o.machine!)} · ${machineSummary(o.machine!)}`;
    case "devcontainer":
      return editor.t("machine.devcontainer_summary");
    default:
      return "";
  }
}

function applyMachinePick(index: number): void {
  if (!form) return;
  const opts = machineOptions();
  const o = opts[index];
  if (!o) return;
  form.machinePick = index;
  form.machineId = null;
  switch (o.kind) {
    case "local":
      form.backend = "local";
      break;
    case "machine":
      form.backend = o.machine!.kind;
      form.machineId = o.machine!.id;
      break;
    case "devcontainer":
      form.backend = "devcontainer";
      break;
  }
  form.lastError = null;
  // A different machine is a different filesystem: the last answer belongs to
  // the host that gave it, so it is dropped rather than shown against the new
  // one, and a fresh probe is scheduled for whatever this is.
  form.remoteIsGit = null;
  form.remoteRepoRoot = "";
  form.remoteDefaultBranch = "";
  form.remoteProbeError = "";
  form.remoteProbing = false;
  scheduleRemoteReprobe();
  closeCompletion();
}

/** How `agent` rejoins session `id`, per the agent registry. `exact` is false
 *  for an agent with no id-addressed resume (codex `resume --last` takes the
 *  newest session in the directory), and when no id is known (empty). */
function resumeArgv(agent: string, id: string): { argv: string[]; exact: boolean } | null {
  const entry = agentEntryForCmd(agent);
  if (!entry) return null;
  if (entry.spec.provision && id) {
    return {
      argv: [agent, ...entry.spec.provision.resumeArgs.map((a) => a.replace("{id}", id))],
      exact: true,
    };
  }
  if (entry.spec.continue) {
    return { argv: [agent, ...entry.spec.continue.resumeArgs], exact: false };
  }
  return null;
}

/** Open the New Workspace form on `seed` with `prefill` filled in; how a
 *  discovered session is rejoined. The form, not a silent launch, so the
 *  reader sees what will run where and a connect gets its trust decision. */
function openWorkspaceForm(
  seed: FormSeed,
  prefill: {
    projectPath: string;
    cmd: string;
    createWorktree?: boolean;
    /** The session's own name, for the workspace it becomes. */
    label?: string;
    /** The Claude cloud session this workspace is a teleported copy of. */
    teleportOf?: string;
  },
): void {
  pendingFormPrefill = prefill;
  if (seed.kind === "option") {
    pendingFormMachine = seed;
    dockBlurred = true;
    openForm({ fromPicker: true });
    return;
  }
  // A machine that is not saved (an open window's host or pod): a workspace
  // runs only on a saved machine, so it is added first, prefilled, and the
  // form follows on Save.
  const template: Partial<Machine> = seed.kind === "ssh"
    ? { kind: "ssh", target: seed.target, name: sshTargetParts(seed.target).host }
    : { kind: "kubernetes", namespace: seed.namespace, pod: seed.pod, name: seed.pod };
  openMachineDialog(null, "form", undefined, template);
}

function seedFormMachine(): void {
  if (!form) return;
  const asked = pendingFormMachine;
  pendingFormMachine = undefined;
  if (asked === undefined) {
    const last = editor.getGlobalState("orchestrator.last_machine");
    if (typeof last === "string") pickMachineOption(last);
    return;
  }
  // Only a saved machine reaches the form; `openWorkspaceForm` adds any other
  // first.
  if (asked.kind === "option") pickMachineOption(asked.key);
}

/** Apply the `machineOptions()` entry with this key, if it is offered. */
function pickMachineOption(key: string): void {
  const idx = machineOptions().findIndex((o) => o.key === key);
  if (idx >= 0) applyMachinePick(idx);
}

// The Machine control: the first row of WHERE, with `+ Add machine…` beside
// it — the shared Machine picker.
function machinePickerRow(): WidgetSpec {
  const opts = machineOptions();
  // Machines can be deleted while the form is open, so the stored pick is
  // re-clamped here rather than only where it is drawn.
  if (form!.machinePick >= opts.length || form!.machinePick < 0) applyMachinePick(0);
  return machinePicker({
    options: opts.map((o) => o.label),
    selectedIndex: form!.machinePick,
    label: formLabel("form.machine"),
    labelWidth: FORM_LABEL_W,
    key: "machine",
    addKey: "form_add_machine",
    addLabel: `+ ${editor.t("machine.add")}`,
  });
}

// The Machine row — the control, then `+ Add machine…` right beside it — and
// under it what a non-local machine resolves to (`user@host:port`, a pod);
// Local needs no gloss.
function machineRows(): WidgetSpec[] {
  const o = machineOptions()[form!.machinePick];
  const note = !o || o.kind === "local" ? "" : machineOptionNote(o);
  const out: WidgetSpec[] = [
    machinePickerRow(),
  ];
  if (note) out.push(label(noteText(note), { labelWidth: FORM_LABEL_W, style: NOTE_STYLE }));
  return out;
}

// Agent selector: a single dropdown of the preset labels (terminal, the
// known agents, custom…). ←/→ or ↑/↓ over it cycles; the change event maps
// the chosen index back to a preset and applies it (fills the command field).
function agentPresetRow(): WidgetSpec {
  const presets = agentPresets();
  const activeKey = activeAgentPresetKey();
  const selectedIndex = Math.max(0, presets.findIndex((p) => p.key === activeKey));
  return dropdown(presets.map((p) => p.label), {
    selectedIndex,
    label: formLabel("form.agent"),
    labelWidth: FORM_LABEL_W,
    key: "agent_dropdown",
  });
}

// The raw launch command is revealed by the dropdown: it shows once the agent
// is `custom…` — picked, or implied by a command no preset spells — and a
// preset fills it, so there is nothing to see otherwise.
function cmdVisible(): boolean {
  return !!form && activeAgentPresetKey() === "agent-preset-custom";
}

function cmdField(f: NewSessionForm): WidgetSpec[] {
  // Clearing the field falls back to the backend default: a bare local
  // terminal (the host resolves `$SHELL`), or — for SSH — letting ssh
  // spawn the remote login shell. The placeholder names that default.
  const ssh = splitPlaceholder(editor.t("form.cmd_placeholder_ssh"));
  return field(formLabel("form.agent_command"), f.cmd, {
    key: "cmd",
    placeholder: f.backend === "ssh" ? ssh.placeholder : editor.t("form.agent_terminal"),
    note: f.backend === "ssh" ? ssh.note : undefined,
  });
}

// "Teach Fresh CLI" is local-only: the CLI it teaches drives this editor
// over a local socket, which a shell on another machine cannot reach.
function teachApplies(): boolean {
  return !!form && (form.target === "current" || form.backend === "local");
}

// "Start prompt": for an agent that takes a launch prompt. Sits right under
// the agent it is handed to.
function startPromptFields(): WidgetSpec[] {
  if (!form) return [];
  if (!activeAgentEntry()?.prompt) return [];
  return field(formLabel("form.start_prompt"), form.startPrompt, {
    key: "start_prompt",
    // Single-line to stay consistent with the form's keyboard model (Enter
    // advances focus, Ctrl+Enter submits); the whole prompt is handed to
    // the agent as one launch argument.
    placeholder: editor.t("form.start_prompt_placeholder"),
  });
}

// "Auto mode" / "Teach the agent the Fresh CLI": the agent's own switches,
// each shown only for an agent that has the flag or strategy behind it.
function agentSwitchFields(): WidgetSpec[] {
  if (!form) return [];
  const entry = activeAgentEntry();
  if (!entry) return [];
  const out: WidgetSpec[] = [];
  if (entry.auto) {
    out.push(formToggle(form.autoMode, editor.t("form.auto_mode"), "auto_mode"));
  }
  if (entry.systemPrompt && teachApplies()) {
    out.push(formToggle(form.teachFreshCli, editor.t("form.teach_fresh_cli"), "teach_fresh_cli"));
  }
  return out;
}

// Local backend: Project Path, with the linked-worktree hint under it.
function localBodyFields(): WidgetSpec[] {
  if (!form) return [];
  // The value slot shows the default itself (dim, as every placeholder is);
  // the note under it says that blank means this path. Submitting with the
  // field empty uses it.
  const fields = field(formLabel("form.folder"), form.projectPath, {
    key: "project_path",
    placeholder: form.defaultProjectPath || editor.t("form.detecting_project_root"),
  });
  if (form.projectPathIsLinkedWorktree === true) {
    fields.push(
      fieldNote(
        form.createWorktree
          ? editor.t("form.linked_worktree_uncheck")
          : editor.t("form.linked_worktree_attach"),
        { fg: "ui.help_key_fg", italic: true },
      ),
    );
  }
  return fields;
}

// What the workspace will be called: the typed name, or the auto-generated
// default the Workspace Name field is showing as its placeholder.
function plannedWorkspaceName(f: NewSessionForm): string {
  return f.name.value.trim() || formDefaultSessionName(f);
}

// The auto-name an empty Workspace field launches with. The folder probe names
// it from the local folder, which says nothing about a repository's clone on
// another machine or one not cloned yet: those take the repository's name.
function formDefaultSessionName(f: NewSessionForm): string {
  const r = formRepo(f);
  if (r && (f.backend !== "local" || formNeedsPlace(f))) {
    const n = ((editor.getGlobalState("orchestrator.session_counter") as number | undefined) ?? 0) + 1;
    return `${sessionNameBaseFor(r.name)}-${n}`;
  }
  return f.defaultSessionName;
}

// The one line that says what `Create` will actually do to the repository.
//
// The hint this replaces read "leave empty to use provided branch", and the
// code does the opposite: with both branch fields blank, `git worktree add`
// is given `-b <workspace name>` off the default branch, so a user following
// the hint silently got a branch they never asked for. Rather than restate
// the rule in better prose — a rule with three arms, two of which depend on
// fields above — the form names the branch. A preview cannot drift from the
// behaviour the way a sentence about it can.
//
// `base` is the fork point as the create resolves it: the typed Checkout
// branch, else the detected default. Blank on a remote host that has not
// answered yet, where the far side's `git worktree add` picks the fork point
// and this side would only be guessing.
// `typedBase` is what the user actually put in "Checkout branch"; `fallback`
// is the detected default shown there as a placeholder. The two are NOT
// interchangeable, and conflating them is what this function got wrong first
// time round: the create has three arms, and which one runs turns on whether
// Checkout branch was *typed*, not on what the field displays.
//
//   new branch set              → cut `newBranch` off the base
//   new branch blank, base set  → check `base` out; NO new branch is cut
//   both blank                  → cut `<workspace name>` off the default
//
// The middle arm is the one a preview that only looked at "is there a base"
// described as cutting a branch. It does not: `runLocalCreate` takes its
// `else if (checkoutBranch)` arm and `createRemoteWorktree` omits `-b`.
function branchPlanNote(f: NewSessionForm, typedBase: string, fallback: string): string {
  const named = f.newBranch.value.trim();
  if (named) {
    const base = typedBase || fallback;
    return base
      ? editor.t("form.branch_plan", { branch: named, base })
      : editor.t("form.branch_plan_nobase", { branch: named });
  }
  if (typedBase) return editor.t("form.branch_plan_checkout", { base: typedBase });
  const branch = plannedWorkspaceName(f);
  if (!branch) return "";
  return fallback
    ? editor.t("form.branch_plan_default", { branch, base: fallback })
    : editor.t("form.branch_plan_default_nobase", { branch });
}

// Git mode: cut a new worktree, or work in the folder as it is. A radio so
// both outcomes are named; the key stays `worktree`, whose value is
// `createWorktree`.
function gitModeRadio(on: boolean): WidgetSpec {
  const inPlace = form?.repoId ? "form.git_mode_main_clone" : "form.git_mode_folder";
  return radio([editor.t("form.git_mode_worktree"), editor.t(inPlace)], {
    selectedIndex: on ? 0 : 1,
    label: formLabel("form.git_mode"),
    labelWidth: FORM_LABEL_W,
    key: "worktree",
  });
}

// The worktree group (local backend): the toggle, then what it reveals.
// Disclosure is value-driven — the branch field shows on any git path (it
// drives an in-place checkout when no worktree is cut), the new-branch field
// only while a worktree is being created — so there is no fold to open.
function worktreeFields(f: NewSessionForm): WidgetSpec[] {
  const worktreeEnabled = f.projectPathIsGit !== false;
  const on = worktreeEnabled && f.createWorktree;
  const out: WidgetSpec[] = [];
  if (!worktreeEnabled) {
    // Not a git path: say so where the toggle would be, and stop.
    out.push(
      label(`[ ] ${editor.t("form.create_worktree_short")}`, {
        labelWidth: FORM_LABEL_W,
        style: { fg: "ui.menu_disabled_fg" },
      }),
      fieldNote(editor.t("form.disabled_non_git").replace(/^\s*[(（]|[)）]\s*$/g, ""), {
        fg: "ui.menu_disabled_fg",
        italic: true,
      }),
    );
    return out;
  }
  out.push(gitModeRadio(on));
  // "Checkout branch" — an existing branch: with a worktree it's the base
  // the worktree is cut from / checked out to; without one it drives an
  // in-place `git checkout` in the project dir. The value slot shows the
  // default branch (a value); what blank means goes under the field.
  let branch: { placeholder: string; note: string };
  if (!on) {
    branch = { placeholder: "", note: editor.t("form.branch_checkout_inplace") };
  } else if (!f.defaultBranch) {
    branch = { placeholder: editor.t("form.detecting_default_branch"), note: "" };
  } else if (f.defaultBranchIsHeadFallback) {
    branch = splitPlaceholder(editor.t("form.branch_head_fallback"));
  } else {
    branch = { placeholder: f.defaultBranch, note: "" };
  }
  out.push(
    ...field(formLabel(on ? "form.branch_from" : "form.check_out"), f.branch, {
      key: "branch",
      placeholder: branch.placeholder,
      note: branch.note || undefined,
    }),
  );
  // "New branch" — creates the worktree on a freshly-cut branch. Only
  // meaningful when a worktree is being created, so it appears with it. The
  // placeholder is the branch a blank field cuts.
  if (on) {
    out.push(...field(formLabel("form.new_branch_short"), f.newBranch, {
      key: "new_branch",
      placeholder: f.branch.value.trim() ? "" : plannedWorkspaceName(f),
    }));
    // Where the files land. A first-run user expects to be taken to their
    // project and is instead dropped in a deep directory under the data dir,
    // which nothing named beforehand.
    const name = plannedWorkspaceName(f);
    if (name) {
      out.push(spacer(0), label(
        editor.t("form.worktree_at", { path: tildePath(localWorktreePath(f, name)) }),
        { labelWidth: FORM_LABEL_W, style: NOTE_STYLE, wrap: true },
      ));
    }
  }
  return out;
}

// The directory `runLocalCreate` will put the worktree in, for the preview.
// Kept beside the preview rather than shared with the create: the create
// resolves the repository's canonical root first (a probe this side of the
// dialog does not run), so the two agree on the shape and the preview shows
// the project path the user can see in the field above.
function localWorktreePath(f: NewSessionForm, name: string): string {
  const project = expandHome(f.projectPath.value.trim() || f.defaultProjectPath);
  return editor.pathJoin(editor.getDataDir(), "orchestrator", slugify(project), name);
}

// Ask the remote whether the path it was given is a repository, and what it
// has checked out. Debounced by the caller and token-guarded like the local
// probe, because an ssh round trip easily outlives the keystroke that asked
// for it.
async function probeRemoteProjectDefaults(): Promise<void> {
  if (!form || form.backend !== "ssh" || form.target !== "new") return;
  const token = ++form.remoteProbeToken;
  const argv = formSshArgv(form, REMOTE_PROBE_TIMEOUT_S);
  const path = form.sshPath.value.trim() || (form.machineId ? machineById(form.machineId)?.path || "" : "");
  if (!argv || !path) {
    form.remoteIsGit = null;
    form.remoteRepoRoot = "";
    form.remoteDefaultBranch = "";
    form.remoteProbeError = "";
    form.remoteProbing = false;
    renderForm();
    return;
  }
  form.remoteProbing = true;
  renderForm();
  const r = await probeRemoteGit(argv, path);
  if (!form || form.remoteProbeToken !== token) return;
  form.remoteIsGit = r.isGit;
  form.remoteRepoRoot = r.repoRoot;
  form.remoteDefaultBranch = r.defaultBranch;
  form.remoteProbeError = r.error;
  form.remoteProbing = false;
  renderForm();
}

// The worktree group for a remote workspace. Same three controls the local
// one has and the same meanings; what differs is that the answers come from
// the far side, and that "not a repository" and "could not ask" are
// different rows — the second is a connection problem, and saying "non-git"
// for it would send the user to fix the wrong thing.
function remoteWorktreeFields(f: NewSessionForm): WidgetSpec[] {
  const out: WidgetSpec[] = [];
  if (f.remoteProbing) {
    out.push(
      label(`[ ] ${editor.t("form.create_worktree_short")}`, {
        labelWidth: FORM_LABEL_W,
        style: { fg: "ui.menu_disabled_fg" },
      }),
      fieldNote(editor.t("form.remote_probing"), {
        fg: "ui.menu_disabled_fg",
        italic: true,
      }),
    );
    return out;
  }
  if (f.remoteProbeError) {
    // Unreachable: offer the toggle anyway. A host that was merely asleep
    // while the user typed is reachable by the time they press Create, and
    // the remote's own `git rev-parse` is what decides — refusing here would
    // be this side guessing on the strength of one failed connection.
    out.push(gitModeRadio(f.createWorktree));
    // "Could not ask" has two causes that send the user to different places:
    // a host that did not answer, and one that answered with a key we have
    // never seen. The second is not an error the user has to go and fix —
    // Create will ask them to confirm the fingerprint — so it must not read
    // like one.
    out.push(fieldNote(
      isHostKeyFailure(f.remoteProbeError)
        ? editor.t("form.remote_untrusted")
        : editor.t("form.remote_unreachable"),
      { fg: "diff.removed_fg", italic: true },
    ));
    return out;
  }
  if (f.remoteIsGit === false) {
    out.push(
      label(`[ ] ${editor.t("form.create_worktree_short")}`, {
        labelWidth: FORM_LABEL_W,
        style: { fg: "ui.menu_disabled_fg" },
      }),
      fieldNote(editor.t("form.remote_non_git"), {
        fg: "ui.menu_disabled_fg",
        italic: true,
      }),
    );
    return out;
  }
  const on = f.createWorktree;
  out.push(gitModeRadio(on));
  if (f.remoteIsGit === null) {
    out.push(fieldNote(editor.t("form.remote_unknown"), {
      fg: "ui.menu_disabled_fg",
      italic: true,
    }));
    return out;
  }
  // Only the worktree path acts on a branch remotely: with the toggle off the
  // session opens the path exactly as the remote already has it, so offering
  // "Checkout branch" would promise a checkout that nothing performs. The
  // local form can offer it because its toggle-off path really does check out
  // in place.
  if (!on) return out;
  out.push(
    ...field(formLabel("form.branch_from"), f.branch, {
      key: "branch",
      placeholder: f.remoteDefaultBranch,
    }),
  );
  out.push(...field(formLabel("form.new_branch_short"), f.newBranch, {
    key: "new_branch",
    placeholder: f.branch.value.trim() ? "" : plannedWorkspaceName(f),
  }));
  // The remote resolves `$HOME` and the repository's basename itself, so the
  // preview says the shape and fills in the part this side does know — the
  // workspace name — rather than guessing at a path it cannot resolve.
  const name = plannedWorkspaceName(f);
  const repo = f.remoteRepoRoot.split("/").filter(Boolean).pop() ?? "";
  out.push(fieldNote(
    repo && name
      ? editor.t("form.remote_worktree_where_at", { path: `~/.fresh/worktrees/${repo}/${name}` })
      : editor.t("form.remote_worktree_where"),
  ));
  return out;
}

// The remote worktree group's Tab stops, in the order it renders them. The
// "checking…" and "not a repository" rows are dim labels rather than
// controls, so they are no stops at all.
function remoteWorktreeKeys(f: NewSessionForm): string[] {
  if (f.remoteProbing) return [];
  if (f.remoteProbeError) return ["worktree"];
  if (f.remoteIsGit === false) return [];
  if (f.remoteIsGit === null) return ["worktree"];
  return f.createWorktree ? ["worktree", "branch", "new_branch"] : ["worktree"];
}

/** Put a caller's directory into the slot this backend's Project Path reads
 *  (see `projectPathFields`). Empty is left alone so a session with no
 *  recorded directory falls back to the machine's default. */
function applyPrefillPath(path: string): void {
  if (!form || path === "") return;
  const slot = { value: path, cursor: path.length };
  switch (form.backend) {
    case "ssh":
      form.sshPath = slot;
      break;
    case "kubernetes":
      form.k8sWorkspace = slot;
      break;
    default:
      form.projectPath = slot;
      break;
  }
}

// One Project Path in every mode (§3.8): the directory the workspace is
// rooted at, wherever that is. The hint under it says what blank means.
function projectPathFields(): WidgetSpec[] {
  if (!form) return [];
  const lbl = formLabel("form.folder");
  const m = form.machineId ? machineById(form.machineId) : null;
  switch (form.backend) {
    case "local":
      return localBodyFields();
    case "devcontainer":
      return field(lbl, form.projectPath, {
        key: "project_path",
        placeholder: form.defaultProjectPath || editor.t("form.devcontainer_path_placeholder"),
        note: editor.t("form.devcontainer_hint"),
      });
    case "ssh":
      return field(lbl, form.sshPath, {
        key: "ssh_path",
        placeholder: m?.path || undefined,
        note: m?.path ? editor.t("form.machine_path_note") : editor.t("form.ssh_remote_path_placeholder"),
      });
    case "kubernetes":
      return field(lbl, form.k8sWorkspace, {
        key: "k8s_workspace",
        placeholder: m?.path || editor.t("form.k8s_workspace_placeholder"),
        note: m?.path ? editor.t("form.machine_path_note") : editor.t("form.k8s_workspace_note"),
      });
  }
}

// The mode-only tail (§3.8): what has no equivalent elsewhere — the worktree
// group. Each starts with its own blank row.
function modeTailFields(f: NewSessionForm): WidgetSpec[] {
  if (f.target !== "new") return [];
  if (f.backend === "local") return worktreeFields(f);
  // A remote workspace gets the same worktree offer a local one does — the
  // repository is simply on the other side of the connection.
  if (f.backend === "ssh") {
    return remoteWorktreeFields(f);
  }
  return [];
}

// The tail's Tab stops, mirroring `modeTailFields` branch for branch. Both
// backends offer a real worktree group now, and its rows come and go on the
// same conditions — so the cycle reads the renderer's own state rather than
// keeping a second opinion about which rows exist.
function tailFocusKeys(f: NewSessionForm): string[] {
  if (f.target !== "new") return [];
  if (f.backend === "local") {
    if (f.projectPathIsGit === false) return [];
    return f.createWorktree
      ? ["worktree", "branch", "new_branch"]
      : ["worktree", "branch"];
  }
  if (f.backend === "ssh") return remoteWorktreeKeys(f);
  return [];
}

// While a submit is in flight the dialog is disabled: a read-only summary in
// place of the fields, only Cancel actionable. It holds until the attach
// resolves — success closes the dialog, failure flips `submitting` back off
// and re-renders the editable form with the error.
function buildConnectingView(): WidgetSpec {
  if (!form) return col();
  const dim = { fg: "ui.menu_disabled_fg" } as const;
  const roRow = (lbl: string, value: string): WidgetSpec =>
    label(`${lbl}: ${value || "—"}`, { style: dim });
  const rows: WidgetSpec[] = [];
  const machine = form.machineId ? machineById(form.machineId) : null;
  if (form.backend === "ssh") {
    rows.push(roRow(editor.t("form.ro_run_in"), machine ? machine.name : editor.t("backend.ssh")));
    rows.push(roRow(editor.t("form.ro_host"), machine ? machine.target : ""));
    if (form.sshPath.value.trim()) rows.push(roRow(editor.t("form.ro_remote_path"), form.sshPath.value.trim()));
  } else if (form.backend === "kubernetes") {
    rows.push(roRow(editor.t("form.ro_run_in"), machine ? machine.name : editor.t("backend.kubernetes")));
    rows.push(roRow(editor.t("form.ro_pod"), machine ? `${machine.namespace}/${machine.pod}` : ""));
  } else {
    rows.push(roRow(
      editor.t("form.ro_run_in"),
      form.backend === "devcontainer" ? editor.t("backend.devcontainer") : editor.t("backend.local"),
    ));
    rows.push(roRow(editor.t("form.ro_project"), form.projectPath.value.trim() || form.defaultProjectPath));
  }
  const name = form.name.value.trim();
  if (name) rows.push(roRow(editor.t("form.ro_workspace"), name));

  const remote = form.backend === "ssh" || form.backend === "kubernetes";
  return col(
    // The "ORCHESTRATOR :: New Workspace" title is native modal-frame
    // chrome (set on the panel at mount time and kept across the
    // connecting-state re-render), so no in-body banner is drawn here.
    ...rows,
    spacer(0),
    label(
      (remote ? editor.t("form.connecting") : editor.t("form.creating_workspace")) +
        editor.t("form.press_cancel_abort"),
      { style: NOTE_STYLE },
    ),
    spacer(0),
    endRow(
      button(editor.t("form.btn_cancel"), { intent: "danger", key: "cancel" }),
      spacer(2),
      button(editor.t("form.btn_create"), { intent: "primary", key: "create", disabled: true }),
    ),
  );
}

// Whether the form has enough input to create: the per-backend minimum
// required field. Gates the Create buttons (rendered disabled otherwise) and
// guards the submit paths so an empty form can't be submitted via Enter.
function formIsSubmittable(): boolean {
  if (!form) return false;
  if (form.agentUnset) return false;
  // Running in the current workspace needs no input at all — worst case it
  // opens a bare terminal here, which is always possible.
  if (form.target === "current") return true;
  if (formRepoBlocker(form)) return false;
  switch (form.backend) {
    case "local":
      // Mirror `captureCreateSpec`'s fallback chain EXACTLY: a local
      // workspace can always be created against `localProjectDefault()`
      // (the cwd) even before the async canonical-root probe
      // (`probeProjectPathDefaults`) has filled `defaultProjectPath`.
      // Omitting that same fallback here — while capture uses it — let a
      // Ctrl+Enter / Create that arrived during the probe window fail this
      // gate and be silently dropped (`if (!formIsSubmittable()) return`).
      // The dialog then never advanced and an unbounded `wait_until` hung
      // until the CI timeout; the probe's `git` round-trip is slow enough
      // under load (macOS CI) to widen that window into the common case.
      return !!(
        form.projectPath.value.trim() ||
        form.defaultProjectPath ||
        localProjectDefault()
      );
    case "devcontainer":
      return !!(form.projectPath.value.trim() || form.defaultProjectPath);
    case "ssh":
    case "kubernetes":
      return !!form.machineId;
  }
}

// ── The launch form's layout ──────────────────────────────────────────────────
//
// Sections top to bottom: the mode switch, PROMPT, AGENT, WHERE (new
// workspace only), GIT (details open, git paths only), then the footer. The
// prompt, the agent and the footer never move; everything that changes height
// sits between them and grows only when the user asked for it (the details
// fold, a typed host, a warning). There is no row reservation: a section is
// as tall as what it shows.

// Rows of the prompt box when it is short: two on a short terminal (see
// `formRoomy`). A longer prompt grows the box, up to `promptMaxRows`, and
// scrolls past that.
const PROMPT_ROWS = 3;
const PROMPT_ROWS_SHORT = 2;

// The most rows the prompt box grows to: a quarter of the terminal, so the
// sections under it stay on screen.
function promptMaxRows(): number {
  const h = editor.getScreenSize().height;
  return Math.max(formRoomy() ? PROMPT_ROWS : PROMPT_ROWS_SHORT, Math.floor((h > 0 ? h : 40) / 4));
}

const SECTION_STYLE = { fg: "ui.menu_disabled_fg", bold: true } as const;
const WARN_STYLE = { fg: "diagnostic.warning_fg" } as const;

// Room for the blank rows between sections. A short terminal drops them first,
// then the prompt's third row; the sections themselves always show.
function formRoomy(): boolean {
  const h = editor.getScreenSize().height;
  return h <= 0 || h >= 34;
}

// A blank row, only when there is room for one.
function gap(): WidgetSpec[] {
  return formRoomy() ? [spacer(0)] : [];
}

// `PROMPT ─────…` — a section's name and a rule to the right edge. The rule
// is a long label the host clips at the panel's inner width, so it always
// ends at the border without this side knowing the width.
// The rule above a dialog's buttons, inset like the section rules so it
// keeps the same margin from the ring on both sides.
function footerRule(): WidgetSpec {
  return label("─".repeat(400), { style: { fg: "ui.menu_disabled_fg" } });
}

function sectionHeader(key: string): WidgetSpec {
  return label(`${editor.t(key)} ${"─".repeat(400)}`, { style: SECTION_STYLE });
}

// The mode switch: a new workspace, or here. Both options are always on
// screen; ←/→ flips it.
function launchModeRow(): WidgetSpec {
  const sel = form ? form.target : "new";
  const here = currentWorkspaceIds();
  const name = orchestratorSessions.get(here.windowId)?.label || editor.pathBasename(here.root) || here.root;
  return radio(
    [editor.t("run_agent.target_new"), editor.t("form.mode_here", { name })],
    {
      selectedIndex: sel === "new" ? 0 : 1,
      labelWidth: FORM_LABEL_W,
      key: "launch_mode",
    },
  );
}

// Whether the active agent takes a launch prompt. The prompt box is drawn for
// every agent so nothing moves when the agent changes; for one that takes no
// prompt it is read-only and out of the Tab cycle.
function promptApplies(): boolean {
  // Before an agent is chosen the prompt can already be written: most
  // agents take one, and the choice comes next.
  if (form?.agentUnset) return true;
  return !!activeAgentEntry()?.prompt;
}

function promptBox(f: NewSessionForm): WidgetSpec {
  const takes = promptApplies();
  const spec = text({
    value: takes ? f.startPrompt.value : "",
    cursorByte: f.startPrompt.cursor,
    // Grows with the text — the host wraps it at the box's real width — from
    // the resting size to the cap, and scrolls (caret in view) past that.
    rows: formRoomy() ? PROMPT_ROWS : PROMPT_ROWS_SHORT,
    maxRows: promptMaxRows(),
    fullWidth: true,
    placeholder: takes ? editor.t("form.prompt_placeholder") : editor.t("form.prompt_none"),
    readOnly: !takes,
    key: takes ? "start_prompt" : undefined,
  });
  // Inset from the dialog's edges: a margin on the left, and a width that
  // leaves the same on the right (a section otherwise fills its row).
  return row(spacer(2), labeledSection({ child: spec }));
}

// The agent and its own switches on one row; `custom…` adds the command row
// under it.
function agentRowFields(f: NewSessionForm): WidgetSpec[] {
  const kids: WidgetSpec[] = [agentPresetRow()];
  const entry = activeAgentEntry();
  if (entry?.auto) {
    kids.push(spacer(4), toggle(f.autoMode, editor.t("form.auto_mode_short"), { key: "auto_mode" }));
  }
  if (entry?.systemPrompt && teachApplies()) {
    kids.push(spacer(4), toggle(f.teachFreshCli, editor.t("form.teach_short"), { key: "teach_fresh_cli" }));
  }
  const out: WidgetSpec[] = [kids.length > 1 ? row(...kids) : kids[0]];
  if (f.agentUnset) {
    out.push(label(`⚠ ${editor.t("form.agent_choose_note")}`, { labelWidth: FORM_LABEL_W, style: WARN_STYLE }));
  }
  if (cmdVisible()) out.push(...cmdField(f));
  return out;
}

// One line under WHERE saying what Launch will do to git — the preview the
// branch notes used to spell out field by field.
function gitPlanLine(f: NewSessionForm): { text: string; style?: Partial<OverlayOptions> } | null {
  const name = plannedWorkspaceName(f);
  const newBranch = f.newBranch.value.trim();
  const typedBase = f.branch.value.trim();
  if (f.backend === "local") {
    if (f.projectPathIsGit === null) return { text: editor.t("form.plan_checking") };
    if (f.projectPathIsGit === false) return { text: editor.t("form.plan_plain") };
    if (!f.createWorktree) {
      return { text: typedBase ? editor.t("form.plan_inplace_checkout", { base: typedBase }) : editor.t("form.plan_inplace") };
    }
    const base = typedBase || f.defaultBranch;
    return { text: planWorktreeText(newBranch || (typedBase ? "" : name), base, name) };
  }
  if (f.backend === "ssh") {
    if (f.remoteProbing) return { text: editor.t("form.remote_probing") };
    if (f.remoteProbeError) {
      return {
        text: isHostKeyFailure(f.remoteProbeError) ? editor.t("form.remote_untrusted") : editor.t("form.remote_unreachable"),
        style: WARN_STYLE,
      };
    }
    if (f.remoteIsGit === false) return { text: editor.t("form.plan_plain") };
    if (f.remoteIsGit === null) return null;
    if (!f.createWorktree) return { text: editor.t("form.plan_inplace") };
    return { text: planWorktreeText(newBranch || (typedBase ? "" : name), typedBase || f.remoteDefaultBranch, name) };
  }
  return null;
}

// `new worktree fresh-47, branched from origin/master` — or, when an existing
// branch is checked out rather than a new one cut, `new worktree on <base>`.
function planWorktreeText(branch: string, base: string, name: string): string {
  if (!branch) return editor.t("form.plan_worktree_checkout", { name, base });
  return base
    ? editor.t("form.plan_worktree", { branch, base })
    : editor.t("form.plan_worktree_nobase", { branch });
}

// The WHERE section (§4.1): Project and Machine on one row, the button that
// adds a machine beside what the picked one resolves to, then either the
// repository's main clone or the folder, then one line saying what Launch
// will do to git.
function whereFields(f: NewSessionForm): WidgetSpec[] {
  const out: WidgetSpec[] = [
    ...machineRows(),
    dropdown(projectOptionLabels(), {
      selectedIndex: projectPickIndex(f),
      label: formLabel("form.project"),
      labelWidth: FORM_LABEL_W,
      key: "project",
    }),
  ];
  const r = formRepo(f);
  if (r) out.push(...repoWhereRows(f, r));
  else out.push(...projectPathFields(), ...folderRepoRows(f));
  if (f.detailsOpen) {
    out.push(...field(formLabel("form.workspace_short"), f.name, {
      key: "name",
      placeholder: formDefaultSessionName(f) || editor.t("form.auto_generating"),
    }));
  } else {
    // A blocked project has no plan to show; its blocker says why.
    const plan = r && formRepoBlocker(f)
      ? null
      : r && formNeedsPlace(f)
      ? (r.kind === "folder" ? null : { text: editor.t("form.plan_after_place", { name: plannedWorkspaceName(f) }) })
      : gitPlanLine(f);
    if (plan) out.push(label(plan.text, { labelWidth: FORM_LABEL_W, style: plan.style ?? NOTE_STYLE }));
  }
  out.push(detailsToggleRow(f));
  return out;
}

// A row in the field column: controls indented to where values start.
function fieldColumnRow(...kids: WidgetSpec[]): WidgetSpec {
  return row(spacer(FORM_LABEL_W + 2), ...kids);
}

// A secondary action inside the form or the Repositories dialog: the
// standard framed button, so it looks, focuses and clicks like every other.
function actionButton(text: string, key: string): WidgetSpec {
  return button(text, { key });
}

// The repository's main clone on the chosen machine (§4.1, §4.4, §4.5).
function repoWhereRows(f: NewSessionForm, r: Repository): WidgetSpec[] {
  const blocker = formRepoBlocker(f);
  const key = formMachineKey(f);
  if (blocker) {
    return [label(`✗ ${blocker}`, { labelWidth: FORM_LABEL_W, style: { fg: "diagnostic.error_fg" }, wrap: true })];
  }
  const clone = formMainClone(f);
  if (!clone) {
    // Nothing to do here: Launch asks where it is, once (§4.17).
    return [label(`⚠ ${editor.t("form.not_on_machine", { name: r.name, machine: machineKeyLabel(key!) })}`, {
      labelWidth: FORM_LABEL_W,
      style: WARN_STYLE,
      wrap: true,
    })];
  }
  if (!f.detailsOpen) {
    const line = r.kind === "folder" ? "form.folder_line" : "form.main_clone_line";
    return [label(editor.t(line, { path: tildePath(clone) }), { labelWidth: FORM_LABEL_W, style: NOTE_STYLE, wrap: true })];
  }
  return [
    label(`${formLabel(r.kind === "folder" ? "repo.folder" : "form.main_clone").padStart(FORM_LABEL_W)}: ${tildePath(clone)}`),
    fieldColumnRow(actionButton(editor.t("form.change_clone"), "change_clone")),
  ];
}

// A path under the home directory as `~/…`, the way it is usually typed.
function tildePath(p: string): string {
  const home = homeDir();
  if (home && (p === home || p.startsWith(home + "/"))) return "~" + p.slice(home.length);
  return p;
}

// A git folder that belongs to a known repository says so, and offers to make
// it that repository's main clone or to switch to the repository (§4.7). A
// git folder of an unknown remote offers to save it as a repository.
function folderRepoRows(f: NewSessionForm): WidgetSpec[] {
  if (f.backend !== "local" || f.projectPathIsGit !== true) return [];
  const known = folderKnownRepo(f);
  if (!known) {
    if (!f.folderOrigin) return [];
    return [fieldColumnRow(actionButton(editor.t("form.save_as_repo"), "save_repo"))];
  }
  const key = formMachineKey(f);
  const main = key ? known.clones[key] ?? "" : "";
  const here = formFolderPath(f);
  if (main && expandHome(main) === here) {
    return [
      label(editor.t("form.folder_is_main", { name: known.name }), { labelWidth: FORM_LABEL_W, style: NOTE_STYLE }),
      fieldColumnRow(actionButton(editor.t("form.switch_repo", { name: known.name }), "switch_repo")),
    ];
  }
  return [
    label(
      main
        ? editor.t("form.folder_clone_of", { name: known.name, machine: key ? machineKeyLabel(key) : "", path: main })
        : editor.t("form.folder_clone_of_nomain", { name: known.name }),
      { labelWidth: FORM_LABEL_W, style: NOTE_STYLE },
    ),
    fieldColumnRow(
      actionButton(editor.t("form.make_main_clone"), "make_main_clone"),
      spacer(4),
      actionButton(editor.t("form.switch_repo", { name: known.name }), "switch_repo"),
    ),
  ];
}

// `▸ Details` / `▾ Hide details`: the fold that reveals the workspace name and
// the GIT section. A focusable row rather than a key chord — the editor's
// keymaps already spend every Alt+letter.
function detailsToggleRow(f: NewSessionForm): WidgetSpec {
  // Hollow triangles: the filled `▸` is the focus marker.
  const text = f.detailsOpen ? `▿ ${editor.t("form.details_hide")}` : `▹ ${editor.t("form.details_show")}`;
  return fieldColumnRow(actionButton(text, "details"));
}

// The GIT section (details open): the worktree-or-in-place choice and the
// branches, for a path that is (or may be) a repository.
function gitSectionFields(f: NewSessionForm): WidgetSpec[] {
  // A main clone still to be made will be a repository: offer the worktree
  // group as it will be, not as the empty path reads now.
  const g: NewSessionForm = formNeedsPlace(f) && formRepo(f)?.kind !== "folder"
    ? { ...f, projectPathIsGit: true, projectPathIsLinkedWorktree: false, remoteIsGit: true, remoteProbing: false, remoteProbeError: "", defaultBranch: f.defaultBranch || "HEAD" }
    : f;
  if (g.backend === "local") return worktreeFields(g);
  if (g.backend === "ssh") return remoteWorktreeFields(g);
  return [];
}

function gitSectionShown(f: NewSessionForm): boolean {
  return f.target === "new" && f.detailsOpen && gitSectionFields(f).length > 0;
}

// The footer: a rule, then the actions flush right, each with its key beside
// it — and the last error under them, when there is one.
function formFooterRows(creating: boolean): WidgetSpec[] {
  if (!form) return [];
  if (creating && form.place) return placeFooterRows(form, form.place);
  const ok = formIsSubmittable();
  // One row: each button with its key beside it, the primary last.
  const actions = creating
    ? endRow(
      withAccel(button(editor.t("form.btn_cancel_short"), { key: "cancel" }), "Esc"),
      spacer(3),
      withAccel(button(editor.t("form.btn_launch_bg"), { key: "create-bg", disabled: !ok }), "Alt+⏎"),
      spacer(3),
      withAccel(button(editor.t("form.btn_launch"), { intent: "primary", key: "create-visit", disabled: !ok }), "Ctrl+⏎"),
      spacer(2),
    )
    : endRow(
      withAccel(button(editor.t("form.btn_cancel_short"), { key: "cancel" }), "Esc"),
      spacer(3),
      withAccel(button(editor.t("run_agent.btn_run"), { intent: "primary", key: "create-visit", disabled: !ok }), "Ctrl+⏎"),
      spacer(2),
    );
  const tail = form.lastError
    ? [...gap(), label(editor.t("form.error_prefix") + form.lastError, {
      style: { fg: "diagnostic.error_fg", bold: true },
      wrap: true,
    })]
    : [];
  return [footerRule(), ...gap(), actions, ...tail, ...gap()];
}

// Launch asks where the project is on this machine (§4.17): the question
// replaces the footer, and its answer resumes the launch.
function placeFooterRows(f: NewSessionForm, a: PlaceAsk): WidgetSpec[] {
  const r = formRepo(f);
  const machine = machineKeyLabel(a.machineKey);
  return [
    footerRule(),
    ...gap(),
    label(`  ⚠ ${editor.t("place.question", { name: r?.name ?? "", machine })}`, { style: { ...WARN_STYLE, bold: true } }),
    ...gap(),
    ...placeAskRows(a),
    ...gap(),
    endRow(
      button(editor.t("form.btn_cancel_short"), { key: "place_cancel" }),
      spacer(5),
      button(`  ${placeGoLabel(a, true)}  `, { intent: "primary", key: "place_go", disabled: !placeReady(a) }),
      spacer(3),
    ),
  ];
}

function formPlaceHost(f: NewSessionForm): PlaceHost {
  return {
    panel: () => (form === f ? formPanel : null),
    render: () => {
      if (form !== f) return;
      renderForm();
    },
    done: (saved) => {
      const visit = f.place?.visit ?? true;
      f.place = null;
      if (form !== f) return;
      renderForm();
      if (!saved) {
        formPanel?.setFocusKey("create-visit");
        return;
      }
      // Now it's there: point the form at it, re-read it, and launch.
      syncRepoPath();
      void (async () => {
        if (f.backend === "local") await probeProjectPathDefaults();
        else if (f.backend === "ssh") await probeRemoteProjectDefaults();
        if (form !== f) return;
        renderForm();
        await submitForm(visit);
      })();
    },
  };
}

function buildFormSpec(): WidgetSpec {
  if (!form) return col();
  if (form.submitting) return buildConnectingView();
  const f = form;
  const creating = f.target === "new";
  const kids: WidgetSpec[] = [
    ...gap(),
    launchModeRow(),
    ...gap(),
    // The agent first, then what to tell it: whether there is a prompt at
    // all, and what it means, depend on the agent chosen above it.
    sectionHeader("form.section_agent"),
    ...gap(),
    ...agentRowFields(f),
    ...gap(),
    sectionHeader("form.section_prompt"),
    ...gap(),
    promptBox(f),
    ...gap(),
  ];
  if (creating) {
    kids.push(sectionHeader("form.section_where"), ...gap(), ...whereFields(f), ...gap());
    if (gitSectionShown(f)) {
      kids.push(sectionHeader("form.section_git"), ...gap(), ...gitSectionFields(f), ...gap());
    }
  }
  kids.push(...formFooterRows(creating));
  return col(...kids);
}

// Derive a "my_org/project_name" style label from the current
// working directory's tail. Orchestrator never opens this dialog
// outside of a workspace; if the cwd has fewer than two
// components we fall back to whatever's there.
function deriveProjectLabel(): string {
  const cwd = editor.getCwd();
  const base = editor.pathBasename(cwd);
  const parent = editor.pathBasename(editor.pathDirname(cwd));
  if (parent && parent !== base) return `${parent}/${base}`;
  return base || cwd;
}

function renderForm(): void {
  if (!form || !formPanel) return;
  formPanel.update(buildFormSpec());
}

// Where the dialog was last launched to, and whether its details fold was
// open: both come back on the next open, whichever entry point opens it.
const LAUNCH_MODE_KEY = "orchestrator.last_launch_mode";
const LAUNCH_DETAILS_KEY = "orchestrator.launch_details_open";

// The mode a fresh open lands on: the last one used. A caller that brings a
// workspace to create (a discovered session, a machine picked elsewhere) is
// asking for a new workspace whatever was used last.
function initialLaunchTarget(): RunAgentTarget {
  if (pendingFormPrefill || pendingFormMachine !== undefined) return "new";
  return editor.getGlobalState(LAUNCH_MODE_KEY) === "current" ? "current" : "new";
}

const LAUNCH_PROJECT_KEY = "orchestrator.last_project";

// A repository asked for by whoever opens the form (the Repositories dialog's
// `New workspace here`); consumed by the next open.
let pendingFormRepo: string | null = null;

// The Project a fresh open lands on: one asked for, else the last used (if it
// still exists), else `Folder…`. A discovered session brings a folder.
function initialProjectRepo(): string | null {
  const asked = pendingFormRepo;
  pendingFormRepo = null;
  if (asked && repoById(asked)) return asked;
  if (pendingFormPrefill) return null;
  const last = editor.getGlobalState(LAUNCH_PROJECT_KEY);
  return typeof last === "string" && repoById(last) ? last : null;
}

function openForm(options?: { fromPicker?: boolean; target?: RunAgentTarget }): void {
  invalidateRepositories();
  // Same reason as `openMachinesDialog`: the Machine picker is built from the
  // saved machines, so re-read them rather than offer this session's cached
  // list — a machine added in another window is otherwise unreachable here.
  invalidateMachines();
  const storedCmd = editor.getGlobalState("orchestrator.last_cmd") as string | undefined;
  const lastCmd = storedCmd ?? "";
  form = {
    // Defaults to creating a workspace; "Run Agent…" opens the same form
    // pre-switched to the current one.
    target: options?.target ?? initialLaunchTarget(),
    detailsOpen: editor.getGlobalState(LAUNCH_DETAILS_KEY) === true,
    repoId: initialProjectRepo(),
    folderOrigin: "",
    place: null,
    backend: "local",
    machineId: null,
    machinePick: 0,
    sshPath: { value: "", cursor: 0 },
    k8sWorkspace: { value: "", cursor: 0 },
    projectPath: { value: "", cursor: 0 },
    name: { value: "", cursor: 0 },
    // Prefill the last-used command as *actual* editable text (not a
    // placeholder), so the field value is the single source of truth: keep it,
    // edit it, or clear it to fall back to the backend default (a bare local
    // terminal, or — for SSH — the remote login shell). No hidden
    // "empty means reuse lastCmd" fallback at submit time.
    cmd: { value: lastCmd, cursor: lastCmd.length },
    startPrompt: { value: "", cursor: 0 },
    autoMode: false,
    // Teach the agent the Fresh CLI by default: the capability token is always
    // minted, so an agent that knows the `fresh` verbs is strictly more useful
    // out of the box. Only surfaces for agents with a systemPrompt strategy.
    teachFreshCli: true,
    branch: { value: "", cursor: 0 },
    newBranch: { value: "", cursor: 0 },
    agentCustom: storedCmd !== undefined && !agentPresets().some((p) => !p.custom && !p.unset && p.cmd === lastCmd.trim()),
    agentUnset: storedCmd === undefined,
    // Default checkbox state is `true` (the historical behaviour
    // of "always create a worktree"); the renderer demotes this
    // to `false` automatically when the resolved Project Path is
    // non-git.
    createWorktree: true,
    remoteIsGit: null,
    remoteRepoRoot: "",
    remoteDefaultBranch: "",
    remoteProbeError: "",
    remoteProbing: false,
    remoteProbeToken: 0,
    submitting: false,
    lastError: null,
    defaultProjectPath: "",
    projectPathIsGit: null,
    projectPathIsLinkedWorktree: null,
    defaultSessionName: "",
    defaultBranch: "",
    defaultBranchIsHeadFallback: false,
    fromPicker: !!options?.fromPicker,
    probeToken: 0,
    historyCursor: { project_path: -1, name: -1, cmd: -1, branch: -1 },
    historyDraft: { project_path: "", name: "", cmd: "", branch: "" },
    completion: { field: null, items: [], selectedIndex: 0, anchor: "", token: 0 },
  };
  // Rejoining a discovered session: no worktree, since the session's files
  // are already in that directory — unless the caller asks for one (a
  // teleport checks its branch out, which belongs in a tree of its own).
  const prefill = pendingFormPrefill;
  pendingFormPrefill = null;
  if (prefill) {
    form.cmd = { value: prefill.cmd, cursor: prefill.cmd.length };
    // The command is the choice: without this the Agent field still reads
    // "Choose an agent…" (no command was saved from a previous launch) and
    // the prefilled one is hidden behind it.
    form.agentUnset = false;
    form.createWorktree = prefill.createWorktree ?? false;
    form.teleportOf = prefill.teleportOf;
    // An imported session keeps its name. With a worktree the name field
    // also names the worktree and its branch, so it gets a branch-safe
    // form of the name and the workspace is renamed to the name itself.
    if (prefill.label) {
      const name = form.createWorktree ? liveBranchName(prefill.label) : prefill.label;
      form.name = { value: name, cursor: utf8Len(name) };
      form.prefillName = name;
      if (name !== prefill.label) form.displayName = prefill.label;
    }
    form.agentCustom = !agentPresets().some((pr) => !pr.custom && pr.cmd === prefill.cmd.trim());
  }
  formPanel = new FloatingWidgetPanel();
  // A machine chosen elsewhere (`Machines ▸ New workspace here`, a machine
  // just added from this form) or the last one used opens the form on it.
  seedFormMachine();
  // After the machine, because the backend decides which field holds the path.
  if (prefill) applyPrefillPath(prefill.projectPath);
  syncRepoPath();
  mountFormPanel();
  // Kick off the placeholder probes (canonical repo root,
  // default branch, next session name) against the editor's
  // cwd. Each probe is async and re-renders on completion.
  void probeProjectPathDefaults();
  // …and the remote one, for a form that opened straight onto a machine.
  scheduleRemoteReprobe();
}

/// Mount (or re-mount) the form panel and land initial focus.
///
/// Re-mounted when the "Launch in" switch flips, because the frame *title*
/// is mount-time chrome: leaving it alone would keep a form that now creates
/// a workspace labelled "Run Agent". The form state itself is untouched, so
/// the agent, auto mode and prompt survive the flip; only focus moves, to the
/// first field of the shape the user just switched to.
function mountFormPanel(focusKey?: string): void {
  if (!form || !formPanel) return;
  const creating = form.target === "new";
  // The host shrinks the panel to its content, so the height is a ceiling
  // rather than a canvas. The width is set by the Project Path completion
  // list: the label column takes ~17 cells off every value, and a candidate
  // only shows whole — and an accepted one fits with its cursor — when ~95
  // cells are left for it (a macOS temp path with a directory name is 80).
  formPanel.mount(buildFormSpec(), {
    widthPct: FORM_WIDTH_PCT,
    heightPct: FORM_HEIGHT_PCT,
    // Reserve the `▸ ` focus-marker gutter: focus is then legible from
    // a plain terminal capture (driveable by automation) and the
    // layout stays constant as Tab moves focus between controls.
    focusMarker: true,
    // The form grid: labels right-aligned into one column so every value
    // cell opens on the same column (see `FORM_LABEL_W`).
    labelAlign: "right",
    // The dialog's title + border are now native modal-frame chrome
    // (drawn by the host around the WidgetSpec) rather than the in-body
    // "ORCHESTRATOR :: New Workspace" banner, and `closable` renders a
    // native `[×]` that dismisses via the same cancel path as Esc.
    title: creating ? editor.t("form.header_label") : editor.t("run_agent.title"),
    closable: true,
    mode: NEW_SESSION_MODE,
  });
  // The New-Session form is a global orchestrator feature too: center it
  // over the full screen (covering its own dimmed dock) rather than in the
  // chrome area beside the dock. A no-op when no dock is up.
  editor.floatingPanelControl(formPanel.id(), "fullscreen", 1);
  // Mirror the host's focus cycle so Up/Down route to the right field's
  // history. Without an explicit focus the form would open on the Launch-in
  // switch and typing would go nowhere, so focus lands on the first input.
  // Land on the first thing the user actually wants to set: the agent when
  // running here (there is nothing else to fill in), the backend's first
  // input when creating a workspace. A caller that re-mounts mid-edit passes
  // `focusKey` to keep focus where the user left it — flipping the "Launch in"
  // switch must not fling focus away from the control just used, or the next
  // ←/→ silently lands on whatever inherited focus instead.
  // The prompt, when the agent takes one — typing it is the whole flow.
  const field = focusKey ?? (!form.agentUnset && promptApplies() ? "start_prompt" : "agent_dropdown");
  formPanel.setFocusKey(field);
}

/// The local directory a brand-new *local* workspace should default to.
///
/// Almost always the active window's cwd (`editor.getCwd()`). But when the
/// active window is a remote session (ssh / kubernetes / devcontainer), its
/// cwd is a path on the *remote* filesystem — `editor.getCwd()` returns the
/// active window's root, which for those backends is the remote root. Seeding
/// the New-Session form's Local Project Path with it roots the new *local*
/// worktree at a path that need not exist on this machine (the "new workspace
/// uses the remote fs for the local one" bug). In that case fall back to a
/// local tracked session's root — preferring the launch/base session (lowest
/// window id) — so the default stays on the local filesystem.
function localProjectDefault(): string {
  const cwd = editor.getCwd();
  // A non-empty authority label means the active window runs under a remote
  // authority; corroborate with the orchestrator's own per-session remote
  // facet (set for the active SSH / k8s row). Either signal ⇒ cwd is remote.
  const active = orchestratorSessions.get(editor.activeWindow());
  const activeIsRemote = editor.getAuthorityLabel().length > 0 || !!active?.remote;
  if (!activeIsRemote) return cwd;
  // Active window is remote: pick the lowest-id local (non-remote, non-
  // discovered) session's root — in practice the launch/base window. If there
  // is no local session at all, leave cwd as the last-resort value rather than
  // an empty default.
  let base: AgentSession | null = null;
  for (const s of orchestratorSessions.values()) {
    if (s.remote || s.discovered) continue;
    if (base === null || s.id < base.id) base = s;
  }
  return base ? base.root : cwd;
}

/// Resolve placeholders for the Project Path / Session Name /
/// Branch fields based on the *currently-effective* project
/// path: the user-typed value if any, else a local default
/// (the canonical-root probe runs against the latter). Re-runs
/// on every Project Path keystroke (debounced via the caller).
async function probeProjectPathDefaults(): Promise<void> {
  if (!form) return;
  const token = ++form.probeToken;
  const typedPath = form.projectPath.value.trim();

  // (1) Default Project Path: only meaningful when the user
  //     hasn't typed anything. Resolve a local default → canonical
  //     root, fall back to the local default verbatim for non-git
  //     launches. `localProjectDefault()` keeps this on the local
  //     filesystem even when the active window is a remote session.
  if (!typedPath) {
    const localDefault = localProjectDefault();
    const resolved = await resolveCanonicalRepoRoot(localDefault);
    if (!form || form.probeToken !== token) return;
    form.defaultProjectPath = resolved || localDefault;
  } else {
    // User typed a path: that IS the project, no canonical
    // resolution needed. Defaults that depend on it (session
    // name, default branch) still need to run against it below.
    form.defaultProjectPath = typedPath;
  }

  // (2) Is-inside-work-tree probe drives the worktree checkbox. Expanded,
  //     because the probe execs git directly: an unexpanded `~/src/repo`
  //     fails, reads as "not a git path", and disables the worktree toggle on
  //     a repo that plainly is one.
  const effectivePath = expandHome(typedPath || form.defaultProjectPath);
  const isGit = await pathIsInsideGitWorkTree(effectivePath);
  if (!form || form.probeToken !== token) return;
  form.projectPathIsGit = isGit;
  // The folder's origin, so a clone of a known repository can say so.
  if (isGit) {
    const o = await editor.spawnHostProcess("git", ["-C", effectivePath, "remote", "get-url", "origin"]);
    if (!form || form.probeToken !== token) return;
    form.folderOrigin = o.exit_code === 0 ? (o.stdout || "").trim() : "";
  } else {
    form.folderOrigin = "";
  }

  // (2b) Existing-linked-worktree detection. When the path is a
  //      worktree created by `git worktree add` (not the repo's main
  //      checkout), default the checkbox to *unchecked* so the
  //      natural action is to attach to it. Only flip on the
  //      detection transition so we don't fight a user who
  //      deliberately re-checks "create a new worktree".
  const wasLinked = form.projectPathIsLinkedWorktree;
  if (isGit) {
    const info = await classifyWorktree(effectivePath);
    if (!form || form.probeToken !== token) return;
    form.projectPathIsLinkedWorktree = info?.isLinked === true;
  } else {
    form.projectPathIsLinkedWorktree = false;
  }
  if (form.projectPathIsLinkedWorktree && wasLinked !== true) {
    form.createWorktree = false;
  }

  // (3) Default branch + session name probes only make sense on
  //     a git path. On non-git, leave both empty (the renderer
  //     surfaces a "no git — N/A" branch placeholder, and the
  //     session name still works against the counter alone).
  if (isGit) {
    const [{ ref, isHeadFallback }, sessionName] = await Promise.all([
      detectDefaultBranchWithFallback(effectivePath),
      nextAutoSessionName(effectivePath),
    ]);
    if (!form || form.probeToken !== token) return;
    form.defaultBranch = ref;
    form.defaultBranchIsHeadFallback = isHeadFallback;
    form.defaultSessionName = sessionName;
  } else {
    // Non-git: still surface a numeric placeholder for Session
    // Name so the user sees what an empty submit will produce.
    // `nextAutoSessionName` falls back cleanly when the refs
    // probe fails (no git → empty set → counter+1).
    const sessionName = await nextAutoSessionName(effectivePath);
    if (!form || form.probeToken !== token) return;
    form.defaultBranch = "";
    form.defaultBranchIsHeadFallback = false;
    form.defaultSessionName = sessionName;
  }
  renderForm();
}

/// Schedule a debounced re-probe after the user changes the
/// Project Path field. 200ms feels snappy without spawning a
/// git subprocess on every keystroke. QuickJS has no
/// `setTimeout` — `editor.delay(ms)` is the async-sleep
/// primitive; the `probeToken` already enforces "only the
/// latest scheduled probe wins" so back-to-back keystrokes
/// collapse cleanly without an explicit timer handle.
function scheduleProjectPathReprobe(): void {
  if (!form) return;
  const token = ++form.probeToken;
  void editor.delay(200).then(() => {
    if (!form || form.probeToken !== token) return;
    void probeProjectPathDefaults();
  });
}

/// The same, for the remote path — with a longer settle, because each of
/// these is a connection rather than a `stat`. The machine control and the
/// connection fields feed it too: changing the host changes the answer as
/// surely as changing the path does.
function scheduleRemoteReprobe(): void {
  if (!form || form.backend !== "ssh") return;
  const token = ++form.remoteProbeToken;
  void editor.delay(500).then(() => {
    if (!form || form.remoteProbeToken !== token) return;
    void probeRemoteProjectDefaults();
  });
}

// =============================================================================
// Inline-dropdown completion (Phase 7)
//
// For Project Path and Branch we render a `list` below the input
// when the candidate set is non-empty. Candidates are fetched
// asynchronously (filesystem read for paths, git for branches);
// the `completion.token` makes only the freshest fetch's result
// land — same pattern as the project-path is-git probe.
// =============================================================================

const COMPLETION_VISIBLE_ROWS = 6;
const COMPLETION_MAX_ITEMS = 50;

/// Fire a fresh fetch of completion candidates for the named
/// field. Stale fetches (older `token`) discard their results
/// on completion. Caller is responsible for re-rendering once
/// the fetch lands — `setCompletionItems` does that.
function scheduleCompletionRefresh(
  field: "project_path" | "branch",
): void {
  if (!form) return;
  const anchor = form[field === "project_path" ? "projectPath" : "branch"].value;
  const token = ++form.completion.token;
  form.completion.field = field;
  form.completion.anchor = anchor;
  // Path completion reads from `editor.readDir`, which is a
  // synchronous host call (no IPC waiting). Run it inline so
  // Tab pressed immediately after the last keystroke picks
  // from the up-to-date candidate list rather than a stale
  // one — the user reported that with the debounce in place,
  // typing "repo" + Tab would accept the *previous* prefix's
  // top match (e.g. "Desktop") because the popup hadn't
  // refreshed yet.
  if (field === "project_path") {
    const items = computePathCompletions(anchor);
    if (!form || form.completion.token !== token) return;
    setCompletionItems(field, items);
    return;
  }
  // Branch completion shells out to `git for-each-ref` — that
  // *is* async, so a sync flush isn't possible. Keep the
  // 150ms debounce so we coalesce rapid typing into a single
  // subprocess invocation; Tab during the gap accepts the
  // last known list, which is the same behaviour `bash`'s
  // tab completion exhibits while a long-running compspec is
  // catching up.
  void editor.delay(150).then(async () => {
    if (!form || form.completion.token !== token) return;
    const items = await fetchBranchCompletions(anchor);
    if (!form || form.completion.token !== token) return;
    setCompletionItems(field, items);
  });
}

/// Synchronous variant of `fetchPathCompletions` — same logic,
/// but doesn't go through a `Promise` so it can run inline from
/// the `change` event handler. `fetchPathCompletions` keeps the
/// async signature for the legacy debounce path (in case the
/// fetcher ever grows an async step), but delegates here so the
/// two paths can't drift.
function computePathCompletions(typed: string): string[] {
  const slashIdx = typed.lastIndexOf("/");
  let parent: string;
  let basename: string;
  if (slashIdx < 0) {
    // Empty field: list the local default's siblings, not the active
    // (possibly remote) window's cwd — the Project Path is always local.
    parent = typed ? "." : localProjectDefault();
    basename = typed;
  } else if (slashIdx === 0) {
    parent = "/";
    basename = typed.slice(1);
  } else {
    parent = typed.slice(0, slashIdx);
    basename = typed.slice(slashIdx + 1);
  }
  // Expanded for the lookup only: the rows below keep the *typed* prefix, so
  // accepting one leaves `~/src/…` in the field rather than rewriting it to an
  // absolute path the user did not type. Everything that turns the field into
  // a real path expands it the same way.
  const entries = editor.readDir(editor.localPath(expandHome(parent)));
  const matches = entries
    .filter((e) => !basename || e.name.startsWith(basename))
    .filter((e) => !e.name.startsWith(".") || basename.startsWith("."));
  matches.sort((a, b) => {
    if (a.is_dir !== b.is_dir) return a.is_dir ? -1 : 1;
    return a.name.localeCompare(b.name);
  });
  const prefix = parent.endsWith("/") ? parent : `${parent}/`;
  return matches.map((e) => `${prefix}${e.name}${e.is_dir ? "/" : ""}`);
}

function setCompletionItems(
  field: "project_path" | "branch",
  items: string[],
): void {
  if (!form) return;
  // Compose the popup row list: live completion candidates
  // first (regular `kind: undefined`), then any history entries
  // for this field that aren't already in the live list,
  // marked `kind: "history"` so the host renders them with the
  // `↶` marker + italic. Duplicate suppression keeps the popup
  // from showing the same path twice when a candidate happens
  // to match a previous submission.
  const live: CompletionItem[] = items
    .slice(0, COMPLETION_MAX_ITEMS)
    .map((value) => ({ value }));
  const histField = focusToHistoryField(field);
  let composed: CompletionItem[] = live;
  if (histField) {
    const seen = new Set(live.map((i) => i.value));
    const historyRows: CompletionItem[] = readHistory(histField)
      .filter((v) => !seen.has(v))
      .slice(0, COMPLETION_MAX_ITEMS)
      .map((value) => ({ value, kind: "history" as const }));
    composed = [...live, ...historyRows].slice(0, COMPLETION_MAX_ITEMS);
  }
  form.completion.field = field;
  form.completion.items = composed;
  form.completion.selectedIndex = 0;
  // Push the candidate list to the host's Text-widget instance
  // state. The host repaints the popup chrome (dim separator,
  // side borders, selected-row highlight) on its own — the
  // plugin doesn't need to drive a re-render.
  if (formPanel) {
    formPanel.setCompletions(field, form.completion.items);
  }
}

function closeCompletion(): void {
  if (!form) return;
  if (form.completion.field === null && form.completion.items.length === 0) {
    return;
  }
  const prevField = form.completion.field;
  form.completion.field = null;
  form.completion.items = [];
  form.completion.selectedIndex = 0;
  form.completion.token += 1; // invalidate any in-flight fetch
  // Mirror the close in host instance state so its popup goes
  // away in the same frame. Without this the host would keep
  // painting the candidate list until the next spec push
  // happened to land for this widget.
  if (formPanel && prevField) {
    formPanel.setCompletions(prevField, []);
  }
}

/// Split typed Project Path into (parent, basename), list
/// `parent` via the host's `readDir`, and filter to entries
/// whose name starts with `basename`. Directories get a
/// trailing `/` so the user sees the type and Tab keeps
/// descending. Empty input lists the user's home directory's
/// top-level entries as a starting point.
async function fetchPathCompletions(typed: string): Promise<string[]> {
  // Heuristic for "where to list". `parent` is everything up
  // to and including the last `/`; `basename` is the unfinished
  // tail we filter on. `/foo/ba` → parent `/foo/`, basename
  // `ba`. `bar` (no slash) → parent `.`, basename `bar`. `/`
  // → parent `/`, basename `""`. Delegates to the sync
  // `computePathCompletions` so the two paths can't drift —
  // see `scheduleCompletionRefresh` for the sync use case.
  return computePathCompletions(typed);
}

/// List the project's local + remote branches and tags via
/// `git for-each-ref` (one subprocess instead of three). Filter
/// by substring of the typed value — branch names commonly
/// carry slash-separated prefixes (`feat/`, `release/`) that
/// the user often doesn't type first.
async function fetchBranchCompletions(typed: string): Promise<string[]> {
  if (!form) return [];
  const projectPath = expandHome(form.projectPath.value.trim() || form.defaultProjectPath);
  if (!projectPath) return [];
  if (form.projectPathIsGit === false) return [];
  const res = await spawnCollect(
    "git",
    [
      "-C",
      projectPath,
      "for-each-ref",
      "--format=%(refname:short)",
      "refs/heads/",
      "refs/remotes/",
      "refs/tags/",
    ],
    projectPath,
  );
  if (res.exit_code !== 0) return [];
  const lines = (res.stdout || "")
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0 && l !== "origin/HEAD");
  const needle = typed.toLowerCase();
  const matches = needle
    ? lines.filter((l) => l.toLowerCase().includes(needle))
    : lines;
  // Dedup the common `origin/<branch>` vs `<branch>` pair when
  // the local copy exists. Prefer the local short name; drop the
  // origin alias unless the user explicitly typed `origin`.
  const local = new Set(matches.filter((l) => !l.includes("/")));
  const wantsOrigin = needle.startsWith("origin/");
  const filtered = matches.filter((l) => {
    if (!wantsOrigin && l.startsWith("origin/")) {
      const bare = l.slice("origin/".length);
      if (local.has(bare)) return false;
    }
    return true;
  });
  // Stable order: exact-match-first, then prefix-match, then
  // substring; ties broken by length so shorter names surface.
  filtered.sort((a, b) => {
    const ascore = a.toLowerCase() === needle ? 0 : a.toLowerCase().startsWith(needle) ? 1 : 2;
    const bscore = b.toLowerCase() === needle ? 0 : b.toLowerCase().startsWith(needle) ? 1 : 2;
    if (ascore !== bscore) return ascore - bscore;
    return a.length - b.length || a.localeCompare(b);
  });
  return filtered;
}

function closeForm(): void {
  if (formPanel) {
    formPanel.unmount();
    formPanel = null;
  }
  form = null;
}

// Whether the New-Session form was opened over a still-mounted dock: closing
// it then goes back to the dock (the host returns the keyboard to the control
// that opened the form) rather than reopening a centered picker.
function dockUnderForm(): boolean {
  return !!openPanel && dockMode;
}

// Cancel path: tear down the form, and if it was reached via the
// picker (Alt+N or "+ New Session" button), reopen the picker so
// Esc behaves like a true "back" rather than dropping the user
// into the bare editor. When the dock is still mounted underneath,
// just hand focus back to it instead.
function cancelForm(): void {
  const wasFromPicker = !!form?.fromPicker;
  // Cancelling while a remote connect is in flight: tell the host to abort it.
  // The pending `attachRemoteAgent` promise rejects with "cancelled" (its catch
  // is a no-op once `form` is null below) and the connect's late result is
  // discarded host-side, so no window is ever built.
  if (form?.submitting) {
    pendingRemoteFacet = null;
    editor.cancelRemoteAgent();
  }
  closeForm();
  if (dockUnderForm()) return;
  if (wasFromPicker) {
    openControlRoom();
  }
}

// =============================================================================
// Non-blocking workspace creation
//
// Submitting the New-Workspace form no longer blocks the editor behind a
// modal "Creating…/Connecting…" view. Instead the form's inputs are captured
// into a self-contained `CreateSpec`, the form closes, and a synthetic
// placeholder row appears in the dock — "Creating…" for a local worktree,
// "Connecting…" for a remote host that may not even be reachable yet. The
// real work runs in the background; the user is free to switch to any other
// workspace meanwhile. On success the placeholder is dropped and the real
// live window takes its place; on failure the row flips to an error state
// offering retry / dismiss.
//
// Remote attaches are *serialised*: the host's `cancelRemoteAgent()` cancels
// EVERY in-flight connect, so two concurrent background attaches could not be
// cancelled independently. Remote placeholders therefore run one at a time
// through `remoteCreateQueue` / `remoteInFlightId`. Local creates have no such
// constraint and run immediately, in parallel.
//
// Still-creating specs are persisted (`savePendingSpecs`) so a quit + restart
// re-surfaces them as resumable ("paused") rows via `recoverPendingWorkspaces`
// on the `ready` hook.
// =============================================================================

type CaptureResult = { ok: true; spec: CreateSpec } | { ok: false; error: string };

// ---------------------------------------------------------------------
// Spec builders — plain values in, a `CreateSpec` out.
//
// These are the single construction path for a workspace create. The
// dialog reaches them through `captureCreateSpec` (which does nothing but
// read its fields), and the plugin API's `newWorkspace` reaches them
// directly with the caller's options. Neither side builds a spec of its
// own, so a new agent flag or a changed default lands in both at once —
// the API used to assemble the local spec inline and had already drifted
// into being a second, near-copy of the local branch below.
// ---------------------------------------------------------------------

/// Per-agent launch options, gated on what the resolved agent supports.
/// Shared by every backend so a bare terminal (or a command that isn't a
/// known agent) never gets stray flags or a prompt appended.
interface AgentOptionInputs {
  auto: boolean;
  prompt: string;
  teach: boolean;
}

function gateAgentOptions(
  cmd: string,
  o: AgentOptionInputs,
): { auto: boolean; startPrompt: string; teachFreshCli: boolean } {
  const entry = agentEntryForCmd(cmd);
  return {
    auto: !!entry?.auto && o.auto,
    startPrompt: entry?.prompt ? o.prompt : "",
    teachFreshCli: !!entry?.systemPrompt && o.teach,
  };
}

// The argv a remote transport runs: the agent command with its auto-mode
// flag and start prompt folded in (the same resolution the local launch
// does), for an agent the registry knows; anything else passes through.
function remoteAgentArgv(cmd: string, o: AgentOptionInputs): string[] {
  const argv = splitAgentCmd(cmd);
  const gated = gateAgentOptions(cmd, o);
  return resolveAgentLaunch(argv, { auto: gated.auto, prompt: gated.startPrompt }).launch;
}

interface LocalSpecInputs extends AgentOptionInputs {
  projectPath: string;
  /// Explicit workspace name; "" ⇒ auto-generated at create time.
  name: string;
  cmd: string;
  branch: string;
  newBranch: string;
  createWorktree: boolean;
  /// Row label to show while the create runs. "" ⇒ derived from the name /
  /// the project's basename, which is what the dialog's placeholder shows.
  displayLabel?: string;
}

function buildLocalSpec(o: LocalSpecInputs): CreateSpec {
  return {
    backend: "local",
    projectPath: o.projectPath,
    name: o.name,
    cmd: o.cmd,
    ...gateAgentOptions(o.cmd, o),
    branch: o.branch,
    newBranch: o.newBranch,
    createWorktree: o.createWorktree,
    displayLabel: o.displayLabel ||
      o.name ||
      editor.pathBasename(o.projectPath) ||
      editor.t("dock.pending_default_name"),
    displayProject: o.projectPath,
  };
}

interface SshSpecInputs extends AgentOptionInputs {
  /// `[user@]host[:port]`, or a pasted `ssh://…`.
  host: string;
  name: string;
  cmd: string;
  /// Remote directory to root the session at.
  remotePath: string;
  /// Identity file passed to ssh.
  identity: string;
  /// Extra ssh arguments, already split into argv.
  extraArgs: string[];
  /// When set, the create makes this worktree on the remote first and roots
  /// the session there. See `RemoteWorktreePlan`.
  worktree?: RemoteWorktreePlan;
}

function buildSshSpec(o: SshSpecInputs): CaptureResult {
  // `[user@]host[:port]` (also tolerating a pasted `ssh://…`), through the
  // one parser that gets this right. The second copy here read the port as
  // whatever followed the last colon, which for `2001:db8::1` is a host of
  // `2001:db8:` on port 1 — a destination the user never typed, reported
  // against a field they cannot fix. The user is optional: a bare `host`
  // lets ssh resolve it from its own config.
  const { dest, port: portText } = parseSshTarget(o.host);
  const port = portText ? parseInt(portText, 10) : null;
  const at = dest.lastIndexOf("@");
  const user = at > 0 ? dest.slice(0, at) : undefined;
  // `parseSshTarget` brackets an IPv6 literal because that is the form `ssh`
  // takes on a command line; the transport carries the port in a field of its
  // own, so what it wants here is the bare address.
  const host = (at >= 0 ? dest.slice(at + 1) : dest).replace(/^\[(.*)\]$/, "$1");
  if (!host) return { ok: false, error: editor.t("err.ssh_host_required") };
  const agentArgv = remoteAgentArgv(o.cmd, o);
  const target = user ? `${user}@${host}` : host;
  // **The workspace name, not the machine twice.** A remote row renders the
  // label and then the backend target beside it, so a blank name read
  // `ssh:testbox  testbox` — naming the machine twice and the workspace never,
  // leaving two sessions on one host indistinguishable. The fix is upstream of
  // here: the form now hands over its generated default when the field is left
  // empty, so `o.name` is populated and the label is the workspace name, with
  // the machine appearing exactly once, in the row's target segment.
  //
  // The label deliberately does *not* also carry the target. Spelling it
  // `<name> · ssh:<target>` reads well in isolation but puts the machine back
  // in twice, and the dock is one narrow line: the extra width pushed the
  // pending status off the end, so a workspace being created showed its name
  // and host but never what it was doing. `remoteDetailSegs` guards the
  // duplication; keeping the label short is what leaves room for the status.
  const label = o.name || `ssh:${target}`;
  const spec: RemoteAgentSpec = {
    transport: {
      kind: "ssh",
      ...(user ? { user } : {}),
      host,
      port,
      identity_file: o.identity || null,
      remote_path: o.remotePath || null,
      ...(o.extraArgs.length > 0 ? { extra_args: o.extraArgs } : {}),
    },
    base_env: [],
    window: true,
    label,
    command: agentArgv.length > 0 ? agentArgv : undefined,
  };
  return {
    ok: true,
    spec: {
      backend: "ssh",
      spec,
      facet: { kind: "ssh", detail: target, state: "starting" },
      displayLabel: label,
      displayProject: target,
      persistCmd: o.cmd,
      ...(o.worktree ? { remoteWorktree: o.worktree } : {}),
    },
  };
}

/// The worktree plan for the form's current state, or `null` when there is
/// nothing to make: the toggle is off, the host said it is not a repository,
/// or this is not an ssh create.
///
/// **Only a refusal the remote actually made stops it.** `remoteIsGit` is
/// `null` while the probe is in flight and when it never connected, and
/// refusing on the strength of a probe that failed to ask would be this side
/// deciding the question. A host unreachable while the user typed may be
/// reachable now, so an unanswered probe still plans; the remote's own `git
/// rev-parse` is the one that gets to say no, and its error lands on the row.
function remoteWorktreePlan(f: NewSessionForm, name: string): RemoteWorktreePlan | null {
  if (f.backend !== "ssh" || f.target !== "new" || !f.createWorktree) return null;
  if (f.remoteIsGit === false) return null;
  const ssh = formSshArgv(f, REMOTE_CREATE_TIMEOUT_S);
  const path = f.sshPath.value.trim() || (f.machineId ? machineById(f.machineId)?.path || "" : "");
  if (!ssh || !path) return null;
  return {
    ssh,
    path,
    name,
    base: f.branch.value.trim(),
    newBranch: f.newBranch.value.trim(),
  };
}

interface K8sSpecInputs extends AgentOptionInputs {
  /// Named target from `.fresh/k8s.json`; when set, `pod` is still required.
  target: string;
  context: string;
  namespace: string;
  pod: string;
  workspace: string;
  name: string;
  cmd: string;
}

function buildK8sSpec(o: K8sSpecInputs): CaptureResult {
  if (o.target && !o.pod) return { ok: false, error: editor.t("err.k8s_named_target") };
  if (!o.namespace || !o.pod) {
    return { ok: false, error: editor.t("err.k8s_ns_pod_required") };
  }
  const agentArgv = remoteAgentArgv(o.cmd, o);
  const detail = `${o.namespace}/${o.pod}`;
  const label = o.name || `k8s:${detail}`;
  const spec: RemoteAgentSpec = {
    transport: {
      kind: "kubectl-exec",
      context: o.context || null,
      namespace: o.namespace,
      pod: o.pod,
      container: null,
      workspace: o.workspace || null,
    },
    base_env: [],
    // Born-attached: a new window beside the local ones (not a global
    // restart). Core records nothing about us — the orchestrator tracks the
    // session via the `window_created` hook once the connect succeeds.
    window: true,
    label,
    command: agentArgv.length > 0 ? agentArgv : undefined,
  };
  return {
    ok: true,
    spec: {
      backend: "kubernetes",
      spec,
      facet: { kind: "kubernetes", detail, state: "starting" },
      displayLabel: label,
      displayProject: detail,
      persistCmd: "",
    },
  };
}

// Resolve the (about-to-close) form into a `CreateSpec`, or return the
// validation error that keeps the form open. Reads field values only — no
// async work, no side effects — so the background worker never touches form
// state that no longer exists. The spec itself is built by the shared
// builders above, which the plugin API calls with the same shapes.
function captureCreateSpec(f: NewSessionForm): CaptureResult {
  const cmd = f.cmd.value.trim();
  const sessionName = f.name.value.trim();
  const agentOptions: AgentOptionInputs = {
    auto: f.autoMode,
    prompt: f.startPrompt.value.trim(),
    teach: f.teachFreshCli && f.backend === "local",
  };

  if (f.backend === "local") {
    // Project Path: typed value wins; otherwise the resolved canonical-root
    // placeholder (or, if that probe never completed, a local default).
    // `localProjectDefault()` keeps the fallback on the local filesystem even
    // when the active window is a remote session.
    const projectPath = expandHome(
      f.projectPath.value.trim() || f.defaultProjectPath || localProjectDefault(),
    );
    return {
      ok: true,
      spec: buildLocalSpec({
        ...agentOptions,
        projectPath,
        name: sessionName,
        cmd,
        branch: f.branch.value.trim(),
        newBranch: f.newBranch.value.trim(),
        createWorktree: f.createWorktree,
        // The form has a third fallback the API has no equivalent for: the
        // auto-generated `<project>-N` shown as the Name field's placeholder.
        displayLabel: sessionName || formDefaultSessionName(f),
      }),
    };
  }

  if (f.machineId) {
    // A saved machine: the connection is the record's; the form only says
    // where the workspace is rooted (blank = the machine's default path).
    const m = machineById(f.machineId);
    if (!m) return { ok: false, error: editor.t("machine.err_gone") };
    if (m.kind === "ssh") {
      return buildSshSpec({
        ...agentOptions,
        host: m.target,
        name: sessionName,
        cmd,
        remotePath: f.sshPath.value.trim() || m.path,
        identity: m.identity,
        extraArgs: m.options ? m.options.split(/\s+/) : [],
        worktree: remoteWorktreePlan(f, sessionName || formDefaultSessionName(f)) ?? undefined,
      });
    }
    if (m.pod.startsWith("-l")) return { ok: false, error: editor.t("machine.err_selector_launch") };
    return buildK8sSpec({
      ...agentOptions,
      target: "",
      context: m.context,
      namespace: m.namespace,
      pod: m.pod,
      workspace: f.k8sWorkspace.value.trim() || m.path,
      name: sessionName,
      cmd,
    });
  }

  if (f.backend === "devcontainer") {
    // No runtime plugin-to-plugin attach yet.
    return { ok: false, error: editor.t("err.devcontainer_unsupported") };
  }

  // A remote with no saved machine behind it: the machine was removed while
  // the form was open.
  if (f.backend === "kubernetes" || f.backend === "ssh") {
    return { ok: false, error: editor.t("machine.err_gone") };
  }

  // Every `FormBackend` has returned above; this keeps the compiler honest
  // when one is added.
  const unreachable: never = f.backend;
  return unreachable;
}

// `attachRemoteAgent` rejects with an Error whose message is the host's
// reason (ssh diagnostic, a window-creation failure, a bad spec, …).
function remoteAttachErrorText(e: unknown): string {
  const msg = e instanceof Error ? e.message : String(e ?? "");
  return msg.trim() || editor.t("err.connection_failed");
}

// The "Creating…" / "Connecting…" line shown on a freshly-launched row.
function pendingCreatingMessage(spec: CreateSpec): string {
  return spec.backend === "local"
    ? editor.t("dock.pending_creating")
    : editor.t("dock.pending_connecting");
}

// Open a workspace that is still being built and — unless it is a restored
// (paused) row — close the form, surface the dock, and launch the background
// worker. Resolves to the row's id.
//
// A LOCAL workspace is a *real window* from this moment: the host opens it
// with its own id, durable stable id, and label, showing a "being created"
// page in place of its contents. That is what makes the wait bearable — the
// user is taken into the workspace they asked for straight away (Create &
// Visit) instead of being left on the previous one and having focus yanked
// out from under them whenever `git worktree add` happens to finish. It is
// also what makes the row a first-class workspace while it builds: renaming,
// filing it into a folder, switching to it and closing it all work on the
// window, not on a stub that only offers "dismiss".
//
// A REMOTE workspace gets the same treatment. Its window used to be born by
// the connect itself (`attachRemoteAgent`), which meant there was nothing to
// land in while it ran and nothing to report on when it failed; the connect
// now adopts this placeholder instead (`adopt_window`).
async function startPendingWorkspace(
  spec: CreateSpec,
  opts?: { restored?: boolean; visit?: boolean; label?: string },
): Promise<number> {
  const restored = opts?.restored === true;
  const remoteFacet: RemoteFacet | undefined =
    spec.backend === "local" ? undefined : { ...spec.facet };
  // A restored row keeps the name it last showed (the resolved / relabelled
  // one persisted alongside the spec); a fresh row starts from the spec's
  // capture-time display label.
  const label = opts?.label || spec.displayLabel;
  const message = restored
    ? editor.t("dock.pending_interrupted")
    : pendingCreatingMessage(spec);
  // Focus follows into the new workspace *now*, while it is still empty —
  // never later, when it finishes. A create that grabs the keyboard minutes
  // after the click interrupts whatever the user moved on to.
  const visit = !restored && opts?.visit === true;

  let id: number;
  let stableId: string | undefined;
  let bufferId: number | undefined;
  let root: string;
  if (spec.backend === "local") {
    // Root the placeholder at the project directory: the workspace's own
    // directory is exactly what does not exist yet. The adopt step re-roots
    // the window onto the worktree once it has been created.
    const born = await editor.createPreparingWindow({
      root: spec.projectPath,
      label,
      message,
      activate: visit,
    });
    id = born.windowId;
    stableId = born.stableId || undefined;
    bufferId = born.bufferId || undefined;
    root = spec.projectPath;
  } else {
    // A remote workspace gets the same placeholder window a local one does,
    // and for the same two reasons: the user lands in the workspace they
    // asked for straight away instead of being left on the previous one, and
    // a connect that never arrives has a page of its own to say so on.
    //
    // It used to get a synthetic row and no window, because the window was
    // born by the connect itself — so pressing Create against an unreachable
    // machine looked like nothing had happened, and the eventual error could
    // only be reported as a line at the bottom of the dock.
    //
    // The window is anchored at a *local* directory because the workspace's
    // own root is on a machine we have not reached yet; the connect re-roots
    // it onto the remote path when the session adopts it (`adopt_window`).
    // The row keeps a synthetic root of its own so it cannot collide with a
    // real workspace at the anchor.
    const anchor = editor.getCwd();
    const born = await editor.createPreparingWindow({
      root: anchor,
      label,
      message,
      activate: visit,
    });
    id = born.windowId;
    stableId = born.stableId || undefined;
    bufferId = born.bufferId || undefined;
    root = `pending:${id}`;
  }
  orchestratorSessions.set(id, {
    id,
    stableId,
    label,
    hostLabel: label,
    root,
    // Pin the dock slot to the row's identity, not to a root that is about
    // to change under it.
    orderKey: `pending:${id}`,
    projectPath: spec.displayProject,
    sharedWorktree: false,
    terminalId: null,
    state: "idle",
    lastOutputAt: null,
    createdAt: Date.now(),
    remote: remoteFacet,
    pending: {
      phase: restored ? "paused" : "creating",
      message,
      bufferId,
      spec,
      // A restored/resumed row never yanks focus on relaunch.
      visit,
    },
  });
  savePendingSpecs();
  if (!restored) {
    closeForm();
    showDockUnfocused();
    launchPendingCreate(id);
  } else if (spec.backend === "local") {
    // A row restored from a previous run is paused, not running: say so on
    // its page too, so entering it doesn't read as "still working".
    syncPreparingPage(orchestratorSessions.get(id)!);
  }
  return id;
}

// Ensure the dock is visible without stealing keyboard focus — the user
// asked to keep working ("stay put"). Used for a just-created placeholder
// (so it's seen), and for the `autoOpenDock` setting at startup.
function showDockUnfocused(): void {
  // Open the dock if nothing is up yet. (Structured so the module-level
  // `openPanel`'s narrowing survives the `openControlRoom` reassignment —
  // mirrors `openMoveToFolderForCurrent`.)
  if (!openPanel) {
    // Mounted blurred from the first frame — a focused mount plus a
    // follow-up blur would leave a tick-sized window where the dock
    // owns the keyboard (command dispatch is budgeted across frames).
    openControlRoom({ dock: true, blurred: true });
    if (openPanel && dockMode) dockBlurred = true;
  }
  if (!openPanel) return;
  // Keep keyboard focus in the editor ("stay put") — only the dock is shown.
  // A centered modal picker (dockMode false) is left focused as-is. The
  // explicit blur stays for the already-open case (and is a no-op right
  // after a blurred mount).
  if (dockMode) {
    dockBlurred = true;
    editor.floatingPanelControl(openPanel.id(), "blur", 0);
    syncDockSelectionToActive();
  }
  refreshOpenDialog();
}

// Dispatch the background worker for a placeholder (local runs immediately;
// remote queues behind any in-flight connect).
function launchPendingCreate(id: number): void {
  const s = orchestratorSessions.get(id);
  if (!s || !s.pending) return;
  if (s.pending.spec.backend === "local") void runLocalCreate(id);
  else enqueueRemoteCreate(id);
}

// =============================================================================
// Create completion — for callers that need the result, not just the row
//
// A workspace create is deliberately non-blocking: the dialog closes, the dock
// shows a pending row, and the user keeps working. A *caller* (the headless
// `orchestrator_agent_new`, driven from an agent's shell) has no dock to watch
// and nothing to do until the workspace exists, so it needs the outcome — above
// all the new workspace's durable id, which only exists once the window is born.
//
// Resolvers registered here are settled by the create worker at exactly the
// points that end a create: success, failure, and dismissal. Nothing else may
// resolve them, or a caller would be told a workspace exists that doesn't.
// =============================================================================

interface CreateOutcome {
  ok: boolean;
  /// Per-process window handle. Valid until this editor exits.
  windowId?: number;
  /// Durable workspace identity — the id to keep. Survives restarts.
  workspaceId?: string;
  /// The workspace's root directory (its worktree, when it has one).
  root?: string;
  error?: string;
}

const createOutcomeResolvers = new Map<number, (r: CreateOutcome) => void>();

// Await the outcome of the pending create `id`. The promise settles exactly
// once; a create that is dismissed or fails settles with `ok: false`.
function awaitCreateOutcome(id: number): Promise<CreateOutcome> {
  return new Promise((resolve) => {
    createOutcomeResolvers.set(id, resolve);
  });
}

// Settle a pending create's outcome, if anyone is waiting on it. Safe to call
// on every terminal path — a create nobody awaited simply has no resolver.
function settleCreateOutcome(id: number, outcome: CreateOutcome): void {
  const resolve = createOutcomeResolvers.get(id);
  if (!resolve) return;
  createOutcomeResolvers.delete(id);
  resolve(outcome);
}

// Update a placeholder's status line (a no-op once the row is gone). The
// same line narrates the dock row and — for a workspace that already owns a
// window — the page inside it, so the user sees one story whether they are
// watching the list or sitting in the workspace.
function setPendingMessage(id: number, msg: string): void {
  const s = orchestratorSessions.get(id);
  if (!s || !s.pending) return;
  s.pending.message = msg;
  syncPreparingPage(s);
  if (openPanel) refreshOpenDialog();
}

// Keep the placeholder's label in step with the resolved session name (local
// auto-generates it only inside the worker).
function relabelPending(id: number, label: string): void {
  const s = orchestratorSessions.get(id);
  if (!s || !s.pending || !label || s.label === label) return;
  // A manual rename outranks the auto-resolved name: the user may well have
  // renamed the workspace while it was building, and the worker resolving
  // `<project>-N` must not overwrite that.
  if (workspaceCustomName(s) !== undefined) return;
  s.label = label;
  s.hostLabel = label;
  syncPreparingPage(s);
  savePendingSpecs();
  if (openPanel) refreshOpenDialog();
}

// Flip a placeholder into its error state with `reason`, surfacing it on the
// row (and the status bar) and dropping it from the persisted set.
function failPending(id: number, reason: string): void {
  const s = orchestratorSessions.get(id);
  if (!s || !s.pending) return;
  s.pending.phase = "error";
  s.pending.message = reason.trim() || editor.t("err.connection_failed");
  syncPreparingPage(s);
  if (s.remote) s.remote.state = "error";
  editor.setStatus(editor.t("status.prefix", { msg: s.pending.message }));
  savePendingSpecs();
  // Highlight the row that just failed, so the failure panel — the full
  // reason and its Retry / Dismiss — is on screen at the moment it is needed
  // rather than after the user has gone looking for it. The dock highlight is
  // not the active window, so this moves nothing the user is working in.
  selectDockRow(id);
  if (openPanel) refreshOpenDialog();
  // The row stays for the user to retry or dismiss, but a caller waiting on
  // this create is done — it gets the reason rather than hanging.
  settleCreateOutcome(id, { ok: false, error: s.pending.message });
}

// Return keyboard focus to the window that was active before a spawn/attach
// dove into its new window — the "stay put, mark ready" contract. Safe if the
// target window has since closed.
function restoreActiveWindow(id: number): void {
  if (id <= 0 || editor.activeWindow() === id) return;
  if (!editor.listWindows().some((w) => w.id === id)) return;
  editor.setActiveWindow(id);
}

// Re-run a failed or paused (restored) placeholder from scratch.
function retryPending(id: number): void {
  const s = orchestratorSessions.get(id);
  if (!s || !s.pending) return;
  s.pending.phase = "creating";
  s.pending.message = pendingCreatingMessage(s.pending.spec);
  syncPreparingPage(s);
  if (s.remote) s.remote.state = "starting";
  savePendingSpecs();
  if (openPanel) refreshOpenDialog();
  launchPendingCreate(id);
}

// Drop a placeholder for good. If it is the remote connect currently in
// flight, tear that connect down first (the host's `cancelRemoteAgent`
// cancels the single in-flight attach); a queued one is just removed.
function dismissPending(id: number): void {
  const s = orchestratorSessions.get(id);
  if (!s || !s.pending) return;
  dropPlaceholderPage(id);
  if (remoteInFlightId === id) {
    pendingRemoteFacet = null;
    editor.cancelRemoteAgent();
    remoteInFlightId = null;
  }
  const qi = remoteCreateQueue.indexOf(id);
  if (qi >= 0) remoteCreateQueue.splice(qi, 1);
  orchestratorSessions.delete(id);
  // A local placeholder owns a real window; dismissing the workspace has to
  // close it, or the user is left sitting in a page for a create that is no
  // longer running. Move off it first — the host refuses to close the active
  // window — and mark it closing so `reconcileSessions` doesn't resurrect
  // the row from the host snapshot before the close lands.
  if (id > 0) {
    closingWindowIds.add(id);
    if (editor.activeWindow() === id) {
      const other = editor.listWindows().find((w) => w.id !== id);
      if (other) editor.setActiveWindow(other.id);
    }
    editor.closeWindow(id);
  }
  savePendingSpecs();
  if (openPanel) {
    refreshOpenDialog();
    syncDockSelectionToActive();
  }
}

// Best-effort teardown of a worktree this local create added but then had to
// abandon (the placeholder was dismissed mid-flight). Leaving it would orphan
// the branch + directory with nothing tracking it. `--force` since the tree is
// freshly created; any failure is swallowed — there's nothing else to do from
// a cancellation path.
async function discardCreatedWorktree(repoRoot: string, root: string): Promise<void> {
  await spawnCollect(
    "git",
    ["-C", repoRoot, "worktree", "remove", "--force", root],
    repoRoot,
  );
}

/** `name`, or the first of `name-2`, `name-3`, … that no worktree folder or
 *  branch of this project's repository already has. `runLocalCreate` reuses
 *  a worktree it finds on disk — that is how an interrupted create resumes —
 *  so a new workspace given a name already in use would open inside the
 *  existing worktree rather than get its own. */
async function freeWorktreeName(projectPath: string, name: string): Promise<string> {
  const repoRoot = (await resolveCanonicalRepoRoot(projectPath)) ?? projectPath;
  const taken = async (n: string): Promise<boolean> => {
    const root = editor.pathJoin(editor.getDataDir(), "orchestrator", slugify(repoRoot), n);
    if (editor.fileExists(editor.localPath(root))) return true;
    const ref = await spawnCollect(
      "git",
      ["-C", repoRoot, "rev-parse", "--verify", "--quiet", `refs/heads/${n}`],
      repoRoot,
    );
    return ref.exit_code === 0;
  };
  for (let i = 1; i < 100; i++) {
    const n = i === 1 ? name : `${name}-${i}`;
    if (!(await taken(n))) return n;
  }
  return name;
}

// Background worker: create a local worktree (when requested) and spawn the
// session window, swapping the placeholder for the real row. Idempotent on a
// resume — if the target worktree already exists (a prior run made it before
// the editor quit) the add is skipped and the session opens in place.
//
// Cancellation: `dismissPending` deletes the session from the map, so each
// `orchestratorSessions.get(id)?.pending` check below is also a cancel point.
// Because a local create has real side effects (a worktree on disk, a spawned
// window), the checkpoints after those effects undo them rather than just
// bailing — so a dismissed create leaves nothing behind.
async function runLocalCreate(id: number): Promise<void> {
  const s0 = orchestratorSessions.get(id);
  if (!s0 || !s0.pending || s0.pending.spec.backend !== "local") return;
  const spec = s0.pending.spec;
  const cmd = spec.cmd;
  const checkoutBranch = spec.branch;
  const newBranch = spec.newBranch;
  const projectPath = spec.projectPath;

  // Re-probe is-git so we trust the latest filesystem state, not a UI flag.
  const isGit = await pathIsInsideGitWorkTree(projectPath);
  if (!orchestratorSessions.get(id)?.pending) return; // dismissed mid-probe
  const createWorktree = isGit === true && spec.createWorktree;

  let repoRoot = projectPath;
  if (createWorktree) {
    const canonical = await resolveCanonicalRepoRoot(projectPath);
    if (canonical) repoRoot = canonical;
  }

  const sessionName = spec.name ||
    (await nextAutoSessionName(repoRoot, { persist: true }));
  if (!orchestratorSessions.get(id)?.pending) return;
  // Pin the auto-resolved name back into the spec so a retry or a
  // restart-recovery targets the *same* worktree instead of allocating a fresh
  // `<proj>-(N+1)` — which would bypass the `rootExists` idempotency below and
  // orphan the worktree a prior attempt already created.
  if (!spec.name) {
    spec.name = sessionName;
    savePendingSpecs();
  }
  relabelPending(id, sessionName);

  const root = createWorktree
    ? editor.pathJoin(editor.getDataDir(), "orchestrator", slugify(repoRoot), sessionName)
    : projectPath;

  // Recovery idempotency: a worktree left on disk by an interrupted run is
  // reused rather than re-added (a re-add would fail and error the row).
  const rootExists = createWorktree && editor.fileExists(editor.localPath(root));
  // Whether *this* run put the worktree on disk (vs. reusing an existing one),
  // so a mid-flight dismissal can remove exactly what it created.
  let addedWorktree = false;
  if (createWorktree && !rootExists) {
    setPendingMessage(id, editor.t("dock.pending_adding_worktree"));
    const parent = editor.pathDirname(root);
    if (!editor.createDir(editor.localPath(parent))) {
      failPending(id, editor.t("err.mkdir_failed", { path: parent }));
      return;
    }
    const defaultBranch = await detectDefaultBranch(repoRoot);
    // Fork point for the new worktree: the explicit checkout branch, or the
    // detected default when the user left it blank.
    const base = checkoutBranch || defaultBranch;
    if (newBranch) {
      // "New branch name" set: cut a fresh branch off `base`. A pre-existing
      // branch of that name is a hard error — NO silent fallback to checking
      // it out (that would put the user on someone else's history).
      const addRes = await spawnCollect(
        "git",
        ["-C", repoRoot, "worktree", "add", root, "-b", newBranch, base],
        repoRoot,
      );
      if (addRes.exit_code !== 0) {
        if (/already exists/i.test(addRes.stderr || "")) {
          failPending(id, editor.t("err.branch_exists", { branch: newBranch }));
        } else {
          failPending(
            id,
            lastNonEmptyLine(addRes.stderr) || editor.t("err.worktree_add_failed"),
          );
        }
        return;
      }
    } else if (checkoutBranch) {
      // "Checkout branch" set (no new branch): check that existing branch/ref
      // out into the new worktree.
      const addRes = await spawnCollect(
        "git",
        ["-C", repoRoot, "worktree", "add", root, checkoutBranch],
        repoRoot,
      );
      if (addRes.exit_code !== 0) {
        failPending(
          id,
          lastNonEmptyLine(addRes.stderr) || editor.t("err.worktree_add_failed"),
        );
        return;
      }
    } else {
      // Neither field set — today's behaviour: cut `<sessionName>` off the
      // default branch, falling back to checking out an existing branch of
      // that name (only for this default case).
      let addRes = await spawnCollect(
        "git",
        ["-C", repoRoot, "worktree", "add", root, "-b", sessionName, defaultBranch],
        repoRoot,
      );
      if (addRes.exit_code !== 0) {
        const fallback = await spawnCollect(
          "git",
          ["-C", repoRoot, "worktree", "add", root, sessionName],
          repoRoot,
        );
        if (fallback.exit_code !== 0) {
          failPending(
            id,
            lastNonEmptyLine(fallback.stderr) ||
              lastNonEmptyLine(addRes.stderr) ||
              editor.t("err.worktree_add_failed"),
          );
          return;
        }
        addRes = fallback;
      }
    }
    addedWorktree = true;
  }

  // Non-worktree (in-place) checkout: switch the project's own working tree
  // to `checkoutBranch`. Refuse unless the tree is clean AND fully pushed —
  // a checkout here mutates the user's real repo, so we never risk stranding
  // uncommitted or unpushed work (and never use `-f`). `newBranch` is ignored
  // in this path.
  if (!createWorktree && checkoutBranch) {
    setPendingMessage(id, editor.t("dock.pending_adding_worktree"));
    const statusRes = await spawnCollect(
      "git",
      ["-C", projectPath, "status", "--porcelain"],
      projectPath,
    );
    if ((statusRes.stdout || "").trim().length > 0) {
      failPending(id, editor.t("err.checkout_unclean"));
      return;
    }
    const upstreamRes = await spawnCollect(
      "git",
      ["-C", projectPath, "rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}"],
      projectPath,
    );
    if (upstreamRes.exit_code !== 0) {
      failPending(id, editor.t("err.checkout_no_upstream"));
      return;
    }
    const unpushedRes = await spawnCollect(
      "git",
      ["-C", projectPath, "rev-list", "--count", "@{u}..HEAD"],
      projectPath,
    );
    if (parseInt((unpushedRes.stdout || "0").trim(), 10) > 0) {
      failPending(id, editor.t("err.checkout_unpushed"));
      return;
    }
    const coRes = await spawnCollect(
      "git",
      ["-C", projectPath, "checkout", checkoutBranch],
      projectPath,
    );
    if (coRes.exit_code !== 0) {
      failPending(
        id,
        lastNonEmptyLine(coRes.stderr) || editor.t("err.worktree_add_failed"),
      );
      return;
    }
  }
  if (!orchestratorSessions.get(id)?.pending) {
    // Dismissed while the worktree was being added — remove what we just
    // created so a dismissed create leaves nothing orphaned on disk.
    if (addedWorktree) await discardCreatedWorktree(repoRoot, root);
    settleCreateOutcome(id, { ok: false, error: "workspace creation was dismissed" });
    return;
  }

  // Remembered even when empty: the terminal is a choice too, and a stored
  // choice is what spares the next launch from asking (`agentUnset`).
  editor.setGlobalState("orchestrator.last_cmd", cmd);

  // Attach-to-existing-worktree classification for the no-worktree path
  // (a linked worktree the user pointed at directly).
  const attachInfo = !createWorktree ? await classifyWorktree(root) : null;
  const isLinkedAttach = attachInfo?.isLinked === true;
  const effectiveProjectPath = isLinkedAttach ? attachInfo!.mainRoot : projectPath;
  const reportedBranch = createWorktree
    ? (newBranch || checkoutBranch || sessionName)
    : (checkoutBranch || (isLinkedAttach ? attachInfo!.branch : ""));

  appendHistory("project_path", projectPath);
  appendHistory("name", sessionName);
  if (cmd) appendHistory("cmd", cmd);
  if (createWorktree) appendHistory("branch", reportedBranch);

  // "Teach Fresh CLI": inject the CLI contract and (below) mint a capability
  // token. Both `via` forms ride the launch argv, resolved just below.
  const teachEntry = spec.teachFreshCli ? agentEntryForCmd(cmd) : null;
  const teach = teachEntry?.systemPrompt ?? null;

  const argv = splitAgentCmd(cmd);
  const { launch: launchArgv, resume: resumeArgv } = resolveAgentLaunch(argv, {
    auto: spec.auto,
    prompt: spec.startPrompt,
    systemPrompt: teach ? FRESH_CLI_SYSTEM_PROMPT : undefined,
  });
  const sharedWorktree = !createWorktree && !isLinkedAttach;

  // Where the user actually is, captured immediately before the spawn dives
  // into the new window. Focus was already settled when the workspace opened
  // — "Create & Visit" put the user in it then, "Create in Background" left
  // them where they were — so whatever the spawn does to the active window is
  // undone here. Without this, a create that finishes minutes later yanks the
  // keyboard out of whatever the user moved on to.
  const restoreTo = editor.activeWindow();
  setPendingMessage(id, editor.t("dock.pending_starting"));
  try {
    const result = await editor.createWindowWithTerminal({
      root,
      label: sessionName,
      cwd: root,
      command: launchArgv.length > 0 ? launchArgv : undefined,
      title: launchArgv.length > 0 ? launchArgv[0] : undefined,
      resume: resumeArgv,
      // Grow the placeholder the user has been looking at (and may have
      // renamed or filed away) into the live session, keeping its window id
      // and durable workspace id.
      adoptWindow: id > 0 ? id : undefined,
      // Always mint the capability token bound to this window so
      // `fresh --cmd script ...` from inside the workspace is authorised —
      // whether or not the agent was taught about it. `teach` only gates the
      // prompt.
      allowScript: FRESH_CLI_ALLOW_SCRIPT,
    });
    const winId = result.windowId;
    // Dismissed during the (awaited) spawn: the window was born and dove in,
    // but the user has since dismissed this workspace. Tear the window (and its
    // agent process) down and remove any worktree we added, rather than
    // resurrecting the dismissed row as a live session.
    if (!orchestratorSessions.get(id)?.pending) {
      // `close_window` refuses the active window (the spawn dove into it), so
      // move focus off it first — back where the user was, or any other window.
      restoreActiveWindow(restoreTo);
      if (editor.activeWindow() === winId) {
        const other = editor.listWindows().find((w) => w.id !== winId);
        if (other) editor.setActiveWindow(other.id);
      }
      if (result.terminalId) editor.signalWindow(winId, "SIGKILL");
      editor.closeWindow(winId);
      if (addedWorktree) await discardCreatedWorktree(repoRoot, root);
      settleCreateOutcome(id, { ok: false, error: "workspace creation was dismissed" });
      return;
    }
    editor.setWindowState("project_path", effectiveProjectPath);
    editor.setWindowState("shared_worktree", sharedWorktree);
    const discId = discoveredIdByPath.get(root);
    if (discId !== undefined) {
      orchestratorSessions.delete(discId);
      discoveredIdByPath.delete(root);
    }
    // The workspace is live. When it grew out of a placeholder (`adoptWindow`)
    // `winId === id`, so this replaces the row in place and it keeps its dock
    // slot; otherwise the placeholder is superseded by the new row.
    const wasPending = orchestratorSessions.get(id);
    dropPlaceholderPage(id);
    orchestratorSessions.delete(id);
    savePendingSpecs();
    orchestratorSessions.set(winId, {
      id: winId,
      stableId: result.stableId || undefined,
      label: customNameFor(result.stableId || undefined, root) ?? sessionName,
      hostLabel: sessionName,
      root,
      // Keep the slot the row has occupied since the user asked for it, so
      // coming alive doesn't move it in the list.
      orderKey: wasPending?.orderKey,
      projectPath: effectiveProjectPath,
      sharedWorktree,
      terminalId: result.terminalId,
      state: "idle",
      // Quiet, not unheard-from (`null` would show `?`): the shell's first
      // prompt arrives before this row exists, so it never stamps it.
      lastOutputAt: 0,
      createdAt: Date.now(),
      branch: reportedBranch || undefined,
    });
    // The workspace exists and is running: hand a waiting caller its ids. The
    // durable `stableId` is minted with the window, so it is already final —
    // this is the only moment it can be reported from.
    settleCreateOutcome(id, {
      ok: true,
      windowId: winId,
      workspaceId: result.stableId,
      root,
    });
    // Put the active window back where it was a moment ago. This is NOT the
    // "Create & Visit" decision — that was honoured when the workspace
    // opened, minutes earlier. It only undoes the dive the spawn just
    // performed, so finishing a build never moves the user: if they were
    // already in this workspace (`restoreTo === winId`) they stay, and if
    // they had gone elsewhere they are left there.
    restoreActiveWindow(restoreTo);
    if (restoreTo === winId && openPanel && dockMode) {
      // The user is sitting in the workspace that just came alive — hand it
      // the keyboard (blur the dock) so they can type into the agent.
      dockBlurred = true;
      editor.floatingPanelControl(openPanel.id(), "blur", 0);
    }
    if (openPanel) {
      refreshOpenDialog();
      syncDockSelectionToActive();
    }
  } catch (e) {
    failPending(id, e instanceof Error ? e.message : String(e));
  }
}

// Queue a remote placeholder and pump the (serialised) remote worker.
function enqueueRemoteCreate(id: number): void {
  const s = orchestratorSessions.get(id);
  if (s?.pending && remoteInFlightId !== null) {
    // Something is already connecting — show that this one is waiting.
    setPendingMessage(id, editor.t("dock.pending_queued"));
  }
  remoteCreateQueue.push(id);
  pumpRemoteQueue();
}

// Start the next queued remote connect when none is in flight, skipping
// placeholders that were dismissed or errored while waiting.
function pumpRemoteQueue(): void {
  if (remoteAttachBusy) return;
  let next: number | undefined;
  for (;;) {
    next = remoteCreateQueue.shift();
    if (next === undefined) return;
    const s = orchestratorSessions.get(next);
    if (s?.pending && s.pending.phase !== "error") break;
  }
  remoteAttachBusy = true;
  remoteInFlightId = next;
  void runRemoteCreate(next).finally(() => {
    remoteAttachBusy = false;
    remoteInFlightId = null;
    pumpRemoteQueue();
  });
}

// Background worker for a remote (SSH / Kubernetes) placeholder. The connect
// may take seconds and can fail (unreachable host, bad pod); until it
// resolves the row sits in its "Connecting…" state, switchable-away-from like
// any other. `attachRemoteAgent` resolves only once the authority AND the
// born-attached window exist, so the placeholder is dropped only when the
// session is truly real.
async function runRemoteCreate(id: number): Promise<void> {
  const s = orchestratorSessions.get(id);
  if (
    !s || !s.pending ||
    (s.pending.spec.backend !== "ssh" && s.pending.spec.backend !== "kubernetes")
  ) {
    return;
  }
  const spec = s.pending.spec;
  s.pending.phase = "creating";
  s.pending.message = editor.t("dock.pending_connecting");
  if (s.remote) s.remote.state = "starting";
  const visit = s.pending.visit;
  // The born window adopts this facet via the `window_created` hook.
  pendingRemoteFacet = { ...spec.facet };
  if (openPanel) refreshOpenDialog();
  try {
    // Capture the user's *current* window right before the attach dives into
    // the born one, so a "stay put" create returns focus to where they are now.
    // The connect can run — or wait queued behind another attach — for seconds
    // while the user navigates elsewhere, so the submit-time window is stale;
    // mirror the local worker, which recaptures fresh here too.
    const restoreTo = editor.activeWindow();
    // **The worktree before the attach.** The session has to root at a
    // directory that exists, so this runs first and rewrites the transport's
    // path to what the remote reports — one ssh round trip that resolves the
    // repository, makes the worktree if it is not already there, and answers
    // with the absolute path. A failure here is the create's failure: the row
    // says what the remote said rather than connecting to the wrong place.
    // **Without a worktree to make, nothing else would ask.** The agent
    // carrier trusts an unknown key on its own (`accept-new`), so a create
    // with the worktree toggle off connected silently — while the form had
    // already promised "you'll be asked to confirm it on create". One cheap
    // round trip buys the promise back; on a host that is already trusted it
    // succeeds and costs nothing more.
    if (spec.backend === "ssh" && !spec.remoteWorktree) {
      const argv = specSshArgv(spec.spec, REMOTE_CREATE_TIMEOUT_S);
      if (argv) {
        const probe = await editor.spawnHostProcess("ssh", [...argv, "true"]);
        if (!orchestratorSessions.get(id)?.pending) return;
        if (probe.exit_code !== 0 && isHostKeyFailure(lastNonEmptyLine(probe.stderr))) {
          setPendingMessage(id, editor.t("dock.pending_awaiting_hostkey"));
          const trusted = await offerHostKeyTrust(argv, spec.facet.detail);
          if (!orchestratorSessions.get(id)?.pending) return;
          if (!trusted) {
            failPending(id, editor.t("hostkey.declined"));
            return;
          }
        }
      }
    }
    if (spec.backend === "ssh" && spec.remoteWorktree) {
      s.pending.message = editor.t("dock.pending_adding_worktree");
      if (openPanel) refreshOpenDialog();
      let made = await createRemoteWorktree(spec.remoteWorktree);
      if (!orchestratorSessions.get(id)?.pending) return;
      // An untrusted host key is the one failure the user can clear from
      // right here, and the first ssh call of the create is where it shows
      // up. Ask for the fingerprint the way every other ssh client does and
      // run the same create again; declining is an outcome, not a crash, so
      // the row says what happened and Retry asks once more.
      if (!made.ok && isHostKeyFailure(made.error)) {
        // **Say that it is waiting, not that it is working.** The modal below
        // blocks until the user answers, and for as long as it does there is
        // no ssh process, no worktree and no `known_hosts` — so a row still
        // reading "Adding worktree…" describes work that is not happening,
        // and a user who looks at the dock rather than the modal sees a
        // create wedged mid-step. This is the state the study recorded as
        // "permanently in progress".
        setPendingMessage(id, editor.t("dock.pending_awaiting_hostkey"));
        const trusted = await offerHostKeyTrust(
          spec.remoteWorktree.ssh,
          spec.facet.detail,
        );
        if (!orchestratorSessions.get(id)?.pending) return;
        if (!trusted) {
          failPending(id, editor.t("hostkey.declined"));
          return;
        }
        s.pending.message = editor.t("dock.pending_adding_worktree");
        if (openPanel) refreshOpenDialog();
        made = await createRemoteWorktree(spec.remoteWorktree);
        if (!orchestratorSessions.get(id)?.pending) return;
      }
      if (!made.ok) {
        failPending(id, made.error);
        return;
      }
      // Narrowed rather than cast: only the ssh transport has a remote path,
      // and `spec.backend === "ssh"` above is the Orchestrator's own tag, not
      // the transport's. The two agree, but the compiler is right to want the
      // one that owns the field to say so.
      if (spec.spec.transport.kind === "ssh") spec.spec.transport.remote_path = made.root;
      savePendingSpecs();
    }
    // Grow the placeholder the user has been sitting in since they pressed
    // Create into the live session, rather than minting a second window
    // beside it. Keeps its window id, its durable workspace id and its dock
    // slot across the connect — the same adoption the local path does.
    if (id > 0) spec.spec.adopt_window = id;
    await editor.attachRemoteAgent(spec.spec);
    // Success: the workspace is live in the window the user has been sitting
    // in. Its page has done its job, so take it down before the row is
    // replaced — the pane behind it is the workspace's own content now.
    dropPlaceholderPage(id);
    orchestratorSessions.delete(id);
    savePendingSpecs();
    // Hand a waiting caller its ids. The attach dove into the born window, so
    // it is the active one right now — before the `restoreActiveWindow` below
    // puts focus back. Without this a caller awaiting a remote create waited
    // forever: the local worker settles its outcome and this one never did,
    // which went unnoticed while `newWorkspace` was local-only.
    const bornId = editor.activeWindow();
    const born = editor.listWindows().find((w) => w.id === bornId);
    settleCreateOutcome(id, {
      ok: true,
      windowId: bornId,
      workspaceId: born?.stable_id,
      root: born?.root,
    });
    if (spec.persistCmd) editor.setGlobalState("orchestrator.last_cmd", spec.persistCmd);
    if (visit) {
      // Create & Visit: the attach already made the born window active; hand
      // it the keyboard so the user lands in the connected session.
      if (openPanel && dockMode) {
        dockBlurred = true;
        editor.floatingPanelControl(openPanel.id(), "blur", 0);
      }
    } else {
      // Stay put: the attach activated the born window — return to where the
      // user was.
      restoreActiveWindow(restoreTo);
    }
    if (openPanel) {
      refreshOpenDialog();
      syncDockSelectionToActive();
    }
  } catch (e) {
    pendingRemoteFacet = null;
    failPending(id, remoteAttachErrorText(e));
  }
}

// ---------------------------------------------------------------------
// Restart recovery — persist still-creating LOCAL placeholders so a quit +
// relaunch re-surfaces them (paused) instead of silently losing an
// in-progress workspace whose worktree may not have been created yet.
//
// Remote (SSH / Kubernetes) placeholders are deliberately NOT persisted
// here: a born-attached remote session that actually connected is already
// restored across restarts by the host's own dormant-session persistence
// (it comes back as a reconnectable remote row), and re-surfacing a connect
// that never completed would either duplicate that row or silently re-open a
// network connection on launch. Local worktree creation has no such host-side
// record, so it is the case this recovery exists for.
// ---------------------------------------------------------------------

const PENDING_KEY = "orchestrator.pending";

// Persist every LOCAL placeholder that is still creating or paused (never the
// errored ones — those are a completed, surfaced outcome; nor remote ones —
// see the section note). Called on every mutation of the pending set.
function savePendingSpecs(): void {
  const out: { spec: CreateSpec; label: string }[] = [];
  for (const s of orchestratorSessions.values()) {
    if (s.pending && s.pending.phase !== "error" && s.pending.spec.backend === "local") {
      out.push({ spec: s.pending.spec, label: s.label });
    }
  }
  editor.setGlobalState(PENDING_KEY, out as unknown as object);
}

// Rehydrate persisted local placeholders on startup as paused rows the user
// resumes (Enter) or dismisses. Nothing auto-runs — resuming is a deliberate
// keystroke, never an automatic filesystem touch on launch.
function recoverPendingWorkspaces(): void {
  const raw = editor.getGlobalState(PENDING_KEY);
  if (!Array.isArray(raw) || raw.length === 0) return;
  let restored = 0;
  for (const e of raw) {
    if (!e || typeof e !== "object") continue;
    const spec = (e as Record<string, unknown>).spec as CreateSpec | undefined;
    if (!spec || spec.backend !== "local") continue;
    // Restore the name the row last showed (persisted by `savePendingSpecs`),
    // not the generic capture-time default it would otherwise re-derive.
    const savedLabel = (e as Record<string, unknown>).label;
    const label = typeof savedLabel === "string" && savedLabel ? savedLabel : undefined;
    void startPendingWorkspace(spec, { restored: true, label });
    restored++;
  }
  // A file launch (`fresh FILE`, `--simple`) keeps the dock closed; the rows
  // are there when the user opens it.
  if (restored > 0 && !editor.fileLaunch()) showDockUnfocused();
}

// `visit`: "Create & Visit" — focus follows into the workspace once it's real.
// `!visit`: "Create in Background" — stay put. Both are non-blocking.
async function submitForm(visit: boolean): Promise<void> {
  if (!form) return;
  // A project this machine doesn't know the place of: ask (§4.17). The
  // answer resumes this launch (`formPlaceHost`).
  if (form.target === "new" && formNeedsPlace(form)) {
    const r = formRepo(form);
    const key = formMachineKey(form);
    if (formRepoBlocker(form) || !r || !key) return;
    form.place = Object.assign(newPlaceAsk(r, key, undefined, formPlaceHost(form)), { visit });
    renderForm();
    const first = form.place.how === "clone" ? "place_go" : "place_folder";
    formPanel?.setFocusKey(first);
    return;
  }
  // The next open lands on the mode and project used now (§7: last used wins).
  editor.setGlobalState(LAUNCH_MODE_KEY, form.target);
  // Here has no project; only a new workspace says which one was used.
  if (form.target === "new") editor.setGlobalState(LAUNCH_PROJECT_KEY, form.repoId ?? "");
  // "Run in the current workspace": no workspace to create, no spec to
  // validate — just launch the chosen agent here. Same argv resolution
  // (`resolveAgentLaunch`, including the resume spec) as the create path.
  if (form.target === "current") {
    const agent = activeAgentEntry();
    const opts: RunAgentLaunchOpts = {
      auto: !!agent?.auto && form.autoMode,
      prompt: agent?.prompt ? form.startPrompt.value.trim() : "",
      teachFreshCli: !!agent?.systemPrompt && form.teachFreshCli,
    };
    const cmd = form.cmd.value;
    closeForm();
    // The agent runs here, in the window the user is looking at: keyboard
    // focus goes to its terminal, so the dock (if one is mounted under the
    // form) stays visible but blurred instead of taking the focus back.
    if (openPanel && dockMode) {
      dockBlurred = true;
      editor.floatingPanelControl(openPanel.id(), "blur", 0);
      refreshOpenDialog();
    }
    void launchAgentInCurrentWorkspace(cmd, opts);
    return;
  }
  // Resolve the form's inputs into a self-contained spec. A validation
  // failure (bad ssh host, missing pod) keeps the form open with the error;
  // otherwise the form closes and the create runs in the background.
  const captured = captureCreateSpec(form);
  if (!captured.ok) {
    form.lastError = captured.error;
    editor.setStatus(editor.t("status.prefix", { msg: captured.error }));
    renderForm();
    return;
  }
  // Claim a remote workspace's auto-generated name so the *next* dialog does
  // not propose it again. A local create derives its own name at create time
  // and advances the counter there (`runLocalCreate`, which also pins the
  // result back into the spec so a retry targets the same worktree); a remote
  // create baked the name in at capture, so nothing downstream advances
  // anything. That left an ssh workspace holding `<project>-2` with the
  // counter still at 1, and the following dialog offered `<project>-2` again.
  // The branch scan that backs the counter up cannot cover it either — a
  // worktree cut on another machine leaves no ref in this repository.
  // Only when the user left Workspace Name blank, so the name in the spec is
  // the generated `<project>-N` rather than something they typed. A typed name
  // is theirs and says nothing about the counter — deriving a base to test
  // against would not help either, since an ssh form's default name comes
  // from the local folder, or from the repository when one is picked.
  if (
    captured.spec.backend === "ssh" && captured.spec.remoteWorktree &&
    !form.name.value.trim() && captured.spec.remoteWorktree.name === formDefaultSessionName(form)
  ) {
    claimAutoSessionName(captured.spec.remoteWorktree.name);
  }
  const picked = machineOptions()[form.machinePick];
  editor.setGlobalState("orchestrator.last_machine", picked ? picked.key : "");
  // Read before the create closes the form.
  const proposed = form.prefillName !== undefined && form.name.value.trim() === form.prefillName;
  const displayName = proposed ? form.displayName : undefined;
  const teleportOf = form.teleportOf;
  // A name the form proposed (an imported session's) must not land on a
  // worktree already made: a second copy of the same session, or another
  // session of the same title, would open inside the first one's.
  if (
    proposed && captured.spec.backend === "local" && captured.spec.createWorktree &&
    captured.spec.name
  ) {
    captured.spec.name = await freeWorktreeName(captured.spec.projectPath, captured.spec.name);
  }
  const id = await startPendingWorkspace(captured.spec, { visit });
  const bornWs = teleportOf ? orchestratorSessions.get(id) : undefined;
  if (teleportOf && bornWs?.stableId) rememberTeleport(teleportOf, bornWs.stableId);
  // Named from birth: a local workspace has its durable id already.
  const born = displayName ? orchestratorSessions.get(id) : undefined;
  if (born?.stableId && displayName) {
    renameWorkspace(born, displayName);
    refreshDockTree();
  }
}

/// Open a session in an existing worktree without creating one —
/// the dive action for a discovered row, and the building block the
/// new-session form reuses when the user points Project Path at an
/// existing linked worktree. Spawns a bare terminal (no agent
/// command) rooted at the worktree, tags the window with its
/// canonical project + `shared_worktree = false` so Archive / Delete
/// manage it as the real worktree it is, then drops the discovered
/// placeholder (the live window supersedes it).
async function attachToWorktree(opts: {
  root: string;
  projectPath: string;
  label: string;
  branch?: string;
  discoveredId?: number;
  /**
   * Whether to hand keyboard focus to the new window (blur the dock) once
   * attached. `true` for the "dive in" gestures (Enter, Visit) — mirrors
   * the dock's live-session Enter, which blurs to the editor. `false`
   * (default) for the "activate / live-switch" gestures (arrow-nav, a
   * row click), which open the worktree as the active session but keep
   * the dock focused so you can keep navigating — mirrors the dock's
   * live-session arrow/click switch, which never blurs. No-op in the
   * modal picker (it closes `openPanel` before calling here).
   */
  dive?: boolean;
}): Promise<void> {
  try {
    const result = await editor.createWindowWithTerminal({
      root: opts.root,
      label: opts.label,
      cwd: opts.root,
      // Always mint the workspace's capability token (see runLocalCreate).
      allowScript: FRESH_CLI_ALLOW_SCRIPT,
    });
    const id = result.windowId;
    editor.setWindowState("project_path", opts.projectPath);
    editor.setWindowState("shared_worktree", false);
    if (opts.discoveredId !== undefined) {
      orchestratorSessions.delete(opts.discoveredId);
      discoveredIdByPath.delete(opts.root);
    }
    orchestratorSessions.set(id, {
      id,
      stableId: result.stableId || undefined,
      label: customNameFor(result.stableId || undefined, opts.root) ?? opts.label,
      hostLabel: opts.label,
      root: opts.root,
      projectPath: opts.projectPath,
      sharedWorktree: false,
      terminalId: result.terminalId,
      state: "idle",
      // Quiet, not unheard-from (`null` would show `?`): the shell's first
      // prompt arrives before this row exists, so it never stamps it.
      lastOutputAt: 0,
      createdAt: Date.now(),
      branch: opts.branch,
    });
    // The new window is now the active session. For a "dive in" gesture
    // (Enter / Visit) the dock is still focused, so its keys would be
    // swallowed and the new session's terminal couldn't receive input —
    // mirror the dock's live-session Enter path and blur it so the new
    // window gets the keyboard. The "activate / live-switch" gestures
    // (arrow-nav, row click) deliberately keep the dock focused, exactly
    // like switching to a live session does.
    if (opts.dive && dockMode && openPanel) {
      // A dive out of the dock keeps the search filter (see `dockDiveBlur`).
      dockDiveBlur = true;
      dockBlurred = true;
      editor.floatingPanelControl(openPanel.id(), "blur", 0);
    } else if (dockMode && openPanel) {
      // Live-switch: keep the dock focused, but rebuild the list (the
      // `· on-disk` row's synthetic id is gone, replaced by the new live
      // window's) and move the highlight onto the now-active session so
      // the user stays put on the row they just opened.
      refreshOpenDialog();
      syncDockSelectionToActive();
    }
  } catch (e) {
    editor.setStatus(
      editor.t("status.attach_failed", {
        error: e instanceof Error ? e.message : String(e),
      }),
    );
  }
}

function startNewSession(): void {
  if (form) return; // already open
  openForm();
}

// =============================================================================
// "Run Agent…" — launch a starting process into the CURRENT workspace
//
// The dialog itself is the New-Workspace form with its "Launch in" switch set
// to "current" (see `NewSessionForm.target`); only the launch below is
// specific to this target.
// =============================================================================

// Options a Run-Agent launch carries, mirroring the dialogue's per-agent
// controls. `auto`/`prompt`/`teachFreshCli` are only honoured for an agent
// whose registry entry supports each (a bare terminal ignores all three).
interface RunAgentLaunchOpts {
  auto: boolean;
  prompt: string;
  teachFreshCli: boolean;
}

// Launch `cmd` as a terminal in the CURRENT window — no new worktree, no new
// window. Reuses `resolveAgentLaunch` for the argv (session-id pin, auto
// flags, the Fresh CLI contract) and mints the same capability token the
// dialogue does via the extended `createTerminal`, so the agent can drive the
// editor exactly like a dialogue-launched one.
async function launchAgentInCurrentWorkspace(
  cmd: string,
  opts: RunAgentLaunchOpts,
): Promise<number | null> {
  const trimmedCmd = cmd.trim();
  const cwd = editor.getCwd();
  const entry = agentEntryForCmd(trimmedCmd);
  // "Teach Fresh CLI": inject the CLI contract on launch. The capability token
  // is minted regardless (see `allowScript` below) — `teach` only gates the
  // contract.
  const teach = opts.teachFreshCli && entry?.systemPrompt ? entry.systemPrompt : null;
  const argv = splitAgentCmd(trimmedCmd);
  // Keep the resume argv: it is what lets a finished agent be picked back up
  // (status-bar "Resume claude", or a workspace restore) instead of relaunching
  // as a brand-new conversation. Dropping it here was why an agent started in
  // the current workspace restarted as a bare shell.
  const { launch, resume } = resolveAgentLaunch(argv, {
    auto: opts.auto,
    prompt: opts.prompt,
    systemPrompt: teach ? FRESH_CLI_SYSTEM_PROMPT : undefined,
  });
  editor.setGlobalState("orchestrator.last_cmd", trimmedCmd);
  try {
    const created = await editor.createTerminal({
      cwd,
      command: launch.length > 0 ? launch : undefined,
      resume,
      title: launch.length > 0 ? editor.pathBasename(launch[0]) || launch[0] : undefined,
      // Always mint the capability token bound to THIS window + allowlist, so
      // `fresh --cmd ...` from inside the terminal is authorised — matching the
      // dialogue, where the token is always present and only the prompt is
      // gated by "Teach Fresh CLI".
      allowScript: FRESH_CLI_ALLOW_SCRIPT,
      focus: true,
    });
    // The terminal's id, so `runAgent` can judge readiness by this terminal
    // alone.
    return typeof created?.terminalId === "number" ? created.terminalId : null;
  } catch (e) {
    editor.setStatus(
      editor.t("status.prefix", { msg: e instanceof Error ? e.message : String(e) }),
    );
    return null;
  }
}

// =============================================================================
// The orchestrator's plugin API — what a script (or another plugin) can drive
//
// The two dialogs above are how a *human* launches an agent. An agent driving
// the editor from its shell has no way to fill in a form, so each dialog gets a
// programmatic twin taking the same parameters and submitting through the very
// same path (`launchAgentInCurrentWorkspace` / `captureCreateSpec` +
// `startPendingWorkspace`). One launch pipeline, two front doors — a fix or a
// new agent flag reaches both without being implemented twice.
//
// Published through `editor.exportPluginApi`, so a script reaches it the way
// any plugin reaches another's surface:
//
//   const orch = editor.getPluginApi("orchestrator");
//   const ws = await orch.newWorkspace({ path: "/repo", agent: "claude" });
//
// The types below are emitted into `~/.config/fresh/types/plugins.d.ts`, which
// is what makes that call *typed* at the call site rather than a string
// incantation an agent has to be told about.
// =============================================================================

/// The ids that name a workspace to a caller. `workspaceId` is the durable
/// identity — still valid after a restart, and the one to record; `windowId`
/// is a per-process handle, useful only for the rest of this run.
export type WorkspaceIds = {
  workspaceId: string;
  windowId: number;
  root: string;
};

export type AgentLaunchResult = WorkspaceIds & {
  /** The launched command resolved to this agent (`"terminal"` for a bare
   *  shell, `"unknown"` for a command the registry does not know). */
  agent: string;
  /** `true` once the launch was seen to come up: its terminal produced
   *  output within `readyTimeoutMs`. `false` with `error` set when it exited
   *  first or stayed silent; also `false`, without an error, when the caller
   *  passed `wait: false`. */
  ready: boolean;
  /** The workspace's agent state at return. */
  state: AgentState;
  error?: string;
};

/// What `waitForState` resolves with.
export type WaitResult = {
  workspaceId: string;
  windowId: number;
  state: AgentState;
  elapsedMs: number;
  timedOut: boolean;
};

/// Options shared by both launch verbs. Every field is optional; an omitted one
/// takes the dialog's own default, so `runAgent({})` is the dialog's defaults
/// with no agent.
export type RunAgentOptions = {
  /** Wait for the launch to come up before returning (default `true`): the
   *  terminal has to produce output within `readyTimeoutMs`, and an exit
   *  before that is reported as an error. */
  wait?: boolean;
  /** How long `wait` allows, in ms (default 15000). */
  readyTimeoutMs?: number;
  /** Agent command line, e.g. `claude` or `claude --model opus`. A bare
   *  terminal when empty or omitted. */
  agent?: string;
  /** Initial prompt handed to the agent at launch (agents that accept one). */
  prompt?: string;
  /** Run the agent in its reduced-approval mode. Default false. Ignored for an
   *  agent whose registry entry has no such mode. */
  auto?: boolean;
  /** Inject the Fresh system prompt so the agent knows it can drive the editor.
   *  Default true. */
  teach?: boolean;
};

/// Options shared by every `newWorkspace` backend.
export type NewWorkspaceCommon = RunAgentOptions & {
  /** Workspace name. Default: the next auto-generated `<project>-N` locally,
   *  or `ssh:<target>` for a remote one. */
  name?: string;
  /** Move focus into the new workspace once it is up. Default false — an agent
   *  asking for a workspace should not yank the human's focus into it. */
  visit?: boolean;
};

/// A workspace on this machine: the dialog's "Local" backend.
export type LocalWorkspaceOptions = NewWorkspaceCommon & {
  /** Omit (or `"local"`) for a workspace on this machine. */
  backend?: "local";
  /** Project directory the workspace roots at. Default: this workspace's
   *  project. Must exist. */
  path?: string;
  /** Existing branch to check out in the new worktree. Default: the repo's
   *  default branch. */
  branch?: string;
  /** Create the worktree on a new branch of this name, cut from `branch`. */
  newBranch?: string;
  /** Create a git worktree for the workspace. Default true; ignored for a
   *  non-git path. */
  worktree?: boolean;
};

/// A workspace on a remote host over SSH: the dialog's "SSH" backend, whose
/// fields these mirror one-for-one.
export type SshWorkspaceOptions = NewWorkspaceCommon & {
  backend: "ssh";
  /** `host`, `user@host`, `user@host:port`, or a pasted `ssh://…`. The user
   *  is optional — a bare host lets ssh resolve it from its own config.
   *  Required. */
  host: string;
  /** Remote directory to root the session at. Default: ssh's landing
   *  directory on the host. */
  path?: string;
  /** Identity file to authenticate with (ssh's `-i`). */
  identity?: string;
  /** Extra ssh arguments, e.g. `"-J jump"` or `["-o", "ProxyCommand=…"]`.
   *  A string is split on whitespace, like the dialog's field. */
  sshOptions?: string | string[];
};

export type NewWorkspaceOptions = LocalWorkspaceOptions | SshWorkspaceOptions;

/// One workspace, as `listWorkspaces()` reports it.
export type WorkspaceSummary = {
  /** What kind of row this is — the dock lists three, and they are not
   *  interchangeable:
   *   * `"live"` — a real workspace with an editor window behind it. The
   *     only kind with a usable `workspaceId` and a positive `windowId`.
   *   * `"discovered"` — a worktree found on disk that has never been
   *     opened. No window yet, so `workspaceId` is `""` and `windowId` is a
   *     synthetic *negative* placeholder. `focusWorkspace` opens it.
   *   * `"pending"` — a workspace still being created (or one whose create
   *     failed and is waiting for a retry). A local one owns a real window
   *     and real ids from the moment it was asked for, so it can be
   *     focused, renamed and filed like any workspace — only its
   *     *contents* are still on their way. A remote one has no window
   *     until its connect resolves: synthetic ids, and it cannot be
   *     renamed or filed until it lands.
   *  Branch on this rather than on the sign of `windowId`. */
  kind: "live" | "discovered" | "pending";
  /** Durable identity — survives editor restarts. Record this one. Empty
   *  for a `discovered` row, and for a `pending` row that has no window
   *  yet. */
  workspaceId: string;
  /** Per-process window id; valid only for this editor run. Negative for a
   *  `discovered` row, and for a `pending` row with no window (see
   *  `kind`). */
  windowId: number;
  /** `true` for the one workspace the editor is focused on right now. */
  active: boolean;
  /** Dock folder this workspace is filed under (`listFolders()` reports the
   *  set), or `null` when it sits at the top level. */
  folderId: string | null;
  /** Display name shown on the dock. */
  name: string;
  /** Filesystem root (the worktree, for a worktree workspace). */
  root: string;
  /** The project this workspace was cut from. */
  projectPath: string;
  /** Checked-out branch, when known. */
  branch?: string;
  /** Coarse agent activity: working, blocked (waiting on the user), done (unseen finished work), idle, or unknown. */
  agentState: AgentState;
  /** Terminal tab title — in practice the agent's command line, since the
   *  launcher titles the tab with it. Empty when the pane has no title. */
  title: string;
  /** Working-tree summary, when a git probe has completed. `dirty` counts
   *  changed paths; `ahead`/`behind` are relative to the upstream. */
  git?: { branch?: string; dirty?: number; ahead?: number; behind?: number };
  /** Backend kind for a remote workspace (`ssh`, `docker`, …), absent for
   *  a local one. */
  backend?: string;
};

/// One archived workspace, as `listArchived()` reports it. An archived
/// workspace has no window and no dock row — its worktree has been moved out
/// to the graveyard — so it is identified by path, not by `workspaceId`.
export type ArchivedWorkspace = {
  /** Current path of the archived worktree. This is the identity
   *  `unarchiveWorkspace` takes. */
  archivedRoot: string;
  /** Where the worktree lived before it was archived, and where
   *  `unarchiveWorkspace` puts it back. Equal to `archivedRoot` for a
   *  workspace that was archived in place (nothing was moved). */
  originalRoot: string;
  /** Display name it had on the dock. */
  name: string;
  /** Branch the worktree was on. */
  branch: string;
  /** ISO 8601 timestamp of when it was archived. */
  archivedAt: string;
  /** Repo it belongs to, when known. Manifests written by older versions
   *  did not record it; it is recovered from the worktree on demand, so an
   *  empty value here does not prevent `unarchiveWorkspace` from working. */
  projectPath: string;
};

/// One dock folder, as `listFolders()` reports it.
export type FolderSummary = {
  /** Stable folder id — what `moveWorkspace` / `createFolder` take. */
  folderId: string;
  /** Display name shown on the dock. */
  name: string;
  /** Parent folder, or `null` for a top-level one. */
  parent: string | null;
  /** Nesting level, 0 for a top-level folder. Reported so a caller can
   *  render the tree without re-deriving it from `parent`. */
  depth: number;
};

/// What the dock is filtering by. Every field is optional; an omitted one is
/// left as it is, so a caller can flip one control without disturbing the
/// rest.
export type DockFilterOptions = {
  /** The dock's search box. `""` clears it. */
  text?: string;
  /** Restrict the dock to one project (a `projectPath` from
   *  `listWorkspaces()`), or `null` for every project. Not validated — a
   *  project with no workspaces just lists nothing. */
  project?: string | null;
  /** Show on-disk worktrees that have no open workspace (the "all
   *  worktrees" checkbox). */
  worktrees?: boolean;
  /** Show workspaces with no edited files (the "show empty" checkbox). */
  showEmpty?: boolean;
  /** The modal picker's scope control: `"current"` foregrounds the active
   *  window's project, `"all"` lists every project. The dock uses `project`
   *  instead, so this only shows up when the picker is open. */
  scope?: "current" | "all";
};

/// Public surface of the bundled `orchestrator` plugin, reachable through
/// `editor.getPluginApi("orchestrator")`.
///
/// One convention runs through the whole surface: a verb returns `false`
/// when the thing it was pointed at does not exist (no workspace with that
/// id, no folder with that id) and *throws* when it does exist but the
/// operation was refused or failed. So a caller that trusts its ids can
/// ignore the return value and let a real failure surface as a rejected
/// promise / thrown error, and a caller that is guessing can branch on the
/// boolean without wrapping everything in try/catch.
export type OrchestratorApi = DiscoveryHost & {
  /** Replace the dock's external sessions group: Claude/Codex sessions open outside
   *  this editor, as `live_sessions.ts` lists them. `commands` are the CLI
   *  programs it ran, so opening a row attaches with the same ones. */
  setExternalSessions(update: ExternalUpdate): void;
  /** Launch a coding agent in THIS workspace — the headless twin of the
   *  "Run Agent…" dialog. By default resolves once the launch has been seen
   *  to come up (its terminal produced output within `readyTimeoutMs`);
   *  `ready: false` with `error` when it exited first or stayed silent, so
   *  a caller never mistakes a dead terminal for a running agent. */
  runAgent(options?: RunAgentOptions): Promise<AgentLaunchResult>;
  /** Create a workspace and launch a coding agent in it — the headless twin
   *  of the "New Workspace" dialog, including its backend switch.
   *
   *  Omit `backend` (or pass `"local"`) for a workspace on this machine: a
   *  git worktree by default. Pass `backend: "ssh"` with a `host` for one on
   *  a remote host, which mirrors the dialog's SSH fields — remote path,
   *  identity file, and extra ssh arguments.
   *
   *  Unlike the dialog, which returns to the user immediately and reports
   *  progress on the dock, this waits for the create to finish: a caller has no
   *  dock to watch, the durable workspace id does not exist until the window is
   *  born, and waiting is what lets a failed create reject rather than
   *  silently do nothing. */
  newWorkspace(options?: NewWorkspaceOptions): Promise<WorkspaceIds>;
  /** Every workspace the dock is tracking, in dock order — what a caller
   *  needs to find the one it made earlier, or to report on all of them.
   *  Reads the live model, so it reflects creations made moments ago. */
  listWorkspaces(): WorkspaceSummary[];
  /** One workspace — by `workspaceId`, `windowId` (or its decimal string),
   *  or dock name — with the decision chain behind its `agentState`
   *  (`explain`: reasons, the question line and rule that matched, output
   *  age, the rule set in force). `null` when there is no such workspace. */
  getWorkspace(target: string | number): (WorkspaceSummary & { explain: StateExplanation }) | null;
  /** Block until the workspace's agent state is one of `until` (default:
   *  anything but `working`), polling every `pollMs` (250). Resolves with
   *  `timedOut: true` after `timeoutMs` (default 5 minutes; 0 = no limit).
   *  Throws for an unknown workspace. The synchronisation primitive a lead
   *  agent needs to dispatch work and collect it. */
  waitForState(
    target: string | number,
    options?: { until?: AgentState | AgentState[]; timeoutMs?: number; pollMs?: number },
  ): Promise<WaitResult>;
  /** Focus a workspace by its durable `workspaceId` (or its `windowId`) —
   *  what `listWorkspaces()` reports.
   *
   *  Use this rather than `editor.setActiveWindow(w.windowId)`. A workspace
   *  discovered on disk but never activated has no window yet, and
   *  `listWorkspaces()` reports a placeholder *negative* `windowId` for it,
   *  which `setActiveWindow` rejects. This attaches a session at the worktree
   *  first when that is what the row needs, so one call works for every row
   *  the list returns.
   *
   *  Resolves `true` once the workspace is active, `false` if no workspace
   *  matches. */
  focusWorkspace(target: string | number): Promise<boolean>;

  // ── organising the dock ────────────────────────────────────────────────
  // The headless twins of the dock's row context menu and its "New Task… ▾"
  // / "Move…" dropdowns. `target` is a `workspaceId` or a `windowId`, the
  // same pair `focusWorkspace` accepts.

  /** Rename a workspace — the dock's "Rename…". Omit `name` (or pass an
   *  empty one) to clear the manual name and let the auto-name (the
   *  terminal's title) or the host label take back over.
   *
   *  Throws for a workspace still being created — it has no durable
   *  identity to hang a name on yet. */
  renameWorkspace(target: string | number, name?: string): boolean;
  /** File a workspace under a dock folder — the dock's "Move to Folder…".
   *  `null` moves it back to the top level.
   *
   *  Throws on an unknown `folderId`, and for a workspace still being
   *  created. */
  moveWorkspace(target: string | number, folderId: string | null): boolean;

  /** Every dock folder, parents before children, siblings in the order the
   *  dock shows them. */
  listFolders(): FolderSummary[];
  /** Create a dock folder and return its new id. `parent` nests it under an
   *  existing folder; omitted (or `null`) puts it at the top level.
   *
   *  Throws on an empty name or an unknown `parent`. */
  createFolder(name: string, parent?: string | null): string;
  /** Rename a dock folder. Throws on an empty name. */
  renameFolder(folderId: string, name: string): boolean;
  /** Delete a dock folder. Nothing inside is lost: its child folders and
   *  member workspaces reparent to its own parent, exactly as the dock's
   *  "Delete Folder" does. */
  deleteFolder(folderId: string): boolean;

  // ── lifecycle ──────────────────────────────────────────────────────────
  // The headless twins of the picker's Stop / Archive / Delete, each with
  // the same eligibility rules the buttons enforce — an ineligible target
  // throws rather than quietly doing nothing.

  /** Signal the workspace's agent process group (SIGTERM, then SIGKILL for
   *  an agent that ignores it) and leave the workspace in place.
   *
   *  Throws for a workspace with no agent terminal to signal. */
  stopWorkspace(target: string | number): boolean;
  /** Stop the workspace and move its worktree to the archive, recording it
   *  in the archive manifest so it can be recovered later. Resolves once the
   *  move has finished.
   *
   *  Throws if the workspace cannot be archived, or if the archive fails. */
  archiveWorkspace(target: string | number): Promise<boolean>;
  /** Forget the workspace, removing its worktree when it owns one outright.
   *  Resolves once the removal has finished.
   *
   *  Throws if the workspace cannot be deleted, or if the delete fails. */
  deleteWorkspace(target: string | number): Promise<boolean>;

  // ── the archive ────────────────────────────────────────────────────────
  // Archived workspaces are off the dock entirely: no window, no row, their
  // worktree moved out to the graveyard. These two are how a caller sees
  // them and brings one back.

  /** Every archived workspace on this machine, across every repo, newest
   *  first. */
  listArchived(): ArchivedWorkspace[];
  /** Put an archived workspace back where it came from: its worktree returns
   *  to `originalRoot` and its archive entry is dropped. `target` is the
   *  `archivedRoot` (or the `name`) that `listArchived()` reports.
   *
   *  The workspace comes back as an unopened worktree on the dock rather
   *  than a running session — the inverse of Archive, not "restore and
   *  launch". Call `focusWorkspace` after it to open one.
   *
   *  Resolves `false` when nothing matches; throws when the restore itself
   *  fails — most usefully when something already occupies `originalRoot`,
   *  which it refuses to overwrite. */
  unarchiveWorkspace(target: string): Promise<boolean>;

  // ── dock view state ────────────────────────────────────────────────────
  // Both apply to the dock whether or not it is open: with the dock closed
  // they set what it will show the next time it opens, which is the same
  // thing the in-dock controls do for the rest of the session.

  /** Dock row density: `"card"` (the multi-line pill) or `"compact"` (one
   *  line per workspace) — the dock's "view" button. */
  setDockView(view: "card" | "compact"): void;
  /** Set any of the dock's filter controls. See `DockFilterOptions`. */
  setDockFilter(options?: DockFilterOptions): void;
};

declare global {
  interface FreshPluginRegistry {
    orchestrator: OrchestratorApi;
  }
}

// The active workspace's ids, for a launch that ran in place.
function currentWorkspaceIds(): WorkspaceIds {
  const id = editor.activeWindow();
  const info = editor.listWindows().find((w) => w.id === id);
  return {
    workspaceId: info?.stable_id ?? "",
    windowId: id,
    root: info?.root ?? editor.getCwd(),
  };
}

function trimmed(value: string | undefined): string {
  return typeof value === "string" ? value.trim() : "";
}

/// Yield once, so the caller's `await` is attached before anything below can
/// throw.
///
/// An `async` function that throws before its first `await` returns an
/// *already-rejected* promise. The runtime's rejection tracker fires the
/// moment a promise rejects with no handler attached — which is one tick
/// before the caller's `await` can attach one — so a validation failure the
/// caller catches perfectly well still gets reported as an unhandled
/// rejection, and under the plugin test harness
/// (`set_panic_on_js_errors(true)`) that kills the plugin thread. Yielding
/// first makes the returned promise *pending*, so the rejection lands on a
/// promise someone is already watching.
///
/// Every async verb that can reject on its arguments starts with this.
function yieldToCaller(): Promise<void> {
  return Promise.resolve();
}

/// The per-agent options in the shape the shared spec builders take. The
/// gating against what the resolved agent actually supports happens inside
/// `gateAgentOptions`, so this only has to supply the caller's intent and the
/// API's defaults (teach on, auto off — the dialog's defaults too).
function agentOptionsFrom(options: RunAgentOptions): AgentOptionInputs {
  return {
    auto: options.auto ?? false,
    prompt: trimmed(options.prompt),
    teach: options.teach ?? true,
  };
}

async function runAgent(options: RunAgentOptions = {}): Promise<AgentLaunchResult> {
  await yieldToCaller();
  const cmd = trimmed(options.agent);
  // Same gating and the same launch function as `submitForm`'s
  // current-workspace branch, so a bare terminal never gets stray flags.
  const gated = gateAgentOptions(cmd, agentOptionsFrom(options));
  const launchedAt = Date.now();
  const terminalId = await launchAgentInCurrentWorkspace(cmd, {
    auto: gated.auto,
    prompt: gated.startPrompt,
    teachFreshCli: gated.teachFreshCli,
  });
  // The agent runs in the workspace the caller is already in; returning its ids
  // means a caller never has to correlate "which workspace did that land in".
  const ids = currentWorkspaceIds();
  const entry = cmd ? agentEntryForCmd(cmd) : null;
  const argv0 = splitAgentCmd(cmd)[0] ?? "";
  const agent = !cmd ? "terminal" : (entry?.id ?? (editor.pathBasename(argv0) || argv0 || "unknown"));
  const s = orchestratorSessions.get(ids.windowId);
  const stateOf = (): AgentState => (s ? sessionState(s) : "unknown");
  if (terminalId === null) {
    return { ...ids, agent, ready: false, state: stateOf(), error: `could not open a terminal for ${cmd || "the shell"}` };
  }
  if (options.wait === false) {
    return { ...ids, agent, ready: false, state: stateOf() };
  }
  // A launch is "up" once *its* terminal has said anything; one that exits
  // first is the silent failure this exists to catch (a missing binary, a
  // bad flag, an auth prompt on a tty that closed). Judged per terminal, so
  // another shell printing in the same window cannot vouch for it.
  const deadline = launchedAt + Math.max(1000, options.readyTimeoutMs ?? 15000);
  while (Date.now() < deadline) {
    const out = terminalOutputAt.get(terminalId);
    const exit = terminalExitAt.get(terminalId);
    const printed = out !== undefined && out >= launchedAt;
    if (exit !== undefined && exit >= launchedAt) {
      return {
        ...ids,
        agent,
        ready: false,
        state: stateOf(),
        error: `${cmd || "terminal"} exited ${printed ? "right after starting" : "before it produced output"}`,
      };
    }
    if (printed) {
      return { ...ids, agent, ready: true, state: stateOf() };
    }
    await editor.delay(200);
  }
  return {
    ...ids,
    agent,
    ready: false,
    state: stateOf(),
    error: `${cmd || "terminal"} produced no output within ${Math.round((deadline - launchedAt) / 1000)}s`,
  };
}

/// Block until a workspace's agent state is one of `until` (default: any
/// state other than `working`, i.e. "quiet"), polling every `pollMs`. Resolves
/// with `timedOut: true` after `timeoutMs` (default 5 minutes; `0` = no
/// limit). Throws for an unknown workspace.
async function waitForState(
  target: string | number,
  options: { until?: AgentState | AgentState[]; timeoutMs?: number; pollMs?: number } = {},
): Promise<WaitResult> {
  await yieldToCaller();
  const s = resolveWorkspace(target);
  if (!s || s.discovered) throw new Error(`no such workspace: ${String(target)}`);
  const until = new Set<AgentState>(
    options.until === undefined
      ? ["blocked", "done", "idle", "unknown"]
      : Array.isArray(options.until)
        ? options.until
        : [options.until],
  );
  const started = Date.now();
  const timeout = options.timeoutMs ?? 300_000;
  const poll = Math.max(50, options.pollMs ?? 250);
  const ids = (): { workspaceId: string; windowId: number } => ({
    workspaceId: editor.listWindows().find((w) => w.id === s.id)?.stable_id ?? "",
    windowId: s.id,
  });
  for (;;) {
    const state = sessionState(s);
    if (until.has(state)) {
      return { ...ids(), state, elapsedMs: Date.now() - started, timedOut: false };
    }
    if (timeout > 0 && Date.now() - started >= timeout) {
      return { ...ids(), state, elapsedMs: Date.now() - started, timedOut: true };
    }
    await editor.delay(poll);
  }
}

/// One workspace with the decision chain behind its state, or `null`.
function getWorkspace(target: string | number): (WorkspaceSummary & { explain: StateExplanation }) | null {
  const s = resolveWorkspace(target);
  if (!s) return null;
  const row = listWorkspaces().find((w) => w.windowId === s.id);
  if (!row) return null;
  return { ...row, explain: explainState(s) };
}

/// Build the caller's options into the same `CreateSpec` the dialog submits.
/// Every field goes through the shared builders — this function only supplies
/// the API's defaults and the validation the dialog gets from its own widgets
/// (a path field that completes against the filesystem, a host field that
/// refuses to submit empty).
function specForNewWorkspace(options: NewWorkspaceOptions): CreateSpec {
  const cmd = trimmed(options.agent);
  const name = trimmed(options.name);
  const agentOptions = agentOptionsFrom(options);

  if (options.backend === "ssh") {
    const raw = options.sshOptions;
    const extraArgs = Array.isArray(raw)
      ? raw.map((a) => String(a).trim()).filter((a) => a !== "")
      : trimmed(raw)
        ? trimmed(raw).split(/\s+/)
        : [];
    const built = buildSshSpec({
      ...agentOptions,
      host: trimmed(options.host),
      name,
      cmd,
      remotePath: trimmed(options.path),
      identity: trimmed(options.identity),
      extraArgs,
    });
    // The dialog keeps itself open on a bad host and shows the message; a
    // caller gets the same message as a thrown error.
    if (!built.ok) throw new Error(built.error);
    return built.spec;
  }

  const requestedPath = trimmed(options.path);
  const projectPath = requestedPath || localProjectDefault();
  // A path the caller passed has to exist. The dialog's field completes against
  // the filesystem, so a human sees a wrong path immediately; a caller passing
  // `path` by hand does not, and the create would otherwise "succeed" into a
  // workspace rooted at a directory that isn't there.
  if (requestedPath && !editor.fileExists(editor.localPath(requestedPath))) {
    throw new Error(`project path does not exist: ${requestedPath}`);
  }
  return buildLocalSpec({
    ...agentOptions,
    projectPath,
    // "" ⇒ `runLocalCreate` allocates the next `<project>-N` name, the same
    // default the dialog's placeholder shows.
    name,
    cmd,
    branch: trimmed(options.branch),
    newBranch: trimmed(options.newBranch),
    // Worktree by default (the dialog's default too); `runLocalCreate` demotes
    // it to false on its own when the path isn't a git tree.
    createWorktree: options.worktree ?? true,
  });
}

async function newWorkspace(
  options: NewWorkspaceOptions = {},
): Promise<WorkspaceIds> {
  // Before `specForNewWorkspace`, which rejects a bad host / missing path.
  await yieldToCaller();
  const spec = specForNewWorkspace(options);
  const pendingId = await startPendingWorkspace(spec, { visit: options.visit ?? false });
  const outcome = await awaitCreateOutcome(pendingId);
  if (!outcome.ok) {
    // Thrown, not returned: a failed create must reject the caller's promise
    // (and so fail its script), not hand it a result object it might mistake
    // for a workspace. The dock keeps the row for a human to retry or dismiss.
    throw new Error(outcome.error || "workspace creation failed");
  }
  return {
    workspaceId: outcome.workspaceId ?? "",
    windowId: outcome.windowId ?? 0,
    root: outcome.root ?? "",
  };
}

function listWorkspaces(): WorkspaceSummary[] {
  // Reconcile first: a workspace created seconds ago (by a script, or by
  // the dialog) is only in the model once the host's window list has been
  // folded in, and a caller listing right after creating should see it.
  reconcileSessions();
  const windows = editor.listWindows();
  const activeId = editor.activeWindow();
  return [...orchestratorSessions.values()].map((session) => {
    const win = windows.find((w) => w.id === session.id);
    const git = session.git?.info;
    return {
      // The three row kinds the dock lists. A caller used to have to infer
      // this from a negative `windowId` — a sentinel the type never named.
      kind: session.pending
        ? "pending" as const
        : session.discovered
          ? "discovered" as const
          : "live" as const,
      workspaceId: win?.stable_id ?? "",
      windowId: session.id,
      active: session.id === activeId,
      folderId: folderOfSession(session.id),
      name: session.label,
      root: session.root,
      projectPath: session.projectPath,
      branch: session.branch ?? git?.branch,
      // Live, not the cached `state`: blocked/done are computed at read time.
      agentState: session.discovered || session.pending ? session.state : sessionState(session),
      title: session.terminalTitle ?? "",
      git: git
        ? {
          branch: git.branch,
          dirty: git.dirty,
          ahead: git.ahead,
          behind: git.behind,
        }
        : undefined,
      backend: session.remote?.kind,
    };
  });
}

/// Focus a workspace by durable `workspaceId` or per-process `windowId`.
///
/// The reason this exists rather than leaving callers to
/// `editor.setActiveWindow(w.windowId)`: a workspace the orchestrator found
/// on disk but has never activated has no window at all, and the
/// `windowId` reported for it is a synthetic negative placeholder. Handing
/// that to `setActiveWindow` cannot work — so the "focus a workspace I got
/// from listWorkspaces()" operation has to know how to *make* the window when
/// there isn't one. That is what `attachToWorktree` does, and doing it behind
/// one verb means a caller never has to learn the distinction.
async function focusWorkspace(target: string | number): Promise<boolean> {
  const match = resolveWorkspace(target);
  if (!match) return false;

  if (match.discovered) {
    // No window yet — attach a session at the worktree, which activates it.
    await attachToWorktree({
      root: match.root,
      projectPath: match.projectPath ?? match.root,
      label: match.label,
      branch: match.branch,
      discoveredId: match.id,
      dive: true,
    });
    return true;
  }

  if (match.id <= 0) return false;
  if (match.id !== editor.activeWindow()) editor.setActiveWindow(match.id);
  return true;
}

/// Resolve the `workspaceId | windowId` pair every workspace verb takes to a
/// live session, or `null` when nothing matches.
///
/// Reconciles first for the same reason `listWorkspaces` does: a workspace
/// created moments ago is only in the model once the host's window list has
/// been folded in, and a caller acting on an id it was just handed should not
/// have to sleep first.
function resolveWorkspace(target: string | number): AgentSession | null {
  reconcileSessions();
  // Match on either identity. `workspaceId` (the host's `stable_id`) is the
  // one worth recording; `windowId` is accepted because it is right there in
  // the same summary and a caller reaching for it is not wrong to.
  if (typeof target === "number") return orchestratorSessions.get(target) ?? null;
  if (!target) return null;
  const windows = editor.listWindows();
  for (const session of orchestratorSessions.values()) {
    const stable = windows.find((w) => w.id === session.id)?.stable_id;
    if (stable === target) return session;
  }
  // A CLI caller may only have the dock's name or the window number.
  if (/^-?\d+$/.test(target)) return orchestratorSessions.get(Number(target)) ?? null;
  for (const session of orchestratorSessions.values()) {
    if (session.label === target || session.hostLabel === target || workspaceCustomName(session) === target) {
      return session;
    }
  }
  return null;
}

/// A workspace still being created has no durable identity and no worktree
/// yet — the dock offers it Retry / Dismiss and nothing else, so the verbs
/// that organise a *real* workspace refuse it here rather than writing a name
/// or a folder assignment against a placeholder key that is about to vanish.
// Guard the verbs that need somewhere durable to record their result.
//
// A workspace still being created keys its name and its folder off the
// durable `stableId` it was born with, so both survive the build and both
// are safe to set while it runs. A *windowless* placeholder (a remote
// create, whose window is born by the connect) has no such id yet — there
// is nothing to file the change against, so it is still refused.
function rejectPending(s: AgentSession, verb: string): void {
  if (s.pending && !s.stableId) {
    throw new Error(`workspace is still being created and cannot be ${verb}`);
  }
}

/// Push folder-tree changes into an open dock. The tree's expansion set is
/// host-owned state seeded from the plugin's persisted set, so a folder
/// created or deleted behind the dock's back has to be re-seeded before the
/// re-render — the same two steps `submitCreateFolder` runs.
function refreshDockTree(): void {
  if (openPanel && dockMode) {
    openPanel.setExpandedKeys("sessions", dockExpandedKeys());
  }
  refreshOpenDialog();
}

function apiRenameWorkspace(target: string | number, name?: string): boolean {
  const s = resolveWorkspace(target);
  if (!s) return false;
  rejectPending(s, "renamed");
  // An omitted / empty name clears the manual rename, exactly as submitting
  // the dialog's emptied-out field does.
  renameWorkspace(s, typeof name === "string" ? name : "");
  refreshOpenDialog();
  return true;
}

function apiMoveWorkspace(
  target: string | number,
  folderId: string | null,
): boolean {
  const s = resolveWorkspace(target);
  if (!s) return false;
  rejectPending(s, "filed");
  // An unknown folder id throws rather than silently filing at the top
  // level: `assignSessionToFolder` would happily record it, and the row
  // would then read as unfiled because `folderOfSession` drops assignments
  // to folders that don't exist — a move that reports success and does
  // nothing is the worst of both.
  if (folderId !== null && !folderById(folderId)) {
    throw new Error(`no such folder: ${folderId}`);
  }
  assignSessionToFolder(s.id, folderId);
  refreshDockTree();
  return true;
}

function apiListFolders(): FolderSummary[] {
  const out: FolderSummary[] = [];
  // Depth-first from the top level, so parents precede their children and
  // siblings come out in the order `childFoldersOf` gives the dock.
  const walk = (parent: string | null, depth: number): void => {
    for (const f of childFoldersOf(parent)) {
      out.push({ folderId: f.id, name: f.name, parent: f.parent ?? null, depth });
      walk(f.id, depth + 1);
    }
  };
  walk(null, 0);
  return out;
}

function apiCreateFolder(name: string, parent?: string | null): string {
  const clean = trimmed(name);
  // The dialog falls back to "New Folder" on an empty submit because a human
  // who typed nothing meant "just make me one". A caller passing an empty
  // string meant something else — most likely a variable that didn't hold
  // what they thought — so it is an error rather than a silent default.
  if (!clean) throw new Error("folder name must not be empty");
  const parentId = parent ?? null;
  if (parentId !== null && !folderById(parentId)) {
    throw new Error(`no such folder: ${parentId}`);
  }
  const id = createFolder(clean, parentId);
  refreshDockTree();
  return id;
}

function apiRenameFolder(folderId: string, name: string): boolean {
  if (!folderById(folderId)) return false;
  const clean = trimmed(name);
  if (!clean) throw new Error("folder name must not be empty");
  renameFolder(folderId, clean);
  refreshOpenDialog();
  return true;
}

function apiDeleteFolder(folderId: string): boolean {
  if (!folderById(folderId)) return false;
  // `deleteFolder` reparents the subtree one level up, so nothing inside is
  // lost — same as the dock's "Delete Folder".
  deleteFolder(folderId);
  refreshDockTree();
  return true;
}

/// Shared guard for the three lifecycle verbs: the picker disables a button
/// it cannot honour, and a caller deserves the reason rather than a no-op.
function requireEligible(s: AgentSession, action: BulkAction): void {
  if (bulkEligible(action, s.id)) return;
  if (action === "stop") {
    throw new Error("workspace has no agent process to stop");
  }
  throw new Error(`workspace cannot be ${action === "archive" ? "archived" : "deleted"}`);
}

function apiStopWorkspace(target: string | number): boolean {
  const s = resolveWorkspace(target);
  if (!s) return false;
  requireEligible(s, "stop");
  // Same batch runner as the picker's confirmed Stop, over one id.
  if (runStopBatch([s.id]) === 0) throw new Error("stop failed");
  refreshOpenDialog();
  return true;
}

/// Archive / delete over a single workspace, through the same batch runner
/// the picker's confirmed action uses — so the cross-machine manifest sync,
/// and anything added to that path later, applies to a scripted archive too.
async function runLifecycle(
  target: string | number,
  action: "archive" | "delete",
): Promise<boolean> {
  // Before `requireEligible`, which rejects an ineligible workspace.
  await yieldToCaller();
  const s = resolveWorkspace(target);
  if (!s) return false;
  requireEligible(s, action);
  const res = await runLifecycleBatch(action, [s.id]);
  if (res.ok === 0) {
    throw new Error(res.lastErr || `${action} failed`);
  }
  refreshOpenDialog();
  return true;
}

function apiListArchived(): ArchivedWorkspace[] {
  const out: ArchivedWorkspace[] = [];
  for (const { manifest } of scanArchiveManifests()) {
    for (const e of manifest.sessions) {
      out.push({
        archivedRoot: e.root,
        originalRoot: e.original_root,
        name: e.label,
        branch: e.branch,
        archivedAt: e.archived_at,
        projectPath: e.repo_root ?? "",
      });
    }
  }
  // Newest first: the one a caller is most likely to want back is the one it
  // just archived.
  out.sort((a, b) => (a.archivedAt < b.archivedAt ? 1 : a.archivedAt > b.archivedAt ? -1 : 0));
  return out;
}

async function apiUnarchiveWorkspace(target: string): Promise<boolean> {
  const want = trimmed(target);
  if (!want) return false;
  // Match on the archived path first (unique), then the display name, which
  // is what a human reads off the listing. A name shared by two archived
  // workspaces resolves to the newest, matching the listing's own order.
  let match: ArchivedSession | null = null;
  for (const { manifest } of scanArchiveManifests()) {
    for (const e of manifest.sessions) {
      if (e.root === want) {
        match = e;
        break;
      }
      if (e.label === want && (!match || e.archived_at > match.archived_at)) {
        match = e;
      }
    }
    if (match && match.root === want) break;
  }
  if (!match) return false;
  const res = await unarchiveOne(match);
  if (!res.ok) throw new Error(res.err || "unarchive failed");
  // The manifest changed, so push it the same way the archive path does.
  refreshOpenDialog();
  return true;
}

function apiSetDockView(view: "card" | "compact"): void {
  if (view !== "card" && view !== "compact") {
    throw new Error(`unknown dock view: ${view}`);
  }
  dockView = view;
  // Pin it for the rest of the session, exactly as the toolbar's "view"
  // button does — the `defaultView` setting only decides where the dock
  // *starts*, so without the override a later re-open would undo this.
  dockViewOverride = view;
  refreshOpenDialog();
}

function apiSetDockFilter(
  options: DockFilterOptions = {},
  // Internal, and deliberately absent from the published signature: set when
  // the call comes from the filter box's own `change` event. The box already
  // holds the text and owns the caret, so the value must not be pushed back
  // (that would move the caret to the end and make mid-string editing jump).
  fromWidget?: { cursorByte?: number },
): void {
  // The row the user is looking at, so it can be kept highlighted across the
  // re-filter below. Captured before anything changes.
  const prevId = openDialog?.filteredIds[openDialog.selectedIndex];

  // Each control is written to its remembered module value *and* to the open
  // dialog's live state. The remembered value is what makes this work with
  // the dock closed: the next open seeds from it, so setting a filter ahead
  // of opening the dock does what a caller expects instead of nothing.
  if (typeof options.text === "string") {
    const value = options.text;
    if (openDialog) {
      openDialog.filter.value = value;
      openDialog.filter.cursor = fromWidget?.cursorByte ?? utf8Len(value);
      // The filter box is a controlled widget with its own buffer: updating
      // our state only changes what we filter *by*, so the typed text has to
      // be pushed back explicitly or the list and the box disagree. Not when
      // the box is where the value came from — see `fromWidget`.
      if (!fromWidget) openPanel?.setValue("filter", value, utf8Len(value));
    }
  }
  if (options.project !== undefined) {
    const key = options.project ?? "";
    lastDockProjectFilter = key === "" ? null : key;
    // `pickProject` re-filters, closes any open dropdown and re-renders; it
    // is a no-op with the dialog closed, which the remembered value covers.
    if (openDialog) pickProject(key);
  }
  if (typeof options.worktrees === "boolean") {
    lastShowWorktrees = options.worktrees;
    if (openDialog) openDialog.showWorktrees = options.worktrees;
  }
  if (typeof options.showEmpty === "boolean") {
    // The stored flag is the inverse of the user-facing checkbox.
    lastHideTrivial = !options.showEmpty;
    if (openDialog) openDialog.hideTrivial = !options.showEmpty;
  }
  if (options.scope === "current" || options.scope === "all") {
    lastOpenScope = options.scope;
    if (openDialog) openDialog.scope = options.scope;
  }

  if (openDialog) {
    openDialog.filteredIds = filterSessions(openDialog.filter.value);
    // Pruning is deliberately limited to the two *visibility* checkboxes.
    // A row hidden by the search box or the project menu stays checked on
    // purpose — `selectedSessions()` counts checked-but-filtered-out rows, so
    // a bulk action survives narrowing the list to find the next member. A
    // row hidden by "all worktrees" / "show empty" is a different matter: the
    // user just said they do not want that class of row at all.
    if (options.worktrees === false || options.showEmpty === false) {
      const visible = new Set(openDialog.filteredIds);
      for (const id of [...openDialog.selectedIds]) {
        if (!visible.has(id)) openDialog.selectedIds.delete(id);
      }
    }
    // Keep the highlight on the same row when it survived the narrowing.
    const nextIdx = prevId !== undefined ? openDialog.filteredIds.indexOf(prevId) : -1;
    openDialog.selectedIndex = nextIdx >= 0 ? nextIdx : 0;
  }
  // A search force-opens every folder so matches aren't buried, and restores
  // the user's expansion set when it clears — `refreshOpenDialog` runs that
  // reconciliation (`applyDockExpansion`) after it rebuilds the tree.
  refreshOpenDialog();
  // Turning "all worktrees" ON re-scans *now* so the rows reflect every
  // project's on-disk worktrees at this moment — not just whatever the single
  // scan at dialog-open time happened to catch. Discovery walks every known
  // project (each open/persisted session's repo, plus the cwd repo), so a
  // fresh scan here is what makes the toggle show worktrees across all
  // projects rather than a stale subset. Async; `refreshDiscoveredWorktrees`
  // re-renders the dialog when the scan lands.
  if (options.worktrees === true) void refreshDiscoveredWorktrees();
}

editor.exportPluginApi("orchestrator", {
  // The external sessions group's feed (`live_sessions.ts`).
  setExternalSessions,
  // `DiscoveryHost`: what the Everything dialog (`agent_discovery.ts`) needs.
  scanTargets,
  resumeArgv,
  openWorkspaceForm,
  addMachine: (done: (savedKey: string | null) => void) =>
    openMachineDialog(null, "discover", undefined, undefined, done),
  runAgent,
  newWorkspace,
  listWorkspaces,
  getWorkspace,
  waitForState,
  focusWorkspace,
  renameWorkspace: apiRenameWorkspace,
  moveWorkspace: apiMoveWorkspace,
  listFolders: apiListFolders,
  createFolder: apiCreateFolder,
  renameFolder: apiRenameFolder,
  deleteFolder: apiDeleteFolder,
  stopWorkspace: apiStopWorkspace,
  archiveWorkspace: (target: string | number) => runLifecycle(target, "archive"),
  deleteWorkspace: (target: string | number) => runLifecycle(target, "delete"),
  listArchived: apiListArchived,
  unarchiveWorkspace: apiUnarchiveWorkspace,
  setDockView: apiSetDockView,
  setDockFilter: apiSetDockFilter,
});

// Form key bindings. The focused control answers a key first — a field
// types and moves its caret, the prompt box takes Enter and the arrows, a
// dropdown opens and walks its list, a suggestion list accepts on Tab/Enter
// once stepped into, Esc closes a pop-up — and these commands get only what
// it leaves. Tab / Shift+Tab are the host's ring, and Enter on a
// single-line field is the host's too: it moves on to the next control.
// Ctrl+Enter and Alt+Enter are dialog-wide shortcuts: they run ahead of any
// control.
const FORM_MODE_BINDINGS: string[][] = [
  ["C-Enter", "orchestrator_form_submit", "shortcut"],
  ["M-Enter", "orchestrator_form_submit_bg", "shortcut"],
  ["Escape", "orchestrator_form_key_escape"],
  // ⌫ in the "where is this project?" folder browser goes up a folder.
  ["Backspace", "orchestrator_form_browse_up", "on:place_browse_list"],
  // ↑/↓ on the fields that remember what was typed: history, or the
  // suggestions with history mixed in. On every other control ↑/↓ are the
  // host's — they move focus to the control above or below.
  ["Up", "orchestrator_form_key_up", "on:project_path,branch,name,cmd"],
  ["Down", "orchestrator_form_key_down", "on:project_path,branch,name,cmd"],
];

editor.defineMode(NEW_SESSION_MODE, FORM_MODE_BINDINGS, true, true);

// Enter on the dock's session tree — the "dive in" gesture for a session,
// or expand/collapse for a folder. A session row is already the active
// window via the arrow/click live-switch (a discovered worktree was opened
// on navigation too), so Enter just hands keyboard focus to the editor. If
// the row is still discovered here (Enter pressed before the debounced
// switch landed) attach it now, diving in to match the live path below.
function dockActivate(): void {
  if (!dockMode || !openPanel || !openDialog) return;
  const node = dockSelectedNode();
  // Choosing a folder: Enter on one picks it; nothing else is a target.
  if (movePick) {
    if (node?.kind === "folder" && !isExternalFolder(node.folderId)) applyMovePick(node.folderId);
    return;
  }
  if (node && node.kind === "folder") {
    toggleDockFolderExpansion(folderNodeKey(node.folderId));
    return;
  }
  if (node && node.kind === "live") {
    activateLiveRow(node.liveKey);
    return;
  }
  const id = dockSelectedSessionId();
  const sel = typeof id === "number" ? orchestratorSessions.get(id) : undefined;
  const act = rowActivation(sel);
  if (act.kind === "inert") return;
  if (act.kind === "attach") {
    const w = act.session;
    void attachToWorktree({
      root: w.root,
      projectPath: w.projectPath ?? w.root,
      label: w.label,
      branch: w.branch,
      discoveredId: w.id,
      dive: true,
    });
    return;
  }
  // Enter is the deliberate dive: if the highlighted session isn't the
  // active window yet — a disconnected remote that `scheduleDockSwitch`
  // intentionally did NOT auto-connect on arrow-nav — commit the switch
  // now. For a dormant remote this lands in its "Connecting…" shell (the
  // #2570 dive path); for a live/local row it's the switch arrow-nav would
  // otherwise have made before the debounce landed.
  if (act.windowId !== editor.activeWindow()) {
    editor.setActiveWindow(act.windowId);
  }
  // Same as the row click: the filter that surfaced this row is kept
  // across the dive (see `dockDiveBlur`).
  dockDiveBlur = true;
  dockBlurred = true;
  editor.floatingPanelControl(openPanel.id(), "blur", 0);
  return;
}

// Whether a list widget event names `key`: keyboard events carry the
// list's own key, a row click carries the row's key with the list's in
// `payload.list_key`.
function isListEvent(
  e: { event_type: string; widget_key?: string; payload?: unknown },
  key: string,
): boolean {
  if (e.event_type !== "select" && e.event_type !== "activate") return false;
  if (e.widget_key === key) return true;
  const payload = (e.payload ?? {}) as Record<string, unknown>;
  return payload.list_key === key;
}

// The dock's keymap. The focused control answers a key first — the tree
// moves, opens folders and fires `activate` on Enter (see the `sessions`
// activate below), a menu list walks and accepts, the filter types, a
// button runs — and these commands get what it leaves.
const DOCK_MODE_BINDINGS: string[][] = [
  ["/", "orchestrator_dock_filter"],
  ["Escape", "orchestrator_dock_escape"],
  ["Enter", "orchestrator_dock_enter"],
  ["F2", "orchestrator_dock_context"],
  ["Menu", "orchestrator_dock_context"],
  ["M-t", "orchestrator_dock_toggle_worktrees"],
  ["M-i", "orchestrator_dock_toggle_trivial"],
  ["M-p", "orchestrator_dock_toggle_scope"],
  ["M-n", "orchestrator_dock_new"],
];
editor.defineMode(DOCK_MODE, DOCK_MODE_BINDINGS, false, false);

// Whichever dropdown is open, if one is.
function dockOpenMenu(): "project" | "menu" | null {
  if (!openDialog) return null;
  if (openDialog.dockMenu) return "menu";
  if (openDialog.projectMenuOpen) return "project";
  return null;
}

function dockOnSessions(): boolean {
  const focus = pickerFocusKey();
  return focus === "sessions" || focus === "";
}

// Move the dock's focus to `key`. The host applies it; `focusKey()` reads
// it back at once (the write goes through).
function focusDockControl(key: string): void {
  if (!openPanel) return;
  openPanel.setFocusKey(key);
}

function openDockSearch(): void {
  if (!dockMode || !openDialog || !openPanel) return;
  openDialog.searchOpen = true;
  // The field has to exist in the spec before it can take focus.
  openPanel.update(buildDockSpec());
  focusDockControl("filter");
}

// Leave the search: an empty field closes the row; a needle stays applied
// (the row stays with it) and the keyboard goes back to the list.
function leaveDockSearch(): void {
  if (!dockMode || !openDialog || !openPanel) return;
  if (openDialog.filter.value === "") {
    openDialog.searchOpen = false;
    openPanel.update(buildDockSpec());
  }
  focusDockControl("sessions");
}

// `/` — to the filter, from anywhere in the dock.
registerHandler("orchestrator_dock_filter", () => {
  openDockSearch();
});

// Esc — closes an open dropdown; otherwise returns from the filter to the
// session list; otherwise leaves the dock, which stays visible.
registerHandler("orchestrator_dock_escape", () => {
  if (!dockMode || !openPanel) return;
  if (movePick) return endMovePick();
  const menu = dockOpenMenu();
  if (menu === "menu") return closeDockMenu();
  if (menu === "project") return closeProjectMenu();
  if (pickerFocusKey() === "filter") return leaveDockSearch();
  editor.floatingPanelControl(openPanel.id(), "blur", 0);
});

// Enter no control used: the filter's. The filter is a search, not a form
// field to submit, so Enter returns to the list. (An open menu list, the
// tree and the buttons take their own Enter.)
registerHandler("orchestrator_dock_enter", () => {
  if (!dockMode || !openPanel) return;
  if (pickerFocusKey() === "filter") focusDockControl("sessions");
});

// F2 / the Menu key on the tree — the highlighted node's context menu, the
// same one a right-click anchors at the pointer.
registerHandler("orchestrator_dock_context", () => {
  if (dockMode && dockOnSessions()) openDockContextMenuFromKeyboard();
});

registerHandler("orchestrator_dock_toggle_worktrees", () => {
  if (dockMode) toggleShowWorktrees();
});
registerHandler("orchestrator_dock_toggle_trivial", () => {
  if (dockMode) toggleHideTrivial();
});
// Alt+P opens/closes the project dropdown. Opening hands the keyboard to
// the menu; closing returns it to the session list.
registerHandler("orchestrator_dock_toggle_scope", () => {
  if (!dockMode || !openDialog) return;
  if (openDialog.projectMenuOpen) closeProjectMenu();
  else openProjectMenu();
});
// Alt+N — the new-session form. It is a centered modal in a separate slot,
// so the dock stays visible.
registerHandler("orchestrator_dock_new", () => {
  if (!dockMode) return;
  dockBlurred = true;
  openForm({ fromPicker: true });
});

// The "New Folder" dialog: Enter in the name field submits (a button or
// the checkbox answers its own Enter first); Ctrl+Enter submits from
// anywhere. Everything else is the controls' and the host's ring.
const FOLDER_DIALOG_MODE_BINDINGS: string[][] = [
  ["Enter", "orchestrator_folder_submit"],
  ["C-Enter", "orchestrator_folder_submit", "shortcut"],
];
editor.defineMode(CREATE_FOLDER_MODE, FOLDER_DIALOG_MODE_BINDINGS, true, true);

registerHandler("orchestrator_folder_submit", () => {
  if (!createFolderDialog) return;
  submitCreateFolder();
});

// Ctrl+Enter: submit from anywhere, no matter which field is focused or
// whether a completion popup is open. Runs the primary action, "Create &
// Visit" (the "In Background" alternative is an explicit button / Enter on it).
registerHandler("orchestrator_form_submit", () => {
  if (!form) return;
  if (form.place) {
    void placeGo(form.place, formPlaceHost(form));
    return;
  }
  // Same gating as the Create buttons: no required input ⇒ no submit.
  if (!formIsSubmittable()) return;
  void submitForm(true);
});
// Alt+Enter: launch in the background from anywhere in the form.
registerHandler("orchestrator_form_submit_bg", () => {
  if (!form || form.target !== "new" || !formIsSubmittable()) return;
  void submitForm(false);
});

// Open or close the `▸ Details` fold, keeping focus on its row.
function toggleFormDetails(): void {
  if (!form || !formPanel) return;
  form.detailsOpen = !form.detailsOpen;
  editor.setGlobalState(LAUNCH_DETAILS_KEY, form.detailsOpen);
  renderForm();
  formPanel.setFocusKey("details");
}

registerHandler("orchestrator_form_browse_up", () => {
  if (form?.place && formPanel) form.place.browse.up(formPanel.focusKey());
});
registerHandler("orchestrator_form_key_escape", () => {
  // An open suggestion list or dropdown took the first Esc already (the
  // focused control answers before this binding); this is the dialog's.
  if (form?.place) {
    // Esc closes the folder browser first, then drops the question.
    if (!form.place.browse.close()) void placeCancel(form.place, formPlaceHost(form));
    return;
  }
  if (form) cancelForm();
});
// ↑/↓ on a field that remembers (the binding is scoped to them): on a
// completion-bearing field (project_path / branch) re-fetch the suggestions,
// live candidates AND the `↶`-marked history rows mixed in (see
// `setCompletionItems`); on name / cmd walk the history in place. An open
// suggestion list takes its own arrows before this binding is asked.
function formHistoryKey(delta: -1 | 1): void {
  const focusKey = formFocusedKey();
  if (focusKey === "project_path" || focusKey === "branch") {
    scheduleCompletionRefresh(focusKey);
    return;
  }
  const histField = focusToHistoryField(focusKey);
  if (histField) walkHistory(histField, delta);
}
registerHandler("orchestrator_form_key_up", () => formHistoryKey(-1));
registerHandler("orchestrator_form_key_down", () => formHistoryKey(1));

// Printable input arrives via the global `mode_text_input` action.
// Other plugins may also register a `mode_text_input` handler;
// guard on `form` so this handler is a no-op outside the form.
//
// Special-case: a space character on a focused Toggle / Button
// is "activate this control", not "insert a literal space into
// the value". The host's smart-key dispatch already does this
// for `widgetCommand({kind: "key", name: "Space"})`, but the
// mode binding for "Space" is shadowed by the global text-input
// path (printable chars route to `mode_text_input` ahead of the
// custom mode keymap), so we intercept here instead.
function orchestrator_mode_text_input(args: { text: string }): void {
  if (!form || !formPanel || !args?.text) return;
  formPanel.command(textInputChar(args.text));
}
registerHandler("mode_text_input", orchestrator_mode_text_input);

// Open the confirm panel for `action` against the currently
// selected session, rebuild the spec, and ensure the Cancel
// button gets default focus.
//
// `buildOpenSpec` drops the `key` from the filter input and the
// `+ New Session` button while `pendingConfirm` is set, so they
// fall out of the Tab cycle. Cancel still isn't the first
// tabbable in raw declaration order, though — `setFocusKey`
// pins it explicitly so a stray Enter on mount is a no-op
// rather than a worktree wipe (confirm prompts for destructive
// actions should be biased toward the safe path).
function enterConfirm(action: "stop" | "archive" | "delete"): void {
  if (!openDialog || !openPanel) return;
  const id = openDialog.filteredIds[openDialog.selectedIndex];
  if (typeof id !== "number" || id <= 0) return;
  // Every live session can be stopped/archived/deleted now: Archive
  // records a launch/in-place session at its own root (no worktree to
  // move) and worktree sessions move to the graveyard; closing the last
  // live window opens a replacement first (see `ensureReplacementWindow`
  // in `archiveOne` / `deleteOne`). So no eligibility refusal here — just
  // confirm and run.
  confirmRemoveWorktree = true;
  openDialog.pendingConfirm = { action, ids: [id] };
  openPanel.update(buildOpenSpec());
  openPanel.setFocusKey("confirm-cancel");
}

// Open the confirm panel for a *bulk* action over the current
// checkbox selection. Filters to the eligible members up front (so
// the confirm count matches what will actually run); refuses with a
// banner when nothing is eligible.
function enterBulkConfirm(action: BulkAction): void {
  if (!openDialog || !openPanel) return;
  const targets = eligibleSelected(action);
  if (targets.length === 0) {
    setDialogError(editor.t("err.no_eligible_selected", {
      verb: action === "stop"
        ? editor.t("status.verb_stopped")
        : action === "archive"
        ? editor.t("status.verb_archived")
        : editor.t("status.verb_deleted"),
    }));
    refreshOpenDialog();
    return;
  }
  // All three actions confirm — even Stop, so a bulk Stop over a
  // large selection isn't a single mis-key away. The confirm panel
  // lists the targets and shows the eligible count.
  confirmRemoveWorktree = true;
  openDialog.pendingConfirm = { action, ids: targets };
  openPanel.update(buildOpenSpec());
  openPanel.setFocusKey("confirm-cancel");
}

editor.on("widget_event", (e) => {
  // ---------------------------------------------------------------------
  // A workspace's placeholder page: the two things to do about a build that
  // has stalled, on the page that is reporting it. They are here rather than
  // in the dock because this is where the user already is — creating a
  // workspace takes them into it.
  // ---------------------------------------------------------------------
  const placeholderWindow = placeholderWindows.get(e.panel_id);
  if (placeholderWindow !== undefined) {
    if (e.event_type !== "activate") return;
    if (e.widget_key === "placeholder-retry") retryPending(placeholderWindow);
    else if (e.widget_key === "placeholder-dismiss") dismissPending(placeholderWindow);
    return;
  }
  // ---------------------------------------------------------------------
  // Machines: the Add / Edit Machine dialog and the Machines list.
  // ---------------------------------------------------------------------
  if (machinePanel && machineDialog && e.panel_id === machinePanel.id()) {
    handleMachineDialogEvent(e);
    return;
  }
  if (machinesPanel && machinesState && e.panel_id === machinesPanel.id()) {
    handleMachinesEvent(e);
    return;
  }
  if (repoPanel && repoDialog && e.panel_id === repoPanel.id()) {
    handleRepoDialogEvent(e);
    return;
  }
  if (explainPanel && e.panel_id === explainPanel.id()) {
    handleExplainEvent(e);
    return;
  }
  if (hostKeyPanel && hostKeyState && e.panel_id === hostKeyPanel.id()) {
    handleHostKeyEvent(e);
    return;
  }
  // ---------------------------------------------------------------------
  // "New Folder" dialog: name field, organize checkbox, Cancel / Create.
  // ---------------------------------------------------------------------
  if (createFolderPanel && createFolderDialog && e.panel_id === createFolderPanel.id()) {
    const d = createFolderDialog;
    if (e.event_type === "cancel") {
      // Esc / click-outside: the host already unmounted the panel (and
      // gave the keyboard back to what opened it), so drop our handle.
      createFolderPanel = null;
      createFolderDialog = null;
      return;
    }
    if (e.event_type === "change" && e.widget_key === "folder-name") {
      const payload = (e.payload ?? {}) as Record<string, unknown>;
      if (typeof payload.value === "string") d.name.value = payload.value;
      if (typeof payload.cursorByte === "number") d.name.cursor = payload.cursorByte;
      return;
    }
    if (e.event_type === "toggle" && e.widget_key === "folder-organize") {
      const checked = (e.payload as { checked?: unknown })?.checked;
      d.organizeCurrent = typeof checked === "boolean" ? checked : !d.organizeCurrent;
      createFolderPanel.update(buildCreateFolderSpec());
      return;
    }
    if (e.event_type === "activate" && e.widget_key === "folder-cancel") {
      closeCreateFolderDialog();
      return;
    }
    if (e.event_type === "activate" && e.widget_key === "folder-create") {
      submitCreateFolder();
      return;
    }
    return;
  }
  // ---------------------------------------------------------------------
  // "Run Agent…" dialog: agent picker, target picker, Auto toggle,
  // Start-prompt field, Cancel / Run.
  // ---------------------------------------------------------------------
  // ---------------------------------------------------------------------
  // Dock session context menu (right-click): Visit / Archive / Delete.
  // ---------------------------------------------------------------------
  // ---------------------------------------------------------------------
  // The dock's Menu panel.
  // ---------------------------------------------------------------------
  if (mainMenuPanel && e.panel_id === mainMenuPanel.id()) {
    if (e.event_type === "cancel") {
      // Esc or a press outside: the host unmounted it already. A press on
      // the Menu button is spent on the dismissal, so it cannot reopen it.
      mainMenuPanel = null;
      closeMainMenu();
      return;
    }
    // The project dropdown: a `change` is an accepted value (the list's
    // highlight moves fire nothing), so the filter moves on it.
    if (e.event_type === "change" && e.widget_key === MAIN_MENU_PROJECT_KEY) {
      const index = Number(((e.payload ?? {}) as Record<string, unknown>).index ?? 0);
      applyProjectFilter(projectMenuKeys()[index] ?? "");
      return;
    }
    if (e.event_type === "activate" && typeof e.widget_key === "string" && e.widget_key.startsWith(MAIN_MENU_PREFIX)) {
      runDockMenuOption(e.widget_key.slice(MAIN_MENU_PREFIX.length));
    }
    return;
  }
  if (dockMenuPanel && dockMenuState && e.panel_id === dockMenuPanel.id()) {
    const target = dockMenuState.target;
    if (e.event_type === "cancel") {
      // Esc or a click outside dismissed the popup — the host already
      // unmounted the panel and gave the keyboard back to what opened it,
      // so just drop our handle (don't unmount it again).
      dockMenuPanel = null;
      dockMenuState = null;
      return;
    }
    // The confirm pane's "also remove the worktree" checkbox. Handled before
    // the `activate` narrowing below, because a toggle is its own event type.
    if (e.event_type === "toggle" && e.widget_key === "confirm-worktree") {
      const payload = (e.payload ?? {}) as Record<string, unknown>;
      confirmRemoveWorktree = typeof payload.checked === "boolean"
        ? payload.checked
        : !confirmRemoveWorktree;
      // The consequence list above the checkbox says what it will do, so it
      // has to be rebuilt with it.
      renderDockMenu();
      return;
    }
    if (e.event_type === "activate") {
      if (target.kind === "folder" && isExternalFolder(target.id)) {
        if (e.widget_key === "ctx-external-refresh") {
          closeDockContextMenu();
          refreshExternal();
        }
        return;
      }
      if (target.kind === "live") {
        if (e.widget_key === "ctx-live-open") {
          closeDockContextMenu();
          void openLiveSession(target.key, { dive: true });
        } else if (e.widget_key === "ctx-live-move") {
          closeDockContextMenu();
          startMovePick({ kind: "live", key: target.key, name: liveByKey(target.key)?.title ?? target.key });
        } else if (e.widget_key === "ctx-live-goto") {
          closeDockContextMenu();
          const s = liveByKey(target.key);
          const w = s ? teleportedWorkspace(s) : undefined;
          if (w) {
            if (w.id !== editor.activeWindow()) editor.setActiveWindow(w.id);
            if (dockMode && openPanel) {
              dockDiveBlur = true;
              dockBlurred = true;
              editor.floatingPanelControl(openPanel.id(), "blur", 0);
            }
          }
        } else if (e.widget_key === "ctx-live-teleport") {
          closeDockContextMenu();
          teleportLiveSession(target.key);
        } else if (e.widget_key === "ctx-live-browser") {
          closeDockContextMenu();
          const s = liveByKey(target.key);
          if (s?.url) openLiveOutside(s, s.url);
        } else if (e.widget_key === "ctx-live-desktop") {
          closeDockContextMenu();
          const s = liveByKey(target.key);
          const link = s ? desktopLink(s) : null;
          if (s && link) openLiveOutside(s, link);
        }
        return;
      }
      // Folder organise actions.
      if (target.kind === "folder") {
        if (e.widget_key === "ctx-rename") {
          // Same centered dialog UX as "New Folder" (was: a bottom
          // minibuffer prompt, inconsistent and label/value ran
          // together). The host blurs the dock as the dialog mounts.
          closeDockContextMenu();
          openRenameFolderDialog(target.id);
          return;
        }
        if (e.widget_key === "ctx-new-subfolder") {
          closeDockContextMenu();
          openCreateFolderDialog(target.id);
          return;
        }
        if (e.widget_key === "ctx-delete-folder") {
          apiDeleteFolder(target.id);
          closeDockContextMenu();
          return;
        }
        return;
      }
      const id = target.id;
      if (e.widget_key === "ctx-retry") {
        closeDockContextMenu();
        retryPending(id);
        return;
      }
      if (e.widget_key === "ctx-dismiss") {
        closeDockContextMenu();
        dismissPending(id);
        return;
      }
      if (e.widget_key === "ctx-visit") {
        // Visit dives into the editor — no dock refocus.
        closeDockContextMenu();
        dockMenuVisit(id);
        return;
      }
      if (e.widget_key === "ctx-rename-session") {
        // Same centered dialog as folder rename; the host blurs the dock as it mounts.
        closeDockContextMenu();
        openRenameWorkspaceDialog(id);
        return;
      }
      if (e.widget_key === "ctx-move") {
        // The dock asks for the target: the user clicks a folder.
        closeDockContextMenu();
        startMovePick({ kind: "session", id, name: orchestratorSessions.get(id)?.label ?? String(id) });
        return;
      }
      if (e.widget_key === "ctx-archive" && bulkEligible("archive", id)) {
        dockMenuEnterConfirm("archive");
        return;
      }
      if (e.widget_key === "ctx-delete" && bulkEligible("delete", id)) {
        dockMenuEnterConfirm("delete");
        return;
      }
      if (e.widget_key === "confirm-cancel") {
        // Back to the anchored menu (not all the way out) so a mis-click
        // on a destructive action is one click from recoverable.
        dockMenuState = {
          target,
          anchorCol: dockMenuState.anchorCol,
          anchorRow: dockMenuState.anchorRow,
          stage: "menu",
        };
        mountDockMenu();
        return;
      }
      if (e.widget_key === "confirm-archive" || e.widget_key === "confirm-delete") {
        const action = e.widget_key === "confirm-archive" ? "archive" : "delete";
        closeDockContextMenu();
        void runConfirmedAction(action, [id]);
        return;
      }
    }
    return;
  }

  // ---------------------------------------------------------------------
  // New-session form
  // ---------------------------------------------------------------------
  if (form && formPanel && e.panel_id === formPanel.id()) {
    // The launch-time "where is it?" question owns its own widgets.
    if (form.place && e.event_type !== "focus" && handlePlaceEvent(form.place, formPlaceHost(form), e as WidgetEvt)) return;
    if (e.event_type === "focus") {
      // Leaving the where-is-it question's folder browser closes it.
      form.place?.browse.focusMoved(e.widget_key ?? "");
      // Leaving a field (Shift+Tab, a click) closes its suggestions.
      if (form.completion.field !== null && form.completion.field !== e.widget_key) {
        closeCompletion();
      }
      return;
    }
    if (e.event_type === "change" && e.widget_key === "machine") {
      // The Machine control moved (design §5.1): the option decides the
      // backend and the host state; the body follows.
      const payload = (e.payload ?? {}) as Record<string, unknown>;
      const index = payload.index;
      if (typeof index === "number" && index !== form.machinePick) {
        applyMachinePick(index);
        syncRepoPath();
        renderForm();
      }
      return;
    }
    if (e.event_type === "change" && e.widget_key === "launch_mode") {
      // New workspace ⇄ here. The prompt, agent and options carry over; the
      // panel re-mounts because its title is mount-time chrome.
      const index = ((e.payload ?? {}) as Record<string, unknown>).index;
      if (typeof index === "number") {
        const next: RunAgentTarget = index === 0 ? "new" : "current";
        if (next !== form.target) {
          form.target = next;
          form.lastError = null;
          mountFormPanel("launch_mode");
        }
      }
      return;
    }
    if (e.event_type === "change" && e.widget_key === "project") {
      const index = ((e.payload ?? {}) as Record<string, unknown>).index;
      if (typeof index !== "number") return;
      const repos = loadRepositories();
      if (index < repos.length) {
        form.repoId = repos[index].id;
        syncRepoPath();
      } else if (index === repos.length) {
        if (form.repoId) {
          form.repoId = null;
          clearRepoPath();
        }
      } else {
        // `Manage repositories…` is an action, not a project: it runs when it
        // is chosen (a `change` is an accepted value), and the dropdown goes
        // back to the project it showed.
        formPanel.setDropdown("project", projectPickIndex(form));
        openRepositoriesFromForm(form.repoId, formMachineKey(form));
        return;
      }
      form.lastError = null;
      renderForm();
      return;
    }
    if (e.event_type === "change" && e.widget_key === "worktree") {
      // Git mode radio: 0 = new worktree, 1 = work in the folder as is.
      const index = ((e.payload ?? {}) as Record<string, unknown>).index;
      if (typeof index === "number") {
        form.createWorktree = index === 0;
        renderForm();
      }
      return;
    }
    if (e.event_type === "change" && e.widget_key === "agent_dropdown") {
      // Agent selector: the host reports the newly-selected option index
      // (`payload.index`, verified against `handle_widget_dropdown_cycle`).
      // Map it back to a preset and apply it (fills the command field / hands
      // focus to it for "custom…"), then relay out the Tab cycle.
      const payload = (e.payload ?? {}) as Record<string, unknown>;
      const index = payload.index;
      if (typeof index === "number") {
        const presets = agentPresets();
        const preset = presets[index];
        if (preset && !preset.unset) {
          const wasUnset = form.agentUnset;
          form.agentUnset = false;
          applyAgentPreset(preset);
          // The placeholder left the list, so every option moved up one.
          if (wasUnset) {
            renderForm();
            formPanel.setDropdown("agent_dropdown", agentPresets().findIndex((p) => p.key === preset.key));
          }
        }
      }
      return;
    }
    if (e.event_type === "change") {
      const field = e.widget_key;
      const payload = (e.payload ?? {}) as Record<string, unknown>;
      const value = payload.value;
      const cursor = payload.cursorByte;
      if (typeof value !== "string") return;
      const slot = field === "project_path"
        ? form.projectPath
        : field === "name"
        ? form.name
        : field === "cmd"
        ? form.cmd
        : field === "start_prompt"
        ? form.startPrompt
        : field === "branch"
        ? form.branch
        : field === "new_branch"
        ? form.newBranch
        : field === "ssh_path"
        ? form.sshPath
        : field === "k8s_workspace"
        ? form.k8sWorkspace
        : null;
      if (slot) {
        slot.value = value;
        if (typeof cursor === "number") slot.cursor = cursor;
        // Typing in any history-bearing field invalidates the
        // history cursor — the user is composing a new draft.
        const histField = focusToHistoryField(field);
        if (histField) form.historyCursor[histField] = -1;
        // Snap our focus mirror to wherever the change just
        // landed — covers mouse-click focus changes (no Tab key
        // for us to intercept).
      }
      if (field === "project_path") {
        scheduleProjectPathReprobe();
        scheduleCompletionRefresh("project_path");
        // Re-render so the Create gating (which keys off the project path)
        // updates the disabled state as the user types.
        renderForm();
      } else if (field === "ssh_path") {
        scheduleRemoteReprobe();
        renderForm();
      } else if (field === "branch") {
        scheduleCompletionRefresh("branch");
        // The branch preview under "New branch name" names the fork point,
        // so it has to redraw as the fork point is typed — a preview that
        // lags the field it previews is the stale-hint problem again.
        renderForm();
      } else {
        // Any other field's change implicitly closes the
        // dropdown (the user moved on).
        closeCompletion();
        // Editing the command changes which agent it resolves to, and thus
        // whether the Auto mode / Start prompt controls appear — re-lay-out.
        if (field === "cmd") {
          // Typing a command is `custom…` by definition — keep the field
          // even if what was typed happens to spell a preset.
          form.agentCustom = true;
          renderForm();
        }
        // The remaining Create-gating fields: re-render so the disabled
        // state on the Create buttons tracks what the user has typed.
        //
        // `name` and `new_branch` are here for the branch/worktree preview:
        // it names the branch and the directory the create will make, both
        // of which are derived from these two.
        if (field === "name" || field === "new_branch") {
          renderForm();
        }
      }
      return;
    }
    if (e.event_type === "toggle" && e.widget_key === "worktree") {
      const payload = (e.payload ?? {}) as Record<string, unknown>;
      const checked = payload.checked;
      if (typeof checked === "boolean") {
        form.createWorktree = checked;
      } else {
        form.createWorktree = !form.createWorktree;
      }
      renderForm();
      return;
    }
    if (e.event_type === "toggle" && e.widget_key === "auto_mode") {
      const payload = (e.payload ?? {}) as Record<string, unknown>;
      const checked = payload.checked;
      if (typeof checked === "boolean") {
        form.autoMode = checked;
      } else {
        form.autoMode = !form.autoMode;
      }
      renderForm();
      return;
    }
    if (e.event_type === "toggle" && e.widget_key === "teach_fresh_cli") {
      const payload = (e.payload ?? {}) as Record<string, unknown>;
      const checked = payload.checked;
      if (typeof checked === "boolean") {
        form.teachFreshCli = checked;
      } else {
        form.teachFreshCli = !form.teachFreshCli;
      }
      renderForm();
      return;
    }
    if (e.event_type === "completion_accept") {
      // The host already put the accepted suggestion in the field and
      // reported it as a `change` (which re-probes the path). Keep the list
      // shut after an accept — even onto a folder — so the next Tab moves on
      // rather than re-accepting (F8); typing re-opens it.
      closeCompletion();
      return;
    }
    if (e.event_type === "completion_dismiss") {
      // Host fires this on Enter / Esc against a Text widget
      // with an open popup. Sync plugin-side state so the
      // history-walk gate (Up/Down on an empty-popup history-
      // bearing field) reads `false` again.
      closeCompletion();
      return;
    }
    if (e.event_type === "activate") {
      if (e.widget_key === "create-visit") {
        // Gate: a Create with no required input is a no-op (the button is
        // also rendered disabled, but Enter-on-button could still reach here).
        if (!formIsSubmittable()) return;
        void submitForm(true);
      } else if (e.widget_key === "create-bg") {
        if (!formIsSubmittable()) return;
        void submitForm(false);
      } else if (e.widget_key === "details") {
        toggleFormDetails();
      } else if (e.widget_key === "change_clone") {
        openRepositoriesFromForm(form.repoId, formMachineKey(form));
      } else if (e.widget_key === "switch_repo") {
        const known = folderKnownRepo(form);
        if (known) {
          form.repoId = known.id;
          syncRepoPath();
          renderForm();
          // The dropdown's pick is host-owned after the first render.
          formPanel.setDropdown("project", projectPickIndex(form));
          formPanel.setFocusKey("project");
        }
      } else if (e.widget_key === "make_main_clone") {
        const known = folderKnownRepo(form);
        const key = formMachineKey(form);
        if (known && key) {
          known.clones[key] = tildePath(formFolderPath(form));
          upsertRepository(known);
          form.repoId = known.id;
          syncRepoPath();
          renderForm();
          formPanel.setDropdown("project", projectPickIndex(form));
          formPanel.setFocusKey("project");
        }
      } else if (e.widget_key === "save_repo") {
        openAddRepositoryFromForm(tildePath(formFolderPath(form)), formMachineKey(form));
      } else if (e.widget_key === "form_add_machine") {
        // Set the form aside; Save brings it back on the new machine.
        suspendForm();
        openMachineDialog(null, "form");
      } else if (e.widget_key === "cancel") {
        cancelForm();
      }
      return;
    }
    if (e.event_type === "cancel") {
      // Host fires this when Esc unmounts the floating panel —
      // mirror our own state and (if reached from the picker)
      // bounce back to the picker so Esc is "back", not "out".
      const wasFromPicker = !!form?.fromPicker;
      // Esc while connecting aborts the in-flight remote attach, same as the
      // Cancel button: reject the promise and discard the late result host-side.
      if (form?.submitting) {
        pendingRemoteFacet = null;
        editor.cancelRemoteAgent();
      }
      form = null;
      formPanel = null;
      if (dockUnderForm()) return;
      if (wasFromPicker) {
        openControlRoom();
      }
      return;
    }
    return;
  }

  // ---------------------------------------------------------------------
  // Open dialog (session picker)
  // ---------------------------------------------------------------------
  if (openPanel && openDialog && e.panel_id === openPanel.id()) {
    if (e.event_type === "blur") {
      // Host fired this because focus left the dock (Enter/Esc dive or
      // leave, editor click, or an unhandled chord like Ctrl+P). The
      // dock stays visible; the host stops routing keys to it.
      if (dockMode) {
        const wasDive = dockDiveBlur;
        dockDiveBlur = false;
        dockBlurred = true;
        // Leaving the dock abandons a move-to-folder pick.
        movePick = null;
        // Leaving the dock also closes its dropdowns so they don't
        // linger over the blurred dock. `dockMenu` covers the "New
        // Task… ▾" and "Move to Folder…" overlays: they are menus, and
        // clicking away from a menu dismisses it.
        openDialog.projectMenuOpen = false;
        // The Menu is a panel of its own that takes the keyboard, so the
        // dock blurs when it opens; it stays up.
        if (!mainMenuPanel) openDialog.dockMenu = null;
        // The search row goes with them — unless a needle keeps it (a
        // dive keeps the filter, see below), which the render decides.
        openDialog.searchOpen = false;
        // Leaving the dock resets the filter so re-entering always
        // shows the full session list. A stale filter (e.g. an old
        // "/gamma") otherwise silently hides sessions on the next
        // focus, with only the filter box as a clue — and there is no
        // one-key clear from the list. (See F5.)
        //
        // A *dive* is the exception: clicking a row (or Enter on it) is
        // acting on the filtered list, not abandoning it, so the needle
        // stays put and the next workspace can be picked out of the same
        // search without retyping it. Esc/editor-click still clear, so
        // the one-key escape from a stale filter is unchanged.
        if (!wasDive && openDialog.filter.value !== "") {
          // Clearing goes through the shared path, which also pushes the
          // empty value back into the (controlled) text box — without that
          // the list would show every session while the box still read
          // "gamma".
          apiSetDockFilter({ text: "" });
          // Then override the highlight: leaving the dock lands on the
          // *active* session, not on whatever row the abandoned search had
          // highlighted.
          const activeIdx = openDialog.filteredIds.indexOf(editor.activeWindow());
          openDialog.selectedIndex = activeIdx >= 0 ? activeIdx : 0;
          refreshOpenDialog();
        } else {
          // Re-render so the keyboard hints drop off the blurred dock.
          openPanel?.update(buildDockSpec());
        }
      }
      return;
    }
    if (e.event_type === "focus") {
      // Focus (re-)entered the dock / picker — a mouse click on a
      // row/filter, a host-driven focus move, or the symmetric
      // refocus_floating_panel notification fired by the host's
      // un-dive mouse handler. Mark the dock active.
      if (dockMode) {
        // A dropdown is a menu: focus leaving its list (Tab, a click
        // elsewhere) dismisses it, the way any menu goes away when you
        // act elsewhere. The host's re-focus — the dock getting the
        // keyboard back as a dialog over it closes — is not focus leaving
        // anything, and leaves it open.
        const refocus = (e.payload as { previous?: string } | undefined)?.previous === "(re-focus)";
        if (
          openDialog.projectMenuOpen && e.widget_key !== PROJECT_MENU_KEY && !refocus
        ) {
          openDialog.projectMenuOpen = false;
          openPanel?.update(buildDockSpec());
        }
        // A dive that never produced a `blur` (already blurred, say)
        // must not leave the flag armed for the next, unrelated one.
        dockDiveBlur = false;
        const wasBlurred = dockBlurred;
        dockBlurred = false;
        // Re-render so the keyboard hints reappear now the dock holds
        // focus again.
        if (wasBlurred) openPanel?.update(buildDockSpec());
      }
      return;
    }
    if (e.event_type === "change" && e.widget_key === "filter") {
      const payload = (e.payload ?? {}) as Record<string, unknown>;
      const value = payload.value;
      const cursor = payload.cursorByte;
      if (typeof value !== "string") return;
      // Filter change implies the user has moved on from any
      // previous error — clear the banner so it doesn't shadow
      // the typing experience. Before the re-render below.
      clearDialogError();
      // Same path a script's `setDockFilter({ text })` takes: it re-filters,
      // preserves the highlighted session where it survives, re-renders and
      // reconciles the tree's expansion. `fromWidget` keeps the caret where
      // the user put it instead of snapping it to the end.
      apiSetDockFilter(
        { text: value },
        { cursorByte: typeof cursor === "number" ? cursor : undefined },
      );
      return;
    }
    // A row being dragged with the mouse: where it is, for the dock to show
    // what it lifted and where it would land; and the drag's end.
    if ((e.event_type === "drag" || e.event_type === "dragend") && e.widget_key === "sessions") {
      const payload = (e.payload ?? {}) as Record<string, unknown>;
      dockDrag = e.event_type === "drag" && typeof payload.key === "string"
        ? { key: payload.key, target: typeof payload.target === "string" ? payload.target : null }
        : null;
      syncDockMovePreview();
      if (openPanel && dockMode) openPanel.update(buildDockSpec());
      return;
    }
    // A row dragged onto another with the mouse (`draggable` rows): filed
    // where the row it landed on is.
    if (e.event_type === "drop" && e.widget_key === "sessions") {
      // The drop is the drag's end as far as drawing goes: the frame that
      // shows the row filed must not show it lifted, and `dragend` is a
      // separate event a frame can be painted before.
      dockDrag = null;
      const payload = (e.payload ?? {}) as Record<string, unknown>;
      if (typeof payload.key === "string" && typeof payload.target === "string") {
        commitDockDrop(payload.key, payload.target);
      }
      return;
    }
    // The drop's preview has played out: file the row now.
    if (e.event_type === "movepreviewend" && e.widget_key === "sessions") {
      const payload = (e.payload ?? {}) as Record<string, unknown>;
      if (typeof payload.key !== "string") return;
      const toKey = committedDockDrops.get(payload.key);
      if (pendingDockDrop?.committed && pendingDockDrop.fromKey === payload.key) pendingDockDrop = null;
      if (toKey === undefined) return;
      committedDockDrops.delete(payload.key);
      dropOnDockRow(payload.key, toKey);
      return;
    }
    // Right-click on a tree node → open its context menu. Only the dock
    // wires this up (the host fires `context` for right-clicks in the dock
    // column); the modal picker has its own action buttons. For the tree
    // the node key rides in `payload.key`/`widget_key`; `payload.index` is
    // the flat node index into `dockNodes`.
    if (
      e.event_type === "context" &&
      dockMode &&
      (e.widget_key === "sessions" ||
        ((e.payload ?? {}) as Record<string, unknown>).list_key === "sessions")
    ) {
      const payload = (e.payload ?? {}) as Record<string, unknown>;
      const idx = payload.index;
      const col = typeof payload.col === "number" ? payload.col : 0;
      const row = typeof payload.row === "number" ? payload.row : 0;
      // One row below the pointer, as a click's menu opens, so the row it
      // is for stays in sight above it.
      if (typeof idx === "number") openDockContextMenu(idx, col, row + 1);
      return;
    }
    // List selection. Keyboard nav fires this with `widget_key`
    // "sessions" (the list's own key); a mouse click on a row fires it
    // with `widget_key` set to the clicked item's key, carrying the
    // list key in `payload.list_key` instead — accept both so clicking a
    // row selects it (highlight + preview) just like arrowing to it.
    if (
      e.event_type === "select" &&
      (e.widget_key === "sessions" ||
        ((e.payload ?? {}) as Record<string, unknown>).list_key === "sessions")
    ) {
      const payload = (e.payload ?? {}) as Record<string, unknown>;
      const idx = payload.index;
      if (typeof idx === "number") {
        clearDialogError();
        if (dockMode) {
          // The dock is a tree. Track the highlighted node by key. A
          // *folder* row only moves the highlight (and a click toggles
          // its expansion — the disclosure column does that too). A
          // *session* row live-switches the active window: arrowing
          // wipes down/up and keeps focus on the dock so you can keep
          // arrowing; a *click* is a deliberate "open this" gesture that
          // also dives (hands keyboard focus to the window). A discovered
          // on-disk worktree has no window, so both paths attach a fresh
          // session instead.
          // Reaching the tree at all means the pointer (or the arrow
          // keys) landed outside any open dropdown — the overlay is
          // opaque to clicks over its own rows — so dismiss it, the way
          // any menu goes away when you act elsewhere.
          openDialog.dockMenu = null;
          const key = typeof payload.key === "string"
            ? payload.key
            : (openDialog.dockKeys[idx] ?? null);
          const prevKey = openDialog.dockSelKey;
          const prevIdx = prevKey ? openDialog.dockKeys.indexOf(prevKey) : -1;
          openDialog.dockSelKey = key;
          openPanel.update(buildDockSpec());
          openPanel.setSelectedIndex("sessions", idx);
          const node = key
            ? openDialog.dockNodes[openDialog.dockKeys.indexOf(key)] ?? null
            : null;
          // Choosing a folder: a click on one picks it; a click anywhere
          // else in the tree only moves the highlight.
          if (movePick) {
            if (payload.via === "click" && node?.kind === "folder" && !isExternalFolder(node.folderId)) {
              applyMovePick(node.folderId);
            }
            return;
          }
          if (node && node.kind === "folder") {
            if (payload.via === "click") toggleDockFolderExpansion(key!);
            return;
          }
          // An external session row is not a window: arrowing onto it only moves
          // the highlight (opening one creates a workspace, which must not
          // happen by scrolling past it); a click opens it.
          if (node && node.kind === "live") {
            dockSwitchToken++;
            if (payload.via === "click") {
              activateLiveRow(
                node.liveKey,
                typeof payload.col === "number" && typeof payload.row === "number"
                  ? { index: openDialog.dockKeys.indexOf(key!), col: payload.col, row: payload.row }
                  : undefined,
              );
            }
            return;
          }
          const fromEdge = idx > prevIdx ? "bottom" : idx < prevIdx ? "top" : null;
          if (payload.via === "click") diveDockSelectionFromClick(fromEdge);
          else scheduleDockSwitch(fromEdge);
          return;
        }
        openDialog.selectedIndex = idx;
        // Update preview pane.
        openPanel.update(buildOpenSpec());
        // Re-pin the list selection so the spec re-emit doesn't
        // snap it back to 0.
        openPanel.setSelectedIndex("sessions", openDialog.selectedIndex);
        // A mouse click on an inactive on-disk worktree opens it
        // directly — no Enter/Visit "confirmation" needed. There's no
        // live window to switch to, so attach a fresh session, mirroring
        // the dialog's Visit (`activate`) path. Live rows keep
        // select+preview (opened with Enter / Visit). Arrow-nav fires
        // `select` without `via`, so it only previews.
        if (payload.via === "click") {
          const clickedId = openDialog.filteredIds[openDialog.selectedIndex];
          const clicked = typeof clickedId === "number"
            ? orchestratorSessions.get(clickedId)
            : undefined;
          if (clicked && clicked.discovered) {
            closeOpenDialog();
            void attachToWorktree({
              root: clicked.root,
              projectPath: clicked.projectPath ?? clicked.root,
              label: clicked.label,
              branch: clicked.branch,
              discoveredId: clicked.id,
            });
            return;
          }
        }
        // Focus stays where it is: the arrows reach the list by moving
        // focus onto it (it is a focus stop of its own), and Enter on it
        // opens the highlighted row as Visit does. (Snapping focus back to
        // Visit here made every next ↓ start from Visit again, so the list
        // could never move past one row.)
      }
      return;
    }
    // The dock's session tree: Enter dives into the row (or opens and
    // closes a folder). Space is inert on it — bulk select is the modal
    // picker's — and the tree says when Space was the key.
    if (dockMode && e.event_type === "activate" && e.widget_key === "sessions") {
      if (((e.payload ?? {}) as Record<string, unknown>).via !== "space") dockActivate();
      return;
    }
    if (
      e.event_type === "activate" &&
      (e.widget_key === "sessions" || e.widget_key === "visit")
    ) {
      const id = openDialog.filteredIds[openDialog.selectedIndex];
      const act = rowActivation(
        typeof id === "number" ? orchestratorSessions.get(id) : undefined,
      );
      if (act.kind === "inert") return;
      if (act.kind === "attach") {
        // Discovered worktree: there's no window to switch to —
        // open one by attaching a fresh session to the worktree.
        const sel = act.session;
        closeOpenDialog();
        void attachToWorktree({
          root: sel.root,
          projectPath: sel.projectPath ?? sel.root,
          label: sel.label,
          branch: sel.branch,
          discoveredId: sel.id,
        });
        return;
      }
      if (act.windowId !== editor.activeWindow()) {
        editor.setActiveWindow(act.windowId);
      }
      if (dockMode && openPanel) {
        // Dock stays visible; Enter just hands keyboard focus to the
        // editor (the session is already active via live-switch).
        editor.floatingPanelControl(openPanel.id(), "blur", 0);
        dockBlurred = true;
        return;
      }
      closeOpenDialog();
      return;
    }
    // The move-to-folder pick's banner buttons.
    if (e.event_type === "activate" && movePick) {
      if (e.widget_key === "pick-root") return applyMovePick(null);
      if (e.widget_key === "pick-new") return movePickNew();
      if (e.widget_key === "pick-cancel") return endMovePick();
    }
    if (e.event_type === "activate" && e.widget_key === "new-session") {
      if (dockMode) {
        // `+ New` goes straight to the dialog — a centered modal in its
        // own slot, so the dock stays visible behind it.
        //
        // **Repaint the dock here, before the modal is mounted.** The press
        // that activated this button moved the panel's focus onto it, and a
        // tree that loses focus drops its highlight (the host clears it, so
        // a focus ring and a highlighted row are never up at once). The dock
        // is about to be the inert background, where the rule is the
        // opposite — `buildDockSpec` pins the highlight to the active
        // workspace on every blurred paint — and the paint that re-asserts
        // it would otherwise be the one the host's own `blur` notification
        // triggers, which lands a few hundred ms later, with the modal
        // already up. The dock must not change under a modal, so it settles
        // now: `refreshOpenDialog` pushes the spec *and* re-pins the
        // highlight (the tree's `selectedIndex` is a seed, not a setter).
        dockBlurred = true;
        refreshOpenDialog();
        openForm({ fromPicker: true });
        return;
      }
      closeOpenDialog();
      openForm({ fromPicker: true });
      return;
    }
    if (e.event_type === "activate" && e.widget_key === "dock-close") {
      if (dockMode) {
        closeOpenDialog();
        rememberDockOpen(false);
      }
      return;
    }
    if (e.event_type === "activate" && e.widget_key === "search-toggle") {
      openDockSearch();
      return;
    }
    // A press outside an open dock menu: close it (the press itself goes
    // on to whatever it was aimed at).
    if (e.event_type === "dismiss") {
      if (e.widget_key === DOCK_PROJECT_OVERLAY_KEY && openDialog.projectMenuOpen) {
        closeProjectMenu();
      }
      return;
    }
    if (e.event_type === "activate" && e.widget_key === "dock-menu") {
      if (openDialog.dockMenu?.kind === "main") closeDockMenu();
      else openMainMenu();
      return;
    }
    // Host-owned tree expansion changed (a disclosure click or →/← on a
    // folder): mirror it into the persisted expansion set so it survives
    // re-renders and restarts.
    if (e.event_type === "expand" && e.widget_key === "sessions") {
      const payload = (e.payload ?? {}) as Record<string, unknown>;
      const key = payload.key;
      const expanded = payload.expanded;
      if (typeof key === "string" && key.startsWith(FOLDER_NODE_PREFIX)) {
        const group = externalGroupOfKey(key);
        if (group) {
          setExternalCollapsed(group, expanded !== true);
        } else {
          const set = loadExpanded();
          if (expanded === true) set.add(key);
          else set.delete(key);
          saveExpanded();
        }
        // A fold changes how many rows the tree occupies; re-render so
        // the blank padding between the tree and the bottom hint bar
        // re-balances and the hints stay pinned to the dock's bottom.
        if (dockMode && openPanel) openPanel.update(buildDockSpec());
        // While a search holds every folder open the host's flip is undone
        // here; otherwise this re-pushes the set the host already has.
        if (dockMode) applyDockExpansion();
      }
      return;
    }
    // The project dropdown list, the same way.
    if (isListEvent(e, PROJECT_MENU_KEY)) {
      const payload = (e.payload ?? {}) as Record<string, unknown>;
      const idx = typeof payload.index === "number" ? payload.index : -1;
      if (e.event_type === "select" && idx >= 0) {
        projectMenuSelected(idx, payload.via === "click");
      } else if (e.event_type === "activate") {
        acceptProjectMenu(idx >= 0 ? idx : undefined);
      }
      return;
    }
    if (e.event_type === "activate" && e.widget_key === "scope-toggle") {
      toggleScope();
      return;
    }
    if (e.event_type === "activate" && e.widget_key === "toggle-details") {
      openDialog.showDetails = !openDialog.showDetails;
      refreshOpenDialog();
      return;
    }
    if (e.event_type === "toggle" && e.widget_key === "worktree-show") {
      // The toggle widget reports the new checked state; route through
      // the shared flip so the Alt+T chord and the click stay in sync.
      toggleShowWorktrees();
      return;
    }
    if (e.event_type === "toggle" && e.widget_key === "hide-trivial") {
      // Same pattern as the worktree toggle: route the click through the
      // shared flip so the checkbox and the Alt+I chord stay in sync.
      toggleHideTrivial();
      return;
    }
    if (e.event_type === "activate" && e.widget_key === "stop") {
      enterConfirm("stop");
      return;
    }
    if (e.event_type === "activate" && e.widget_key === "archive") {
      enterConfirm("archive");
      return;
    }
    if (e.event_type === "activate" && e.widget_key === "delete") {
      enterConfirm("delete");
      return;
    }
    // Bulk action bar (Layout B) — Stop / Archive / Delete over the
    // checkbox selection, plus Clear.
    if (e.event_type === "activate" && e.widget_key === "bulk-stop") {
      enterBulkConfirm("stop");
      return;
    }
    if (e.event_type === "activate" && e.widget_key === "bulk-archive") {
      enterBulkConfirm("archive");
      return;
    }
    if (e.event_type === "activate" && e.widget_key === "bulk-delete") {
      enterBulkConfirm("delete");
      return;
    }
    if (e.event_type === "activate" && e.widget_key === "bulk-clear") {
      openDialog.selectedIds.clear();
      refreshOpenDialog();
      openPanel.setFocusKey("visit");
      return;
    }
    if (e.event_type === "activate" && e.widget_key === "confirm-cancel") {
      openDialog.pendingConfirm = null;
      openPanel.update(buildOpenSpec());
      return;
    }
    if (e.event_type === "toggle" && e.widget_key === "confirm-worktree") {
      const payload = (e.payload ?? {}) as Record<string, unknown>;
      confirmRemoveWorktree = typeof payload.checked === "boolean"
        ? payload.checked
        : !confirmRemoveWorktree;
      openPanel.update(buildOpenSpec());
      return;
    }
    // Confirmed Stop / Archive / Delete — single row or bulk batch.
    // The ids were captured into `pendingConfirm` by enterConfirm /
    // enterBulkConfirm; `runConfirmedAction` re-checks eligibility,
    // drives the in-flight markers, and triggers sync.
    if (
      e.event_type === "activate" &&
      (e.widget_key === "confirm-stop" ||
        e.widget_key === "confirm-archive" ||
        e.widget_key === "confirm-delete")
    ) {
      const confirm = openDialog.pendingConfirm;
      openDialog.pendingConfirm = null;
      if (confirm) {
        void runConfirmedAction(confirm.action, confirm.ids);
      }
      if (openPanel) openPanel.update(buildOpenSpec());
      return;
    }
    if (e.event_type === "cancel") {
      // Esc / native `[×]` unmounted the picker panel — sync our own
      // state. This teardown is for the centered MODAL picker only: the
      // dock (LeftDock placement) never fires `cancel` (its Esc blurs to
      // the editor, host-side), and the modal always runs with
      // `dockMode === false` — even when floated over a live dock, where
      // the dock is parked in `dockPanel`. Guard on `dockMode` so a stray
      // cancel can never tear the dock down.
      if (dockMode) return;
      openPanel = null;
      // If the picker was floated over a live dock, hand control back to
      // the dock (still mounted in its own slot) rather than dropping to
      // the bare editor.
      if (restoreDockBehindPicker()) return;
      openDialog = null;
      return;
    }
    return;
  }
});

// Legacy kill helper retained for the `Orchestrator: Kill Selected`
// command-palette command. In the widget-based picker (Phase 1)
// the open dialog has no kill action — Phase 3-5 will replace
// this with Stop / Archive / Delete. When invoked while the
// open dialog is up, it targets that dialog's selection; when
// invoked from the palette outside the dialog, it status-bars
// with guidance.
function killSelected(): void {
  if (!openDialog) {
    editor.setStatus(editor.t("status.kill_open_list_first"));
    return;
  }
  const ids = openDialog.filteredIds;
  if (ids.length === 0) {
    editor.setStatus(editor.t("status.kill_no_selected"));
    return;
  }
  const id = ids[Math.max(0, Math.min(openDialog.selectedIndex, ids.length - 1))];
  if (id <= 0) {
    editor.setStatus(editor.t("status.kill_select_row"));
    return;
  }
  if (id === editor.activeWindow()) {
    editor.setStatus(editor.t("status.kill_dive_elsewhere"));
    return;
  }
  const s = orchestratorSessions.get(id);
  if (s && s.terminalId !== null) {
    editor.closeTerminal(s.terminalId);
  }
  // Tombstone so reconcile drops the row immediately instead of resurrecting
  // it from the stale window snapshot until the deferred close lands.
  closingWindowIds.add(id);
  editor.closeWindow(id);
}

// =============================================================================
// Lifecycle hook handlers
// =============================================================================

editor.on("window_created", () => {
  // The orchestrator's own new-session flow uses
  // `createWindowWithTerminal` (atomic — populates the window
  // before returning), so by the time this hook fires for one of
  // our spawns the session is already tracked. Other plugins or
  // host actions creating windows just need the picker to
  // refresh.
  refreshOpenDialog();
});

editor.on("window_closed", () => {
  // Deliberately does NOT clear the window's tombstone. The hook fires when
  // the host closes the window, but the plugin's `listWindows()` snapshot
  // may not have caught up yet — and a reconcile in that gap would see a
  // window with no tombstone and resurrect the row the user just deleted.
  // `reconcileSessions` retires each tombstone the moment the window is
  // genuinely absent from the snapshot, which is the same condition, read
  // from the source that actually decides.
  refreshOpenDialog();
});

// Startup: re-surface any workspaces that were still being created when the
// editor last quit. They come back as paused placeholder rows the user
// resumes (Enter) or dismisses — nothing auto-runs (§ recoverPendingWorkspaces).
editor.on("ready", () => {
  void loadDetectionRules();
  recoverPendingWorkspaces();
  // Blurred, so the keyboard stays with the editor. Whether it opens is the
  // host's call (`orchestrator.manifest.json`, what the user left, and never
  // on a file launch); the column is already carved, and the mount fills it.
  if (editor.dockOpen()) {
    showDockUnfocused();
  }
});

// A Settings-UI edit to `always` / `never` is an instruction too, so it opens
// or closes the dock now rather than at the next start. `auto` asks for
// nothing now.
//
// Guarded on a change to *this* setting, not on the dock's state:
// `config_changed` fires for every config save, and the dock is legitimately
// closed at moments nobody asked for it to open (the plugin's own close
// around a dive). The plugin's own `saveSetting` does not fire this hook, and
// `rememberDockOpen` has already moved `lastDockMode`, so a later save does
// not replay it.
//
// The hook does not say which keys changed, so a value that reached the file
// another way (a hand edit, another Fresh process) is adopted at the next
// Settings save or config reload. That is still the user's latest
// instruction, so acting on it then is the rule, not a leak.
editor.on("config_changed", () => {
  const mode = configuredDockMode();
  if (mode === lastDockMode) return;
  lastDockMode = mode;
  // `editor.dockOpen()` — the host's "a dock is mounted" — not the plugin's
  // `openPanel`/`dockMode`: with the modal picker floating over a live dock
  // those read "no dock" while the column is still on screen. A picker that
  // owns the screen is left alone; the edit is on disk, so the next start
  // follows it either way.
  if (mode === "always" && !editor.dockOpen()) {
    if (!openPanel) showDockUnfocused();
  } else if (mode === "never" && editor.dockOpen()) {
    if (dockMode) closeOpenDialog();
  }
});

// Grace window after a session becomes active during which terminal
// output is attributed to the activation redraw (or an attach's shell
// startup), not the agent — so selecting a session doesn't flash it
// `working`.
const ACTIVATION_GRACE_MS = 1500;
// When the layout changes (the terminal resized, the dock shown or
// hidden) every terminal redraws at once; that burst is not the agent
// working. Output inside this window from a session that was quiet is
// ignored — a real burst that starts at the same moment counts from its
// next line.
let layoutChangedAt = 0;
function noteLayoutChange(): void {
  layoutChangedAt = Date.now();
}

editor.on("active_window_changed", () => {
  const s = orchestratorSessions.get(editor.activeWindow());
  if (s) {
    s.activatedAt = Date.now();
    // Looking at the window is "seeing" its work: a `done` row goes back
    // to idle the moment the user switches in.
    s.workedSinceSeen = false;
    // Switching into a workspace counts as activity for the dock's recency
    // order (persisted at day granularity).
    markSessionActiveToday(s);
  }
  sweepAttention();
  refreshOpenDialog();
  // A passive (blurred) dock mirrors the active window, so keep its
  // highlighted row in sync when focus moves to another window from
  // outside the dock. While the dock holds focus the user drives ↑/↓
  // selection (and the debounced live-switch already aligns the two), so
  // re-selecting here would fight the scroll — hence the blurred guard.
  if (dockBlurred) syncDockSelectionToActive();
});

// Re-flow the open-picker on terminal resize. The dialog's
// `listVisibleRows` / `embedRows` are captured at open-time
// (orchestrator.ts:`openControlRoom`); without this subscription
// they stay frozen at the pre-resize values and the live preview
// embed gets clipped (or leaves blank space) when the user
// resizes their tmux pane. The host also re-renders the panel
// against the new screen width unconditionally (see
// `Editor::resize` in `lifecycle.rs`); this handler just refreshes
// the spec so the *plugin's* row-count knobs adopt the new
// viewport at the same time.
editor.on("resize", () => {
  noteLayoutChange();
  if (openDialog && openPanel) {
    // The host re-fits the dock column itself; buildOpenSpec/buildDockSpec
    // refit `listVisibleRows` + content width on the refresh.
    refreshOpenDialog();
  }
  // A panel that was measured at mount holds a fact about the frame it was
  // measured in, so a resize has to retake it. Most of what this used to
  // cover has since moved host-side — the footer no longer measures and the
  // popup no longer wraps — and what is left is the form's fixed-versus-
  // compact fit and the machine dialogs' content. Each no-ops when its panel
  // is closed.
  renderForm();
  renderMachineDialog();
  renderMachinesDialog();
  renderExplainPopup();
});

// =============================================================================
// Agent activity tracking from terminal output / exit
//
// We only claim what the terminal can prove: a session is "working" while
// it's actively printing, "idle" once it goes quiet. The signal is the
// timestamp of the last output; `sessionState` buckets it against
// IDLE_AFTER_MS at render time. We don't poll the process, so this tracks
// *output*, not liveness — a wedged agent reads idle, same as a finished
// one, which is the honest limit of what we can see from here.
//
// Keyed by `window_id`, not the one terminal id Orchestrator spawned: a
// session is its editor window (its id == the session id), so output from
// ANY terminal in that window counts — a second shell the user opened, an
// agent that re-execs, etc. The host fires `terminal_output` on every PTY
// read, so this also lights up for in-place redraws and carriage-return
// progress bars, not just newline-terminated lines.
// =============================================================================

// `sessionState` buckets `working`/`idle` from `lastOutputAt` at render
// time, but a re-render only happens on *new* output. So when a session
// goes quiet nothing repaints it, and the row freezes on `working` until
// some unrelated event forces a redraw. This schedules one refresh just
// past the idle window so the working→idle flip happens on its own. The
// token collapses back-to-back outputs into a single pending sweep, and
// because it covers the *most recent* output across all sessions, the
// sweep recomputes (and idles) every quiet session at once.
let idleSweepToken = 0;
function scheduleIdleSweep(): void {
  const token = ++idleSweepToken;
  void editor.delay(IDLE_AFTER_MS + 100).then(() => {
    if (idleSweepToken !== token) return;
    // Quiet is when a session turns blocked or done — announce it.
    sweepAttention();
    refreshOpenDialog();
  });
}

editor.on("terminal_output", (payload) => {
  terminalOutputAt.set(payload.terminal_id, Date.now());
  const s = orchestratorSessions.get(payload.window_id);
  if (s) {
    // Ignore the redraw burst a terminal emits right after its window
    // becomes active — that's not the agent working, and counting it
    // would flash the card to `working` on every selection.
    if (s.activatedAt !== undefined && Date.now() - s.activatedAt < ACTIVATION_GRACE_MS) {
      return;
    }
    // Likewise the redraw every terminal emits when the layout changes
    // (a resize, the dock toggled): a quiet session stays quiet.
    if (
      Date.now() - layoutChangedAt < ACTIVATION_GRACE_MS &&
      (s.lastOutputAt === null || Date.now() - s.lastOutputAt >= IDLE_AFTER_MS)
    ) {
      return;
    }
    // Stamp the moment of output. `sessionState` turns this into
    // working/idle; the cached `state` is updated so persistence and
    // any non-render reader see a fresh value too.
    const now = Date.now();
    // Burst bookkeeping for the "done" state: a run of output with gaps
    // shorter than IDLE_AFTER_MS is one burst; once it has lasted
    // WORK_MIN_MS while the user was looking at another window, there is
    // unseen work. Output while the window is active is seen as it
    // happens, so it never arms the flag (and clears a stale one).
    if (s.lastOutputAt === null || now - s.lastOutputAt >= IDLE_AFTER_MS) {
      s.burstStartAt = now;
    }
    if (s.id === editor.activeWindow()) {
      s.workedSinceSeen = false;
    } else if (now - (s.burstStartAt ?? now) >= WORK_MIN_MS) {
      s.workedSinceSeen = true;
    }
    s.lastOutputAt = now;
    s.state = "working";
    // Keep the trailing lines of the agent terminal for the blocked-prompt
    // heuristic — only the session's own terminal, so a side shell can't
    // make the row look blocked.
    if (
      (s.terminalId === null || s.terminalId === payload.terminal_id) &&
      typeof payload.last_line === "string"
    ) {
      noteRecentLine(s, payload.last_line);
    }
    // Terminal output is activity — feed the dock's day-granularity recency
    // order (persists at most once per session per day).
    markSessionActiveToday(s);
    // Adopt any explicit OSC activity signal (OSC 133 / OSC 9;4) from the
    // session's own terminal — authoritative for the working/idle dot. Only
    // the session's agent terminal (when it has one), so a second shell in
    // the same window can't drive the indicator. `null`/`undefined` leaves
    // the previous state (a program that emits markers, then a batch without
    // one, is still considered running/idle per the last marker).
    if (
      (s.terminalId === null || s.terminalId === payload.terminal_id) &&
      (payload.osc_activity === true || payload.osc_activity === false)
    ) {
      s.oscRunning = payload.osc_activity;
    }
    // Track the terminal's tab title so an un-renamed workspace names itself
    // after whatever it's running. Only adopt the session's own agent
    // terminal (when it has one) so a second shell the user opened in the
    // same window can't hijack the workspace name.
    const title = (payload.terminal_title ?? "").trim();
    if (
      title &&
      (s.terminalId === null || s.terminalId === payload.terminal_id) &&
      s.terminalTitle !== title
    ) {
      s.terminalTitle = title;
      applyResolvedLabel(s);
    }
    sweepAttention();
    refreshOpenDialog();
    // Ensure the row flips back to idle once output stops, even if no
    // further event arrives to trigger a render.
    scheduleIdleSweep();
  }
});

editor.on("terminal_exit", (payload) => {
  terminalExitAt.set(payload.terminal_id, Date.now());
  terminalOutputAt.delete(payload.terminal_id);
  // The stamps only matter for the seconds after a launch; a dead terminal's
  // are read once at most, so they are dropped on the next exit rather than
  // kept for the life of the editor.
  reapTerminalStamps();
  const s = orchestratorSessions.get(payload.window_id);
  // Only the session's own agent terminal (or any terminal, when it has
  // none) resets the row: a side shell closing must not blank the badge.
  if (s && (s.terminalId === null || s.terminalId === payload.terminal_id)) {
    // A terminal in this session ended — it can't be the source of work
    // anymore. Drop to idle and clear the timestamp so the row reads idle
    // immediately rather than riding out the IDLE_AFTER_MS tail. If another
    // terminal in the same window is still printing, the next
    // `terminal_output` re-marks it working within the debounce window.
    s.lastOutputAt = null;
    s.state = "unknown";
    s.recentLines = [];
    s.workedSinceSeen = false;
    s.burstStartAt = undefined;
    // The terminal is gone, so any running OSC marker is stale — clear it so
    // a command that never emitted its "done" marker (killed, detached)
    // doesn't leave the row stuck "working".
    s.oscRunning = null;
    sweepAttention();
    refreshOpenDialog();
  }
});

// =============================================================================
// Commands
// =============================================================================

registerHandler("orchestrator_open", openControlRoom);
registerHandler("orchestrator_new", startNewSession);
registerHandler("orchestrator_kill", killSelected);

// `terminalBypass: true` keeps these commands reachable from a
// keyboard-focused terminal pane — a user with `Ctrl+O` bound to
// `Orchestrator: Open` shouldn't need to first hit `Ctrl+Space` to
// exit terminal mode to switch sessions. The bypass routes the
// key past `TerminalModeInputHandler` (which would otherwise
// forward it to the PTY child) and dispatches the action
// directly.
editor.registerCommand(
  "%cmd.open",
  "%cmd.open_desc",
  "orchestrator_open",
  null,
  { terminalBypass: true },
);
editor.registerCommand(
  "%cmd.machines",
  "%cmd.machines_desc",
  "orchestrator_machines",
  null,
  { terminalBypass: true },
);
editor.registerCommand(
  "%cmd.repositories",
  "%cmd.repositories_desc",
  "orchestrator_repositories",
  null,
  { terminalBypass: true },
);
editor.registerCommand(
  "%cmd.new",
  "%cmd.new_desc",
  "orchestrator_new",
  null,
  { terminalBypass: true },
);
editor.registerCommand(
  "%cmd.kill",
  "%cmd.kill_desc",
  "orchestrator_kill",
  null,
  { terminalBypass: true },
);
editor.registerCommand(
  "%cmd.dock_toggle",
  "%cmd.dock_toggle_desc",
  "orchestrator_dock_toggle",
  null,
  { terminalBypass: true },
);
editor.registerCommand(
  "%cmd.move",
  "%cmd.move_desc",
  "orchestrator_move",
  null,
  { terminalBypass: true },
);

// ── Explain State popup ────────────────────────────────────────────────
// The chain behind a badge is several lines, and the status bar elides
// it to a few words on a normal-width terminal, so it opens as a small
// popup; the one-line summary still goes to the status bar and the log.
const EXPLAIN_MODE = "orchestrator-explain";
let explainPanel: FloatingWidgetPanel | null = null;

function closeExplainPopup(): void {
  if (!explainPanel) return;
  explainPanel.unmount();
  explainPanel = null;
  explainShowing = null;
}

// What the popup is showing, so a resize can rebuild it: the host wraps
// its prose to the panel's width, which a resize changes.
let explainShowing: { s: AgentSession; ex: StateExplanation } | null = null;

function buildExplainSpec(s: AgentSession, ex: StateExplanation): WidgetSpec {
  const dim = { fg: "ui.menu_disabled_fg" };
  const sym = STATE_SYMBOL[ex.state];
  const name = workspaceCustomName(s) || s.hostLabel || s.label;
  const head = label([
    { text: `${sym.glyph} ${ex.state}`, style: { fg: sym.fg, bold: true } },
    { text: `   ${name}`, style: { bold: true } },
  ]);
  // A reason runs long — it quotes a rule's pattern, or the terminal line
  // that matched — so it wraps to the popup's width, which is the host's to
  // know. The leading two spaces are what each continuation row starts at,
  // so a wrapped reason stays inside its own bullet.
  const reasons = ex.reasons.map((r) => label(`  \u{2022} ${r}`, { wrap: true }));
  const rules = label(
    editor.t("explain.rules_loaded", { version: String(ex.rules.version), source: ex.rules.source }),
    { style: dim },
  );
  const parts: WidgetSpec[] = [head, spacer(0), ...reasons, spacer(0), rules];
  if (ex.recentLines.length > 0) {
    parts.push(spacer(0), label(editor.t("explain.recent_lines"), { style: dim }));
    // **Not wrapped.** These are the agent's screen lines, not prose: one
    // of them can be hundreds of columns, and `recentLines` goes to 50, so
    // reflowing would push the close button off the panel — and a progress
    // bar or a table reflowed is a different picture. The row is cut at the
    // border instead, and says so: the head is the part that matched a rule.
    for (const l of ex.recentLines.slice(-RECENT_LINES)) {
      parts.push(label(`  ${l}`, { style: { ...dim, italic: true }, elide: "tail" }));
    }
  }
  parts.push(
    spacer(0),
    endRow(withAccel(button(editor.t("machine.btn_close"), { key: "explain-close" }), "Esc")),
  );
  return col(...parts);
}

function renderExplainPopup(): void {
  if (explainPanel && explainShowing) {
    explainPanel.update(buildExplainSpec(explainShowing.s, explainShowing.ex));
  }
}

function openExplainPopup(s: AgentSession, ex: StateExplanation): void {
  closeExplainPopup();
  explainShowing = { s, ex };
  explainPanel = new FloatingWidgetPanel();
  explainPanel.mount(buildExplainSpec(s, ex), {
    widthPct: 70,
    heightPct: 60,
    focusMarker: true,
    title: editor.t("explain.title"),
    closable: true,
    mode: EXPLAIN_MODE,
  });
  editor.floatingPanelControl(explainPanel.id(), "fullscreen", 1);
  explainPanel.setFocusKey("explain-close");
}

editor.defineMode(EXPLAIN_MODE, [["Enter", "orchestrator_explain_close"]], true, true);
registerHandler("orchestrator_explain_close", closeExplainPopup);

function handleExplainEvent(e: WidgetEvt): void {
  if (e.event_type === "cancel") {
    // Esc / click-outside: the host already unmounted the panel.
    explainPanel = null;
    explainShowing = null;
    return;
  }
  if (e.event_type === "activate" && e.widget_key === "explain-close") closeExplainPopup();
}

// Explain the state badge of the dock's selected workspace (or the active
// one): a popup with the chain, one line in the status bar, all of it in the log.
registerHandler("orchestrator_explain", () => {
  let id: number | null = null;
  const selKey = openDialog?.dockSelKey;
  if (selKey?.startsWith(SESSION_NODE_PREFIX)) {
    const sel = Number(selKey.slice(SESSION_NODE_PREFIX.length));
    if (orchestratorSessions.has(sel)) id = sel;
  }
  if (id === null) id = editor.activeWindow();
  const s = orchestratorSessions.get(id);
  if (!s) {
    editor.setStatus(editor.t("explain.none"));
    return;
  }
  const ex = explainState(s);
  const line = explainSummaryLine(s, ex);
  editor.setStatus(line);
  editor.info(`orchestrator: ${line}\n  recent lines: ${JSON.stringify(ex.recentLines)}`);
  openExplainPopup(s, ex);
});
editor.registerCommand("%cmd.explain", "%cmd.explain_desc", "orchestrator_explain", null, {
  terminalBypass: true,
});
registerHandler("orchestrator_reload_rules", () => {
  void loadDetectionRules().then((r) => {
    const loaded = editor.t("explain.rules_loaded", { version: String(r.version), source: r.source });
    editor.setStatus(
      detectionRulesProblem ? editor.t("explain.rules_bad", { path: detectionRulesProblem, loaded }) : loaded,
    );
    refreshOpenDialog();
  });
});
editor.registerCommand("%cmd.reload_rules", "%cmd.reload_rules_desc", "orchestrator_reload_rules", null, {
  terminalBypass: true,
});

registerHandler("orchestrator_jump", jumpToAttention);
editor.registerCommand("%cmd.jump", "%cmd.jump_desc", "orchestrator_jump", null, {
  terminalBypass: true,
});
registerHandler("orchestrator_jump_back", jumpBack);
editor.registerCommand("%cmd.jump_back", "%cmd.jump_back_desc", "orchestrator_jump_back", null, {
  terminalBypass: true,
});

registerHandler("orchestrator_run_agent", () => openForm());
editor.registerCommand(
  "%cmd.run_agent",
  "%cmd.run_agent_desc",
  "orchestrator_run_agent",
  null,
  { terminalBypass: true },
);

// View ▸ Orchestrator Dock — the menu route to the same toggle as the
// command, the `toggle_dock_focus` accelerator, and the dock's own title-bar
// `[ × ]`. It sits directly under "File Explorer" because the two are the
// editor's two side panels and users look for them together.
//
// Both anchors are stable ids rather than rendered text: `"View"` is the
// menu's `id` and `"toggle_file_explorer"` is the neighbouring row's action,
// so the placement holds in every locale. The `dock` checkbox is a
// host-computed menu-context key ("a dock panel is mounted"), which keeps
// the checkmark honest even when the dock is closed by a route the plugin
// didn't initiate.
editor.addMenuItem({
  menu: "View",
  label: editor.t("menu.dock"),
  action: "orchestrator_dock_toggle",
  checkbox: "dock",
  after: "toggle_file_explorer",
});
