-- LuaRocks configuration

rocks_trees = {
   { name = "user", root = home .. "/.luarocks" };
   { name = "system", root = "/data/data/com.nobiterminal/files/usr" };
}
variables = {
   LUA_DIR = "/data/data/com.nobiterminal/files/usr";
   LUA_BINDIR = "/data/data/com.nobiterminal/files/usr/bin";
   LUA_VERSION = "5.4";
   LUA = "/data/data/com.nobiterminal/files/usr/bin/lua5.4";
}
