#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Td::tdutils" for configuration "Release"
set_property(TARGET Td::tdutils APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Td::tdutils PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libtdutils.a"
  )

list(APPEND _cmake_import_check_targets Td::tdutils )
list(APPEND _cmake_import_check_files_for_Td::tdutils "/data/data/com.nobiterminal/files/usr/lib/libtdutils.a" )

# Import target "Td::tde2e" for configuration "Release"
set_property(TARGET Td::tde2e APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Td::tde2e PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libtde2e.a"
  )

list(APPEND _cmake_import_check_targets Td::tde2e )
list(APPEND _cmake_import_check_files_for_Td::tde2e "/data/data/com.nobiterminal/files/usr/lib/libtde2e.a" )

# Import target "Td::tdactor" for configuration "Release"
set_property(TARGET Td::tdactor APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Td::tdactor PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libtdactor.a"
  )

list(APPEND _cmake_import_check_targets Td::tdactor )
list(APPEND _cmake_import_check_files_for_Td::tdactor "/data/data/com.nobiterminal/files/usr/lib/libtdactor.a" )

# Import target "Td::tdnet" for configuration "Release"
set_property(TARGET Td::tdnet APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Td::tdnet PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libtdnet.a"
  )

list(APPEND _cmake_import_check_targets Td::tdnet )
list(APPEND _cmake_import_check_files_for_Td::tdnet "/data/data/com.nobiterminal/files/usr/lib/libtdnet.a" )

# Import target "Td::tdsqlite" for configuration "Release"
set_property(TARGET Td::tdsqlite APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Td::tdsqlite PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libtdsqlite.a"
  )

list(APPEND _cmake_import_check_targets Td::tdsqlite )
list(APPEND _cmake_import_check_files_for_Td::tdsqlite "/data/data/com.nobiterminal/files/usr/lib/libtdsqlite.a" )

# Import target "Td::tddb" for configuration "Release"
set_property(TARGET Td::tddb APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Td::tddb PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libtddb.a"
  )

list(APPEND _cmake_import_check_targets Td::tddb )
list(APPEND _cmake_import_check_files_for_Td::tddb "/data/data/com.nobiterminal/files/usr/lib/libtddb.a" )

# Import target "Td::tdjson_static" for configuration "Release"
set_property(TARGET Td::tdjson_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Td::tdjson_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libtdjson_static.a"
  )

list(APPEND _cmake_import_check_targets Td::tdjson_static )
list(APPEND _cmake_import_check_files_for_Td::tdjson_static "/data/data/com.nobiterminal/files/usr/lib/libtdjson_static.a" )

# Import target "Td::tdjson_private" for configuration "Release"
set_property(TARGET Td::tdjson_private APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Td::tdjson_private PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libtdjson_private.a"
  )

list(APPEND _cmake_import_check_targets Td::tdjson_private )
list(APPEND _cmake_import_check_files_for_Td::tdjson_private "/data/data/com.nobiterminal/files/usr/lib/libtdjson_private.a" )

# Import target "Td::tdcore" for configuration "Release"
set_property(TARGET Td::tdcore APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Td::tdcore PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libtdcore.a"
  )

list(APPEND _cmake_import_check_targets Td::tdcore )
list(APPEND _cmake_import_check_files_for_Td::tdcore "/data/data/com.nobiterminal/files/usr/lib/libtdcore.a" )

# Import target "Td::tdmtproto" for configuration "Release"
set_property(TARGET Td::tdmtproto APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Td::tdmtproto PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libtdmtproto.a"
  )

list(APPEND _cmake_import_check_targets Td::tdmtproto )
list(APPEND _cmake_import_check_files_for_Td::tdmtproto "/data/data/com.nobiterminal/files/usr/lib/libtdmtproto.a" )

# Import target "Td::tdclient" for configuration "Release"
set_property(TARGET Td::tdclient APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Td::tdclient PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libtdclient.a"
  )

list(APPEND _cmake_import_check_targets Td::tdclient )
list(APPEND _cmake_import_check_files_for_Td::tdclient "/data/data/com.nobiterminal/files/usr/lib/libtdclient.a" )

# Import target "Td::tdapi" for configuration "Release"
set_property(TARGET Td::tdapi APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Td::tdapi PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libtdapi.a"
  )

list(APPEND _cmake_import_check_targets Td::tdapi )
list(APPEND _cmake_import_check_files_for_Td::tdapi "/data/data/com.nobiterminal/files/usr/lib/libtdapi.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
