/*
* Copyright (c) 2013-2026, The PurpleI2P Project
*
* This file is part of Purple i2pd project and licensed under BSD3
*
* See full license text in LICENSE file at top of project tree
*/

#ifndef UDPTUNNEL_H__
#define UDPTUNNEL_H__

#include <inttypes.h>
#include <string>
#include <string_view>
#include <memory>
#include <thread>
#include <vector>
#include <list>
#include <unordered_map>
#include <boost/asio.hpp>
#include "util.h"
#include "Identity.h"
#include "Destination.h"
#include "Datagram.h"
#include "AddressBook.h"

namespace i2p
{
namespace client
{
	/** 2 minute timeout for udp sessions */
	const uint64_t I2P_UDP_SESSION_TIMEOUT = 1000 * 60 * 2;
	const int I2P_UDP_SESSION_CLEANUP_INTERVAL = 17; // in seconds
	const uint64_t I2P_UDP_REPLIABLE_DATAGRAM_INTERVAL = 100; // in milliseconds
	const uint64_t I2P_UDP_MAX_UNACKED_DATAGRAM_TIME = 8000; // in milliseconds
	const uint64_t I2P_UDP_MIN_ACK_TIMEOUT = 500; // in milliseconds
	// rfc 6298 rto estimator, as denominators: srtt alpha = 1/8, rttvar beta = 1/4
	const uint64_t I2P_UDP_RTT_ALPHA = 8;
	const uint64_t I2P_UDP_RTT_VAR_BETA = 4;
	const uint64_t I2P_UDP_RTO_K = 4; // rto = srtt + k*rttvar
	const uint64_t I2P_UDP_MIN_WINDOW_PROBE_INTERVAL = 50; // in milliseconds
	const uint64_t I2P_UDP_FIRST_PACKET_RESEND_INTERVAL = 1000; // in milliseconds
	const size_t I2P_UDP_MIN_MAX_NUM_UNACKED_DATAGRAMS = 500;
	const size_t I2P_UDP_DEFAULT_MAX_NUM_UNACKED_DATAGRAMS = 1000;
	const size_t I2P_UDP_MAX_NUM_UNACKED_DATAGRAMS = 8192;
	const size_t I2P_UDP_WINDOW_GAIN = 2; // in bandwidth-delay products
	const uint64_t I2P_UDP_MIN_RTT_EXPIRATION_TIMEOUT = 15000; // in milliseconds
	const uint64_t I2P_UDP_SEND_RATE_INTERVAL = 200; // in milliseconds
	const uint64_t I2P_UDP_SEND_RATE_EXPIRATION_TIMEOUT = 5000; // in milliseconds
	const uint32_t I2P_UDP_MAX_NUM_ACK_TIMEOUTS = 3; // in a row, before routing path gets reset
	const uint64_t I2P_UDP_PEER_PATH_RESET_TIMEOUT = 4*I2P_UDP_MAX_UNACKED_DATAGRAM_TIME; // silence, in milliseconds

	/** max size for i2p udp */
	const size_t I2P_UDP_MAX_MTU = 64*1024;
	/** local socket buffers, not datagram size */
	const size_t I2P_UDP_SOCKET_BUFFER_SIZE = 4*1024*1024;

	// handlers of both sides are queued on sockets and can outlive the object
	// they belong to, so they hold it by a shared pointer
	struct UDPConnection: public std::enable_shared_from_this<UDPConnection>
	{
		std::shared_ptr<i2p::datagram::DatagramDestination> m_Destination;
		std::weak_ptr<i2p::datagram::DatagramSession> m_LastDatagramSession;
		uint64_t m_LastRepliableDatagramTime; // milliseconds
		i2p::data::IdentHash Identity;
		bool isIdentity = false;
		uint32_t m_NextSendPacketNum = 1, m_LastReceivedPacketNum = 0;
		std::list<std::pair<uint32_t, uint64_t> > m_UnackedDatagrams; // list of sent but not acked repliable datagrams(seqn, timestamp) in ascending order
		uint64_t m_RTT = 0, m_RTTVar = 0; // milliseconds, smoothed
		uint64_t m_MinRTT = 0, m_MinRTTCandidate = 0, m_MinRTTUpdateTime = 0; // path delay, without queueing
		uint64_t m_LastReceivedTime = 0; // milliseconds, any datagram from the peer
		uint64_t m_SendRateUpdateTime = 0, m_SendRateMaxTime = 0; // milliseconds
		uint32_t m_NumSentSinceRateUpdate = 0, m_SendRate = 0; // datagrams per second
		size_t m_MaxWindow = I2P_UDP_MIN_MAX_NUM_UNACKED_DATAGRAMS;

		boost::asio::steady_timer m_AckTimer;
		uint32_t m_AckTimerSeqn = 0;
		bool m_IsSendingAllowed = true;
		bool m_IsFirstPacket = true;
		uint32_t m_NumAckTimeoutsInRow = 0;
		uint64_t m_LastWindowProbeTime = 0; // milliseconds
		uint32_t m_NumWindowDrops = 0, m_NumAckTimeouts = 0;

		UDPConnection (boost::asio::io_context& service, std::shared_ptr<i2p::datagram::DatagramDestination> destination):
			m_Destination (destination), m_LastRepliableDatagramTime (0), m_AckTimer (service) {};
		void SetIdentity (const i2p::data::IdentHash& ident) { Identity = ident; isIdentity = true; };
		void SetMaxWindow (size_t w) { m_MaxWindow = w; };

		virtual ~UDPConnection () { Stop (); };
		virtual void Start () {};
		virtual void Stop ();

		void Acked (uint32_t seqn);
		void ScheduleAckTimer (uint32_t seqn);
		void UpdateRTT (uint64_t rtt, uint64_t ts);
		void UpdateSendRate (uint32_t numDatagrams, uint64_t ts);
		uint64_t GetRTO () const;
		uint64_t GetWindowProbeInterval () const;
		size_t GetMaxNumUnackedDatagrams () const;
		bool IsWindowFull () const;
		void ExpireUnackedDatagrams (uint64_t ts);

		std::shared_ptr<i2p::datagram::DatagramSession> GetDatagramSession ();
	};

	struct UDPSession: public UDPConnection // for server side
	{
		boost::asio::ip::udp::socket IPSocket;
		boost::asio::ip::udp::endpoint FromEndpoint;
		boost::asio::ip::udp::endpoint SendEndpoint;
		uint64_t LastActivity; // milliseconds

		uint16_t LocalPort;
		uint16_t RemotePort;

		uint8_t m_Buffer[I2P_UDP_MAX_MTU];

		UDPSession(boost::asio::ip::udp::endpoint localEndpoint,
			const std::shared_ptr<i2p::client::ClientDestination> & localDestination,
			const boost::asio::ip::udp::endpoint& remote, const i2p::data::IdentHash& ident,
			uint16_t ourPort, uint16_t theirPort);
		void HandleReceived(const boost::system::error_code & ecode, std::size_t len);
		void Receive();
	};


	/** read only info about a datagram session */
	struct DatagramSessionInfo
	{
		/** the name of this forward */
		std::string Name;
		/** ident hash of local destination */
		std::shared_ptr<const i2p::data::IdentHash> LocalIdent;
		/** ident hash of remote destination */
		std::shared_ptr<const i2p::data::IdentHash> RemoteIdent;
		/** ident hash of IBGW in use currently in this session or nullptr if none is set */
		std::shared_ptr<const i2p::data::IdentHash> CurrentIBGW;
		/** ident hash of OBEP in use for this session or nullptr if none is set */
		std::shared_ptr<const i2p::data::IdentHash> CurrentOBEP;
		/** i2p router's udp endpoint */
		boost::asio::ip::udp::endpoint LocalEndpoint;
		/** client's udp endpoint */
		boost::asio::ip::udp::endpoint RemoteEndpoint;
		/** how long has this conversation been idle in ms */
		uint64_t idle;
	};

	typedef std::shared_ptr<UDPSession> UDPSessionPtr;

	/** server side udp tunnel, many i2p inbound to 1 ip outbound */
	class I2PUDPServerTunnel
	{
		public:

			I2PUDPServerTunnel (const std::string & name,
				std::shared_ptr<i2p::client::ClientDestination> localDestination,
				const boost::asio::ip::address& localAddress,
				const boost::asio::ip::udp::endpoint& forwardTo, uint16_t port, bool gzip);
			~I2PUDPServerTunnel ();

			/** expire stale udp conversations */
			void ExpireStale (const uint64_t delta=I2P_UDP_SESSION_TIMEOUT);
			void Start ();
			void Stop ();
			const char * GetName () const { return m_Name.c_str(); }
			std::vector<std::shared_ptr<DatagramSessionInfo> > GetSessions ();
			std::shared_ptr<ClientDestination> GetLocalDestination () const { return m_LocalDest; }

			void SetUniqueLocal (bool isUniqueLocal = true) { m_IsUniqueLocal = isUniqueLocal; }
			void SetMaxWindow (size_t w) { m_MaxWindow = w; }

		private:

			void HandleRecvFromI2P (const i2p::data::IdentityEx& from, uint16_t fromPort, uint16_t toPort,
				const uint8_t * buf, size_t len, const i2p::util::Mapping * options);
			void HandleRecvFromI2PRaw (uint16_t fromPort, uint16_t toPort, const uint8_t * buf, size_t len);
			UDPSessionPtr ObtainUDPSession (const i2p::data::IdentityEx& from, uint16_t localPort, uint16_t remotePort);
			uint32_t GetSessionIndex (uint16_t fromPort, uint16_t toPort) const { return ((uint32_t)fromPort << 16) + toPort; }

			void ScheduleStatsTimer ();
			void HandleStatsTimer (const boost::system::error_code& ecode);
			void ScheduleCleanupTimer ();
			void HandleCleanupTimer (const boost::system::error_code& ecode);

		private:

			bool m_IsUniqueLocal;
			const std::string m_Name;
			boost::asio::ip::address m_LocalAddress;
			boost::asio::ip::udp::endpoint m_RemoteEndpoint;
			std::mutex m_SessionsMutex;
			std::unordered_map<uint32_t, UDPSessionPtr> m_Sessions; // (from port, to port)->session
			std::shared_ptr<i2p::client::ClientDestination> m_LocalDest;
			UDPSessionPtr m_LastSession;
			uint16_t m_inPort;
			bool m_Gzip;
			bool m_IsStarted = false; // a tunnel that never started shares nothing to tear down
			uint32_t m_NumRawNoSession = 0;
			size_t m_MaxWindow = I2P_UDP_MIN_MAX_NUM_UNACKED_DATAGRAMS;
			std::unique_ptr<boost::asio::steady_timer> m_StatsTimer;
			std::unique_ptr<boost::asio::steady_timer> m_CleanupTimer;

		public:

			bool isUpdated; // transient, used during reload only
	};

	class I2PUDPClientTunnel: public UDPConnection
	{
		public:

			I2PUDPClientTunnel (std::string_view name, std::string_view remoteDest,
				const boost::asio::ip::udp::endpoint& localEndpoint, std::shared_ptr<i2p::client::ClientDestination> localDestination,
				uint16_t remotePort, bool gzip, i2p::datagram::DatagramVersion datagramVersion);
			~I2PUDPClientTunnel ();

			void Start () override;
			void Stop () override;
			const char * GetName () const { return m_Name.c_str(); }
			std::vector<std::shared_ptr<DatagramSessionInfo> > GetSessions ();

			bool IsLocalDestination (const i2p::data::IdentHash & destination) const { return destination == m_LocalDest->GetIdentHash(); }
			std::shared_ptr<ClientDestination> GetLocalDestination () const { return m_LocalDest; }
			inline void SetLocalDestination (std::shared_ptr<ClientDestination> dest)
			{
				if (m_LocalDest) m_LocalDest->Release ();
				if (dest) dest->Acquire ();
				m_LocalDest = dest;
			}
			const boost::asio::ip::udp::endpoint& GetLocalEndpoint () const { return m_LocalEndpoint; };

			void ExpireStale (const uint64_t delta=I2P_UDP_SESSION_TIMEOUT);
			void SetKeepAliveInterval (uint32_t keepAliveInterval);

		private:

			typedef std::pair<boost::asio::ip::udp::endpoint, uint64_t> UDPConvo;
			void RecvFromLocal ();
			void HandleRecvFromLocal (const boost::system::error_code & e, std::size_t transferred);
			void HandleRecvFromI2P (const i2p::data::IdentityEx& from, uint16_t fromPort, uint16_t toPort,
				const uint8_t * buf, size_t len, const i2p::util::Mapping * options);
			void HandleRecvFromI2PRaw (uint16_t fromPort, uint16_t toPort, const uint8_t * buf, size_t len);
			void TryResolving ();

			void ScheduleKeepAliveTimer ();
			void HandleKeepAliveTimer (const boost::system::error_code& ecode);

			void ScheduleStatsTimer ();
			void HandleStatsTimer (const boost::system::error_code& ecode);
			void ScheduleCleanupTimer ();
			void HandleCleanupTimer (const boost::system::error_code& ecode);

		private:

			const std::string m_Name;
			std::mutex m_SessionsMutex;
			std::unordered_map<uint16_t, std::shared_ptr<UDPConvo> > m_Sessions; // maps i2p port -> local udp convo
			const std::string m_RemoteDest;
			std::shared_ptr<i2p::client::ClientDestination> m_LocalDest;
			const boost::asio::ip::udp::endpoint m_LocalEndpoint;
			std::thread * m_ResolveThread;
			std::unique_ptr<boost::asio::ip::udp::socket> m_LocalSocket;
			boost::asio::ip::udp::endpoint m_RecvEndpoint;
			uint8_t m_RecvBuff[I2P_UDP_MAX_MTU];
			uint16_t RemotePort, m_LastPort;
			bool m_cancel_resolve;
			bool m_Gzip;
			bool m_IsStarted = false; // see the comment in I2PUDPServerTunnel
			i2p::datagram::DatagramVersion m_DatagramVersion;
			std::shared_ptr<UDPConvo> m_LastSession;
			uint32_t m_KeepAliveInterval = 0;
			std::unique_ptr<boost::asio::steady_timer> m_KeepAliveTimer;
			std::unique_ptr<boost::asio::steady_timer> m_StatsTimer;

		public:

			bool isUpdated; // transient, used during reload only
	};


}
}

#endif
