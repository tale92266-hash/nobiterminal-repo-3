/*
* Copyright (c) 2013-2026, The PurpleI2P Project
*
* This file is part of Purple i2pd project and licensed under BSD3
*
* See full license text in LICENSE file at top of project tree
*/

#ifndef I2PTUNNEL_H__
#define I2PTUNNEL_H__

#include <inttypes.h>
#include <string>
#include <string_view>
#include <set>
#include <vector>
#include <tuple>
#include <memory>
#include <sstream>
#include <boost/asio.hpp>
#include <boost/asio/ssl.hpp>
#include "Identity.h"
#include "Destination.h"
#include "Streaming.h"
#include "I2PService.h"
#include "AddressBook.h"

namespace i2p
{
namespace client
{
	constexpr size_t I2P_TUNNEL_CONNECTION_BUFFER_SIZE = 8192;
	constexpr size_t I2P_TUNNEL_CONNECTION_STREAM_MAX_SEND_BUFFER_SIZE = 8*I2P_TUNNEL_CONNECTION_BUFFER_SIZE;
	constexpr size_t I2P_TUNNEL_CONNECTION_STREAM_BUFFER_SIZE = 16384;
	constexpr int I2P_TUNNEL_CONNECTION_MAX_IDLE = 3600; // in seconds
	constexpr int I2P_TUNNEL_DESTINATION_REQUEST_TIMEOUT = 10; // in seconds
	// for HTTP tunnels
	constexpr std::string_view X_I2P_DEST_HASH { "X-I2P-DestHash" }; // hash in base64
	constexpr std::string_view X_I2P_DEST_B64 { "X-I2P-DestB64" }; // full address in base64
	constexpr std::string_view X_I2P_DEST_B32 { "X-I2P-DestB32" }; // .b32.i2p address
	constexpr int I2P_TUNNEL_HTTP_MAX_HEADER_SIZE = 8192;
	constexpr int I2P_TUNNEL_MAX_NUM_HTTP_HEADERS = 100;

	class I2PTunnelConnection: public I2PServiceHandler, public std::enable_shared_from_this<I2PTunnelConnection>
	{
		public:

			I2PTunnelConnection (std::shared_ptr<I2PService> owner, std::shared_ptr<boost::asio::ip::tcp::socket> socket,
				std::shared_ptr<const i2p::data::LeaseSet> leaseSet, uint16_t port = 0); // to I2P
			I2PTunnelConnection (std::shared_ptr<I2PService> owner, std::shared_ptr<boost::asio::ip::tcp::socket> socket,
				std::shared_ptr<i2p::stream::Stream> stream); // to I2P using simplified API
			I2PTunnelConnection (std::shared_ptr<I2PService> owner, std::shared_ptr<i2p::stream::Stream> stream,
				const boost::asio::ip::tcp::endpoint& target,
			    std::shared_ptr<boost::asio::ssl::context> sslCtx = nullptr); // from I2P
			~I2PTunnelConnection ();
			void I2PConnect (const uint8_t * msg = nullptr, size_t len = 0);
			void Connect (bool isUniqueLocal = true);
			void Connect (const boost::asio::ip::address& localAddress);

		protected:

			virtual void Established ();
			void Terminate ();

			void Receive ();
			void StreamReceive ();
			void HandleStreamReceive (const boost::system::error_code& ecode, std::size_t bytes_transferred);
			virtual void Write (const uint8_t * buf, size_t len); // can be overloaded
			virtual void WriteToStream (const uint8_t * buf, size_t len); // can be overloaded

			std::shared_ptr<boost::asio::ip::tcp::socket> GetSocket () const { return m_Socket; };
			std::shared_ptr<i2p::stream::Stream> GetStream () const { return m_Stream; };
			std::shared_ptr<boost::asio::ssl::stream<boost::asio::ip::tcp::socket&> > GetSSL () const { return m_SSL; };
			uint8_t * GetStreamBuffer () { return m_StreamBuffer; };

		private:

			void HandleConnect (const boost::system::error_code& ecode);
			void HandleHandshake (const boost::system::error_code& ecode);
			void HandleReceive (const boost::system::error_code& ecode, std::size_t bytes_transferred);
			void HandleWrite (const boost::system::error_code& ecode);

		private:

			uint8_t m_Buffer[I2P_TUNNEL_CONNECTION_BUFFER_SIZE], m_StreamBuffer[I2P_TUNNEL_CONNECTION_STREAM_BUFFER_SIZE];
			std::shared_ptr<boost::asio::ip::tcp::socket> m_Socket;
			std::shared_ptr<boost::asio::ssl::stream<boost::asio::ip::tcp::socket&> > m_SSL;
			std::shared_ptr<i2p::stream::Stream> m_Stream;
			boost::asio::ip::tcp::endpoint m_RemoteEndpoint;
			bool m_IsReceiving;
	};

	class I2PClientTunnelConnectionHTTP: public I2PTunnelConnection
	{
		public:

			I2PClientTunnelConnectionHTTP (std::shared_ptr<I2PService> owner, std::shared_ptr<boost::asio::ip::tcp::socket> socket,
				std::shared_ptr<i2p::stream::Stream> stream):
				I2PTunnelConnection (owner, socket, stream), m_HeaderSent (false),
				m_ConnectionSent (false), m_ProxyConnectionSent (false), m_NumHeaders (0) {};

		protected:

			void Write (const uint8_t * buf, size_t len) override;

		private:

			std::stringstream m_InHeader, m_OutHeader;
			bool m_HeaderSent, m_ConnectionSent, m_ProxyConnectionSent;
			int m_NumHeaders;
	};

	class I2PServerTunnelConnectionHTTP: public I2PTunnelConnection
	{
		public:

			I2PServerTunnelConnectionHTTP (std::shared_ptr<I2PService> owner, std::shared_ptr<i2p::stream::Stream> stream,
				const boost::asio::ip::tcp::endpoint& target, const std::string& host, const std::string& XI2P,
			    std::shared_ptr<boost::asio::ssl::context> sslCtx = nullptr);

		protected:

			void Write (const uint8_t * buf, size_t len) override;
			void WriteToStream (const uint8_t * buf, size_t len) override;

		private:

			std::string m_Host, m_XI2P;
			std::stringstream m_InHeader, m_OutHeader;
			bool m_HeaderSent, m_ResponseHeaderSent;
			int m_NumHeaders;
	};

	class I2PTunnelConnectionIRC: public I2PTunnelConnection
	{
		public:

			I2PTunnelConnectionIRC (std::shared_ptr<I2PService> owner, std::shared_ptr<i2p::stream::Stream> stream,
				const boost::asio::ip::tcp::endpoint& target, const std::string& m_WebircPass,
			    std::shared_ptr<boost::asio::ssl::context> sslCtx = nullptr);

		protected:

			void Write (const uint8_t * buf, size_t len) override;

		private:

			std::shared_ptr<const i2p::data::IdentityEx> m_From;
			std::stringstream m_OutPacket, m_InPacket;
			bool m_NeedsWebIrc;
			std::string m_WebircPass;
	};


	class I2PClientTunnel: public TCPIPAcceptor
	{
		protected:

			// Implements TCPIPAcceptor
			std::shared_ptr<I2PServiceHandler> CreateHandler(std::shared_ptr<boost::asio::ip::tcp::socket> socket) override;

		public:

			I2PClientTunnel (const std::string& name, const std::string& destination,
				const std::string& address, uint16_t port, std::shared_ptr<ClientDestination> localDestination, uint16_t destinationPort = 0);
			~I2PClientTunnel () {}

			void Start () override;
			void Stop () override;

			const char* GetName() const override { return m_Name.c_str (); }
			void SetKeepAliveInterval (uint32_t keepAliveInterval);

		private:

			std::shared_ptr<const Address> GetAddress ();

			void ScheduleKeepAliveTimer ();
			void HandleKeepAliveTimer (const boost::system::error_code& ecode);

		private:

			std::string m_Name;
			std::vector<std::string> m_Destinations;
			std::vector<std::shared_ptr<const Address> > m_Addresses; // resolved lazily, same order
			size_t m_NextAddress;
			uint16_t m_DestinationPort;
			uint32_t m_KeepAliveInterval;
			std::unique_ptr<boost::asio::steady_timer> m_KeepAliveTimer;
	};

	class I2PServerTunnel: public I2PService
	{
		public:

			I2PServerTunnel (const std::string& name, const std::string& address, uint16_t port,
				std::shared_ptr<ClientDestination> localDestination, uint16_t inport = 0, bool gzip = true);

			void Start () override;
			void Stop () override;

			void SetAccessList (const std::set<i2p::data::IdentHash>& accessList);

			void SetUniqueLocal (bool isUniqueLocal) { m_IsUniqueLocal = isUniqueLocal; }
			bool IsUniqueLocal () const { return m_IsUniqueLocal; }

			void SetSSL (bool ssl);
			std::shared_ptr<boost::asio::ssl::context> GetSSLCtx () const { return m_SSLCtx; };

			void SetLocalAddress (const std::string& localAddress);

			const std::string& GetAddress() const { return m_Address; }
			uint16_t GetPort () const { return m_Port; };
			uint16_t GetLocalPort () const { return m_PortDestination->GetLocalPort (); };
			const boost::asio::ip::tcp::endpoint& GetEndpoint () const { return m_Endpoint; }

			const char* GetName() const override { return m_Name.c_str (); }

			void Accept ();
			void DetachAcceptor (); // called before the tunnels are read again on reload

		private:

			bool Resolve (std::shared_ptr<i2p::stream::Stream> stream);
			void HandleResolve (const boost::system::error_code& ecode, boost::asio::ip::tcp::resolver::results_type endpoints,
				std::shared_ptr<i2p::stream::Stream> stream);

			void HandleAccept (std::shared_ptr<i2p::stream::Stream> stream);
			void Connect (std::shared_ptr<i2p::stream::Stream> stream);
			virtual std::shared_ptr<I2PTunnelConnection> CreateI2PConnection (std::shared_ptr<i2p::stream::Stream> stream);

		private:

			bool m_IsUniqueLocal;
			bool m_IsDefaultAcceptor; // this tunnel is the one accepting on the destination
			std::string m_Name, m_Address;
			uint16_t m_Port;
			boost::asio::ip::tcp::endpoint m_Endpoint;
			std::shared_ptr<i2p::stream::StreamingDestination> m_PortDestination;
			std::set<i2p::data::IdentHash> m_AccessList;
			bool m_IsAccessList;
			std::unique_ptr<boost::asio::ip::address> m_LocalAddress;
			std::shared_ptr<boost::asio::ssl::context> m_SSLCtx;
			std::shared_ptr<boost::asio::ip::tcp::resolver> m_Resolver;
	};

	class I2PServerTunnelHTTP: public I2PServerTunnel
	{
		public:

			I2PServerTunnelHTTP (const std::string& name, const std::string& address, uint16_t port,
				std::shared_ptr<ClientDestination> localDestination, const std::string& host,
				uint16_t inport = 0, bool gzip = true, bool i2pheaders = true);

		private:

			std::shared_ptr<I2PTunnelConnection> CreateI2PConnection (std::shared_ptr<i2p::stream::Stream> stream);

		private:

			std::string m_Host, m_XI2P;
			std::weak_ptr<const i2p::data::IdentityEx> m_From;
			bool m_I2PHeaders;
	};

	class I2PServerTunnelIRC: public I2PServerTunnel
	{
		public:

			I2PServerTunnelIRC (const std::string& name, const std::string& address, uint16_t port,
				std::shared_ptr<ClientDestination> localDestination, const std::string& webircpass,
				uint16_t inport = 0, bool gzip = true);

		private:

			std::shared_ptr<I2PTunnelConnection> CreateI2PConnection (std::shared_ptr<i2p::stream::Stream> stream);

		private:

			std::string m_WebircPass;
	};

	boost::asio::ip::address GetLoopbackAddressFor(const i2p::data::IdentHash & addr);
}
}

#endif
