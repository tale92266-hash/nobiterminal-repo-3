/* SPDX-License-Identifier: Zlib */

#ifndef GIRARA_VERSION_H
#define GIRARA_VERSION_H

/* clang-format off */
#define GIRARA_VERSION_MAJOR 2026
#define GIRARA_VERSION_MINOR 07
#define GIRARA_VERSION_REV 18
#define GIRARA_VERSION "2026.07.18"
/* clang-format on */

#endif
