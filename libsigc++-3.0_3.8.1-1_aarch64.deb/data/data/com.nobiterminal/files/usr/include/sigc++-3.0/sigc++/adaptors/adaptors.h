/* Copyright 2002 - 2016, The libsigc++ Development Team
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, see <https://www.gnu.org/licenses/>.
 */
#ifndef SIGC_ADAPTOR_HPP
#define SIGC_ADAPTOR_HPP

#include <sigc++/adaptors/bind.h>
#include <sigc++/adaptors/bind_return.h>
#include <sigc++/adaptors/hide.h>
#include <sigc++/adaptors/retype_return.h>
#include <sigc++/adaptors/retype.h>
#include <sigc++/adaptors/compose.h>
#include <sigc++/adaptors/exception_catch.h>
#include <sigc++/adaptors/track_obj.h>

#endif /* SIGC_ADAPTOR_HPP */
