/* -*- mode: C++; c-basic-offset: 2; indent-tabs-mode: nil -*- */
/*
 *  Main authors:
 *     Christian Schulte <schulte@gecode.dev>
 *
 *  Contributing authors:
 *     Mikael Zayenz Lagerkvist <lagerkvist@gecode.dev>
 *
 *  Copyright:
 *     Christian Schulte, 2006
 *     Mikael Zayenz Lagerkvist, 2026
 *
 *  This file is part of Gecode, the generic constraint
 *  development environment:
 *     http://www.gecode.dev
 *
 *  Permission is hereby granted, free of charge, to any person obtaining
 *  a copy of this software and associated documentation files (the
 *  "Software"), to deal in the Software without restriction, including
 *  without limitation the rights to use, copy, modify, merge, publish,
 *  distribute, sublicense, and/or sell copies of the Software, and to
 *  permit persons to whom the Software is furnished to do so, subject to
 *  the following conditions:
 *
 *  The above copyright notice and this permission notice shall be
 *  included in all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 *  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 *  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 *  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */

namespace Gecode { namespace Search {

  /*
   * Base class
   *
   */
  forceinline
  Stop::Stop(void) {}
  forceinline
  Stop::~Stop(void) {}


  /*
   * Stopping for node limit
   *
   */

  forceinline
  NodeStop::NodeStop(unsigned long long int l0) : l(l0) {}
  forceinline
  NodeStop::NodeStop(const NodeStop& s) : Stop(s), l(s.limit()) {}
  forceinline NodeStop&
  NodeStop::operator =(const NodeStop& s) {
    Stop::operator =(s);
    limit(s.limit());
    return *this;
  }

  forceinline unsigned long long int
  NodeStop::limit(void) const {
    return l.load(std::memory_order_acquire);
  }

  forceinline void
  NodeStop::limit(unsigned long long int l0) {
    l.store(l0, std::memory_order_release);
  }


  /*
   * Stopping for failure limit
   *
   */

  forceinline
  FailStop::FailStop(unsigned long long int l0) : l(l0) {}
  forceinline
  FailStop::FailStop(const FailStop& s) : Stop(s), l(s.limit()) {}
  forceinline FailStop&
  FailStop::operator =(const FailStop& s) {
    Stop::operator =(s);
    limit(s.limit());
    return *this;
  }

  forceinline unsigned long long int
  FailStop::limit(void) const {
    return l.load(std::memory_order_acquire);
  }

  forceinline void
  FailStop::limit(unsigned long long int l0) {
    l.store(l0, std::memory_order_release);
  }


  /*
   * Stopping for time limit
   *
   */

  forceinline
  TimeStop::TimeStop(double l0)
    : t0(clock::now().time_since_epoch().count()), l(l0) {}
  forceinline
  TimeStop::TimeStop(const TimeStop& s)
    : Stop(s),
      t0(s.t0.load(std::memory_order_acquire)),
      l(s.l.load(std::memory_order_acquire)) {}
  forceinline TimeStop&
  TimeStop::operator =(const TimeStop& s) {
    const clock_rep t00 = s.t0.load(std::memory_order_acquire);
    const double l0 = s.l.load(std::memory_order_acquire);
    Stop::operator =(s);
    t0.store(t00, std::memory_order_release);
    l.store(l0, std::memory_order_release);
    return *this;
  }

  forceinline double
  TimeStop::limit(void) const {
    return l.load(std::memory_order_acquire);
  }

  forceinline void
  TimeStop::limit(double l0) {
    l.store(l0, std::memory_order_release);
  }

  forceinline void
  TimeStop::reset(void) {
    t0.store(clock::now().time_since_epoch().count(),
             std::memory_order_release);
  }

  /*
   * Stopping for restart limit
   *
   */

  forceinline
  RestartStop::RestartStop(unsigned long long int l0) : l(l0) {}
  forceinline
  RestartStop::RestartStop(const RestartStop& s) : Stop(s), l(s.limit()) {}
  forceinline RestartStop&
  RestartStop::operator =(const RestartStop& s) {
    Stop::operator =(s);
    limit(s.limit());
    return *this;
  }

  forceinline unsigned long long int
  RestartStop::limit(void) const {
    return l.load(std::memory_order_acquire);
  }

  forceinline void
  RestartStop::limit(unsigned long long int l0) {
    l.store(l0, std::memory_order_release);
  }

}}

// STATISTICS: search-other
