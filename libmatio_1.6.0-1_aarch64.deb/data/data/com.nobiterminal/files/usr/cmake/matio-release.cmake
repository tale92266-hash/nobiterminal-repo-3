#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "matio" for configuration "Release"
set_property(TARGET matio APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(matio PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libmatio.so"
  IMPORTED_SONAME_RELEASE "libmatio.so"
  )

list(APPEND _cmake_import_check_targets matio )
list(APPEND _cmake_import_check_files_for_matio "/data/data/com.nobiterminal/files/usr/lib/libmatio.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
