//========================================================================
//
// CertificateInfo.h
//
// This file is licensed under the GPLv2 or later
//
// Copyright 2018 Chinmoy Ranjan Pradhan <chinmoyrp65@gmail.com>
// Copyright 2018, 2019, 2025 Albert Astals Cid <aacid@kde.org>
// Copyright 2018 Oliver Sander <oliver.sander@tu-dresden.de>
// Copyright 2020 Thorsten Behrens <Thorsten.Behrens@CIB.de>
// Copyright 2023, 2024, 2026 g10 Code GmbH, Author: Sune Stolborg Vuorela <sune@vuorela.dk>
// Copyright 2026 Sune Stolborg Vuorela <sune@vuorela.dk>, work sponsored by the Direction Interministérielle du Numérique
//
//========================================================================

#ifndef CERTIFICATEINFO_H
#define CERTIFICATEINFO_H

#include <chrono>
#include <vector>
#include "goo/GooString.h"
#include "poppler_private_export.h"

namespace CryptoSign {
enum class SMimeSignatureType
{
    none, /* nothing specified; do something sane, probably adbe_pkcs7_detached - this comes either from 'older software versions' or via a g10c_pgp_signature_detached signature*/
    adbe_pkcs7_detached,
    ETSI_CAdES_B, // Simplest cades
    ETSI_CAdES_T, // B + Time stamp
    ETSI_CAdES_LT, // T + Long term validation
    ETSI_CAdES_LTA, // LT + support for periodical timestamping
};
}

enum CertificateKeyUsageExtension
{
    KU_DIGITAL_SIGNATURE = 0x80,
    KU_NON_REPUDIATION = 0x40,
    KU_KEY_ENCIPHERMENT = 0x20,
    KU_DATA_ENCIPHERMENT = 0x10,
    KU_KEY_AGREEMENT = 0x08,
    KU_KEY_CERT_SIGN = 0x04,
    KU_CRL_SIGN = 0x02,
    KU_ENCIPHER_ONLY = 0x01,
    KU_NONE = 0x00
};

enum PublicKeyType
{
    RSAKEY,
    DSAKEY,
    ECKEY,
    OTHERKEY
};

/** A signing key can be located in different places
 sometimes. For the user, it might be easier to pick
 the key located on a card if it has some visual
 indicator that it is somehow removable.

 \note a keylocation for a certificate without a private
 key (cannot be used for signing) will likely be "Unknown"
 */
enum class KeyLocation
{
    Unknown, /** We don't know the location */
    Other, /** We know the location, but it is somehow not covered by this enum */
    Computer, /** The key is on this computer */
    HardwareToken /** The key is on a dedicated hardware token, either a smartcard or a dedicated usb token (e.g. gnuk, nitrokey or yubikey) */
};

enum class CertificateType
{
    X509,
    PGP
};

namespace Certificate {
using timePointSeconds = std::chrono::time_point<std::chrono::system_clock, std::chrono::seconds>;
}

class POPPLER_PRIVATE_EXPORT X509CertificateInfo // TODO consider rename to just CertificateInfo
{
public:
    X509CertificateInfo();
    ~X509CertificateInfo();

    X509CertificateInfo(const X509CertificateInfo &) = delete;
    X509CertificateInfo &operator=(const X509CertificateInfo &) = delete;

    struct PublicKeyInfo
    {
        PublicKeyInfo() = default;

        PublicKeyInfo(PublicKeyInfo &&) noexcept = default;
        PublicKeyInfo &operator=(PublicKeyInfo &&) noexcept = default;

        PublicKeyInfo(const PublicKeyInfo &) = delete;
        PublicKeyInfo &operator=(const PublicKeyInfo &) = delete;

        GooString publicKey;
        PublicKeyType publicKeyType = OTHERKEY;
        unsigned int publicKeyStrength = 0; // in bits
    };

    struct EntityInfo
    {
        EntityInfo() = default;
        ~EntityInfo() = default;

        EntityInfo(EntityInfo &&) noexcept = default;
        EntityInfo &operator=(EntityInfo &&) noexcept = default;

        EntityInfo(const EntityInfo &) = delete;
        EntityInfo &operator=(const EntityInfo &) = delete;

        std::string commonName;
        std::string distinguishedName;
        std::string email;
        std::string organization;
    };

    struct Validity
    {
        Certificate::timePointSeconds notBefore;
        Certificate::timePointSeconds notAfter;
    };

    /* GETTERS */
    int getVersion() const;
    const GooString &getSerialNumber() const;
    const GooString &getNickName() const;
    const EntityInfo &getIssuerInfo() const;
    const Validity &getValidity() const;
    const EntityInfo &getSubjectInfo() const;
    const PublicKeyInfo &getPublicKeyInfo() const;
    unsigned int getKeyUsageExtensions() const;
    const std::vector<unsigned char> &getCertificateDER() const;
    bool getIsSelfSigned() const;
    bool isQualified() const;
    void setQualified(bool qualified);
    KeyLocation getKeyLocation() const;
    CertificateType getCertificateType() const;
    const std::vector<CryptoSign::SMimeSignatureType> &supportedSMimeSignatureTypes() const;

    /* SETTERS */
    void setVersion(int version);
    void setSerialNumber(const GooString &serialNumber);
    void setNickName(const GooString &nickName);
    void setIssuerInfo(EntityInfo &&issuerInfo);
    void setValidity(Validity validity);
    void setSubjectInfo(EntityInfo &&subjectInfo);
    void setPublicKeyInfo(PublicKeyInfo &&pkInfo);
    void setKeyUsageExtensions(unsigned int keyUsages);
    void setCertificateDER(std::vector<unsigned char> &&certDer);
    void setIsSelfSigned(bool isSelfSigned);
    void setKeyLocation(KeyLocation location);
    void setCertificateType(CertificateType type);
    void setSupportedSMimeSignatureTypes(std::vector<CryptoSign::SMimeSignatureType> &&supported);

private:
    EntityInfo issuer_info;
    EntityInfo subject_info;
    PublicKeyInfo public_key_info;
    Validity cert_validity;
    GooString cert_serial;
    std::vector<unsigned char> cert_der;
    GooString cert_nick;
    unsigned int ku_extensions = KU_NONE;
    int cert_version = -1;
    bool is_qualified = false;
    bool is_self_signed = false;
    KeyLocation keyLocation = KeyLocation::Unknown;
    CertificateType certificate_type = CertificateType::X509;
    std::vector<CryptoSign::SMimeSignatureType> m_supportedTypes = { CryptoSign::SMimeSignatureType::none };
};

#endif
