#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "DjInterop::DjInterop" for configuration "Release"
set_property(TARGET DjInterop::DjInterop APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(DjInterop::DjInterop PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libdjinterop.so"
  IMPORTED_SONAME_RELEASE "libdjinterop.so"
  )

list(APPEND _cmake_import_check_targets DjInterop::DjInterop )
list(APPEND _cmake_import_check_files_for_DjInterop::DjInterop "/data/data/com.nobiterminal/files/usr/lib/libdjinterop.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
