
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was Config.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

# provide meta-data
set(c++utilities_varname "CPP_UTILITIES")
set(c++utilities_varname "CPP_UTILITIES")
set(CPP_UTILITIES_DISPLAY_NAME "C++ Utilities")
set(CPP_UTILITIES_AUTHOR "Martchus")
set(CPP_UTILITIES_VERSION "5.37.0")
set(CPP_UTILITIES_VERSION_MAJOR "5")
set(CPP_UTILITIES_VERSION_MINOR "37")
set(CPP_UTILITIES_VERSION_PATCH "0")
set(CPP_UTILITIES_GIT_REV_COUNT "")
set(CPP_UTILITIES_GIT_LAST_COMMIT_ID "")
set(CPP_UTILITIES_URL "https://github.com/Martchus/c++utilities")
set(CPP_UTILITIES_DESCRIPTION "Useful C++ classes and routines such as argument parser, IO and conversion utilities")
set(CPP_UTILITIES_LICENSE "GPL-2.0+")

# define general config
set(CPP_UTILITIES_IS_HEADER_ONLY NO)
set(CPP_UTILITIES_INCLUDE_DIRS "${PACKAGE_PREFIX_DIR}/include")
set(CPP_UTILITIES_BIN_DIR "${PACKAGE_PREFIX_DIR}/bin")
set(CPP_UTILITIES_LIB_DIR "${PACKAGE_PREFIX_DIR}/lib")
set(CPP_UTILITIES_DATA_DIRS "${PACKAGE_PREFIX_DIR}/share/c++utilities")
set(CPP_UTILITIES_MODULE_DIRS "${PACKAGE_PREFIX_DIR}/share/c++utilities/cmake/modules")
set(CPP_UTILITIES_CONFIG_DIRS "${PACKAGE_PREFIX_DIR}/share/c++utilities/cmake")
set(CPP_UTILITIES_PRIVATE_QT_MODULES "")
set(CPP_UTILITIES_PRIVATE_KF_MODULES "")
set(CPP_UTILITIES_PUBLIC_QT_MODULES "")
set(CPP_UTILITIES_PUBLIC_KF_MODULES "")
set(CPP_UTILITIES_REQUIRED_PACKAGES "")
set(CPP_UTILITIES_REQUIRED_PKG_CONFIG_MODULES "")
set(CPP_UTILITIES_HAS_QT_TRANSLATION_FILES )
set(CPP_UTILITIES_QT_RESOURCES )

# define mapping from CMake targets to pkg-config module names
set(PKG_CONFIG_c++utilities "c++utilities")

# save policies before modifying them e.g. though the inclusion of 3rdParty
cmake_policy(PUSH)

# define additional find_package arguments for required CMake-packages

# define library config, add imported target
set(CPP_UTILITIES_PACKAGE "c++utilities")
set(CPP_UTILITIES_LIB "c++utilities")
set(CPP_UTILITIES_LIB_IS_SHARED "ON")
set(CPP_UTILITIES_STATIC_LINKAGE "OFF")
if(NOT TARGET "${CPP_UTILITIES_LIB}")
    # make dependencies of the library available
    # caveat: This currently does *not* cover Qt and KF modules which are so far only handled
    #         separately when using the function use_CPP_UTILITIES.

    # find c++utilities to use its CMake modules
    if (NOT CPP_UTILITIES_PACKAGE STREQUAL "c++utilities")
        find_package("c++utilities" ${CPP_UTILITIES_FIND_PACKAGE_ARGS_c++utilities} REQUIRED)
    endif ()

    # prefer static libraries if c++utilities was configured this way during its build
    set(CPP_UTILITIES_DEFAULT_CMAKE_MODULE_PATH "${CMAKE_MODULE_PATH}")
    list(APPEND CMAKE_MODULE_PATH "${CPP_UTILITIES_MODULE_DIRS}")
    list(APPEND CMAKE_MODULE_PATH "${CPP_UTILITIES_MODULE_DIRS}")
    include(3rdPartyFunctions)
    if (CPP_UTILITIES_STATIC_LINKAGE)
        save_library_preference()
        prefer_static_libraries()
    endif ()

    # find all required packages
    foreach (_REQUIRED_PACKAGE ${CPP_UTILITIES_REQUIRED_PACKAGES})
        string(REGEX MATCH _REQUIRED_PACKAGE_MATCH "(.*)-([^-]*)" "${_REQUIRED_PACKAGE}")
        if (_REQUIRED_PACKAGE_MATCH)
            set(_REQUIRED_PACKAGE "${CMAKE_MATCH_1}")
            set(_REQUIRED_VERSION "${CMAKE_MATCH_2}")
        else ()
            unset(_REQUIRED_VERSION)
        endif ()
        string(REPLACE "::" "_" _REQUIRED_PACKAGE_VARNAME "${_REQUIRED_PACKAGE}")
        if (CPP_UTILITIES_FIND_PACKAGE_ARGS_${_REQUIRED_PACKAGE_VARNAME})
            set(_FIND_PACKAGE_ARGS ${CPP_UTILITIES_FIND_PACKAGE_ARGS_${_REQUIRED_PACKAGE_VARNAME}})
        else ()
            set(_FIND_PACKAGE_ARGS REQUIRED)
        endif ()
        if (_REQUIRED_VERSION)
            find_package("${_REQUIRED_PACKAGE}" "${_REQUIRED_VERSION}" ${_FIND_PACKAGE_ARGS})
        else ()
            find_package("${_REQUIRED_PACKAGE}" ${_FIND_PACKAGE_ARGS})
        endif()
    endforeach()

    # find all required pkg-config modules
    if (CPP_UTILITIES_REQUIRED_PKG_CONFIG_MODULES)
        foreach (CPP_UTILITIES_REQUIRED_PKG_CONFIG_MODULE ${CPP_UTILITIES_REQUIRED_PKG_CONFIG_MODULES})
            string(REPLACE "::" "_" CPP_UTILITIES_REQUIRED_PKG_CONFIG_MODULE_VARNAME "${CPP_UTILITIES_REQUIRED_PKG_CONFIG_MODULE}")
            use_pkg_config_module(
                TARGET_NAME "${CPP_UTILITIES_REQUIRED_PKG_CONFIG_MODULE}"
                PKG_CONFIG_MODULES "${PKG_CONFIG_${CPP_UTILITIES_REQUIRED_PKG_CONFIG_MODULE_VARNAME}}"
                LIBRARIES_VARIABLE DEV_NULL
                PKG_CONFIG_MODULES_VARIABLE DEV_NULL
            )
        endforeach ()
    endif ()

    # restore preference of static libraries
    if (CPP_UTILITIES_STATIC_LINKAGE)
        restore_library_preference()
    endif ()

    # add target for the library itself
    include("${CMAKE_CURRENT_LIST_DIR}/c++utilitiesTargets.cmake")

    # restore module path
    set(CMAKE_MODULE_PATH "${CPP_UTILITIES_DEFAULT_CMAKE_MODULE_PATH}")
endif()

# define function to ease use of library in projects following conventions of c++utilities' build script
function(use_CPP_UTILITIES)
    # make CMake modules of the project available
    list(APPEND CMAKE_MODULE_PATH "${CPP_UTILITIES_MODULE_DIRS}")
    set(CMAKE_MODULE_PATH "${CMAKE_MODULE_PATH}" PARENT_SCOPE)

    # parse arguments
    list(APPEND CMAKE_MODULE_PATH "${CPP_UTILITIES_MODULE_DIRS}")
    include(3rdParty)
    parse_arguments_for_use_functions(${ARGN})

    # link against library (also "link" against header-only libs to get compile defs and interface link libs)
    if (ARGS_ONLY_HEADERS)
        set(TARGET_NAME "${CPP_UTILITIES_LIB}-headers")
    else ()
        set(TARGET_NAME "${CPP_UTILITIES_LIB}")
    endif ()
    set("${ARGS_LIBRARIES_VARIABLE}" "${${ARGS_LIBRARIES_VARIABLE}};${TARGET_NAME}" PARENT_SCOPE)
    set("${ARGS_PACKAGES_VARIABLE}" "${${ARGS_PACKAGES_VARIABLE}};${CPP_UTILITIES_PACKAGE}" PARENT_SCOPE)

    if (ARGS_ONLY_HEADERS)
        return ()
    endif ()

    # add required Qt and KF modules
    set(IMPORTED_QT_MODULES
        ${IMPORTED_QT_MODULES}
        ${CPP_UTILITIES_PUBLIC_QT_MODULES}
        ${CPP_UTILITIES_PRIVATE_QT_MODULES}
        PARENT_SCOPE
    )
    set(IMPORTED_KF_MODULES
        ${IMPORTED_KF_MODULES}
        ${CPP_UTILITIES_PUBLIC_KF_MODULES}
        ${CPP_UTILITIES_PRIVATE_KF_MODULES}
        PARENT_SCOPE
    )

    # add required translations to APP_SPECIFIC_QT_TRANSLATION_FILES_ARRAY
    if(CPP_UTILITIES_HAS_QT_TRANSLATION_FILES)
        set(APP_SPECIFIC_QT_TRANSLATION_FILES "${APP_SPECIFIC_QT_TRANSLATION_FILES};c++utilities" PARENT_SCOPE)
    endif()

    # add Qt resources if it is a static library
    if (NOT CPP_UTILITIES_LIB_IS_SHARED)
        set(STATIC_LIBRARIES_QT_RESOURCES "${STATIC_LIBRARIES_QT_RESOURCES};${CPP_UTILITIES_QT_RESOURCES}" PARENT_SCOPE)
    endif()
endfunction()

# restore policies
cmake_policy(POP)
