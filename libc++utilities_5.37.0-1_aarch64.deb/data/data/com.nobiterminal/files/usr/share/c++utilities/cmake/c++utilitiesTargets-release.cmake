#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "c++utilities" for configuration "Release"
set_property(TARGET c++utilities APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(c++utilities PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "Boost::iostreams"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libc++utilities.so"
  IMPORTED_SONAME_RELEASE "libc++utilities.so"
  )

list(APPEND _cmake_import_check_targets c++utilities )
list(APPEND _cmake_import_check_files_for_c++utilities "/data/data/com.nobiterminal/files/usr/lib/libc++utilities.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
